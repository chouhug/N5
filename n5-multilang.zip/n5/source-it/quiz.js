/* 出題邏輯：冠詞與介係詞題、動詞變化題、意思題、發音練習資料 */
(function (G) {
  'use strict';
  const IT = G.IT || (G.IT = {});
  const ARTS = ['il', 'lo', "l'", 'la', 'i', 'gli', 'le'];
  const INDEF = ['un', 'uno', 'una', "un'"];

  function shuffle(a, rnd) { rnd = rnd || Math.random; a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
  function pick(a, rnd) { return a[Math.floor((rnd || Math.random)() * a.length)]; }
  IT.shuffle = shuffle; IT.pick = pick;

  const posOfLemma = () => IT._posOf || (IT._posOf = Object.fromEntries(IT.W.map(e => [e[0], e[1]])));
  const entryOf = () => IT._entryOf || (IT._entryOf = Object.fromEntries(IT.W.filter(e => e[1] === 'n' || e[1] === 'adj').map(e => [e[0] + '|' + e[1], e])));

  // 依下一個字，算出所有「文法上可以」的定冠詞
  function validArticles(next, LOOK) {
    const infos = LOOK.get(next) || [];
    const P = posOfLemma(), E = entryOf();
    const out = new Set();
    let known = false;
    for (const x of infos) {
      const pos = P[x.lemma];
      if (pos === 'n') {
        const e = E[x.lemma + '|n']; if (!e || / /.test(e[0])) continue;
        const g = e[2];
        const plG = IT.PL_GENDER[e[0]] || g;
        if (IT.PL_ONLY.has(e[0])) { out.add(IT.defArt(next, g, true)); known = true; continue; }
        if (x.desc === '單數' || x.desc === '單複數同形') { out.add(IT.defArt(next, g, false)); known = true; }
        if (x.desc === '複數' || x.desc === '單複數同形') { out.add(IT.defArt(next, plG, true)); known = true; }
      } else if (pos === 'adj') {
        const m = { '陽性單數': ['m', false], '陰性單數': ['f', false], '陽性複數': ['m', true], '陰性複數': ['f', true] }[x.desc];
        if (!m) continue;
        out.add(IT.defArt(next, m[0], m[1])); known = true;
      } else if (pos) {
        return null; // 後面是限定詞、數字等，先不出題
      }
    }
    return known ? out : null;
  }

  // 從單字的例句挖出冠詞或介係詞合併形
  function makeArtQuestion(entry, LOOK, rnd) {
    rnd = rnd || Math.random;
    const sent = entry[6];
    const T = []; let pos = 0;
    for (const t of IT.tokenize(sent)) { T.push({ t: t.t, w: t.w, s: pos, k: IT.norm(t.t).toLowerCase() }); pos += t.t.length; }
    const cands = [];
    T.forEach((t, i) => {
      if (!t.w) return;
      const nx = T.slice(i + 1).find(x => x.w);
      if (!nx) return;
      // 撇號形必須緊接下一個字
      if (ARTS.includes(t.k) || INDEF.includes(t.k) || IT.ART_PREPS[t.k]) {
        // 「lo、la、le、gli」當代名詞時跳過：後面是動詞
        const V = validArticles(nx.k, LOOK);
        if (!V) return;
        if (ARTS.includes(t.k)) {
          if (!V.has(t.k)) return; // 可能是代名詞
          cands.push({ i, kind: 'art', valid: [...V] });
        } else if (INDEF.includes(t.k)) {
          const sing = [...V].filter(a => ['il', 'lo', "l'", 'la'].includes(a));
          if (!sing.length) return;
          const valid = new Set();
          (LOOK.get(nx.k) || []).forEach(x => {
            const pos2 = posOfLemma()[x.lemma];
            if (pos2 === 'n' && (x.desc === '單數' || x.desc === '單複數同形')) { const e = entryOf()[x.lemma + '|n']; if (e) valid.add(IT.indefArt(nx.k, e[2])); }
            if (pos2 === 'adj') { const m = { '陽性單數': 'm', '陰性單數': 'f' }[x.desc]; if (m) valid.add(IT.indefArt(nx.k, m)); }
          });
          if (!valid.has(t.k)) return;
          cands.push({ i, kind: 'indef', valid: [...valid] });
        } else {
          const ap = IT.ART_PREPS[t.k];
          if (!V.has(ap.art)) return;
          cands.push({ i, kind: 'artprep', prep: ap.prep, valid: [...V].map(a => IT.artPrep(ap.prep, a)) });
        }
      }
    });
    if (!cands.length) return null;
    // 優先挑合併形，其次冠詞
    cands.sort((a, b) => (a.kind === 'artprep' ? 0 : 1) - (b.kind === 'artprep' ? 0 : 1));
    const c = rnd() < 0.6 ? cands[0] : pick(cands, rnd);
    const tok = T[c.i];
    const answer = tok.t.toLowerCase();
    let pool;
    if (c.kind === 'art') pool = ARTS;
    else if (c.kind === 'indef') pool = INDEF;
    else pool = ARTS.map(a => IT.artPrep(c.prep, a));
    const wrong = shuffle(pool.filter(x => !c.valid.includes(x)), rnd);
    // 讓干擾選項看起來接近：同字首、同性別的優先
    const options = shuffle([answer].concat(wrong.slice(0, 3)), rnd);
    const cap = c.i === T.findIndex(x => x.w);
    return {
      kind: c.kind, answer, options, valid: c.valid, cap,
      before: sent.slice(0, tok.s), after: sent.slice(tok.s + tok.t.length),
      sentence: sent, zh: entry[7], word: entry
    };
  }
  function artWrong(q, opt) { return !q.valid.includes(opt); }
  IT.makeArtQuestion = makeArtQuestion; IT.artWrong = artWrong; IT.validArticles = validArticles;

  // 簡單介係詞：人工挑選、確定只有一個答案的句子
  IT.PREP_DRILLS = [
    ['Vado ___ Roma.', 'a', ['in', 'su', 'con'], '我要去羅馬。'],
    ['Abito ___ Italia.', 'in', ['a', 'di', 'su'], '我住在義大利。'],
    ['Sono ___ Taipei.', 'di', ['in', 'su', 'per'], '我來自台北。'],
    ['Vengo ___ Milano.', 'da', ['in', 'su', 'per'], '我從米蘭來。'],
    ['Esco ___ gli amici.', 'con', ['su', 'di', 'da'], '我和朋友出去。'],
    ['Questo regalo è ___ te.', 'per', ['su', 'di', 'in'], '這個禮物是給你的。'],
    ['Parto ___ due giorni.', 'tra', ['su', 'di', 'con'], '我兩天後出發。'],
    ['Vado a Firenze ___ treno.', 'in', ['su', 'di', 'per'], '我搭火車去佛羅倫斯。'],
    ['Vado a scuola ___ piedi.', 'a', ['in', 'su', 'con'], '我走路去學校。'],
    ['Il libro ___ Marco è nuovo.', 'di', ['a', 'su', 'in'], '馬可的書是新的。'],
    ['Torno ___ casa alle sei.', 'a', ['di', 'su', 'con'], '我六點回家。'],
    ['Studio italiano ___ un anno.', 'da', ['su', 'con', 'a'], '我學義大利文一年了。'],
    ['Ho bisogno ___ aiuto.', 'di', ['su', 'in', 'con'], '我需要幫忙。'],
    ['Lavoro ___ un ufficio.', 'in', ['su', 'di', 'per'], '我在辦公室工作。'],
    ['Pago ___ la carta.', 'con', ['su', 'di', 'da'], '我用卡付款。'],
    ['Vado ___ vacanza in agosto.', 'in', ['su', 'di', 'con'], '我八月去度假。'],
    ['Il treno ___ Roma parte alle otto.', 'per', ['su', 'con', 'in'], '開往羅馬的火車八點出發。'],
    ['Abitiamo ___ Napoli.', 'a', ['in', 'su', 'per'], '我們住在拿坡里。'],
    ['Mangio la pasta ___ pranzo.', 'a', ['su', 'con', 'di'], '我午餐吃義大利麵。'],
    ['Una camera ___ vista sul mare.', 'con', ['su', 'in', 'a'], '一間海景房。'],
    ['Un biglietto ___ Venezia, per favore.', 'per', ['su', 'con', 'in'], '請給我一張到威尼斯的票。'],
    ['Faccio un corso ___ italiano.', 'di', ['su', 'a', 'in'], '我在上義大利文課。'],
    ['Ci vediamo ___ una settimana.', 'tra', ['su', 'con', 'di'], '我們一週後見。'],
    ['Andiamo ___ montagna.', 'in', ['su', 'di', 'per'], '我們去山上。']
  ];

  // 主詞通常只有第三人稱的動詞
  const IMPERSONAL = { piovere: [2], nevicare: [2], succedere: [2, 5], durare: [2, 5], costare: [2, 5], funzionare: [2, 5], servire: [2, 5], mancare: [2, 5], piacere: [2, 5], significare: [2, 5], sembrare: [0, 1, 2, 3, 4, 5] };
  IT.IMPERSONAL = IMPERSONAL;
  // 動詞變化題
  function makeVerbQuestion(entry, rnd) {
    rnd = rnd || Math.random;
    const c = IT.conjugate(entry[0], entry[1]);
    const usePast = rnd() < 0.25;
    const allowed = IMPERSONAL[entry[0]] || [0, 1, 2, 3, 4, 5];
    const i = allowed[Math.floor(rnd() * allowed.length)];
    const subj = ['io', 'tu', 'lui', 'noi', 'voi', 'loro'][i];
    const subjShow = ['io', 'tu', rnd() < 0.5 ? 'lui' : 'lei', 'noi', 'voi', 'loro'][i];
    let answer, forms;
    if (usePast && !c.refl) {
      const aux = c.aux === 'e' ? IT.IRR.essere.p.split(' ') : IT.IRR.avere.p.split(' ');
      const ppFor = k => c.aux === 'e' ? (k < 3 ? (subjShow === 'lei' && k === 2 ? c.ppForms.fs : c.ppForms.ms) : c.ppForms.mp) : c.pp;
      answer = aux[i] + ' ' + ppFor(i);
      forms = [0, 1, 2, 3, 4, 5].map(k => aux[k] + ' ' + ppFor(k));
      const otherAux = (c.aux === 'e' ? IT.IRR.avere.p : IT.IRR.essere.p).split(' ')[i] + ' ' + c.pp;
      forms.push(otherAux);
    } else {
      answer = c.presentFull[i];
      forms = c.presentFull.slice();
    }
    const wrong = shuffle([...new Set(forms)].filter(f => f !== answer), rnd);
    // 動詞形相同（例如 essere 的 io／loro 都是 sono）時不會混入正確答案
    const options = shuffle([answer].concat(wrong.slice(0, 3)), rnd);
    return { kind: 'verb', tense: usePast && !c.refl ? 'passato' : 'presente', subj: subjShow, person: i, answer, options, word: entry, conj: c };
  }
  IT.makeVerbQuestion = makeVerbQuestion;

  /* ---------- 發音 ---------- */
  IT.ALPHABET = [
    ['A', 'a', '[a]', '像「啊」，嘴巴張大', 'amico'],
    ['B', 'bi', '[b]', '像「ㄅ」但聲帶要震動', 'bambino'],
    ['C', 'ci', '[k]／[tʃ]', 'a、o、u 前是「ㄎ」；e、i 前是「七」的子音', 'casa'],
    ['D', 'di', '[d]', '像「ㄉ」但聲帶要震動，舌尖碰上排牙齒', 'donna'],
    ['E', 'e', '[e]／[ɛ]', '像「ㄝ」，有開口與閉口兩種', 'estate'],
    ['F', 'effe', '[f]', '像「ㄈ」', 'fratello'],
    ['G', 'gi', '[g]／[dʒ]', 'a、o、u 前是「ㄍ」（濁音）；e、i 前像「機」的子音（濁音）', 'gelato'],
    ['H', 'acca', '不發音', '永遠不發音，只用來讓 c、g 變硬音（che、ghi）', 'ho'],
    ['I', 'i', '[i]', '像「一」', 'isola'],
    ['L', 'elle', '[l]', '像「ㄌ」，舌尖清楚', 'libro'],
    ['M', 'emme', '[m]', '像「ㄇ」', 'mamma'],
    ['N', 'enne', '[n]', '像「ㄋ」', 'naso'],
    ['O', 'o', '[o]／[ɔ]', '像「喔」，有開口與閉口兩種', 'otto'],
    ['P', 'pi', '[p]', '像「ㄅ」，不送氣', 'pane'],
    ['Q', 'cu', '[k]', '一定和 u 一起出現：qu 唸「ㄎㄨ」', 'quando'],
    ['R', 'erre', '[r]', '舌尖彈舌（打舌）', 'Roma'],
    ['S', 'esse', '[s]／[z]', '大多像「ㄙ」；兩個母音之間常唸成濁音 [z]', 'sole'],
    ['T', 'ti', '[t]', '像「ㄉ」，不送氣', 'treno'],
    ['U', 'u', '[u]', '像「烏」', 'uva'],
    ['V', 'vu', '[v]', '上排牙齒輕碰下唇，聲帶震動', 'vino'],
    ['Z', 'zeta', '[ts]／[dz]', '像「ㄘ」或「ㄗ」的濁音', 'pizza'],
    ['J', 'i lunga', '[j]', '外來字母，多半出現在外來語', 'jeans'],
    ['K', 'cappa', '[k]', '外來字母', 'karate'],
    ['W', 'doppia vu', '[w]／[v]', '外來字母', 'weekend'],
    ['X', 'ics', '[ks]', '外來字母', 'taxi'],
    ['Y', 'ipsilon', '[i]', '外來字母（也叫 i greca）', 'yogurt']
  ];

  IT.PRON_RULES = [
    { t: 'c 的兩種唸法', d: 'c 在 a、o、u 前面是硬音 [k]（像「ㄎ」）；在 e、i 前面是軟音 [tʃ]（像「七」的子音）。', ex: [['casa', '[k]'], ['cosa', '[k]'], ['cena', '[tʃ]'], ['ciao', '[tʃ]'], ['cinema', '[tʃ]']] },
    { t: 'g 的兩種唸法', d: 'g 在 a、o、u 前面是硬音 [g]；在 e、i 前面是軟音 [dʒ]（像「機」的子音，但聲帶震動）。', ex: [['gatto', '[g]'], ['gonna', '[g]'], ['gelato', '[dʒ]'], ['giorno', '[dʒ]'], ['gente', '[dʒ]']] },
    { t: 'ch、gh 一定是硬音', d: '想在 e、i 前面保留硬音，就加 h：che [ke]、chi [ki]、ghi [gi]。h 本身不發音。', ex: [['che', '[ke]'], ['chiave', '[kja]'], ['perché', '[ke]'], ['spaghetti', '[ge]']] },
    { t: 'ci、gi + a／o／u：i 不唸', d: 'ciao、giallo、giorno 裡的 i 只是讓 c、g 變軟，本身幾乎不發音：ciao 唸 [tʃao]。', ex: [['ciao', '[tʃa]'], ['giallo', '[dʒa]'], ['giorno', '[dʒo]'], ['arancia', '[tʃa]']] },
    { t: 'gn 像「ㄋㄧ」', d: 'gn 是一個音 [ɲ]，像「ㄋㄧ」連在一起：bagno 唸起來像「巴ㄋㄧㄛ」。', ex: [['bagno', '[ɲ]'], ['giugno', '[ɲ]'], ['lasagne', '[ɲ]']] },
    { t: 'gli 像「ㄌㄧ」', d: 'gli 是一個音 [ʎ]：舌面貼上顎發「ㄌㄧ」，不唸 g。', ex: [['figlio', '[ʎ]'], ['famiglia', '[ʎ]'], ['gli', '[ʎi]'], ['moglie', '[ʎ]']] },
    { t: 'sc + e／i 像「噓」', d: 'sce、sci 唸 [ʃ]（像英文 sh）；sca、sco、scu、sche、schi 唸 [sk]。', ex: [['pesce', '[ʃ]'], ['sciarpa', '[ʃ]'], ['scuola', '[sk]'], ['schiena', '[sk]']] },
    { t: '雙子音要停頓', d: '兩個一樣的子音要唸得比較長、前面稍微停一下，意思會不同：pala（鏟子）／palla（球）。', ex: [['pala', '單'], ['palla', '雙'], ['sete', '單'], ['sette', '雙'], ['nono', '單'], ['nonno', '雙']] },
    { t: 'qu 唸「ㄎㄨ」', d: 'q 後面一定是 u，qu 唸 [kw]：quando、questo、acqua（cq 也是雙子音）。', ex: [['quando', '[kw]'], ['questo', '[kw]'], ['acqua', '[kkw]']] },
    { t: 'r 要彈舌', d: '舌尖輕彈上齒齦；rr 要彈好幾下：caro／carro。', ex: [['Roma', '[r]'], ['treno', '[r]'], ['carro', '[rr]']] },
    { t: 's 與 z', d: 's 大多是 [s]，在兩個母音中間常唸濁音 [z]（rosa）。z 唸 [ts] 或 [dz]：pizza [tts]、zero [dz]。', ex: [['sole', '[s]'], ['rosa', '[z]'], ['pizza', '[tts]'], ['zero', '[dz]']] },
    { t: '重音的位置', d: '大部分單字重音在<b>倒數第二個音節</b>：ca-sa、ra-gaz-zo。重音在最後一個音節時一定要寫出來：città、caffè、perché、lunedì、più。è（開口音）和 é（閉口音）不同：caffè、perché。', ex: [['città', 'à'], ['caffè', 'è'], ['perché', 'é'], ['lunedì', 'ì'], ['più', 'ù'], ['però', 'ò']] }
  ];

  // 聽音選拼字（容易混淆的成對字）
  IT.LISTEN_PAIRS = [
    ['ci', 'chi'], ['ce', 'che'], ['Cina', 'china'], ['giro', 'ghiro'], ['gi', 'ghi'], ['ge', 'ghe'],
    ['pesce', 'pesche'], ['sci', 'si'], ['figli', 'fili'], ['agli', 'ali'], ['cena', 'chena'], ['gelo', 'ghelo'],
    ['pala', 'palla'], ['caro', 'carro'], ['sete', 'sette'], ['nono', 'nonno'], ['papa', 'pappa'], ['capello', 'cappello'],
    ['sono', 'sonno'], ['casa', 'cassa'], ['fato', 'fatto'], ['rosa', 'rossa'], ['pena', 'penna'], ['eco', 'ecco'],
    ['ciao', 'chiao'], ['giallo', 'gallo'], ['bagno', 'banno'], ['scena', 'schena'], ['pace', 'pache'], ['luce', 'luche']
  ];

  // 看拼字選讀法
  const S = {
    k: '[k] 像「ㄎ」', tS: '[tʃ] 像「七」的子音', g: '[g] 像「ㄍ」', dZ: '[dʒ] 像「機」的子音（濁音）', S: '[ʃ] 像「噓」',
    sk: '[sk] 像「ㄙㄎ」', n: '[ɲ] 像「ㄋㄧ」', l: '[ʎ] 像「ㄌㄧ」', gn: '[gn] g 和 n 分開唸', gl: '[gl] g 和 l 分開唸',
    dbl: '唸長一點、前面停頓（雙子音）', sgl: '一般長度（單子音）', mute: '不發音', h: '[h] 像「ㄏ」', kw: '[kw] 像「ㄎㄨ」', z: '[z]（濁音，像英文 z）', s: '[s] 像「ㄙ」'
  };
  IT.READ_ITEMS = [
    ['cena', 'c', 'tS', ['k', 'S', 's']], ['casa', 'c', 'k', ['tS', 'S', 's']], ['cinema', 'c', 'tS', ['k', 'sk', 's']], ['cuore', 'c', 'k', ['tS', 'kw', 'S']],
    ['che', 'ch', 'k', ['tS', 'S', 'h']], ['chiave', 'ch', 'k', ['tS', 'S', 'h']], ['ciao', 'ci', 'tS', ['k', 'S', 'sk']],
    ['gelato', 'g', 'dZ', ['g', 'l', 'n']], ['gatto', 'g', 'g', ['dZ', 'n', 'l']], ['giorno', 'gi', 'dZ', ['g', 'l', 'n']], ['gonna', 'g', 'g', ['dZ', 'n', 'l']],
    ['spaghetti', 'gh', 'g', ['dZ', 'h', 'l']], ['funghi', 'gh', 'g', ['dZ', 'h', 'n']],
    ['bagno', 'gn', 'n', ['gn', 'l', 'g']], ['giugno', 'gn', 'n', ['gn', 'l', 'dZ']], ['figlio', 'gli', 'l', ['gl', 'n', 'dZ']], ['famiglia', 'gli', 'l', ['gl', 'n', 'g']],
    ['pesce', 'sc', 'S', ['sk', 'tS', 'k']], ['scuola', 'sc', 'sk', ['S', 'tS', 's']], ['sciarpa', 'sc', 'S', ['sk', 'tS', 's']], ['schiena', 'sch', 'sk', ['S', 'tS', 'h']],
    ['palla', 'll', 'dbl', ['sgl']], ['pala', 'l', 'sgl', ['dbl']], ['sette', 'tt', 'dbl', ['sgl']], ['sete', 't', 'sgl', ['dbl']], ['nonno', 'nn', 'dbl', ['sgl']], ['mamma', 'mm', 'dbl', ['sgl']],
    ['ho', 'h', 'mute', ['h', 'k', 'g']], ['hotel', 'h', 'mute', ['h', 'k', 's']], ['quando', 'qu', 'kw', ['k', 'g', 'tS']], ['rosa', 's', 'z', ['s', 'S', 'tS']], ['sole', 's', 's', ['z', 'S', 'tS']]
  ].map(([w, part, ans, wr]) => ({ w, part, ans: S[ans], opts: [S[ans]].concat(wr.map(k => S[k])) }));
})(typeof window !== 'undefined' ? window : globalThis);
