/* 建置義大利文頁：node build.js <App 根目錄>
   - 從根目錄的 index.html（日文頁）抽出樣式和 Firebase 設定，讓兩頁外觀、帳號完全一樣
   - 輸出 <根目錄>/it/index.html */
'use strict';
const fs = require('fs');
const path = require('path');
const ROOT = path.resolve(process.argv[2] || '../n5work');
const S = p => fs.readFileSync(path.join(__dirname, p), 'utf8');
const ja = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');

const sm = ja.match(/<style>\s*(\/\* 版面[\s\S]*?)<\/style>/);
if (!sm) throw new Error('在日文頁找不到主要樣式');
const fm = ja.match(/window\.N5_FIREBASE=\{[^}]*\};/);
if (!fm) throw new Error('在日文頁找不到 Firebase 設定');

// 托斯卡尼山丘背景：和日文頁的富士山同一組顏色、同一種畫法
function pat(c) {
  const cy = (x, base, h, w) => `<path d='M${x} ${base} q${w * .5} ${-h * .55} ${w * .5} ${-h} q0 ${h * .45} ${w * .5} ${h}z' fill='${c.cyp}'/>`;
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 420 900' preserveAspectRatio='xMidYMax slice'>` +
    `<circle cx='330' cy='150' r='46' fill='${c.sun}'/>` +
    `<rect x='40' y='120' width='90' height='12' rx='6' fill='${c.cloud}'/><rect x='70' y='140' width='60' height='12' rx='6' fill='${c.cloud}'/>` +
    `<rect x='250' y='250' width='110' height='12' rx='6' fill='${c.cloud}'/><rect x='290' y='270' width='70' height='12' rx='6' fill='${c.cloud}'/>` +
    `<path d='M80 210 q6 -6 12 0 q6 -6 12 0' fill='none' stroke='${c.bird}' stroke-width='2' stroke-linecap='round'/><path d='M110 232 q6 -6 12 0 q6 -6 12 0' fill='none' stroke='${c.bird}' stroke-width='2' stroke-linecap='round'/>` +
    // 遠方山丘與小鎮（塔樓、屋頂）
    `<path d='M-10 640 C 60 585 130 585 200 610 C 260 630 320 580 430 600 L430 910 L-10 910Z' fill='${c.h1}'/>` +
    `<g fill='${c.town}'><rect x='238' y='548' width='9' height='44'/><path d='M236 548 l6.5 -10 l6.5 10z'/><rect x='252' y='572' width='18' height='22'/><rect x='272' y='566' width='14' height='28'/><rect x='288' y='576' width='20' height='18'/><rect x='218' y='578' width='16' height='16'/><path d='M200 594 a16 16 0 0 1 32 0z'/></g>` +
    `<g fill='${c.roof}'><path d='M251 572 l10 -7 l10 7z'/><path d='M271 566 l8 -6 l8 6z'/><path d='M287 576 l11 -6 l11 6z'/><path d='M217 578 l9 -6 l9 6z'/></g>` +
    `<path d='M-10 720 C 70 670 150 690 220 705 C 290 720 350 670 430 685 L430 910 L-10 910Z' fill='${c.h2}'/>` +
    cy(40, 706, 64, 16) + cy(62, 708, 46, 13) + cy(338, 690, 70, 16) + cy(360, 694, 50, 13) +
    `<path d='M-10 800 C 60 760 150 770 230 785 C 320 802 370 760 430 768 L430 910 L-10 910Z' fill='${c.h3}'/>` +
    cy(286, 790, 80, 18) + cy(310, 792, 58, 15) + cy(330, 794, 40, 12) +
    `<path d='M150 900 C 175 870, 230 860, 222 835 S 255 800, 300 790 L 308 795 C 270 806, 240 820, 245 840 S 200 875, 190 900 Z' fill='${c.road}'/>` +
    `</svg>`;
  return 'url("data:image/svg+xml,' + svg.replace(/#/g, '%23').replace(/</g, '%3C').replace(/>/g, '%3E') + '")';
}
const light = pat({ sun: '#f7e6cc', cloud: '#e6ebf3', bird: '#cdd5e2', h1: '#e6ebf3', h2: '#d8e0ec', h3: '#cfd8e6', cyp: '#c3cede', town: '#dde4ef', roof: '#d3dbe8', road: '#eef3fa' });
const dark = pat({ sun: '#252d3a', cloud: '#161c26', bird: '#2a3342', h1: '#141a23', h2: '#18202b', h3: '#1c2531', cyp: '#111720', town: '#1a212c', roof: '#202836', road: '#10151d' });
const patCss = `:root{--pat:${light}}\n@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--pat:${dark}}}\n:root[data-theme="dark"]{--pat:${dark}}`;

const scripts = ['engine.js', 'data1.js', 'data2.js', 'data3.js', 'data4.js', 'data5.js', 'grammar.js', 'quiz.js', 'it-app.js'].map(S).join('\n;\n');
const html = S('it-template.html')
  .replace('/*FIREBASE*/', () => fm[0])
  .replace('/*N5STYLE*/', () => sm[1])
  .replace('/*ITSTYLE*/', () => S('it-style.css'))
  .replace('/*PAT*/', () => patCss)
  .replace('/*SCRIPTS*/', () => scripts.replace(/<\/script/gi, '<\\/script'));
fs.mkdirSync(path.join(ROOT, 'it'), { recursive: true });
fs.writeFileSync(path.join(ROOT, 'it', 'index.html'), html);
console.log('it/index.html', (html.length / 1024).toFixed(0) + ' KB');
