# 義大利文頁的原始檔

`it/index.html` 是用這個資料夾建置出來的，平常不用動。

- `engine.js`：冠詞、名詞複數、形容詞、動詞變化
- `data1.js`～`data5.js`：867 個 A1 單字與例句
- `grammar.js`：43 個文法點與 8 頁詞性變化規則
- `quiz.js`：冠詞與介係詞題、動詞變化題、發音練習
- `it-app.js`、`it-style.css`、`it-template.html`：義大利文頁的介面

改完之後重新建置（需要 Node.js）：

```
cd source-it
node tests/run.js      # 資料測試
node build.js ..       # 產生 ../it/index.html（樣式和 Firebase 設定會從 ../index.html 抽出來）
```
