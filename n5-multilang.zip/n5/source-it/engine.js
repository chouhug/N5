/* 義大利文變化引擎：冠詞、名詞複數、形容詞配合、動詞變化、斷詞與查詢 */
(function (G) {
  'use strict';
  const IT = G.IT || (G.IT = {});

  const PERSONS = ['io', 'tu', 'lui/lei', 'noi', 'voi', 'loro'];
  const PERSONS_ZH = ['我', '你', '他／她／您', '我們', '你們', '他們'];
  const REFL = ['mi', 'ti', 'si', 'ci', 'vi', 'si'];
  IT.PERSONS = PERSONS; IT.PERSONS_ZH = PERSONS_ZH;

  /* ---------- 冠詞 ---------- */
  // 回傳開頭類型：'lo'（s+子音、z、gn、ps、pn、x、y）、'v'（母音或 h）、'il'（其他）
  function initialType(word) {
    const w = String(word).toLowerCase();
    if (/^(s[bcdfghjklmnpqrstvwxz]|z|gn|ps|pn|x|y)/.test(w)) return 'lo';
    if (/^[aeiouàèéìíòóùúh]/.test(w)) return 'v';
    return 'il';
  }
  function defArt(word, g, plural) {
    const t = initialType(word);
    if (g === 'f') return plural ? 'le' : (t === 'v' ? "l'" : 'la');
    if (plural) return t === 'il' ? 'i' : 'gli';
    return t === 'il' ? 'il' : t === 'lo' ? 'lo' : "l'";
  }
  function indefArt(word, g) {
    const t = initialType(word);
    if (g === 'f') return t === 'v' ? "un'" : 'una';
    return t === 'lo' ? 'uno' : 'un';
  }
  function withArt(word, g, plural) {
    const a = defArt(word, g, plural);
    return a.endsWith("'") ? a + word : a + ' ' + word;
  }
  // 複數變陰性的名詞（il braccio → le braccia）與只用複數的名詞
  const PL_GENDER = { orecchio: 'f', uovo: 'f', braccio: 'f', dito: 'f', paio: 'f' };
  const PL_ONLY = new Set(['capelli', 'pantaloni', 'occhiali', 'soldi', 'contanti']);
  function nounForms(e) {
    const [w, , g, pl] = e;
    const sg = PL_ONLY.has(w) ? withArt(w, g, true) : withArt(w, g, false);
    const plural = (!pl || pl === '-') ? '' : withArt(pl, PL_GENDER[w] || g, true);
    return { sg, pl: PL_ONLY.has(w) ? '' : plural, plOnly: PL_ONLY.has(w), plGender: PL_GENDER[w] || g, indef: PL_ONLY.has(w) ? '' : indefArt(w, g) };
  }
  IT.nounForms = nounForms; IT.PL_GENDER = PL_GENDER; IT.PL_ONLY = PL_ONLY;
  IT.initialType = initialType; IT.defArt = defArt; IT.indefArt = indefArt; IT.withArt = withArt;

  /* ---------- 介係詞＋冠詞 ---------- */
  const PREP_BASE = { di: 'de', a: 'a', da: 'da', in: 'ne', su: 'su' };
  const ART_TAIL = { il: 'l', lo: 'llo', "l'": "ll'", la: 'lla', i: 'i', gli: 'gli', le: 'lle' };
  const ARTICLES = ['il', 'lo', "l'", 'la', 'i', 'gli', 'le'];
  const ART_INFO = {
    il: '陽性單數', lo: '陽性單數（s+子音、z、gn、ps、y 前）', "l'": '單數（母音前）', la: '陰性單數',
    i: '陽性複數', gli: '陽性複數（母音、s+子音、z 前）', le: '陰性複數'
  };
  function artPrep(prep, art) { return PREP_BASE[prep] + ART_TAIL[art]; }
  const ART_PREPS = {};
  for (const p of Object.keys(PREP_BASE)) for (const a of ARTICLES) ART_PREPS[artPrep(p, a)] = { prep: p, art: a };
  IT.ARTICLES = ARTICLES; IT.ART_INFO = ART_INFO; IT.ART_PREPS = ART_PREPS; IT.artPrep = artPrep;
  IT.SIMPLE_PREPS = ['di', 'a', 'da', 'in', 'con', 'su', 'per', 'tra', 'fra'];

  /* ---------- 名詞複數（規則預測，用於檢查資料） ---------- */
  function predictPlurals(w, g) {
    const s = new Set();
    if (/[àèéìòóù]$/.test(w) || /[^aeiou]$/.test(w) || /i$/.test(w)) { s.add(w); return s; }
    if (/ie$/.test(w)) { s.add(w); return s; }
    if (/cia$|gia$/.test(w)) {
      const pre = w[w.length - 4];
      if (/[aeiou]/.test(pre)) s.add(w.slice(0, -1) + 'e'); else s.add(w.slice(0, -2) + 'e');
      return s;
    }
    if (/(c|g)a$/.test(w)) { s.add(g === 'f' ? w.slice(0, -1) + 'he' : w.slice(0, -1) + 'hi'); return s; }
    if (/(c|g)o$/.test(w)) { s.add(w.slice(0, -1) + 'hi'); s.add(w.slice(0, -1) + 'i'); return s; }
    if (/io$/.test(w)) { s.add(w.slice(0, -1)); s.add(w.slice(0, -1) + 'i'); return s; }
    if (/a$/.test(w)) { s.add(g === 'f' ? w.slice(0, -1) + 'e' : w.slice(0, -1) + 'i'); return s; }
    if (/[oe]$/.test(w)) { s.add(w.slice(0, -1) + 'i'); return s; }
    return s;
  }
  IT.predictPlurals = predictPlurals;

  /* ---------- 形容詞 ---------- */
  // 傳回 [陽單, 陰單, 陽複, 陰複]
  function adjForms(entry) {
    const w = entry[0];
    if (entry[3] && entry[3] !== '-') {
      const p = entry[3].split('/');
      if (p.length === 3) return [w, p[0], p[1], p[2]];
    }
    if (/o$/.test(w)) return [w, w.slice(0, -1) + 'a', w.slice(0, -1) + 'i', w.slice(0, -1) + 'e'];
    if (/e$/.test(w)) return [w, w, w.slice(0, -1) + 'i', w.slice(0, -1) + 'i'];
    return [w, w, w, w];
  }
  function predictAdj(w) {
    if (/co$/.test(w)) return [[w.slice(0, -1) + 'a', w.slice(0, -1) + 'hi', w.slice(0, -1) + 'he'], [w.slice(0, -1) + 'a', w.slice(0, -1) + 'i', w.slice(0, -1) + 'he']];
    if (/go$/.test(w)) return [[w.slice(0, -1) + 'a', w.slice(0, -1) + 'hi', w.slice(0, -1) + 'he']];
    if (/cio$|gio$/.test(w)) return [[w.slice(0, -1) + 'a', w.slice(0, -2) + 'i', w.slice(0, -1) + 'e'], [w.slice(0, -1) + 'a', w.slice(0, -2) + 'i', w.slice(0, -2) + 'e']];
    if (/io$/.test(w)) return [[w.slice(0, -1) + 'a', w.slice(0, -2) + 'i', w.slice(0, -1) + 'e'], [w.slice(0, -1) + 'a', w.slice(0, -1) + 'i', w.slice(0, -1) + 'e']];
    if (/o$/.test(w)) return [[w.slice(0, -1) + 'a', w.slice(0, -1) + 'i', w.slice(0, -1) + 'e']];
    if (/e$/.test(w)) return [[w, w.slice(0, -1) + 'i', w.slice(0, -1) + 'i']];
    return [[w, w, w]];
  }
  IT.adjForms = adjForms; IT.predictAdj = predictAdj;

  /* ---------- 動詞 ---------- */
  const IRR = {
    essere: { p: 'sono sei è siamo siete sono', pp: 'stato', aux: 'e', imp: 'sii|sia|siamo|siate' },
    avere: { p: 'ho hai ha abbiamo avete hanno', pp: 'avuto', imp: 'abbi|abbia|abbiamo|abbiate' },
    andare: { p: 'vado vai va andiamo andate vanno', pp: 'andato', aux: 'e', imp: "va'/vai|vada|andiamo|andate" },
    fare: { p: 'faccio fai fa facciamo fate fanno', pp: 'fatto', imp: "fa'/fai|faccia|facciamo|fate" },
    dare: { p: 'do dai dà diamo date danno', pp: 'dato', imp: "da'/dai|dia|diamo|date" },
    stare: { p: 'sto stai sta stiamo state stanno', pp: 'stato', aux: 'e', imp: "sta'/stai|stia|stiamo|state" },
    dire: { p: 'dico dici dice diciamo dite dicono', pp: 'detto', imp: "di'|dica|diciamo|dite" },
    venire: { p: 'vengo vieni viene veniamo venite vengono', pp: 'venuto', aux: 'e', imp: 'vieni|venga|veniamo|venite' },
    potere: { p: 'posso puoi può possiamo potete possono', pp: 'potuto', imp: '' },
    volere: { p: 'voglio vuoi vuole vogliamo volete vogliono', pp: 'voluto', imp: '' },
    dovere: { p: 'devo devi deve dobbiamo dovete devono', pp: 'dovuto', imp: '' },
    sapere: { p: 'so sai sa sappiamo sapete sanno', pp: 'saputo', imp: 'sappi|sappia|sappiamo|sappiate' },
    uscire: { p: 'esco esci esce usciamo uscite escono', pp: 'uscito', aux: 'e', imp: 'esci|esca|usciamo|uscite' },
    bere: { p: 'bevo bevi beve beviamo bevete bevono', pp: 'bevuto', imp: 'bevi|beva|beviamo|bevete' },
    rimanere: { p: 'rimango rimani rimane rimaniamo rimanete rimangono', pp: 'rimasto', aux: 'e', imp: 'rimani|rimanga|rimaniamo|rimanete' },
    tenere: { p: 'tengo tieni tiene teniamo tenete tengono', pp: 'tenuto', imp: 'tieni|tenga|teniamo|tenete' },
    salire: { p: 'salgo sali sale saliamo salite salgono', pp: 'salito', aux: 'e', imp: 'sali|salga|saliamo|salite' },
    scegliere: { p: 'scelgo scegli sceglie scegliamo scegliete scelgono', pp: 'scelto', imp: 'scegli|scelga|scegliamo|scegliete' },
    piacere: { p: 'piaccio piaci piace piacciamo piacete piacciono', pp: 'piaciuto', aux: 'e', imp: '' },
    sedersi: { p: 'siedo siedi siede sediamo sedete siedono', pp: 'seduto', aux: 'e', imp: 'siediti|si sieda|sediamoci|sedetevi' },
    tradurre: { p: 'traduco traduci traduce traduciamo traducete traducono', pp: 'tradotto', imp: 'traduci|traduca|traduciamo|traducete' },
    spegnere: { p: 'spengo spegni spegne spegniamo spegnete spengono', pp: 'spento', imp: 'spegni|spenga|spegniamo|spegnete' },
    morire: { p: 'muoio muori muore moriamo morite muoiono', pp: 'morto', aux: 'e', imp: 'muori|muoia|moriamo|morite' }
  };
  // 規則動詞的不規則過去分詞與助動詞
  const VMETA = {
    prendere: { pp: 'preso' }, leggere: { pp: 'letto' }, scrivere: { pp: 'scritto' }, mettere: { pp: 'messo' },
    chiudere: { pp: 'chiuso' }, aprire: { pp: 'aperto' }, vedere: { pp: 'visto' }, rispondere: { pp: 'risposto' },
    chiedere: { pp: 'chiesto' }, perdere: { pp: 'perso' }, vivere: { pp: 'vissuto' }, correre: { pp: 'corso' },
    decidere: { pp: 'deciso' }, scendere: { pp: 'sceso', aux: 'e' }, spendere: { pp: 'speso' }, ridere: { pp: 'riso' },
    offrire: { pp: 'offerto' }, nascere: { pp: 'nato', aux: 'e' }, piangere: { pp: 'pianto' }, rompere: { pp: 'rotto' },
    succedere: { pp: 'successo', aux: 'e' }, accendere: { pp: 'acceso' }, vincere: { pp: 'vinto' },
    conoscere: { pp: 'conosciuto' }, cuocere: { pp: 'cotto' }, crescere: { pp: 'cresciuto', aux: 'e' },
    cadere: { aux: 'e' }, mancare: { aux: 'e' }, servire: { aux: 'a', note: '「（某物）被需要」時用 essere：mi è servito' },
    piovere: { aux: 'a', note: '天氣動詞用 essere 或 avere 都可以：è piovuto／ha piovuto' }, nevicare: { aux: 'a', note: '天氣動詞用 essere 或 avere 都可以' }, mettersi: { pp: 'messo' }, prenotare: {}, dipingere: { pp: 'dipinto' }, soffrire: { pp: 'sofferto' },
    // essere 助動詞
    arrivare: { aux: 'e' }, partire: { aux: 'e' }, tornare: { aux: 'e' }, entrare: { aux: 'e' }, restare: { aux: 'e' },
    diventare: { aux: 'e' }, costare: { aux: 'e' }, durare: { aux: 'e' }, sembrare: { aux: 'e' }, ritornare: { aux: 'e' },
    // 兩種都可以（A1 先記主要用法）
    cominciare: { aux: 'a', note: '「開始做某事」用 avere；「（事情）開始」用 essere' },
    finire: { aux: 'a', note: '「做完某事」用 avere；「（事情）結束」用 essere' },
    passare: { aux: 'a', note: '「度過（時間）」用 avere；「經過」用 essere' }
  };
  IT.IRR = IRR; IT.VMETA = VMETA;

  function vClass(type) { return String(type).replace(/^v-?/, ''); }
  function baseOf(lemma) {
    if (/rsi$/.test(lemma)) return lemma.replace(/rsi$/, 're'); // alzarsi → alzare, mettersi → mettere
    return lemma;
  }
  function isRefl(lemma) { return /rsi$/.test(lemma); }

  function regPresent(base, cls) {
    const st = base.slice(0, -3);
    if (cls === 'are') {
      let stI = st;
      if (/[cg]$/.test(st)) stI = st + 'h';
      const iForm = /i$/.test(st) ? st : stI + 'i';
      const iamo = /i$/.test(st) ? st + 'amo' : stI + 'iamo';
      return [st + 'o', iForm, st + 'a', iamo, st + 'ate', st + 'ano'];
    }
    if (cls === 'ere') return [st + 'o', st + 'i', st + 'e', (/i$/.test(st) ? st + 'amo' : st + 'iamo'), st + 'ete', st + 'ono'];
    if (cls === 'isc') return [st + 'isco', st + 'isci', st + 'isce', st + 'iamo', st + 'ite', st + 'iscono'];
    return [st + 'o', st + 'i', st + 'e', st + 'iamo', st + 'ite', st + 'ono']; // ire
  }
  function regPP(base, cls) {
    const st = base.slice(0, -3);
    if (cls === 'are') return st + 'ato';
    if (cls === 'ere') return st + 'uto';
    return st + 'ito';
  }
  function regImp(base, cls) {
    const st = base.slice(0, -3);
    const pres = regPresent(base, cls);
    if (cls === 'are') {
      const lei = /i$/.test(st) ? st : (/[cg]$/.test(st) ? st + 'hi' : st + 'i');
      return [st + 'a', lei, pres[3], st + 'ate'];
    }
    if (cls === 'ere') return [st + 'i', st + 'a', pres[3], st + 'ete'];
    if (cls === 'isc') return [st + 'isci', st + 'isca', pres[3], st + 'ite'];
    return [st + 'i', st + 'a', pres[3], st + 'ite'];
  }
  // 反身動詞命令式：tu alzati, Lei si alzi, noi alziamoci, voi alzatevi
  function reflImp(imp) {
    return [imp[0] + 'ti', 'si ' + imp[1], imp[2] + 'ci', imp[3] + 'vi'];
  }

  // 主要變化函式
  function conjugate(lemma, type) {
    const cls = vClass(type);
    const refl = isRefl(lemma);
    const base = baseOf(lemma);
    const irr = IRR[lemma] || IRR[base];
    const meta = VMETA[lemma] || VMETA[base] || {};
    let present, pp, imp, aux;
    if (irr && (cls === 'irr' || IRR[lemma])) {
      present = irr.p.split(' ');
      pp = irr.pp;
      aux = irr.aux || 'a';
      imp = irr.imp ? irr.imp.split('|') : null;
    } else {
      const c = cls === 'irr' ? (/are$/.test(base) ? 'are' : /ere$/.test(base) ? 'ere' : 'ire') : cls;
      present = regPresent(base, c);
      pp = meta.pp || regPP(base, c);
      aux = meta.aux || 'a';
      imp = regImp(base, c);
      if (refl) imp = reflImp(imp);
    }
    if (refl) aux = 'e';
    const auxForms = aux === 'e' ? IRR.essere.p.split(' ') : IRR.avere.p.split(' ');
    const ppStem = pp.slice(0, -1);
    const ppForms = { ms: pp, fs: ppStem + 'a', mp: ppStem + 'i', fp: ppStem + 'e' };
    const presentFull = present.map((f, i) => refl ? REFL[i] + ' ' + f : f);
    const passato = auxForms.map((a, i) => {
      const r = refl ? REFL[i] + ' ' : '';
      if (aux === 'e') return r + a + ' ' + (i < 3 ? pp + '/' + ppStem + 'a' : ppStem + 'i/' + ppStem + 'e');
      return a + ' ' + pp;
    });
    return {
      lemma, cls, refl, aux, pp, ppForms, present, presentFull, passato,
      imperative: imp, // [tu, Lei, noi, voi] 或 null
      note: meta.note || ''
    };
  }
  IT.conjugate = conjugate; IT.isRefl = isRefl; IT.baseOf = baseOf;

  // 額外常用形（A1 會用到的條件式等）
  IT.EXTRA_FORMS = {
    vorrei: ['volere', '條件式 io（我想要，禮貌說法）'],
    vorresti: ['volere', '條件式 tu（你想要嗎）'],
    vorrebbe: ['volere', '條件式 lui/lei（他／她／您想要）'],
    vorremmo: ['volere', '條件式 noi（我們想要）'],
    potrei: ['potere', '條件式 io（我可以嗎）'],
    potresti: ['potere', '條件式 tu（你可以…嗎）'],
    potrebbe: ['potere', '條件式 lui/lei（他／她／您可以…嗎）']
  };

  /* ---------- 斷詞 ---------- */
  const LET = "A-Za-zÀ-ÖØ-öø-ÿ";
  const TOK_RE = new RegExp("[" + LET + "]+'|[" + LET + "]+|[^" + LET + "]+", 'g');
  function norm(s) { return String(s).replace(/[’‘]/g, "'"); }
  function tokenize(sentence) {
    const out = [];
    const s = norm(sentence);
    let m; TOK_RE.lastIndex = 0;
    while ((m = TOK_RE.exec(s))) {
      const t = m[0];
      out.push({ t, w: new RegExp('^[' + LET + ']').test(t) });
    }
    return out;
  }
  IT.tokenize = tokenize; IT.norm = norm;

  /* ---------- 查詢表 ---------- */
  // 由單字資料建立「形 → [{lemma, desc, idx}]」
  function buildLookup(words, extra) {
    const map = new Map();
    const add = (form, lemma, desc, idx) => {
      if (!form || form === '-') return;
      const k = norm(form).toLowerCase();
      if (!map.has(k)) map.set(k, []);
      const arr = map.get(k);
      if (!arr.some(e => e.lemma === lemma && e.desc === desc)) arr.push({ lemma, desc, idx });
    };
    words.forEach((e, idx) => {
      const [w, pos, g, pl] = e;
      // 多字詞（例如 carta di credito）：每個字都能查到整個詞
      if (/ /.test(w)) {
        w.split(' ').concat(pl && pl !== '-' ? pl.split(' ') : []).forEach(x => { if (!map.has(x.toLowerCase())) add(x, w, '「' + w + '」的一部分', idx); });
      }
      if (pos === 'n') {
        add(w, w, '單數', idx);
        if (pl && pl !== '-' && pl !== w) add(pl, w, '複數', idx);
        if (pl === w) add(w, w, '單複數同形', idx);
      } else if (pos === 'adj') {
        const f = adjForms(e);
        const lab = ['陽性單數', '陰性單數', '陽性複數', '陰性複數'];
        f.forEach((x, i) => add(x, w, lab[i], idx));
        if (pl && pl.split('/').length > 3) pl.split('/').slice(3).forEach(x => add(x, w, '名詞前的縮短形', idx));
      } else if (/^v/.test(pos)) {
        const c = conjugate(w, pos);
        add(w, w, '原形', idx);
        if (c.refl) add(baseOf(w), w, '原形（不加 si）', idx);
        c.present.forEach((f, i) => add(f, w, '現在式 ' + PERSONS[i], idx));
        add(c.ppForms.ms, w, '過去分詞', idx);
        add(c.ppForms.fs, w, '過去分詞（陰性）', idx);
        add(c.ppForms.mp, w, '過去分詞（陽性複數）', idx);
        add(c.ppForms.fp, w, '過去分詞（陰性複數）', idx);
        if (c.imperative) {
          const who = ['tu', 'Lei', 'noi', 'voi'];
          c.imperative.forEach((f, i) => f.split('/').forEach(x => {
            const k = x.replace(/^si /, '');
            add(k, w, '命令式 ' + who[i], idx);
          }));
        }
      } else {
        add(w, w, '', idx);
        if (pl && pl !== '-' && pos !== 'expr') pl.split('/').forEach(x => add(x, w, '', idx));
      }
    });
    if (extra) for (const k of Object.keys(extra)) add(k, extra[k][0], extra[k][1], -1);
    // 冠詞與介係詞合併形
    for (const k of Object.keys(ART_PREPS)) {
      const { prep, art } = ART_PREPS[k];
      add(k, prep, prep + ' + ' + art, -2);
    }
    return map;
  }
  IT.buildLookup = buildLookup;

  /* ---------- 比對答案 ---------- */
  function stripAccents(s) { return s.normalize('NFD').replace(/[̀-ͯ]/g, ''); }
  // 回傳 'ok' | 'accent' | 'wrong'
  function checkAnswer(input, answer) {
    const a = norm(input).trim().toLowerCase().replace(/\s+/g, ' ');
    const b = norm(answer).trim().toLowerCase();
    if (!a) return 'wrong';
    if (a === b) return 'ok';
    if (stripAccents(a) === stripAccents(b)) return 'accent';
    // 接受用 ` 或 ' 代替重音（例如 e' → è）
    const c = a.replace(/([aeiou])['`]/g, (m, v) => v);
    if (c !== a && stripAccents(c) === stripAccents(b)) return 'accent';
    return 'wrong';
  }
  IT.checkAnswer = checkAnswer; IT.stripAccents = stripAccents;
})(typeof window !== 'undefined' ? window : globalThis);
