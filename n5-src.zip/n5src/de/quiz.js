/* 出題邏輯（德文）：冠詞與性別題、動詞變化題、介係詞練習、發音練習資料 */
(function (G) {
  'use strict';
  const DE = G.DE || (G.DE = {});
  const DEF5 = ['der', 'die', 'das', 'den', 'dem'];
  const IND5 = ['ein', 'eine', 'einen', 'einem', 'einer'];
  const WECHSEL = new Set(['in', 'an', 'auf', 'unter', 'über', 'vor', 'hinter', 'neben', 'zwischen']);
  const CPOOL = { in: ['im', 'ins', 'in der', 'in die', 'in den'], an: ['am', 'ans', 'an der', 'an die', 'an den'], zu: ['zum', 'zur', 'zu den'], von: ['vom', 'von der', 'von den'], bei: ['beim', 'bei der', 'bei den'] };
  const C_ART = { im: 'dem', ins: 'das', am: 'dem', ans: 'das', zum: 'dem', zur: 'der', vom: 'dem', beim: 'dem' };
  DE.ART_DEMO_EXTRA = {};

  function shuffle(a, rnd) { rnd = rnd || Math.random; a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
  function pick(a, rnd) { return a[Math.floor((rnd || Math.random)() * a.length)]; }
  DE.shuffle = shuffle; DE.pick = pick;
  const capF = s => s.charAt(0).toUpperCase() + s.slice(1);
  const posOf = () => DE._posOf2 || (DE._posOf2 = Object.fromEntries(DE.W.filter(e => !/^v/.test(e[1])).map(e => [e[0] + '|' + e[1], e])));

  // 冠詞後面（跳過形容詞）的名詞：回傳 { e, pl, tok }
  function nounAfter(T, i, LOOK) {
    for (let j = i + 1; j < T.length; j++) {
      const t = T[j]; if (!t.w) { if (/[^\s]/.test(t.t)) return null; continue; }
      const inf = LOOK.get(t.k) || [];
      if (/^[A-ZÄÖÜ]/.test(t.t)) {
        const x = inf.find(y => posOf()[y.lemma + '|n']);
        if (!x) return null;
        const e = posOf()[x.lemma + '|n'];
        return { e, pl: e[2] === 'pl' || /複數/.test(x.desc), tok: t };
      }
      if (!inf.some(y => /詞尾/.test(y.desc))) return null; // 不是形容詞就停
    }
    return null;
  }
  const gNum = n => n.e[2] === 'pl' ? '複數' : DE.G_ZH[n.e[2]] + (n.pl ? '名詞的複數' : '單數');
  const caseTxt = cs => (cs.length > 1 ? cs.filter(c => c !== 'Gen') : cs).map(c => DE.CASE_ZH[c] + ' ' + c + '.').join(' 或 ');

  function makeArtQuestion(entry, LOOK, rnd) {
    rnd = rnd || Math.random;
    const isNoun = entry[1] === 'n' && entry[2] !== 'pl' && !/ /.test(entry[0]);
    const genderQ = () => {
      const answer = DE.DEF[entry[2]][0];
      return { kind: 'art', answer, options: shuffle(['der', 'die', 'das'], rnd), valid: [answer], cap: false,
        before: '', after: ' ' + entry[0], sentence: answer + ' ' + entry[0], zh: entry[4], word: entry, gender: true,
        info: `${answer} ${entry[0]}：${DE.G_ZH[entry[2]]}名詞` };
    };
    const sent = entry[6];
    const T = []; let pos = 0;
    for (const t of DE.tokenize(sent)) { T.push({ t: t.t, w: t.w, s: pos, k: DE.norm(t.t).toLowerCase() }); pos += t.t.length; }
    const cands = [];
    T.forEach((t, i) => {
      if (!t.w) return;
      const prev = T.slice(0, i).filter(x => x.w).pop();
      const isDef = DEF5.includes(t.k), isInd = IND5.includes(t.k), isC = !!C_ART[t.k];
      if (!isDef && !isInd && !isC) return;
      const n = nounAfter(T, i, LOOK); if (!n) return;
      const art = isC ? C_ART[t.k] : t.k;
      const cs = DE.casesOf(art, n.e[2], n.pl);
      if (!cs.length) return;
      if (isInd && n.pl) return;
      let pool, wechsel = false;
      if (isC) { const p = DE.ART_PREPS[t.k].prep; pool = CPOOL[p]; wechsel = WECHSEL.has(p); }
      else { pool = isDef ? DEF5 : IND5; wechsel = !!prev && WECHSEL.has(prev.k); }
      // 雙向介係詞後面，同一個名詞的另一個格也說得通（im Park／in den Park），不放進選項
      const fits = o => { const a = C_ART[o] || o.split(' ').pop(); return DE.casesOf(a, n.e[2], n.pl).length > 0; };
      const wrong = pool.filter(o => o !== t.k && !(wechsel && fits(o)) && !(isC && fits(o) && C_ART[o] === undefined && o.endsWith(' ' + art)));
      if (wrong.length < 2) return;
      const where = isC ? `${t.k} ＝ ${DE.ART_PREPS[t.k].prep} ＋ ${art}` : t.k;
      cands.push({ i, kind: isC ? 'artprep' : isDef ? 'art' : 'indef', wrong, info: `${where}：${n.e[0]} 是${gNum(n)}，這裡是${caseTxt(cs)}` });
    });
    if (!cands.length) return isNoun ? genderQ() : null;
    if (isNoun && rnd() < 0.5) return genderQ();
    const c = rnd() < 0.5 ? cands[0] : pick(cands, rnd);
    const tok = T[c.i];
    const capFirst = c.i === T.findIndex(x => x.w);
    const fix = s => capFirst ? capF(s) : s;
    const answer = fix(tok.k);
    const options = shuffle([answer].concat(shuffle(c.wrong, rnd).slice(0, 3).map(fix)), rnd);
    return {
      kind: c.kind, answer, options, valid: [answer], cap: capFirst, info: c.info,
      before: sent.slice(0, tok.s), after: sent.slice(tok.s + tok.t.length),
      sentence: sent, zh: entry[7], word: entry
    };
  }
  function artWrong(q, opt) { return !q.valid.includes(opt); }
  DE.makeArtQuestion = makeArtQuestion; DE.artWrong = artWrong;

  // 介係詞：人工挑選、確定只有一個答案的句子
  DE.PREP_DRILLS = [
    ['Ich fahre ___ dem Bus zur Arbeit.', 'mit', ['von', 'bei', 'aus'], '我搭公車去上班。'],
    ['Ich komme ___ Taiwan.', 'aus', ['nach', 'bei', 'zu'], '我來自台灣。'],
    ['Wir fahren im Sommer ___ Italien.', 'nach', ['zu', 'aus', 'bei'], '我們夏天去義大利。'],
    ['Ich gehe heute ___ Arzt.', 'zum', ['zur', 'im', 'beim'], '我今天去看醫生。'],
    ['Am Abend gehe ich ___ Kino.', 'ins', ['im', 'zur', 'am'], '我晚上去看電影。'],
    ['Ich wohne ___ meinen Eltern.', 'bei', ['nach', 'zu', 'aus'], '我跟父母住。'],
    ['Das Geschenk ist ___ dich.', 'für', ['mit', 'von', 'zu'], '這個禮物是給你的。'],
    ['Ich trinke Tee ___ Zucker, ich mag es nicht süß.', 'ohne', ['für', 'durch', 'bis'], '我喝茶不加糖，我不喜歡甜的。'],
    ['Der Unterricht beginnt ___ neun Uhr.', 'um', ['am', 'im', 'seit'], '九點開始上課。'],
    ['Ich lerne ___ zwei Jahren Deutsch.', 'seit', ['vor', 'für', 'ab'], '我學德文兩年了。'],
    ['___ Montag habe ich frei.', 'Am', ['Im', 'Um', 'Zum'], '我星期一放假。'],
    ['___ Sommer fahren wir ans Meer.', 'Im', ['Am', 'Um', 'Zum'], '我們夏天去海邊。'],
    ['Ich arbeite heute von neun ___ fünf Uhr.', 'bis', ['nach', 'zu', 'um'], '我今天從九點工作到五點。'],
    ['Das Buch liegt ___ Tisch.', 'auf dem', ['auf den', 'auf der', 'auf die'], '書放在桌上。'],
    ['Leg das Buch ___ Tisch.', 'auf den', ['auf dem', 'auf die', 'auf der'], '把書放到桌上。'],
    ['Wie komme ich ___ Bahnhof?', 'zum', ['zur', 'zu die', 'im'], '請問車站怎麼走？'],
    ['Ich fahre mit dem Fahrrad ___ Uni.', 'zur', ['zum', 'in', 'nach'], '我騎腳踏車去學校。'],
    ['Wir treffen uns ___ Café.', 'im', ['ins', 'in die', 'zur'], '我們在咖啡館碰面。'],
    ['Das Bild hängt ___ Wand.', 'an der', ['an die', 'an dem', 'in die'], '畫掛在牆上。'],
    ['Ich warte ___ den Bus.', 'auf', ['für', 'mit', 'zu'], '我在等公車。'],
    ['Danke ___ die Einladung!', 'für', ['mit', 'von', 'zu'], '謝謝你的邀請！'],
    ['Ich gehe jetzt ___ Hause.', 'nach', ['zu', 'in', 'bei'], '我現在要回家了。'],
    ['Am Sonntag bleibe ich ___ Hause.', 'zu', ['nach', 'in', 'bei'], '我星期天待在家。'],
    ['Ich interessiere mich ___ Musik.', 'für', ['mit', 'von', 'zu'], '我對音樂有興趣。'],
    ['Ich freue mich ___ das Wochenende.', 'auf', ['für', 'mit', 'zu'], '我很期待週末。'],
    ['Das Café ist ___ der Bank und dem Hotel.', 'zwischen', ['neben', 'hinter', 'vor'], '咖啡館在銀行和飯店之間。'],
    ['Ich gratuliere dir ___ Geburtstag!', 'zum', ['zur', 'im', 'am'], '祝你生日快樂！'],
    ['Der Zug fährt ___ Gleis drei ab.', 'von', ['aus', 'mit', 'zu'], '火車從三號月台出發。']
  ];

  // 主詞通常只有第三人稱的動詞
  const IMPERSONAL = { regnen: [2], schneien: [2], scheinen: [2], gefallen: [2, 5], schmecken: [2, 5], gehören: [2, 5], kosten: [2, 5], dauern: [2], passieren: [2], stattfinden: [2, 5], funktionieren: [2, 5], bedeuten: [2] };
  const THING_SUBJ = { gefallen: 1, schmecken: 1, gehören: 1, kosten: 1, stattfinden: 1, funktionieren: 1, dauern: 1, bedeuten: 1 };
  DE.IMPERSONAL = IMPERSONAL;
  function makeVerbQuestion(entry, rnd) {
    rnd = rnd || Math.random;
    const c = DE.conjugate(entry[0], entry[1]);
    const usePast = rnd() < 0.25 && c.passato.length > 0;
    const allowed = IMPERSONAL[entry[0]] || [0, 1, 2, 3, 4, 5];
    const i = allowed[Math.floor(rnd() * allowed.length)];
    let subjShow = ['ich', 'du', pick(['er', 'sie', 'es'], rnd), 'wir', 'ihr', pick(['sie', 'Sie'], rnd)][i];
    if (entry[0] === 'regnen' || entry[0] === 'schneien' || entry[0] === 'passieren') subjShow = 'es';
    else if (entry[0] === 'scheinen') subjShow = 'die Sonne';
    else if (THING_SUBJ[entry[0]]) subjShow = i === 2 ? '（單數的東西）' : '（複數的東西）';
    let answer, forms;
    if (usePast) {
      answer = c.passato[i];
      forms = c.passato.slice();
      // 換錯助動詞、規則化的過去分詞，當作干擾選項
      const other = (c.aux === 'sein' ? DE.IRR.haben : DE.IRR.sein).p.split(' ')[i];
      forms.push(answer.replace(/^\S+/, other));
      const reg = c.sep ? c.sep + DE.weakPP(c.inf) : DE.weakPP(c.inf);
      if (reg !== c.pp) forms.push(answer.replace(new RegExp(c.pp + '$'), reg));
    } else {
      answer = c.presentFull[i];
      forms = c.presentFull.slice();
      // 母音變化動詞：沒變的形也是常見錯誤（du fahrst）
      if (c.change && (i === 1 || i === 2)) {
        const r = DE.regPresent(c.inf).p[i];
        forms.push(answer.replace(/^\S+/, r));
      }
    }
    const wrong = shuffle([...new Set(forms)].filter(f => f !== answer), rnd);
    const options = shuffle([answer].concat(wrong.slice(0, 3)), rnd);
    return { kind: 'verb', tense: usePast ? 'passato' : 'presente', subj: subjShow, person: i, answer, options, word: entry, conj: c };
  }
  DE.makeVerbQuestion = makeVerbQuestion;

  /* ---------- 發音 ---------- */
  DE.ALPHABET = [
    ['A', 'a', '[a]／[aː]', '像「啊」；後面子音少時唸長音', 'Apfel'],
    ['B', 'be', '[b]／[p]', '像「ㄅ」但聲帶震動；在字尾變成 [p]（清音化）', 'Buch'],
    ['C', 'ce', '[ts]／[k]', '字母名唸「ㄘㄝ」；單獨出現多在外來語，常唸 [k]', 'Computer'],
    ['D', 'de', '[d]／[t]', '像「ㄉ」但聲帶震動；字尾唸 [t]：Hund', 'danke'],
    ['E', 'e', '[eː]／[ɛ]／[ə]', '長音像「ㄝ」拉長；短音較開；非重音的 -e 很輕，像「ㄜ」', 'Ei'],
    ['F', 'eff', '[f]', '像「ㄈ」', 'Frau'],
    ['G', 'ge', '[g]／[k]', '像「ㄍ」；字尾唸 [k]：Tag；-ig 結尾唸 [ɪç]', 'gut'],
    ['H', 'ha', '[h]／不發音', '字首像「ㄏ」（輕）；母音後面不發音，表示前面母音是長音', 'Haus'],
    ['I', 'i', '[iː]／[ɪ]', '像「一」；短音較鬆', 'ich'],
    ['J', 'jot', '[j]', '像「一」開頭的音，不是英文的 j：ja 唸「呀」', 'ja'],
    ['K', 'ka', '[k]', '像「ㄎ」，送氣', 'Kind'],
    ['L', 'ell', '[l]', '像「ㄌ」，舌尖清楚', 'Lampe'],
    ['M', 'emm', '[m]', '像「ㄇ」', 'Mutter'],
    ['N', 'enn', '[n]', '像「ㄋ」', 'nein'],
    ['O', 'o', '[oː]／[ɔ]', '長音像「喔」嘴巴圓；短音嘴巴較開', 'Obst'],
    ['P', 'pe', '[p]', '像「ㄆ」，送氣', 'Papier'],
    ['Q', 'ku', '[kv]', '一定和 u 一起：qu 唸 [kv]（像「ㄎ」＋德文的 w）', 'bequem'],
    ['R', 'err', '[ʁ]／[ɐ]', '喉嚨後面輕輕摩擦；在字尾 -er 變成像「ㄚ」的弱音', 'rot'],
    ['S', 'ess', '[z]／[s]／[ʃ]', '母音前唸 [z]（聲帶震動）；字尾唸 [s]；st、sp 在字首唸 [ʃt]、[ʃp]', 'Sonne'],
    ['T', 'te', '[t]', '像「ㄊ」，送氣', 'Tag'],
    ['U', 'u', '[uː]／[ʊ]', '像「烏」，嘴巴圓', 'Uhr'],
    ['V', 'vau', '[f]／[v]', '德文字大多唸 [f]：Vater 唸「法特」；外來語唸 [v]', 'Vater'],
    ['W', 'we', '[v]', '唸 [v]（上齒碰下唇），不是英文的 w', 'Wasser'],
    ['X', 'ix', '[ks]', '唸 [ks]', 'Taxi'],
    ['Y', 'ypsilon', '[ʏ]／[i]', '多在外來語：Handy 唸 [i]', 'Handy'],
    ['Z', 'zett', '[ts]', '唸「ㄘ」[ts]，不是英文的 z', 'Zug'],
    ['Ä', 'ä', '[ɛː]／[ɛ]', '像「ㄝ」，嘴巴比 e 開', 'Käse'],
    ['Ö', 'ö', '[øː]／[œ]', '嘴形唸「喔」，舌頭唸「ㄝ」', 'schön'],
    ['Ü', 'ü', '[yː]／[ʏ]', '嘴形唸「烏」，舌頭唸「一」，像注音的「ㄩ」', 'Tür'],
    ['ẞ', 'eszett', '[s]', '唸清楚的 [s]，只出現在長母音或 au、ei 後面：Straße、heißen', 'Straße']
  ];

  DE.PRON_RULES = [
    { t: 'ei 和 ie', d: '最容易搞混的一對：<b>ei</b> 唸「愛」[aɪ]，<b>ie</b> 唸長長的「一」[iː]。口訣：唸<b>第二個字母的英文名稱</b>——ei 的 i 唸「愛」，ie 的 e 唸「一」。', ex: [['mein', '[aɪ]'], ['Wein', '[aɪ]'], ['Bier', '[iː]'], ['vier', '[iː]'], ['Lied', '[iː]']] },
    { t: 'eu、äu 和 au', d: '<b>eu</b> 和 <b>äu</b> 都唸「喔一」[ɔʏ]；<b>au</b> 唸「凹」[aʊ]。', ex: [['heute', '[ɔʏ]'], ['Freund', '[ɔʏ]'], ['Häuser', '[ɔʏ]'], ['Haus', '[aʊ]'], ['Frau', '[aʊ]']] },
    { t: 'ch 的兩種唸法', d: '在 a、o、u、au 後面唸喉嚨後的 [x]（像用力的「ㄏ」）：Buch、acht；在其他母音、子音後面唸舌面的 [ç]（像輕輕的「ㄒ」）：ich、Milch。', ex: [['Buch', '[x]'], ['acht', '[x]'], ['ich', '[ç]'], ['Milch', '[ç]'], ['Küche', '[ç]']] },
    { t: 'sch、st、sp', d: '<b>sch</b> 唸 [ʃ]（像「噓」）。字首（或複合字的一部分開頭）的 <b>st</b>、<b>sp</b> 也唸 [ʃt]、[ʃp]：Stadt 唸「緒他特」。在字中間或結尾的 st 唸 [st]：ist、Fenster。', ex: [['Schule', '[ʃ]'], ['Stadt', '[ʃt]'], ['Sport', '[ʃp]'], ['ist', '[st]'], ['Fenster', '[st]']] },
    { t: 's：母音前要震動', d: 's 在母音前唸 [z]（聲帶震動，像蜜蜂嗡嗡）；在字尾或子音前唸 [s]。ss 和 ß 一定唸 [s]。', ex: [['Sonne', '[z]'], ['Suppe', '[z]'], ['Haus', '[s]'], ['Tasse', '[s]'], ['Straße', '[s]']] },
    { t: 'z 唸 [ts]', d: 'z 和 tz 都唸「ㄘ」[ts]：Zug、Zeit、Platz。不要唸成英文的 z。', ex: [['Zug', '[ts]'], ['Zeit', '[ts]'], ['zehn', '[ts]'], ['Platz', '[ts]']] },
    { t: 'w 唸 [v]，v 唸 [f]', d: '德文的 <b>w</b> 唸英文的 v：Wasser。德文的 <b>v</b> 大多唸 [f]：Vater、viel、vier；外來語唸 [v]：Video。', ex: [['Wasser', '[v]'], ['Wein', '[v]'], ['Vater', '[f]'], ['vier', '[f]'], ['viel', '[f]']] },
    { t: 'j 唸「一」', d: 'j 唸 [j]，跟「呀、喲」的開頭一樣：ja、Jahr、jung。', ex: [['ja', '[j]'], ['Jahr', '[j]'], ['jung', '[j]'], ['Januar', '[j]']] },
    { t: '字尾清音化', d: 'b、d、g 在字尾或子音前唸成 p、t、k：Hund 唸 [hʊnt]、Tag 唸 [taːk]。加了詞尾就恢復：Hunde [d]、Tage [g]。', ex: [['Hund', '[t]'], ['Tag', '[k]'], ['gelb', '[p]'], ['Hunde', '[d]'], ['Tage', '[g]']] },
    { t: '-ig 唸 [ɪç]', d: '字尾的 -ig 唸 [ɪç]（像「一ㄒ」）：richtig、billig、zwanzig。', ex: [['richtig', '[ɪç]'], ['billig', '[ɪç]'], ['zwanzig', '[ɪç]'], ['ruhig', '[ɪç]']] },
    { t: 'r 和 -er', d: '子音 r 在喉嚨後面輕輕摩擦（像漱口）。字尾的 -er 幾乎不發 r，唸成弱弱的「ㄚ」：Vater 唸「法特ㄚ」。', ex: [['rot', '[ʁ]'], ['Reise', '[ʁ]'], ['Vater', '[ɐ]'], ['Lehrer', '[ɐ]'], ['Bruder', '[ɐ]']] },
    { t: '長母音和短母音', d: '母音後面是<b>一個子音</b>，或加了 <b>h</b>、或<b>重複母音</b>，通常唸長音：Tag、fahren、Tee。後面是<b>兩個以上子音</b>（含雙子音），唸短音：Mutter、Bett。', ex: [['Tag', '長'], ['fahren', '長'], ['Tee', '長'], ['Mutter', '短'], ['Bett', '短']] },
    { t: '變音 ä、ö、ü', d: '<b>ä</b> 像「ㄝ」；<b>ö</b> 嘴形唸 o、舌頭唸 e；<b>ü</b> 嘴形唸 u、舌頭唸 i（像「ㄩ」）。打字不方便時可以寫成 ae、oe、ue。', ex: [['Käse', '[ɛː]'], ['schön', '[øː]'], ['Tür', '[yː]'], ['Mütter', '[ʏ]']] },
    { t: '重音在第一個音節', d: '德文字的重音大多在<b>第一個音節</b>：ARbeit、FAmilie…（例外：外來語 Uni<b>ver</b>si<b>tät</b>、-ieren 動詞 stu<b>die</b>ren）。分離動詞重音在前綴：<b>AUF</b>stehen；be-、ver- 開頭的重音不在前綴：be<b>SU</b>chen。', ex: [['arbeiten', 'AR-bei-ten'], ['Kartoffel', 'Kar-TOF-fel'], ['aufstehen', 'AUF-ste-hen'], ['besuchen', 'be-SU-chen'], ['studieren', 'stu-DIE-ren']] }
  ];

  // 聽音選拼字（容易混淆的成對字）
  DE.LISTEN_PAIRS = [
    ['Wein', 'Wien'], ['leider', 'Lieder'], ['Mitte', 'Miete'], ['offen', 'Ofen'], ['Bett', 'Beet'], ['Kirche', 'Kirsche'],
    ['Tasche', 'Tasse'], ['vier', 'für'], ['Kissen', 'küssen'], ['schon', 'schön'], ['Tür', 'Tier'], ['Mutter', 'Mütter'],
    ['Bruder', 'Brüder'], ['zahlen', 'zählen'], ['Kuchen', 'Küchen'], ['Bach', 'Bauch'], ['wir', 'vier'], ['Hölle', 'Hülle'],
    ['Zoll', 'Soll'], ['lesen', 'lösen'], ['Rose', 'Rosse'], ['Bein', 'Bier'], ['Haus', 'Hose'], ['Leute', 'Laute'], ['acht', 'echt']
  ];

  // 看拼字選讀法
  const S = {
    ai: '[aɪ] 像「愛」', ii: '[iː] 長的「一」', oy: '[ɔʏ] 像「喔一」', au: '[aʊ] 像「凹」', x: '[x] 喉嚨的「ㄏ」', c: '[ç] 輕輕的「ㄒ」',
    sh: '[ʃ] 像「噓」', shp: '[ʃp] 像「緒ㄆ」', sp: '[sp] 像「ㄙㄆ」', sht: '[ʃt] 像「緒特」', st: '[st] 像「ㄙㄊ」', z: '[z] 聲帶震動的 s', s: '[s] 清楚的「ㄙ」', ts: '[ts] 像「ㄘ」',
    v: '[v] 上齒碰下唇（震動）', f: '[f] 像「ㄈ」', j: '[j] 像「一」', dj: '[dʒ] 英文的 j', k: '[k]（字尾清音化）', g: '[g] 像「ㄍ」',
    t: '[t]（字尾清音化）', d: '[d]', ich: '[ɪç] 像「一ㄒ」', ik: '[ɪk]', mute: '不發音（母音拉長）', h: '[h]', a: '[ɐ] 弱弱的「ㄚ」', er: '[ɛʁ] 清楚的 er',
    kv: '[kv]', kw: '[kw] 英文的 qu', yy: '[yː] 像「ㄩ」', uu: '[uː] 像「烏」', oe: '[øː] 圓唇的「ㄝ」', oo: '[oː] 像「喔」'
  };
  DE.READ_ITEMS = [
    ['Wein', 'ei', 'ai', ['ii', 'oy']], ['mein', 'ei', 'ai', ['ii', 'au']], ['Bier', 'ie', 'ii', ['ai', 'oy']], ['vier', 'ie', 'ii', ['ai', 'au']],
    ['heute', 'eu', 'oy', ['ai', 'au']], ['Häuser', 'äu', 'oy', ['au', 'ai']], ['Frau', 'au', 'au', ['oy', 'ai']],
    ['Buch', 'ch', 'x', ['c', 'sh']], ['acht', 'ch', 'x', ['c', 'k']], ['ich', 'ch', 'c', ['x', 'sh']], ['Milch', 'ch', 'c', ['x', 'k']],
    ['Schule', 'sch', 'sh', ['s', 'x']], ['Stadt', 'St', 'sht', ['st', 'ts']], ['Sport', 'Sp', 'shp', ['sp', 'z']], ['Fenster', 'st', 'st', ['sht', 'ts']],
    ['Sonne', 'S', 'z', ['s', 'sh']], ['Haus', 's', 's', ['z', 'sh']], ['Zug', 'Z', 'ts', ['z', 's']], ['Platz', 'tz', 'ts', ['z', 's']],
    ['Wasser', 'W', 'v', ['f', 'kw']], ['Vater', 'V', 'f', ['v', 'kw']], ['ja', 'j', 'j', ['dj', 'h']],
    ['Tag', 'g', 'k', ['g', 'x']], ['Hund', 'd', 't', ['d', 'mute']], ['richtig', 'ig', 'ich', ['ik', 'x']],
    ['fahren', 'h', 'mute', ['h', 'x']], ['Vater', 'er', 'a', ['er', 'mute']], ['bequem', 'qu', 'kv', ['kw', 'k']],
    ['Tür', 'ü', 'yy', ['uu', 'ii']], ['schön', 'ö', 'oe', ['oo', 'ai']]
  ].map(([w, part, ans, wr]) => ({ w, part, ans: S[ans], opts: [S[ans]].concat(wr.map(k => S[k])) }));
})(typeof window !== 'undefined' ? window : globalThis);
