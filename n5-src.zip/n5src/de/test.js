/* 德文資料與引擎測試：node de/test.js */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const SRC = __dirname;
const ctx = { console };
ctx.globalThis = ctx;
vm.createContext(ctx);
for (const f of ['engine.js', 'data1.js', 'data2.js', 'data3.js', 'data4.js', 'data5.js', 'grammar.js', 'quiz.js', 'gx1.js', 'gx2.js', 'gxpath.js']) {
  vm.runInContext(fs.readFileSync(path.join(SRC, f), 'utf8'), ctx, { filename: f });
}
const DE = ctx.DE;
const W = DE.W;
let fails = 0, checks = 0;
const failList = [];
function ok(cond, msg) { checks++; if (!cond) { fails++; failList.push(msg); } }
function eq(a, b, msg) { ok(JSON.stringify(a) === JSON.stringify(b), msg + '：預期 ' + JSON.stringify(b) + '，得到 ' + JSON.stringify(a)); }

/* 1. 欄位格式 */
const POS = new Set(['n', 'adj', 'adv', 'prep', 'art', 'pron', 'conj', 'num', 'det', 'q', 'expr', 'v', 'v-st', 'v-irr', 'v-mod']);
W.forEach((e, i) => {
  ok(Array.isArray(e) && e.length === 9, `第 ${i} 筆欄位數不是 9：${JSON.stringify(e)}`);
  ok(POS.has(e[1]), `${e[0]}：未知詞性 ${e[1]}`);
  if (e[1] === 'n') {
    ok(['m', 'f', 'n', 'pl'].includes(e[2]), `${e[0]}：名詞缺性別`);
    ok(/^[A-ZÄÖÜ]/.test(e[0]), `${e[0]}：名詞要大寫開頭`);
    if (e[3] !== '-') ok(/^[A-ZÄÖÜ]/.test(e[3]), `${e[0]}：複數要大寫開頭`);
  } else if (e[1] !== 'expr' && !['Sie', 'Ihr'].includes(e[0])) ok(/^[a-zäöüß]/.test(e[0]), `${e[0]}：非名詞應該小寫`);
  e.forEach((x, j) => ok(typeof x === 'string' && x.length > 0, `${e[0]}：第 ${j} 欄是空的`));
  ok(/[。！？]$/.test(e[7]), `${e[0]}：例句中文沒有句末標點：${e[7]}`);
  ok(/[.!?]$/.test(e[6].trim()), `${e[0]}：例句沒有句末標點：${e[6]}`);
  ok(!/[A-Za-z]-[A-Za-z]|'/.test(e[6]), `${e[0]}：例句有連字號或撇號，點字查詢會斷錯：${e[6]}`);
});
/* 2. 不可重複 */
const keys = new Set();
W.forEach(e => { const k = e[0] + '|' + e[1]; ok(!keys.has(k), `重複的單字：${k}`); keys.add(k); });

/* 3. 例句要對上填空答案，而且答案是該字的變化形 */
const LOOK = DE.getLookup();
function words(s) { return DE.tokenize(s).filter(t => t.w).map(t => t.t.toLowerCase()); }
function containsSeq(sent, ans) {
  const a = words(sent), b = words(ans);
  for (let i = 0; i + b.length <= a.length; i++) if (b.every((x, j) => a[i + j] === x)) return true;
  return false;
}
W.forEach(e => {
  const [w, pos, , pl, , , sent, , ans] = e;
  ok(containsSeq(sent, ans), `${w}：例句「${sent}」裡找不到答案「${ans}」`);
  const a = ans.toLowerCase();
  let isForm = a === w.toLowerCase() || (pl && pl.toLowerCase() === a);
  if (!isForm && !/ /.test(a)) isForm = (LOOK.get(DE.norm(a)) || []).some(x => x.lemma === w);
  ok(isForm, `${w}：答案「${ans}」不是 ${w} 的變化形`);
  // 分離動詞的答案不能只填前綴
  if (/^v/.test(pos)) { const c = DE.conjugate(w, pos); ok(!c.sep || a !== c.sep, `${w}：答案只有前綴`); }
});

/* 4. 點字查詢沒有漏字 */
const missing = new Map();
const chk = (s, who) => DE.tokenize(s).filter(t => t.w).forEach(t => {
  const k = DE.norm(t.t).toLowerCase();
  if (!LOOK.has(k) && !DE.NAMES[k]) missing.set(k, (missing.get(k) || []).concat(who));
});
W.forEach(e => chk(e[6], e[0]));
DE.GRAMMAR.forEach(g => (g.ex || []).forEach(s => chk(s[0], '文法:' + g.id)));
ok(missing.size === 0, '例句中查不到的字：' + [...missing].map(([k, v]) => k + '(' + v.slice(0, 2).join(',') + ')').join('  '));

/* 5. 名詞性別：已知的性別、字尾規則 */
const KNOWN_G = { Mädchen: 'n', Kind: 'n', Haus: 'n', Auto: 'n', Buch: 'n', Brot: 'n', Wasser: 'n', Bier: 'n', Mann: 'm', Frau: 'f', Tisch: 'm', Stuhl: 'm', Lampe: 'f', Tür: 'f', Fenster: 'n', Zimmer: 'n', Bett: 'n', Uhr: 'f', Zeit: 'f', Tag: 'm', Woche: 'f', Jahr: 'n', Monat: 'm', Nacht: 'f', Abend: 'm', Hund: 'm', Katze: 'f', Kaffee: 'm', Tee: 'm', Milch: 'f', Käse: 'm', Butter: 'f', Apfel: 'm', Banane: 'f', Ei: 'n', Fleisch: 'n', Obst: 'n', Gemüse: 'n', Stadt: 'f', Land: 'n', Straße: 'f', Bahnhof: 'm', Bus: 'm', Zug: 'm', Kino: 'n', Hotel: 'n', Bank: 'f', Schule: 'f', Universität: 'f', Wetter: 'n', Sonne: 'f', Regen: 'm', Schnee: 'm', Meer: 'n', See: 'm', Berg: 'm', Hand: 'f', Fuß: 'm', Kopf: 'm', Auge: 'n', Nase: 'f', Mund: 'm', Herz: 'n', Name: 'm', Herr: 'm', Junge: 'm', Handy: 'n', Computer: 'm', Geld: 'n', Problem: 'n', Museum: 'n', Zentrum: 'n', Information: 'f', Wohnung: 'f', Zeitung: 'f', Bäckerei: 'f', Polizei: 'f', Sport: 'm', Musik: 'f', Party: 'f', Euro: 'm', Glas: 'n', Tasse: 'f', Messer: 'n', Gabel: 'f', Löffel: 'm', Teller: 'm', Schlüssel: 'm', Brötchen: 'n', Hähnchen: 'n', Wurst: 'f', Suppe: 'f', Reis: 'm', Salz: 'n', Zucker: 'm', Eis: 'n', Kuchen: 'm', Schokolade: 'f', Café: 'n', Restaurant: 'n', Rechnung: 'f', Kühlschrank: 'm', Sofa: 'n', Bild: 'n', Garten: 'm', Küche: 'f', Bad: 'n', Dusche: 'f', Toilette: 'f', Wand: 'f', Arzt: 'm', Apotheke: 'f', Krankenhaus: 'n', Fieber: 'n', Sohn: 'm', Tochter: 'f', Vater: 'm', Mutter: 'f', Bruder: 'm', Schwester: 'f', Eltern: 'pl', Leute: 'pl', Ferien: 'pl', Geschwister: 'pl', Großeltern: 'pl', Montag: 'm', Mai: 'm', Sommer: 'm', Winter: 'm', Frühling: 'm', Herbst: 'm', Wochenende: 'n', Morgen: 'm', Mittag: 'm', Hemd: 'n', Hose: 'f', Kleid: 'n', Rock: 'm', Jacke: 'f', Mantel: 'm', Pullover: 'm', Schuh: 'm', Farbe: 'f', Größe: 'f', Firma: 'f', Büro: 'n', Arbeit: 'f', Beruf: 'm', Frage: 'f', Antwort: 'f', Wort: 'n', Satz: 'm', Sprache: 'f', Deutsch: 'n', Fahrrad: 'n', Flugzeug: 'n', Schiff: 'n', Taxi: 'n', Fahrkarte: 'f', Reise: 'f', Urlaub: 'm', Weg: 'm', Pass: 'm', Koffer: 'm', Tasche: 'f', Brille: 'f', Geschenk: 'n', Brief: 'm', Karte: 'f', Foto: 'n', Film: 'm', Spiel: 'n', Lied: 'n', Konzert: 'n', Fest: 'n', Ende: 'n', Anfang: 'm', Leben: 'n', Welt: 'f', Glück: 'n', Hilfe: 'f', Sache: 'f', Spaß: 'm', Lust: 'f', Hunger: 'm', Durst: 'm', Liter: 'm', Kilo: 'n', Stück: 'n', Grad: 'm', Viertel: 'n', Datum: 'n', Geburtstag: 'm', Kurs: 'm', Unterricht: 'm', Prüfung: 'f', Fehler: 'm', Text: 'm', Nummer: 'f', Adresse: 'f', Pause: 'f', Termin: 'm', Medikament: 'n', Tablette: 'f', Erkältung: 'f', Schmerz: 'm', Körper: 'm', Haar: 'n', Zahn: 'm', Bauch: 'm', Rücken: 'm', Hals: 'm', Arm: 'm', Bein: 'n', Ohr: 'n', Gesicht: 'n', Vogel: 'm', Pferd: 'n', Fisch: 'm', Tier: 'n', Baum: 'm', Blume: 'f', Wald: 'm', Fluss: 'm', Strand: 'm', Insel: 'f', Himmel: 'm', Wolke: 'f', Wind: 'm', Natur: 'f' };
W.filter(e => e[1] === 'n').forEach(e => { if (KNOWN_G[e[0]]) eq(e[2], KNOWN_G[e[0]], `${e[0]} 的性別`); });
const SUFFIX_G = [[/(ung|heit|keit|schaft|tät|ion)$/, 'f'], [/(chen|lein)$/, 'n'], [/(tag|ling)$/, 'm']];
W.filter(e => e[1] === 'n' && e[2] !== 'pl' && !['Kuchen'].includes(e[0])).forEach(e => SUFFIX_G.forEach(([re, g]) => { if (re.test(e[0])) eq(e[2], g, `${e[0]}：字尾 ${re} 的性別`); }));
ok(Object.keys(KNOWN_G).filter(k => !W.some(e => e[0] === k && e[1] === 'n')).length <= 3, '性別參考表裡太多字不在單字庫：' + Object.keys(KNOWN_G).filter(k => !W.some(e => e[0] === k && e[1] === 'n')).join(', '));

/* 6. 名詞複數 */
const PLURAL_EXC = { Käse: 'Käse', Bus: 'Busse', Grad: 'Grad', Euro: 'Euro', Cent: 'Cent' };
const PL_REF = { Mann: 'Männer', Frau: 'Frauen', Kind: 'Kinder', Buch: 'Bücher', Haus: 'Häuser', Auto: 'Autos', Tag: 'Tage', Hand: 'Hände', Apfel: 'Äpfel', Mutter: 'Mütter', Vater: 'Väter', Bruder: 'Brüder', Tochter: 'Töchter', Lehrer: 'Lehrer', Lehrerin: 'Lehrerinnen', Stadt: 'Städte', Zug: 'Züge', Stuhl: 'Stühle', Tisch: 'Tische', Lampe: 'Lampen', Museum: 'Museen', Zentrum: 'Zentren', Firma: 'Firmen', Datum: 'Daten', Wort: 'Wörter', Fuß: 'Füße', Baum: 'Bäume', Glas: 'Gläser', Ei: 'Eier', Bus: 'Busse', Handy: 'Handys', Fluss: 'Flüsse', See: 'Seen', Zahn: 'Zähne', Nacht: 'Nächte', Name: 'Namen', Herr: 'Herren', Student: 'Studenten', Kunde: 'Kunden', Arzt: 'Ärzte', Ärztin: 'Ärztinnen', Freund: 'Freunde', Schuh: 'Schuhe', Brötchen: 'Brötchen', Mädchen: 'Mädchen', Zimmer: 'Zimmer', Fenster: 'Fenster', Bild: 'Bilder', Kleid: 'Kleider', Land: 'Länder', Dorf: 'Dörfer', Wald: 'Wälder', Gast: 'Gäste', Koch: 'Köche', Satz: 'Sätze', Platz: 'Plätze', Bahnhof: 'Bahnhöfe', Wurst: 'Würste', Sohn: 'Söhne' };
W.filter(e => e[1] === 'n' && e[2] !== 'pl' && e[3] !== '-').forEach(e => {
  const [w, , g, pl] = e;
  if (PLURAL_EXC[w]) { eq(pl, PLURAL_EXC[w], `${w} 的複數`); return; }
  ok(DE.plausiblePlural(w, g, pl), `${w}（${g}）的複數「${pl}」不像常見的複數形，若是不規則請加入白名單`);
});
W.forEach(e => { if (e[1] === 'n' && PL_REF[e[0]]) eq(e[3], PL_REF[e[0]], `${e[0]} 的複數`); });
// 各格的形
eq(DE.nounCases(['Tisch', 'n', 'm', 'Tische']).Akk, ['den Tisch', 'die Tische'], 'Tisch 受格');
eq(DE.nounCases(['Kind', 'n', 'n', 'Kinder']).Dat, ['dem Kind', 'den Kindern'], 'Kind 與格');
eq(DE.nounCases(['Auto', 'n', 'n', 'Autos']).Dat, ['dem Auto', 'den Autos'], 'Auto 複數與格不加 n');
eq(DE.nounCases(['Herr', 'n', 'm', 'Herren']).Akk, ['den Herrn', 'die Herren'], 'Herr 弱變化受格');
eq(DE.nounCases(['Student', 'n', 'm', 'Studenten']).Dat, ['dem Studenten', 'den Studenten'], 'Student 弱變化與格');
eq(DE.nounCases(['Frau', 'n', 'f', 'Frauen']).Dat, ['der Frau', 'den Frauen'], 'Frau 與格');
eq(DE.nounCases(['Eltern', 'n', 'pl', '-']).Dat, ['', 'den Eltern'], 'Eltern 與格');

/* 7. 冠詞 */
eq([DE.defArt('m'), DE.defArt('f'), DE.defArt('n'), DE.defArt('m', true)], ['der', 'die', 'das', 'die'], '定冠詞主格');
eq([DE.defArt('m', false, 'Akk'), DE.defArt('m', false, 'Dat'), DE.defArt('f', false, 'Dat'), DE.defArt('n', true, 'Dat')], ['den', 'dem', 'der', 'den'], '定冠詞受格、與格');
eq([DE.indefArt('m', false, 'Akk'), DE.indefArt('f', false, 'Dat'), DE.indefArt('n', false, 'Dat')], ['einen', 'einer', 'einem'], '不定冠詞');
eq(DE.casesOf('der', 'f', false), ['Dat', 'Gen'], 'der＋陰性');
eq(DE.casesOf('den', 'm', true), ['Dat'], 'den＋複數');
eq(DE.casesOf('die', 'f', false), ['Nom', 'Akk'], 'die＋陰性');
eq([DE.artPrep('in', 'dem'), DE.artPrep('zu', 'der'), DE.artPrep('in', 'die')], ['im', 'zur', 'in die'], '介係詞縮寫');

/* 8. 形容詞 */
const ADJ_REF = {
  gut: ['gut', 'besser', 'am besten'], groß: ['groß', 'größer', 'am größten'], alt: ['alt', 'älter', 'am ältesten'], klein: ['klein', 'kleiner', 'am kleinsten'],
  teuer: ['teuer', 'teurer', 'am teuersten'], dunkel: ['dunkel', 'dunkler', 'am dunkelsten'], hoch: ['hoch', 'höher', 'am höchsten'], warm: ['warm', 'wärmer', 'am wärmsten'],
  kalt: ['kalt', 'kälter', 'am kältesten'], kurz: ['kurz', 'kürzer', 'am kürzesten'], lang: ['lang', 'länger', 'am längsten'], jung: ['jung', 'jünger', 'am jüngsten'],
  heiß: ['heiß', 'heißer', 'am heißesten'], müde: ['müde', 'müder', 'am müdesten'], leise: ['leise', 'leiser', 'am leisesten'], interessant: ['interessant', 'interessanter', 'am interessantesten'],
  schnell: ['schnell', 'schneller', 'am schnellsten'], nah: ['nah', 'näher', 'am nächsten'], gesund: ['gesund', 'gesünder', 'am gesündesten'], schlecht: ['schlecht', 'schlechter', 'am schlechtesten'],
  neu: ['neu', 'neuer', 'am neuesten'], spät: ['spät', 'später', 'am spätesten'], frisch: ['frisch', 'frischer', 'am frischesten'], süß: ['süß', 'süßer', 'am süßesten'], sauer: ['sauer', 'saurer', 'am sauersten'],
  praktisch: ['praktisch', 'praktischer', 'am praktischsten'], spannend: ['spannend', 'spannender', 'am spannendsten'], stark: ['stark', 'stärker', 'am stärksten'], rot: ['rot'], super: ['super']
};
W.forEach(e => { if (e[1] === 'adj' && ADJ_REF[e[0]]) eq(DE.adjForms(e), ADJ_REF[e[0]], `${e[0]} 的比較級`); });
Object.keys(ADJ_REF).forEach(k => ok(W.some(e => e[0] === k && e[1] === 'adj'), `形容詞參考表的 ${k} 不在單字庫`));
const ATT_REF = { neu: ['der neue', 'ein neuer', 'ein neues', 'die neuen'], hoch: ['der hohe', 'ein hoher', 'ein hohes', 'die hohen'], teuer: ['der teure', 'ein teurer', 'ein teures', 'die teuren'], dunkel: ['der dunkle', 'ein dunkler', 'ein dunkles', 'die dunklen'], müde: ['der müde', 'ein müder', 'ein müdes', 'die müden'] };
W.forEach(e => { if (e[1] === 'adj' && ATT_REF[e[0]]) { const a = DE.adjAttr(e); eq([a.def.m, a.ind.m, a.ind.n, a.def.pl], ATT_REF[e[0]], `${e[0]} 名詞前的詞尾`); } });
W.filter(e => e[1] === 'adj').forEach(e => {
  const sp = DE.spec(e[3]);
  Object.keys(sp).forEach(k => ok(['cmp', 'sup', 'att', 'nocmp', 'inv', 'pred'].includes(k), `${e[0]}：形容詞規格有未知欄位 ${k}`));
  const a = DE.adjInfo(e);
  if (a.cmp) ok(/er$/.test(a.cmp) && /ten$/.test(a.sup), `${e[0]} 比較級可疑：${a.cmp}／${a.sup}`);
});

/* 9. 動詞變化（逐字寫出的參考表：現在式、過去分詞、助動詞、命令式 du|ihr|Sie|wir） */
const REF = {
  machen: ['mache machst macht machen macht machen', 'gemacht', 'haben', 'mach|macht|machen Sie|machen wir'],
  arbeiten: ['arbeite arbeitest arbeitet arbeiten arbeitet arbeiten', 'gearbeitet', 'haben', 'arbeite|arbeitet|arbeiten Sie|arbeiten wir'],
  öffnen: ['öffne öffnest öffnet öffnen öffnet öffnen', 'geöffnet', 'haben', 'öffne|öffnet|öffnen Sie|öffnen wir'],
  tanzen: ['tanze tanzt tanzt tanzen tanzt tanzen', 'getanzt', 'haben', 'tanz|tanzt|tanzen Sie|tanzen wir'],
  heißen: ['heiße heißt heißt heißen heißt heißen', 'geheißen', 'haben', 'heiß|heißt|heißen Sie|heißen wir'],
  wandern: ['wandere wanderst wandert wandern wandert wandern', 'gewandert', 'sein', 'wandere|wandert|wandern Sie|wandern wir'],
  klingeln: ['klingle klingelst klingelt klingeln klingelt klingeln', 'geklingelt', 'haben', 'klingle|klingelt|klingeln Sie|klingeln wir'],
  studieren: ['studiere studierst studiert studieren studiert studieren', 'studiert', 'haben', 'studier|studiert|studieren Sie|studieren wir'],
  besuchen: ['besuche besuchst besucht besuchen besucht besuchen', 'besucht', 'haben', 'besuch|besucht|besuchen Sie|besuchen wir'],
  gehören: ['gehöre gehörst gehört gehören gehört gehören', 'gehört', 'haben', ''],
  reisen: ['reise reist reist reisen reist reisen', 'gereist', 'sein', 'reis|reist|reisen Sie|reisen wir'],
  fahren: ['fahre fährst fährt fahren fahrt fahren', 'gefahren', 'sein', 'fahr|fahrt|fahren Sie|fahren wir'],
  schlafen: ['schlafe schläfst schläft schlafen schlaft schlafen', 'geschlafen', 'haben', 'schlaf|schlaft|schlafen Sie|schlafen wir'],
  laufen: ['laufe läufst läuft laufen lauft laufen', 'gelaufen', 'sein', 'lauf|lauft|laufen Sie|laufen wir'],
  essen: ['esse isst isst essen esst essen', 'gegessen', 'haben', 'iss|esst|essen Sie|essen wir'],
  lesen: ['lese liest liest lesen lest lesen', 'gelesen', 'haben', 'lies|lest|lesen Sie|lesen wir'],
  sehen: ['sehe siehst sieht sehen seht sehen', 'gesehen', 'haben', 'sieh|seht|sehen Sie|sehen wir'],
  geben: ['gebe gibst gibt geben gebt geben', 'gegeben', 'haben', 'gib|gebt|geben Sie|geben wir'],
  nehmen: ['nehme nimmst nimmt nehmen nehmt nehmen', 'genommen', 'haben', 'nimm|nehmt|nehmen Sie|nehmen wir'],
  sprechen: ['spreche sprichst spricht sprechen sprecht sprechen', 'gesprochen', 'haben', 'sprich|sprecht|sprechen Sie|sprechen wir'],
  helfen: ['helfe hilfst hilft helfen helft helfen', 'geholfen', 'haben', 'hilf|helft|helfen Sie|helfen wir'],
  vergessen: ['vergesse vergisst vergisst vergessen vergesst vergessen', 'vergessen', 'haben', 'vergiss|vergesst|vergessen Sie|vergessen wir'],
  halten: ['halte hältst hält halten haltet halten', 'gehalten', 'haben', 'halte|haltet|halten Sie|halten wir'],
  finden: ['finde findest findet finden findet finden', 'gefunden', 'haben', 'finde|findet|finden Sie|finden wir'],
  gehen: ['gehe gehst geht gehen geht gehen', 'gegangen', 'sein', 'geh|geht|gehen Sie|gehen wir'],
  kommen: ['komme kommst kommt kommen kommt kommen', 'gekommen', 'sein', 'komm|kommt|kommen Sie|kommen wir'],
  bleiben: ['bleibe bleibst bleibt bleiben bleibt bleiben', 'geblieben', 'sein', 'bleib|bleibt|bleiben Sie|bleiben wir'],
  verstehen: ['verstehe verstehst versteht verstehen versteht verstehen', 'verstanden', 'haben', 'versteh|versteht|verstehen Sie|verstehen wir'],
  sein: ['bin bist ist sind seid sind', 'gewesen', 'sein', 'sei|seid|seien Sie|seien wir'],
  haben: ['habe hast hat haben habt haben', 'gehabt', 'haben', 'hab|habt|haben Sie|haben wir'],
  werden: ['werde wirst wird werden werdet werden', 'geworden', 'sein', 'werde|werdet|werden Sie|werden wir'],
  wissen: ['weiß weißt weiß wissen wisst wissen', 'gewusst', 'haben', ''],
  können: ['kann kannst kann können könnt können', 'gekonnt', 'haben', ''],
  müssen: ['muss musst muss müssen müsst müssen', 'gemusst', 'haben', ''],
  wollen: ['will willst will wollen wollt wollen', 'gewollt', 'haben', ''],
  dürfen: ['darf darfst darf dürfen dürft dürfen', 'gedurft', 'haben', ''],
  mögen: ['mag magst mag mögen mögt mögen', 'gemocht', 'haben', ''],
  möchten: ['möchte möchtest möchte möchten möchtet möchten', '', 'haben', ''],
  kennen: ['kenne kennst kennt kennen kennt kennen', 'gekannt', 'haben', 'kenn|kennt|kennen Sie|kennen wir'],
  bringen: ['bringe bringst bringt bringen bringt bringen', 'gebracht', 'haben', 'bring|bringt|bringen Sie|bringen wir'],
  denken: ['denke denkst denkt denken denkt denken', 'gedacht', 'haben', 'denk|denkt|denken Sie|denken wir'],
  tun: ['tue tust tut tun tut tun', 'getan', 'haben', 'tu|tut|tun Sie|tun wir'],
  aufstehen: ['stehe auf|stehst auf|steht auf|stehen auf|steht auf|stehen auf', 'aufgestanden', 'sein', 'steh auf|steht auf|stehen Sie auf|stehen wir auf'],
  anrufen: ['rufe an|rufst an|ruft an|rufen an|ruft an|rufen an', 'angerufen', 'haben', 'ruf an|ruft an|rufen Sie an|rufen wir an'],
  einkaufen: ['kaufe ein|kaufst ein|kauft ein|kaufen ein|kauft ein|kaufen ein', 'eingekauft', 'haben', 'kauf ein|kauft ein|kaufen Sie ein|kaufen wir ein'],
  fernsehen: ['sehe fern|siehst fern|sieht fern|sehen fern|seht fern|sehen fern', 'ferngesehen', 'haben', 'sieh fern|seht fern|sehen Sie fern|sehen wir fern'],
  einladen: ['lade ein|lädst ein|lädt ein|laden ein|ladet ein|laden ein', 'eingeladen', 'haben', 'lade ein|ladet ein|laden Sie ein|laden wir ein'],
  anfangen: ['fange an|fängst an|fängt an|fangen an|fangt an|fangen an', 'angefangen', 'haben', 'fang an|fangt an|fangen Sie an|fangen wir an'],
  kennenlernen: ['lerne kennen|lernst kennen|lernt kennen|lernen kennen|lernt kennen|lernen kennen', 'kennengelernt', 'haben', 'lern kennen|lernt kennen|lernen Sie kennen|lernen wir kennen'],
  'sich freuen': ['freue mich|freust dich|freut sich|freuen uns|freut euch|freuen sich', 'gefreut', 'haben', 'freu dich|freut euch|freuen Sie sich|freuen wir uns'],
  'sich anziehen': ['ziehe mich an|ziehst dich an|zieht sich an|ziehen uns an|zieht euch an|ziehen sich an', 'angezogen', 'haben', 'zieh dich an|zieht euch an|ziehen Sie sich an|ziehen wir uns an'],
  'sich entschuldigen': ['entschuldige mich|entschuldigst dich|entschuldigt sich|entschuldigen uns|entschuldigt euch|entschuldigen sich', 'entschuldigt', 'haben', 'entschuldige dich|entschuldigt euch|entschuldigen Sie sich|entschuldigen wir uns']
};
const typeOf = {}; W.forEach(e => { if (/^v/.test(e[1])) typeOf[e[0]] = e[1]; });
for (const v of Object.keys(REF)) {
  ok(!!typeOf[v], `參考表的動詞 ${v} 不在單字資料裡`);
  if (!typeOf[v]) continue;
  const c = DE.conjugate(v, typeOf[v]);
  const [pres, pp, aux, imp] = REF[v];
  eq(c.presentFull.join(/\|/.test(pres) ? '|' : ' '), pres, `${v} 現在式`);
  eq(c.pp, pp, `${v} 過去分詞`);
  if (pp) eq(c.aux, aux, `${v} 完成式助動詞`);
  eq(c.imperative ? c.imperative.join('|') : '', imp, `${v} 命令式`);
}
eq(DE.conjugate('aufstehen', 'v-st').passato[0], 'bin aufgestanden', 'aufstehen 完成式');
eq(DE.conjugate('sich freuen', 'v').passato[3], 'haben uns gefreut', 'sich freuen 完成式 wir');
eq(DE.conjugate('fahren', 'v-st').passato[2], 'ist gefahren', 'fahren 完成式 er');
W.filter(e => /^v/.test(e[1])).forEach(e => {
  const sp = DE.spec(e[3]);
  Object.keys(sp).forEach(k => ok(['pp', 'aux', 'sep', 'du', 'er', 'imp', 'pres', 'nopast', 'noimp', 'note'].includes(k), `${e[0]}：動詞規格有未知欄位 ${k}`));
  if (sp.sep) ok(DE.baseOf(e[0]).startsWith(sp.sep), `${e[0]}：前綴 ${sp.sep} 不對`);
  if (e[1] === 'v-st') ok(!!sp.pp, `${e[0]}：強變化動詞要寫 pp`);
  if (sp.aux) ok(sp.aux === 'sein', `${e[0]}：aux 只能寫 sein`);
  const c = DE.conjugate(e[0], e[1]);
  ok(c.present.length === 6 && c.present.every(x => /^[a-zäöüß]+$/.test(x)), `${e[0]} 現在式不完整：${c.present}`);
  if (e[0] !== 'möchten') ok(/^[a-zäöüß]+$/.test(c.pp) && /(t|n)$/.test(c.pp), `${e[0]} 過去分詞可疑：${c.pp}`);
  if (sp.sep) ok(c.pp.startsWith(sp.sep), `${e[0]} 分離動詞的過去分詞要以前綴開頭：${c.pp}`);
  ok(c.passato.length === (c.pp ? 6 : 0), `${e[0]} 完成式不完整`);
  // 過去分詞要在查詢表裡
  if (c.pp) ok((LOOK.get(c.pp) || []).some(x => x.lemma === e[0]), `${e[0]} 的過去分詞查不到`);
});

/* 10. 答案比對 */
eq(DE.checkAnswer('Mache', 'mache'), 'ok', '大小寫（動詞）');
eq(DE.checkAnswer('tisch', 'Tisch', { pos: 'n' }), 'accent', '名詞小寫要提醒');
eq(DE.checkAnswer('schoen', 'schön'), 'accent', 'oe 代替 ö');
eq(DE.checkAnswer('schon', 'schön'), 'accent', '漏掉變音');
eq(DE.checkAnswer('Strasse', 'Straße'), 'accent', 'ss 代替 ß');
eq(DE.checkAnswer('macht', 'mache'), 'wrong', '答錯');
eq(DE.checkAnswer('  Guten   Morgen ', 'Guten Morgen'), 'ok', '多餘空白');
eq(DE.checkAnswer('wie bitte?', 'Wie bitte'), 'ok', '問號');

/* 11. 文法點都有例句 */
const all = W.map(e => e[6]);
DE.GRAMMAR.forEach(g => {
  const n = all.filter(s => DE.grammarMatch(g, s).length).length + (g.ex || []).length;
  ok(n >= 3, `文法點「${g.title}」只找到 ${n} 個例句`);
  (g.ex || []).forEach(x => ok(DE.grammarMatch(g, x[0]).length > 0, `文法點「${g.title}」的範例句沒有被標出：${x[0]}`));
});
const G1 = id => DE.GRAMMAR.find(g => g.id === id);
const hit = (id, s) => DE.grammarMatch(G1(id), s).map(r => s.slice(r[0], r[1]));
eq(hit('sep', 'Ich stehe jeden Tag um sieben Uhr auf.'), ['stehe', 'auf'], '分離動詞標記');
eq(hit('sep', 'Wir fahren morgen nach Hamburg.'), [], '不是分離動詞');
eq(hit('perfSein' in {} ? '' : 'perf-sein', 'Wir sind nach München umgezogen.'), ['sind', 'umgezogen'], '完成式 sein');
eq(hit('perf-haben', 'Ich habe meinen Schlüssel verloren.'), ['habe', 'verloren'], '完成式 haben');
eq(hit('modal', 'Ich muss heute arbeiten.'), ['muss', 'arbeiten'], '情態動詞');
eq(hit('akk', 'Ich suche meinen Schlüssel.'), ['meinen'], '受格');
eq(hit('dat', 'Ich fahre mit dem Bus.'), ['dem'], '與格');
eq(hit('dat', 'Wir wohnen in einer Wohnung.'), ['einer'], '與格陰性');
eq(hit('imper', 'Gehen Sie hier links.'), ['Gehen', 'Sie'], '命令式 Sie');
eq(hit('imper', 'Kommst du mit ins Kino?'), [], '問句不是命令式');
eq(hit('subord', 'Ich glaube, dass er krank ist.'), ['dass', 'ist'], 'dass 子句');
eq(hit('refl', 'Ich freue mich auf das Wochenende.'), ['freue', 'mich'], '反身動詞');
eq(hit('adj-end', 'Ich habe ein neues Fahrrad.'), ['neues'], '形容詞詞尾');
eq(hit('compar', 'Berlin ist größer als München.'), ['größer', 'als'], '比較級');
eq(hit('janein', 'Hast du heute Zeit?'), ['Hast'], '是非問句');
eq(hit('janein', 'Wo ist die Toilette?'), [], 'W 問句不是是非問句');

/* 12. 冠詞題可以產生，而且干擾選項都是錯的 */
{
  let made = 0, sentQ = 0, genderQ = 0;
  const seenKinds = new Set();
  W.forEach(e => {
    [0.1, 0.6, 0.9].forEach(r0 => {
      const q = DE.makeArtQuestion(e, LOOK, () => r0);
      if (!q) return;
      made++; seenKinds.add(q.kind);
      if (q.gender) genderQ++; else sentQ++;
      ok(q.options.includes(q.answer) && new Set(q.options).size === q.options.length && q.options.length >= 3, `${e[0]}：冠詞題選項有問題 ${q.options}`);
      q.options.filter(o => o !== q.answer).forEach(o => ok(DE.artWrong(q, o), `${e[0]}：干擾選項「${o}」可能也對`));
      ok(!!q.info, `${e[0]}：冠詞題沒有說明`);
      if (!q.gender) ok(q.sentence.slice(q.before.length, q.before.length + q.answer.length).toLowerCase() === q.answer.toLowerCase(), `${e[0]}：冠詞題位置不對`);
    });
  });
  ok(sentQ > 300, `從例句挖出的冠詞題太少：${sentQ}`);
  ok(genderQ > 300, `性別題太少：${genderQ}`);
  ['art', 'indef', 'artprep'].forEach(k => ok(seenKinds.has(k), `沒有產生 ${k} 類的冠詞題`));
  // 雙向介係詞：im Park 的選項不能有 in den
  const q = DE.makeArtQuestion(['x', 'adv', '-', '-', '', '', 'Wir gehen im Park spazieren.', '我們在公園散步。', 'x'], LOOK, () => 0.1);
  ok(q && !q.options.includes('in den') && q.answer === 'im', '雙向介係詞的干擾選項：' + (q && q.options));
  const q2 = DE.makeArtQuestion(['x', 'adv', '-', '-', '', '', 'Ich suche den Schlüssel.', '我在找鑰匙。', 'x'], LOOK, () => 0.1);
  ok(q2 && q2.answer === 'den' && /受格/.test(q2.info), '受格冠詞題的說明：' + (q2 && q2.info));
}

/* 13. 動詞變化題：選項不重複、只有一個正確 */
{
  let seed = 7; const rnd = () => ((seed = (seed * 9301 + 49297) % 233280) / 233280);
  W.filter(e => /^v/.test(e[1])).forEach(e => {
    for (let k = 0; k < 8; k++) {
      const q = DE.makeVerbQuestion(e, rnd);
      ok(new Set(q.options).size === q.options.length && q.options.filter(o => o === q.answer).length === 1, `${e[0]}：動詞題選項重複 ${q.options}`);
      ok(q.options.length >= 3, `${e[0]}：動詞題選項太少 ${q.options}`);
    }
  });
}
/* 14. 介係詞練習句與發音資料 */
DE.PREP_DRILLS.forEach(d => {
  ok(d[0].includes('___') && !d[2].includes(d[1]) && d[2].length === 3 && new Set(d[2]).size === 3, `介係詞練習格式錯誤：${d[0]}`);
  DE.tokenize(d[0].replace('___', d[1])).filter(t => t.w).forEach(t => { const k = DE.norm(t.t).toLowerCase(); ok(LOOK.has(k) || DE.NAMES[k], `介係詞練習句查不到「${t.t}」`); });
});
eq(DE.ALPHABET.length, 30, '字母數（26＋4）');
DE.ALPHABET.forEach(a => ok(W.some(e => e[0] === a[4]), `字母 ${a[0]} 的例字 ${a[4]} 不在單字庫`));
DE.ALPHABET.slice(0, 26).forEach(a => ok(a[4].toLowerCase().includes(a[0].toLowerCase()), `字母 ${a[0]} 的例字 ${a[4]} 沒有這個字母`));
DE.READ_ITEMS.forEach(r => ok(new Set(r.opts).size === r.opts.length && r.opts.every(Boolean) && r.w.toLowerCase().includes(r.part.toLowerCase()), `讀法題有問題：${r.w}`));
DE.LISTEN_PAIRS.forEach(p => ok(p.length === 2 && p[0] !== p[1], `聽音題有問題：${p}`));

/* 15. 規則頁與單字頁的表格 */
DE.RULES.forEach(R => {
  const list = W.filter(R.filter);
  ok(list.length > 0, `規則「${R.title}」沒有字`);
  R.demo.forEach(d => ok(W.some(e => e[0] === d && R.filter(e)), `規則「${R.title}」的示範字 ${d} 不在範圍內`));
  const t = DE.demoTable(R.id, R.demo.map(d => W.find(e => e[0] === d && R.filter(e))).filter(Boolean));
  if (t) ok(t.rows.length === R.demo.length && t.rows.every(r => r.length === t.head.length), `規則「${R.title}」的示範表格式不對`);
});
W.filter(e => e[1] === 'n' || e[1] === 'adj').forEach(e => { const t = DE.formsTable(e); ok(t && t.rows.length > 0, `${e[0]}：變化表是空的`); });

/* 結果 */
const nouns = W.filter(e => e[1] === 'n').length, verbs = W.filter(e => /^v/.test(e[1])).length;
/* 文法關卡：每個文法點剛好出現一次 */
const pathIds = (DE.GX_PATH || []).flatMap(x => x[2]);
eq(pathIds.slice().sort(), DE.GRAMMAR.map(g => g.id).sort(), '文法關卡要剛好包含所有文法點');
/* 文法練習題（DE.GX） */
const GX = DE.GX || {};
DE.GRAMMAR.forEach(g => ok(GX[g.id], `文法 ${g.id} 沒有練習題`));
Object.entries(GX).forEach(([id, x]) => {
  ok(DE.GRAMMAR.some(g => g.id === id), `GX ${id} 不在 GRAMMAR`);
  ok(Array.isArray(x.ex) && x.ex.length >= 1, `GX ${id} 沒有範例`);
  ok(Array.isArray(x.q) && x.q.length >= 3, `GX ${id} 題目少於 3`);
  (x.ex || []).forEach((e, i) => {
    ok(e.length === 5 && e[0] && e[1] && e[4], `GX ${id} 範例 ${i} 欄位不全`);
    ok(Array.isArray(e[2]) && e[2].length >= 2 && e[2].every(p => p.length === 2 && p[0] && (p[1] || /^[,.—–!?]$/.test(p[0]))), `GX ${id} 範例 ${i} 拆字格式錯`);
    ok(e[2].every(p => e[0].includes(p[0])), `GX ${id} 範例 ${i} 拆字不在句子裡：${e[2].map(p => p[0]).filter(w => !e[0].includes(w))}`);
    ok(Array.isArray(e[3]) && e[3].length >= 1, `GX ${id} 範例 ${i} 沒有說明`);
    ok(/[。！？]$/.test(e[1]), `GX ${id} 範例 ${i} 中文沒句號：${e[1]}`);
  });
  (x.q || []).forEach((q, i) => {
    ok(q.length === 5 && q[0] && q[1] && q[3] && q[4], `GX ${id} 題 ${i} 欄位不全`);
    ok(q[0].includes('___'), `GX ${id} 題 ${i} 沒有空格：${q[0]}`);
    ok(Array.isArray(q[2]) && q[2].length >= 2 && q[2].length <= 3, `GX ${id} 題 ${i} 選項數`);
    ok(!q[2].includes(q[1]) && new Set(q[2]).size === q[2].length, `GX ${id} 題 ${i} 選項重複或含答案`);
  });
});
console.log(`單字 ${W.length} 個（名詞 ${nouns}、動詞 ${verbs}、形容詞 ${W.filter(e => e[1] === 'adj').length}），文法點 ${DE.GRAMMAR.length} 個`);
console.log(`檢查 ${checks} 項，失敗 ${fails} 項`);
failList.slice(0, 80).forEach(m => console.log(' ✗ ' + m));
process.exit(fails ? 1 : 0);
