/* 德文文法的範例拆解與練習題（2）：與格、介係詞、時間、過去、形容詞詞尾、長句子 */
(function (G) {
  const DE = G.DE || (G.DE = {});
  DE.GX = Object.assign(DE.GX || {}, {
    // ---------- 第 7 關：與格、代名詞、我的 ----------
    'dat': {
      ex: [['Ich gebe dem Kind einen Apfel.', '我給小孩一顆蘋果。', [['Ich', '我'], ['gebe', '給'], ['dem', '（給）那個'], ['Kind', '小孩'], ['einen', '一顆'], ['Apfel', '蘋果']],
        ['dem Kind：收到東西的人用與格，das → dem。', 'einen Apfel：被給的東西用受格。'],
        '「給誰」用與格：der／das → dem，die → der，複數 → den（名詞加 -n）。']],
      q: [['Ich schenke ___ Frau Blumen.', 'der', ['die', 'dem'], '我送那位女士花。', '陰性的與格是 der。'],
        ['Er hilft ___ Mann.', 'dem', ['den', 'der'], '他幫那個男人。', 'helfen 接與格，陽性 → dem。'],
        ['Ich gebe ___ Kindern Geld.', 'den', ['die', 'dem'], '我給孩子們錢。', '複數的與格是 den，名詞加 -n。']]
    },
    'pron-obj': {
      ex: [['Ich liebe dich.', '我愛你。', [['Ich', '我'], ['liebe', '愛'], ['dich', '你']],
        ['du 當受詞（被愛的人）變成 dich。'],
        '代名詞也會變格：ich → mich／mir，du → dich／dir。'],
        ['Kannst du mir helfen?', '你可以幫我嗎？', [['Kannst', '可以'], ['du', '你'], ['mir', '（給）我'], ['helfen', '幫忙']],
        ['helfen 接與格，所以是 mir 不是 mich。'],
        '受格：mich、dich、ihn、sie、es；與格：mir、dir、ihm、ihr、ihm。']],
      q: [['Ich sehe ___ . (du)', 'dich', ['dir', 'du'], '我看到你了。', 'sehen 接受格：du → dich。'],
        ['Das gehört ___ . (ich)', 'mir', ['mich', 'mein'], '這是我的。', 'gehören 接與格：ich → mir。'],
        ['Ich rufe ___ an. (er)', 'ihn', ['ihm', 'er'], '我打電話給他。', 'anrufen 接受格：er → ihn。']]
    },
    'gefallen': {
      ex: [['Das Buch gefällt mir.', '我喜歡這本書。', [['Das', '那本'], ['Buch', '書'], ['gefällt', '讓…喜歡'], ['mir', '（對）我']],
        ['字面是「這本書讓我喜歡」，書才是主詞。', '喜歡的人用與格 mir。'],
        'gefallen、schmecken、helfen、gehören 這些動詞，後面的人要用與格。']],
      q: [['Der Kuchen schmeckt ___ .', 'mir', ['mich', 'ich'], '這個蛋糕很好吃（我覺得）。', 'schmecken 接與格。'],
        ['Die Stadt gefällt ___ . (er)', 'ihm', ['ihn', 'er'], '他喜歡這座城市。', 'er 的與格是 ihm。'],
        ['Die Schuhe ___ mir.', 'gefallen', ['gefällt', 'gefallt'], '我喜歡這雙鞋。', 'Schuhe 是複數主詞，用 gefallen。']]
    },
    'poss': {
      ex: [['Mein Bruder und meine Schwester.', '我哥哥和我姊姊。', [['Mein', '我的'], ['Bruder', '哥哥'], ['und', '和'], ['meine', '我的'], ['Schwester', '姊姊']],
        ['mein 的詞尾跟 ein 一樣：陽性／中性 mein，陰性 meine。'],
        '「我的」就像「一個」：ein → mein，eine → meine，受格陽性 meinen。']],
      q: [['Das ist ___ Mutter.', 'meine', ['mein', 'meinen'], '這是我媽媽。', 'Mutter 陰性，用 meine。'],
        ['Ich suche ___ Schlüssel.', 'meinen', ['mein', 'meine'], '我在找我的鑰匙。', 'Schlüssel 陽性受格，用 meinen。'],
        ['Wie ist ___ Name? (Sie)', 'Ihr', ['Sie', 'Ihre'], '您貴姓大名？', '「您的」是 Ihr（大寫），Name 陽性主格。']]
    },
    'demo': {
      ex: [['Dieser Film ist gut, diese Serie nicht.', '這部電影很好看，這部影集不好看。', [['Dieser', '這部'], ['Film', '電影'], ['ist', '是'], ['gut', '好的'], [',', ''], ['diese', '這部'], ['Serie', '影集'], ['nicht', '不']],
        ['dieser 的詞尾跟 der 一樣：der → dieser、die → diese、das → dieses。'],
        '「這個」：把 der／die／das 的尾巴接在 dies- 後面。']],
      q: [['___ Buch ist neu.', 'Dieses', ['Dieser', 'Diese'], '這本書是新的。', 'Buch 中性，das → dieses。'],
        ['Ich kaufe ___ Tisch.', 'diesen', ['dieser', 'dieses'], '我買這張桌子。', 'Tisch 陽性受格，den → diesen。'],
        ['___ Frau ist meine Lehrerin.', 'Diese', ['Dieser', 'Dieses'], '這位女士是我的老師。', 'Frau 陰性，die → diese。']]
    },
    // ---------- 第 8 關：介係詞 ----------
    'prep-akk': {
      ex: [['Das Geschenk ist für dich.', '這個禮物是給你的。', [['Das', '這個'], ['Geschenk', '禮物'], ['ist', '是'], ['für', '給'], ['dich', '你']],
        ['für 後面一定接受格：du → dich。'],
        'für、ohne、durch、gegen、um 這五個後面一定接受格。']],
      q: [['Ich trinke Kaffee ohne ___ Zucker.', '—', ['den', 'dem'], '我喝咖啡不加糖。', 'ohne Zucker 不加冠詞。'],
        ['Das ist für ___ Vater.', 'meinen', ['meinem', 'mein'], '這是給我爸爸的。', 'für 接受格：Vater 陽性 → meinen。'],
        ['Wir gehen durch ___ Park.', 'den', ['dem', 'der'], '我們穿過公園。', 'durch 接受格：der → den。']]
    },
    'prep-dat': {
      ex: [['Ich fahre mit dem Bus.', '我搭公車。', [['Ich', '我'], ['fahre', '搭車'], ['mit', '用、和'], ['dem', '那台'], ['Bus', '公車']],
        ['mit 後面一定接與格：der Bus → dem Bus。'],
        'mit、nach、aus、zu、von、bei、seit 後面一定接與格。']],
      q: [['Ich wohne bei ___ Eltern.', 'meinen', ['meine', 'meiner'], '我住在爸媽家。', 'bei 接與格，複數 → meinen。'],
        ['Er kommt aus ___ Schweiz.', 'der', ['die', 'dem'], '他來自瑞士。', 'aus 接與格，die Schweiz → der Schweiz。'],
        ['Ich gehe mit ___ Freund.', 'meinem', ['meinen', 'mein'], '我和我的朋友去。', 'mit 接與格，陽性 → meinem。']]
    },
    'prep-wechsel': {
      ex: [['Das Buch liegt auf dem Tisch.', '書在桌上。', [['Das', '那本'], ['Buch', '書'], ['liegt', '躺著、放著'], ['auf', '在…上'], ['dem', '那張'], ['Tisch', '桌子']],
        ['問 Wo?（在哪裡）→ 與格 dem Tisch。'],
        'in、auf、an、unter… 這些介係詞：「在哪裡」用與格，「去哪裡」用受格。'],
        ['Ich lege das Buch auf den Tisch.', '我把書放到桌上。', [['Ich', '我'], ['lege', '放'], ['das', '那本'], ['Buch', '書'], ['auf', '到…上'], ['den', '那張'], ['Tisch', '桌子']],
        ['問 Wohin?（放到哪裡）→ 受格 den Tisch。'],
        '有移動到某處 → 受格；停在某處 → 與格。']],
      q: [['Die Katze schläft auf ___ Sofa.', 'dem', ['das', 'den'], '貓在沙發上睡覺。', '停在那裡（Wo?）→ 與格。'],
        ['Ich hänge das Bild an ___ Wand.', 'die', ['der', 'dem'], '我把畫掛到牆上。', '移動到那裡（Wohin?）→ 受格 die。'],
        ['Das Bild hängt an ___ Wand.', 'der', ['die', 'den'], '畫掛在牆上。', '停在那裡 → 與格，die → der。']]
    },
    'contract': {
      ex: [['Ich bin im Kino.', '我在電影院。', [['Ich', '我'], ['bin', '在'], ['im', '在那個…裡'], ['Kino', '電影院']],
        ['im ＝ in ＋ dem。'],
        '介係詞和冠詞常常縮寫：in dem → im、in das → ins、zu dem → zum、zu der → zur、an dem → am。'],
        ['Ich gehe ins Kino.', '我去電影院。', [['Ich', '我'], ['gehe', '去'], ['ins', '到那個…裡'], ['Kino', '電影院']],
        ['ins ＝ in ＋ das（去哪裡 → 受格）。'],
        '在裡面 im，進去 ins。']],
      q: [['Ich gehe ___ Arzt. (zu + dem)', 'zum', ['zur', 'zu'], '我去看醫生。', 'zu ＋ dem ＝ zum。'],
        ['Wir fahren ___ Schule. (zu + der)', 'zur', ['zum', 'zu die'], '我們去學校。', 'zu ＋ der ＝ zur。'],
        ['Er ist ___ Büro. (in + dem)', 'im', ['ins', 'in'], '他在辦公室。', 'in ＋ dem ＝ im。']]
    },
    'zuhause': {
      ex: [['Ich bin zu Hause, dann gehe ich nach Hause.', '我在家，然後我回家。', [['Ich', '我'], ['bin', '在'], ['zu', '在'], ['Hause', '家'], [',', ''], ['dann', '然後'], ['gehe', '去'], ['ich', '我'], ['nach', '往'], ['Hause', '家']],
        ['zu Hause＝在家（不動）。', 'nach Hause＝回家（移動）。'],
        '在家 zu Hause，回家 nach Hause，Hause 多一個 e 是固定寫法。']],
      q: [['Heute bleibe ich ___ Hause.', 'zu', ['nach', 'in'], '我今天待在家。', '待在家：zu Hause。'],
        ['Wann kommst du ___ Hause?', 'nach', ['zu', 'bei'], '你什麼時候回家？', '回家：nach Hause。'],
        ['Ist Anna ___ Hause?', 'zu', ['nach', 'im'], 'Anna 在家嗎？', '在家：zu Hause。']]
    },
    // ---------- 第 9 關：時間 ----------
    'time': {
      ex: [['Es ist halb neun.', '現在八點半。', [['Es', '它'], ['ist', '是'], ['halb', '一半（到）'], ['neun', '九']],
        ['halb neun＝「到九點還差一半」＝ 8:30，不是 9:30！'],
        '德文的「半」是往下一個小時算：halb drei＝2:30。'],
        ['Der Kurs beginnt um acht Uhr.', '課八點開始。', [['Der', '那堂'], ['Kurs', '課'], ['beginnt', '開始'], ['um', '在'], ['acht', '八'], ['Uhr', '點']],
        ['「在幾點」用 um。'],
        '問：Wie spät ist es? 答：Es ist… ；在幾點：um … Uhr。']],
      q: [['Der Film beginnt ___ zehn Uhr.', 'um', ['am', 'im'], '電影十點開始。', '在幾點用 um。'],
        ['Es ist ___ sieben. (6:30)', 'halb', ['halb nach', 'nach halb'], '現在六點半。', '6:30＝halb sieben。'],
        ['Es ist Viertel ___ drei. (3:15)', 'nach', ['vor', 'halb'], '現在三點十五分。', '過 15 分＝Viertel nach。']]
    },
    'days': {
      ex: [['Am Montag arbeite ich, im Mai fahre ich nach Italien.', '我星期一上班，五月要去義大利。', [['Am', '在'], ['Montag', '星期一'], ['arbeite', '工作'], ['ich', '我'], [',', ''], ['im', '在'], ['Mai', '五月'], ['fahre', '去'], ['ich', '我'], ['nach', '往'], ['Italien', '義大利']],
        ['星期用 am（＝an dem）。', '月份、季節用 im（＝in dem）。'],
        '星期 am Montag，月份 im Mai，季節 im Sommer。']],
      q: [['___ Sonntag schlafe ich lange.', 'Am', ['Im', 'Um'], '星期天我睡很久。', '星期前用 am。'],
        ['___ Winter ist es kalt.', 'Im', ['Am', 'Um'], '冬天很冷。', '季節前用 im。'],
        ['Mein Geburtstag ist ___ Juli.', 'im', ['am', 'um'], '我的生日在七月。', '月份前用 im。']]
    },
    // ---------- 第 10 關：過去 ----------
    'perf-haben': {
      ex: [['Ich habe Pizza gegessen.', '我吃了披薩。', [['Ich', '我'], ['habe', '有（助動詞）'], ['Pizza', '披薩'], ['gegessen', '吃了']],
        ['habe 放第二位，過去分詞 gegessen 放句尾（句框）。', '過去分詞常是 ge- … -t 或 ge- … -en。'],
        '口語說過去的事，用 haben ＋ 過去分詞：Ich habe gespielt、Ich habe gegessen。']],
      q: [['Ich habe Deutsch ___ . (lernen)', 'gelernt', ['gelernen', 'lernt'], '我學了德文。', '規則動詞：ge- ＋ 詞幹 ＋ -t。'],
        ['Hast du schon ___ ? (essen)', 'gegessen', ['geesst', 'gegesst'], '你吃過了嗎？', 'essen 的過去分詞是 gegessen。'],
        ['Wir ___ Fußball gespielt.', 'haben', ['sind', 'hat'], '我們踢了足球。', 'spielen 用 haben 當助動詞。']]
    },
    'perf-sein': {
      ex: [['Ich bin nach Berlin gefahren.', '我去了柏林。', [['Ich', '我'], ['bin', '是（助動詞）'], ['nach', '往'], ['Berlin', '柏林'], ['gefahren', '去了（坐車）']],
        ['移動（去、來、開車）或狀態改變的動詞，用 sein 當助動詞。'],
        '大部分動詞用 haben，「移動」類的用 sein：ich bin gegangen、ich bin gekommen。']],
      q: [['Er ___ nach Hause gegangen.', 'ist', ['hat', 'sind'], '他回家了。', 'gehen 是移動，用 sein。'],
        ['Wir sind spät ___ . (kommen)', 'gekommen', ['gekommt', 'kommen'], '我們很晚到。', 'kommen 的過去分詞是 gekommen。'],
        ['___ du gut geschlafen?', 'Hast', ['Bist', 'Hat'], '你睡得好嗎？', 'schlafen 不是移動，用 haben。']]
    },
    'praet': {
      ex: [['Gestern war ich krank und hatte Fieber.', '我昨天生病，發燒了。', [['Gestern', '昨天'], ['war', '是（過去）'], ['ich', '我'], ['krank', '生病的'], ['und', '和'], ['hatte', '有（過去）'], ['Fieber', '發燒']],
        ['sein 和 haben 說過去，常用 war、hatte，不用完成式。'],
        'war＝was（是），hatte＝had（有），口語也很常用。']],
      q: [['Gestern ___ ich müde.', 'war', ['bin', 'hatte'], '我昨天很累。', 'sein 的過去式 war。'],
        ['Wir ___ keine Zeit.', 'hatten', ['hatte', 'waren'], '我們（那時）沒時間。', 'haben 的過去式，wir → hatten。'],
        ['Wo ___ du gestern?', 'warst', ['war', 'wart'], '你昨天在哪裡？', 'du 的過去式是 warst。']]
    },
    'refl': {
      ex: [['Ich freue mich.', '我很高興。', [['Ich', '我'], ['freue', '使高興'], ['mich', '我自己']],
        ['sich freuen 字面是「讓自己高興」，要加 mich。'],
        '反身動詞要帶一個「自己」：mich、dich、sich、uns、euch、sich。']],
      q: [['Du freust ___ .', 'dich', ['dir', 'sich'], '你很高興。', 'du 的反身代名詞是 dich。'],
        ['Er wäscht ___ .', 'sich', ['ihn', 'mich'], '他在洗澡（洗自己）。', '「他自己」是 sich。'],
        ['Wir treffen ___ morgen.', 'uns', ['sich', 'wir'], '我們明天見面。', 'wir 的反身代名詞是 uns。']]
    },
    // ---------- 第 11 關：形容詞和長句子 ----------
    'adj-end': {
      ex: [['Ich habe einen neuen Laptop.', '我有一台新筆電。', [['Ich', '我'], ['habe', '有'], ['einen', '一台'], ['neuen', '新的'], ['Laptop', '筆電']],
        ['形容詞放在名詞前面就要加詞尾。', 'einen（陽性受格）後面的形容詞加 -en。'],
        '形容詞在名詞前要加詞尾；最常見的是 -e 和 -en。看前面的冠詞和格決定。']],
      q: [['Das ist ein ___ Auto.', 'neues', ['neue', 'neuen'], '這是一台新車。', 'ein ＋ 中性主格：形容詞加 -es。'],
        ['Der ___ Mann ist mein Vater.', 'alte', ['alter', 'alten'], '那個老先生是我爸爸。', 'der 後面主格加 -e。'],
        ['Ich trinke ___ Kaffee.', 'schwarzen', ['schwarze', 'schwarzer'], '我喝黑咖啡。', '沒冠詞＋陽性受格：-en。']]
    },
    'compar': {
      ex: [['Berlin ist größer als München.', '柏林比慕尼黑大。', [['Berlin', '柏林'], ['ist', '是'], ['größer', '更大'], ['als', '比'], ['München', '慕尼黑']],
        ['比較級：形容詞 ＋ -er，短字常加變音：groß → größer。', 'als＝比。'],
        '「A 比 B 更…」：A ist ＋ 形容詞-er ＋ als B。最高級：am ＋ 形容詞-sten。']],
      q: [['Der Zug ist schneller ___ das Auto.', 'als', ['wie', 'dann'], '火車比汽車快。', '比較用 als。'],
        ['Im Sommer ist es ___ als im Winter.', 'wärmer', ['warmer', 'mehr warm'], '夏天比冬天暖和。', 'warm → wärmer（加變音）。'],
        ['Er läuft am ___ .', 'schnellsten', ['schnellste', 'schneller'], '他跑得最快。', '最高級：am ＋ -sten。']]
    },
    'subord': {
      ex: [['Ich lerne Deutsch, weil ich in Berlin studieren will.', '我學德文，因為我想在柏林念書。', [['Ich', '我'], ['lerne', '學'], ['Deutsch', '德文'], [',', ''], ['weil', '因為'], ['ich', '我'], ['in', '在'], ['Berlin', '柏林'], ['studieren', '念書'], ['will', '想']],
        ['weil 後面的子句，動詞要跑到最後：will 在句尾。'],
        'weil、dass、wenn 這類連接詞會把動詞踢到子句最後面（跟 denn 不一樣）。']],
      q: [['Ich bleibe zu Hause, weil ich krank ___ .', 'bin', ['bin ich', 'sein'], '我待在家，因為我生病了。', 'weil 子句的動詞放最後。'],
        ['Ich weiß, dass er Deutsch ___ .', 'spricht', ['spricht er', 'sprechen'], '我知道他會說德文。', 'dass 子句的動詞放最後。'],
        ['___ es regnet, bleibe ich zu Hause.', 'Wenn', ['Denn', 'Aber'], '如果下雨，我就待在家。', 'wenn＝如果；子句在前時，主句動詞緊接在逗號後。']]
    }
  });
})(typeof window !== 'undefined' ? window : globalThis);
