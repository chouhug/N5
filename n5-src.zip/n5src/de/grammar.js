/* A1 文法點與詞性變化規則（德文）
   每個文法點：id、title、tag（分類）、body（說明 HTML）、m（比對規則）、ex（額外例句）
   比對規則 m：{ re: 正規式字串, cs: 是否分大小寫 } 或 { tok: 判斷函式名稱 } */
(function (G) {
  'use strict';
  const DE = G.DE || (G.DE = {});

  /* ---------- 比對工具 ---------- */
  let LK = null;
  function look() {
    if (!LK) LK = DE.buildLookup(DE.W, Object.assign({}, DE.EXTRA_FORMS, DE.EXTRA_LOOKUP));
    return LK;
  }
  DE.getLookup = look;
  const POS_OF = () => {
    if (DE._posOf) return DE._posOf;
    const m = {}; DE.W.forEach(e => { if (!m[e[0]] || /^v/.test(e[1])) m[e[0]] = e[1]; }); return (DE._posOf = m);
  };
  const ENTRY = () => DE._entry || (DE._entry = Object.fromEntries(DE.W.map(e => [e[0] + '|' + e[1], e])));
  function toks(s) {
    const out = []; let i = 0;
    for (const t of DE.tokenize(s)) { out.push({ t: t.t, w: t.w, s: i, e: i + t.t.length, k: DE.norm(t.t).toLowerCase() }); i += t.t.length; }
    return out;
  }
  const info = k => look().get(k) || [];
  const has = (k, pred) => info(k).some(pred);
  const posOf = l => POS_OF()[l] || '';
  const isV = x => /^v/.test(posOf(x.lemma));
  const words = T => T.filter(t => t.w);
  const nextW = (T, i) => T.slice(i + 1).find(x => x.w);
  const prevW = (T, i) => T.slice(0, i).filter(x => x.w).pop();
  const idx = (T, f) => T.map((t, i) => (t.w && f(t, i)) ? i : -1).filter(i => i >= 0);
  const firstW = T => T.findIndex(t => t.w);
  const cap = t => /^[A-ZÄÖÜ]/.test(t.t);
  // 名詞：大寫開頭，而且查得到名詞（句首的字也可能是名詞）
  const nounInfo = t => info(t.k).filter(x => posOf(x.lemma) === 'n' && ENTRY()[x.lemma + '|n']);
  const isNoun = (T, i) => cap(T[i]) && nounInfo(T[i]).length > 0 && !(i === firstW(T) && !nounInfo(T[i]).length);
  const isAdjForm = t => has(t.k, x => posOf(x.lemma) === 'adj' && /詞尾/.test(x.desc));
  // 冠詞後面（跳過形容詞）的名詞位置
  function nounAfter(T, i) {
    let j = T.indexOf(nextW(T, i));
    while (j > 0 && T[j] && !cap(T[j]) && isAdjForm(T[j])) j = T.indexOf(nextW(T, j));
    return j > 0 && T[j] && isNoun(T, j) ? j : -1;
  }
  const DEF = ['der', 'die', 'das', 'den', 'dem', 'des'];
  const INDEF = ['ein', 'eine', 'einen', 'einem', 'einer', 'eines'];
  const POSS = /^(mein|dein|sein|ihr|unser|eur|euer)(e|en|em|er|es)?$/;
  const SEIN = ['bin', 'bist', 'ist', 'sind', 'seid'];
  const HABEN = ['habe', 'hast', 'hat', 'haben', 'habt'];
  const MODAL = new Set(['können', 'müssen', 'dürfen', 'wollen', 'sollen', 'mögen', 'möchten']);
  const finite = (t, pred) => has(t.k, x => isV(x) && /^現在式/.test(x.desc) && (!pred || pred(x)));
  const isInf = t => has(t.k, x => isV(x) && /^原形/.test(x.desc));
  const isPP = (t, aux) => has(t.k, x => isV(x) && /^過去分詞/.test(x.desc) && (!aux || x.desc.includes('：' + aux)));
  // 所有格、dieser、jeder 的詞尾換成 kein／定冠詞，方便判斷格
  const artNorm = k => {
    let m = k.match(/^(mein|dein|sein|ihr|unser|eur|euer)(e|en|em|er|es)?$/);
    if (m) return 'kein' + (m[1] === 'euer' ? '' : (m[2] || ''));
    m = k.match(/^(dies|jed)(er|e|en|em|es)$/);
    if (m) return { er: 'der', e: 'die', en: 'den', em: 'dem', es: 'das' }[m[2]];
    return k;
  };
  const nounCase = (T, i, cases, sgOnly) => {
    // 冠詞 T[i] 配後面名詞，能不能是 cases 之一
    const j = nounAfter(T, i); if (j < 0) return false;
    return nounInfo(T[j]).some(x => {
      const e = ENTRY()[x.lemma + '|n'];
      const pl = /複數/.test(x.desc) || e[2] === 'pl';
      if (sgOnly && pl) return false;
      return DE.casesOf(artNorm(T[i].k), e[2], pl).some(c => cases.includes(c));
    });
  };

  const TOK = {
    defart(T) { return idx(T, (t, i) => DEF.includes(t.k) && nounAfter(T, i) > 0); },
    indef(T) { return idx(T, (t, i) => INDEF.includes(t.k) && nounAfter(T, i) > 0); },
    plural(T) {
      return idx(T, (t, i) => {
        if (!isNoun(T, i)) return false;
        const ni = nounInfo(t);
        if (!ni.some(x => /複數/.test(x.desc) || x.desc === '單複數同形')) return false;
        if (!ni.some(x => /^單數/.test(x.desc) || x.desc === '單複數同形')) return true;
        // 單複數同形（der Lehrer／die Lehrer）：前面要有看得出複數的字
        const p = prevW(T, i);
        return !!p && (/^(viele|alle|zwei|drei|vier|fünf|sechs|sieben|acht|neun|zehn|keine|meine|deine|unsere|diese)$/.test(p.k) || has(p.k, x => posOf(x.lemma) === 'num' && !['ein', 'eins'].includes(p.k)));
      });
    },
    suffix(T) {
      const R = [[/(ung|heit|keit|schaft|ion|tät|ei)$/, 'f'], [/(chen|lein|um)$/, 'n'], [/(ling|ismus)$/, 'm']];
      return idx(T, (t, i) => isNoun(T, i) && nounInfo(t).some(x => { const e = ENTRY()[x.lemma + '|n']; return R.some(([re, g]) => re.test(e[0]) && e[2] === g); }));
    },
    sein(T) { return idx(T, t => SEIN.includes(t.k)); },
    haben(T) { return idx(T, (t, i) => HABEN.includes(t.k) && !T.slice(i + 1).some(x => x.w && isPP(x, 'haben'))); },
    presReg(T) {
      const hasAux = T.some(x => x.w && (has(x.k, y => MODAL.has(y.lemma)) || ['werden', 'wird', 'werde'].includes(x.k)));
      return idx(T, (t, i) => !cap(t) || i === firstW(T) ? finite(t, x => posOf(x.lemma) === 'v' && !/分離/.test(x.desc) && !DE.isRefl(x.lemma)) && !(hasAux && isInf(t)) : false);
    },
    stemChange(T) {
      return idx(T, (t, i) => (!cap(t) || i === firstW(T)) && has(t.k, x => isV(x) && /^現在式 (du|er)/.test(x.desc) && DE.conjugate(x.lemma, posOf(x.lemma)).change));
    },
    jaNein(T) {
      const s = T.map(t => t.t).join('').trim();
      if (!/\?$/.test(s)) return [];
      const f = firstW(T);
      if (f < 0 || has(T[f].k, x => posOf(x.lemma) === 'q')) return [];
      return finite(T[f]) ? [f] : [];
    },
    akk(T) {
      return idx(T, (t, i) => {
        if (!/^(den|einen|keinen|meinen|deinen|seinen|ihren|unseren|euren|diesen|jeden)$/.test(t.k)) return false;
        return nounCase(T, i, ['Akk'], true);
      });
    },
    dat(T) {
      const DP = new Set(['mit', 'nach', 'aus', 'zu', 'von', 'bei', 'seit', 'gegenüber', 'in', 'an', 'auf', 'unter', 'über', 'vor', 'hinter', 'neben', 'zwischen']);
      return idx(T, (t, i) => {
        if (/^(dem|einem|keinem|meinem|deinem|seinem|ihrem|unserem|eurem|diesem|jedem)$/.test(t.k)) return nounAfter(T, i) > 0;
        if (t.k === 'den' && nounCase(T, i, ['Dat']) && !nounCase(T, i, ['Akk'], true)) return true;
        if (/^(der|einer|keiner|meiner|deiner|seiner|ihrer|unserer|eurer|dieser|jeder)$/.test(t.k)) { const p = prevW(T, i); return !!p && DP.has(p.k) && nounCase(T, i, ['Dat']); }
        return ['im', 'am', 'zum', 'zur', 'vom', 'beim'].includes(t.k);
      });
    },
    wechsel(T) {
      const W = ['in', 'an', 'auf', 'unter', 'über', 'vor', 'hinter', 'neben', 'zwischen'];
      const r = [];
      T.forEach((t, i) => {
        if (['im', 'ins', 'am', 'ans'].includes(t.k)) { r.push(i); return; }
        if (!W.includes(t.k)) return;
        const n = nextW(T, i);
        if (n && (DEF.includes(n.k) || INDEF.includes(n.k) || POSS.test(n.k))) r.push(i, T.indexOf(n));
      });
      return r;
    },
    poss(T) {
      return idx(T, (t, i) => {
        if (!POSS.test(t.k) || !has(t.k, x => posOf(x.lemma) === 'det') || nounAfter(T, i) < 0) return false;
        const p = prevW(T, i);
        if (t.k === 'ihr' && p && finite(p) && !cap(t)) return false; // Habt ihr Hunger?（你們）
        return true;
      });
    },
    formal(T) {
      const f = firstW(T);
      return idx(T, (t, i) => {
        if (t.t === 'Ihnen') return true;
        if (!/^(Sie|Ihr|Ihre|Ihren|Ihrem|Ihrer)$/.test(t.t)) return false;
        if (i !== f) return true;
        // 句首大寫看不出是 sie（她）還是 Sie（您）：後面接複數動詞才算
        const n = nextW(T, i);
        return t.t === 'Sie' && !!n && has(n.k, x => /^現在式 sie\/Sie/.test(x.desc)) && !has(n.k, x => /^現在式 er/.test(x.desc));
      });
    },
    klammer(T) { return [].concat(TOK.modal(T).length > 1 ? TOK.modal(T) : [], TOK.sep(T), TOK.perfHaben(T), TOK.perfSein(T)); },
    modal(T) {
      const r = [];
      T.forEach((t, i) => {
        if (!t.w || !finite(t, x => MODAL.has(x.lemma))) return;
        const after = T.slice(i + 1).filter(x => x.w);
        const inf = after.filter(x => !cap(x) && isInf(x)).pop();
        r.push(i);
        if (inf) r.push(T.indexOf(inf));
      });
      return r;
    },
    sep(T) {
      const r = [];
      T.forEach((t, i) => {
        if (!t.w) return;
        info(t.k).forEach(x => {
          if (!isV(x)) return;
          const c = DE.conjugate(x.lemma, posOf(x.lemma));
          if (!c.sep) return;
          if (/^(原形|過去分詞)/.test(x.desc) && t.k.startsWith(c.sep.toLowerCase())) { r.push(i); return; }
          if (/^(現在式|命令式)/.test(x.desc)) {
            const later = T.slice(i + 1).filter(y => y.w);
            const j = later.findIndex(y => y.k === c.sep.toLowerCase());
            // 前綴要在句子（或子句）最後：後面不能再接名詞
            if (j >= 0 && later.slice(j + 1).every(y => !isNoun(T, T.indexOf(y)))) r.push(i, T.indexOf(later[j]));
          }
        });
      });
      return r;
    },
    refl(T) {
      const RP = ['mich', 'dich', 'sich', 'uns', 'euch'];
      const r = [];
      T.forEach((t, i) => {
        if (!t.w || !has(t.k, x => DE.isRefl(x.lemma) && /^(現在式|命令式|過去分詞)/.test(x.desc))) return;
        const near = T.slice(Math.max(0, i - 6), i + 6).map((y, k) => [y, Math.max(0, i - 6) + k]).filter(([y]) => y.w && RP.includes(y.k));
        if (near.length) { r.push(i); near.forEach(([, k]) => r.push(k)); }
      });
      return r;
    },
    perfHaben(T) { return perf(T, HABEN, 'haben'); },
    perfSein(T) { return perf(T, SEIN, 'sein'); },
    imper(T) {
      const s = T.map(t => t.t).join('').trim();
      if (/\?$/.test(s)) return [];
      const ws = words(T);
      let f = ws[0];
      if (f && f.k === 'bitte') f = ws[1];
      if (!f) return [];
      const fi = T.indexOf(f), n = nextW(T, fi);
      if (n && n.t === 'Sie' && isInf(f) && has(f.k, x => isV(x))) return [fi, T.indexOf(n)];
      const inf = info(f.k);
      const isImp = inf.some(x => /^命令式 (du|ihr)/.test(x.desc));
      const isPres = inf.some(x => /^現在式 (ich|er|wir|sie)/.test(x.desc) && !/^現在式 (ihr)/.test(x.desc));
      if (!isImp || (isPres && !inf.some(x => /^命令式 du/.test(x.desc)))) return [];
      // 「Kommt ihr?」不是命令句：後面接主詞就不算
      if (n && ['ihr', 'du', 'er', 'sie', 'es', 'wir', 'ich'].includes(n.k)) return [];
      return [fi];
    },
    num(T) { return idx(T, (t, i) => has(t.k, x => posOf(x.lemma) === 'num') && t.k !== 'ein'); },
    adjAttr(T) { return idx(T, (t, i) => !cap(t) && isAdjForm(t) && (() => { const n = nextW(T, i); return n && isNoun(T, T.indexOf(n)); })()); },
    compar(T) {
      const r = [];
      T.forEach((t, i) => {
        if (!t.w) return;
        if (has(t.k, x => posOf(x.lemma) === 'adj' && /^比較級/.test(x.desc)) && t.k !== 'weiter') {
          const later = T.slice(i + 1).filter(y => y.w);
          const als = later.find(y => y.k === 'als');
          if (als) r.push(i, T.indexOf(als));
        }
        if (t.k === 'am') { const n = nextW(T, i); if (n && has(n.k, x => /^最高級（am/.test(x.desc))) r.push(i, T.indexOf(n)); }
      });
      return r;
    },
    subord(T) {
      const r = [];
      T.forEach((t, i) => {
        if (!['weil', 'dass', 'wenn'].includes(t.k)) return;
        r.push(i);
        let j = i + 1, last = -1;
        while (j < T.length && !/[,.!?]/.test(T[j].w ? '' : T[j].t)) { if (T[j].w) last = j; j++; }
        if (last > i) r.push(last);
      });
      return r;
    }
  };
  function perf(T, AUX, aux) {
    const r = [];
    T.forEach((t, i) => {
      if (!AUX.includes(t.k)) return;
      const later = T.slice(i + 1).filter(y => y.w);
      const pp = later.find(y => !cap(y) && isPP(y, aux));
      if (pp) r.push(i, T.indexOf(pp));
    });
    return r;
  }

  function grammarMatch(g, sentence) {
    const s = DE.norm(sentence);
    const ranges = [];
    if (g.m.re) {
      const re = new RegExp(g.m.re, g.m.cs ? 'g' : 'gi');
      let m;
      while ((m = re.exec(s))) { if (!m[0]) { re.lastIndex++; continue; } ranges.push([m.index, m.index + m[0].length]); }
    } else if (g.m.tok) {
      const T = toks(s);
      const ix = TOK[g.m.tok](T);
      [...new Set(ix)].sort((a, b) => a - b).forEach(i => ranges.push([T[i].s, T[i].e]));
    }
    return ranges;
  }
  DE.grammarMatch = grammarMatch;

  const L = 'A-Za-zÀ-ÖØ-öø-ÿẞ';
  const B = '(?<![' + L + '])';
  const E = '(?![' + L + '])';
  const w = list => B + '(?:' + list + ')' + E;
  const DAYS = 'Montag|Dienstag|Mittwoch|Donnerstag|Freitag|Samstag|Sonntag|Wochenende|Morgen|Vormittag|Mittag|Nachmittag|Abend';
  const MONTHS = 'Januar|Februar|März|April|Mai|Juni|Juli|August|September|Oktober|November|Dezember|Frühling|Sommer|Herbst|Winter';
  const NUMS = 'eins|zwei|drei|vier|fünf|sechs|sieben|acht|neun|zehn|elf|zwölf|ein';

  const T2 = (h, rows) => '<table><tr>' + h.map(x => '<th>' + x + '</th>').join('') + '</tr>' + rows.map(r => '<tr>' + r.map(x => '<td>' + x + '</td>').join('') + '</tr>').join('') + '</table>';

  DE.GRAMMAR = [
    // ---- 名詞與冠詞 ----
    { id: 'art-def', tag: '冠詞', title: '定冠詞 der, die, das', m: { tok: 'defart' },
      body: '<p>德文名詞有三種性別：<b>陽性 der</b>、<b>陰性 die</b>、<b>中性 das</b>。複數不分性別，一律用 <b>die</b>。</p>' +
        T2(['', '單數', '複數'], [['陽性', 'der Tisch', 'die Tische'], ['陰性', 'die Lampe', 'die Lampen'], ['中性', 'das Buch', 'die Bücher']]) +
        '<p>名詞的性別常常沒有道理（<i>das Mädchen</i> 女孩是中性），所以<b>背單字時連冠詞一起背</b>：不要只背 Tisch，要背 <i>der Tisch</i>。</p><p>所有名詞都是<b>大寫開頭</b>，不管在句子哪裡。</p>' },
    { id: 'art-indef', tag: '冠詞', title: '不定冠詞 ein, eine', m: { tok: 'indef' },
      body: '<p>不定冠詞＝英文 a／an，表示「一個」。陽性和中性長一樣，陰性多一個 -e：</p>' +
        T2(['', '主格', '例子'], [['陽性', 'ein', 'ein Tisch'], ['陰性', 'eine', 'eine Lampe'], ['中性', 'ein', 'ein Buch'], ['複數', '（沒有）', 'Tische']]) +
        '<p>說職業、國籍時不加冠詞：<i>Ich bin Student.</i>（我是學生）</p>' },
    { id: 'kein', tag: '冠詞', title: '否定冠詞 kein 與 nicht', m: { re: w('kein|keine|keinen|keinem|keiner|nicht') },
      body: '<p>德文有兩種「不」：</p><ul><li><b>kein</b>：否定<b>名詞</b>（原本是 ein 或沒有冠詞）。詞尾跟 ein 一樣變，複數是 keine。<br><i>Ich habe <b>kein</b> Auto.</i> 我沒有車。<i>Ich habe <b>keine</b> Zeit.</i> 我沒有時間。</li><li><b>nicht</b>：否定<b>動詞、形容詞</b>、或有定冠詞的名詞。<br><i>Ich komme <b>nicht</b>.</i> 我不來。<i>Das ist <b>nicht</b> teuer.</i> 這不貴。<i>Ich finde den Schlüssel <b>nicht</b>.</i></li></ul><p>nicht 的位置：通常放在句尾，或放在要否定的形容詞、地點、時間前面。</p>' },
    { id: 'noun-gender', tag: '名詞', title: '名詞的性別：看字尾猜', m: { tok: 'suffix' },
      body: '<p>大部分名詞的性別要背，但有些字尾很可靠：</p>' +
        T2(['字尾', '性別', '例子'], [['-ung、-heit、-keit、-schaft、-ion、-tät、-ei', '陰性 die', 'die Wohnung、die Information、die Bäckerei'], ['-chen、-lein', '中性 das', 'das Mädchen、das Brötchen'], ['-um', '中性 das', 'das Museum、das Zentrum'], ['-ling、-ismus', '陽性 der', 'der Frühling']]) +
        '<p>其他常見規律：星期、月份、季節都是<b>陽性</b>（der Montag、der Mai、der Sommer）；大部分 <b>-e</b> 結尾的是陰性（die Lampe、die Tasse），但人或動物的 -e 常是陽性（der Junge、der Kunde）。</p><p>複合名詞的性別看<b>最後一個字</b>：das Haus → <i>das Krankenhaus</i>；die Karte → <i>die Speisekarte</i>。</p>' },
    { id: 'noun-plural', tag: '名詞', title: '名詞的複數', m: { tok: 'plural' },
      body: '<p>德文複數有好幾種做法，要一個一個背。常見的類型：</p>' +
        T2(['變法', '例子'], [['-e（常加變音）', 'der Tag → die Tage、die Hand → die Hände'], ['-er（能變音就變）', 'das Kind → die Kinder、das Buch → die Bücher'], ['-(e)n', 'die Lampe → die Lampen、die Frau → die Frauen'], ['-nen（-in 結尾）', 'die Lehrerin → die Lehrerinnen'], ['不變（可能加變音）', 'der Lehrer → die Lehrer、der Apfel → die Äpfel'], ['-s（外來語）', 'das Auto → die Autos、das Handy → die Handys']]) +
        '<p>大致規律：陰性字多半加 <b>-(e)n</b>；-er、-el、-chen 結尾的陽性、中性字複數<b>不變</b>。</p><p>複數<b>與格</b>還要再加 <b>-n</b>：<i>mit den Kinder<b>n</b></i>（-n、-s 結尾的不加：mit den Autos）。</p>' },
    { id: 'cases', tag: '格', title: '四個格是什麼', m: { tok: 'defart' },
      body: '<p>德文名詞在句子裡的角色不同，冠詞就會變，這叫做「格」。A1 先學前三個：</p>' +
        T2(['格', '角色', '問句'], [['主格 Nominativ', '主詞（誰做）', 'Wer? Was?'], ['受格 Akkusativ', '直接受詞（做什麼）', 'Wen? Was?'], ['與格 Dativ', '間接受詞（給誰）、某些介係詞後', 'Wem?']]) +
        T2(['', '陽性', '陰性', '中性', '複數'], [['主格', 'der／ein', 'die／eine', 'das／ein', 'die／–'], ['受格', '<b>den／einen</b>', 'die／eine', 'das／ein', 'die／–'], ['與格', '<b>dem／einem</b>', '<b>der／einer</b>', '<b>dem／einem</b>', '<b>den</b> …n']]) +
        '<p>好消息：受格只有<b>陽性</b>會變（der → den），其他都跟主格一樣。</p><p><i>Der Mann</i> kauft <i>den Apfel</i>. 那個男人買了那顆蘋果。<br>Ich gebe <i>dem Kind</i> <i>einen Apfel</i>. 我給那個孩子一顆蘋果。</p>' },
    { id: 'akk', tag: '格', title: '受格 Akkusativ（den, einen）', m: { tok: 'akk' },
      body: '<p>動詞的<b>直接受詞</b>用受格。只有<b>陽性單數</b>看得出來：der → <b>den</b>、ein → <b>einen</b>、kein → <b>keinen</b>、mein → <b>meinen</b>。</p><ul><li><i>Ich habe <b>einen</b> Bruder.</i> 我有一個哥哥。</li><li><i>Ich suche <b>meinen</b> Schlüssel.</i> 我在找我的鑰匙。</li><li><i>Ich trinke jeden Morgen <b>einen</b> Kaffee.</i></li></ul><p>常接受格的動詞：haben、brauchen、kaufen、suchen、sehen、möchten、essen、trinken、nehmen、besuchen、es gibt。</p><p>有些陽性名詞在受格、與格還要加 -n（弱變化名詞）：<i>den Herr<b>n</b></i>、<i>den Student<b>en</b></i>、<i>den Name<b>n</b></i>。</p>' },
    { id: 'dat', tag: '格', title: '與格 Dativ（dem, der, einem）', m: { tok: 'dat' },
      body: '<p>與格用在：</p><ol><li><b>間接受詞</b>（給誰）：<i>Ich schenke <b>meiner</b> Mutter Blumen.</i></li><li><b>與格介係詞</b>後面：mit、nach、aus、zu、von、bei、seit、gegenüber</li><li><b>與格動詞</b>：helfen、danken、gefallen、gehören、schmecken</li></ol>' +
        T2(['', '陽性', '陰性', '中性', '複數'], [['定冠詞', 'dem', 'der', 'dem', 'den …n'], ['不定冠詞', 'einem', 'einer', 'einem', '–']]) +
        '<p><i>Ich fahre mit <b>dem</b> Bus.</i> 我搭公車。<i>Ich wohne bei <b>meinen</b> Eltern.</i> 我跟父母住。</p>' },
    // ---- 代名詞 ----
    { id: 'pron', tag: '代名詞', title: '人稱代名詞 ich, du, er, sie…', m: { re: w('ich|du|er|es|wir|ihr'), cs: false },
      body: T2(['', '單數', '複數'], [['第一人稱', 'ich 我', 'wir 我們'], ['第二人稱', 'du 你', 'ihr 你們'], ['第三人稱', 'er 他、sie 她、es 它', 'sie 他們'], ['尊稱', 'Sie 您', 'Sie 您們']]) +
        '<p><b>er／sie／es 跟著名詞的性別</b>，不是只用在人身上：<i>Der Tisch ist neu. <b>Er</b> ist schön.</i>（那張桌子很新，它很漂亮。）</p><p>ich 不大寫（除非在句首），尊稱 <b>Sie</b> 一定大寫。</p>' },
    { id: 'sie', tag: '代名詞', title: 'du 和 Sie：怎麼稱呼', m: { tok: 'formal' },
      body: '<ul><li><b>du</b>：家人、朋友、小孩、同學、年輕人之間（線上、運動場合也常用）</li><li><b>Sie</b>：陌生人、店員、老師、同事（剛認識時）、長輩。動詞跟 sie（他們）一樣：<i>Woher kommen <b>Sie</b>?</i></li></ul><p>稱呼姓氏時用 <b>Herr</b>（先生）、<b>Frau</b>（女士）＋姓，配 Sie：<i>Guten Tag, Frau Weber! Wie geht es <b>Ihnen</b>?</i></p><p>不確定時用 Sie 比較安全，對方會說 <i>Wir können uns duzen.</i>（我們可以用 du 稱呼彼此）。</p>' },
    { id: 'pron-obj', tag: '代名詞', title: '代名詞的受格與與格（mich, mir…）', m: { re: w('mich|dich|ihn|mir|dir|ihm|ihnen|Ihnen') },
      body: T2(['主格', '受格', '與格'], [['ich', 'mich', 'mir'], ['du', 'dich', 'dir'], ['er', 'ihn', 'ihm'], ['sie', 'sie', 'ihr'], ['es', 'es', 'ihm'], ['wir', 'uns', 'uns'], ['ihr', 'euch', 'euch'], ['sie／Sie', 'sie／Sie', 'ihnen／Ihnen']]) +
        '<ul><li><i>Ich liebe <b>dich</b>.</i> 我愛你。（受格）</li><li><i>Kannst du <b>mir</b> helfen?</i> 你能幫我嗎？（helfen 接與格）</li><li><i>Wie geht es <b>dir</b>?</i> 你好嗎？</li><li><i>Die Stadt gefällt <b>mir</b>.</i> 我喜歡這座城市。</li></ul>' },
    { id: 'poss', tag: '代名詞', title: '所有格 mein, dein, sein…', m: { tok: 'poss' },
      body: T2(['', '…的', '例子'], [['ich', 'mein', 'mein Vater、meine Mutter'], ['du', 'dein', 'dein Handy'], ['er／es', 'sein', 'sein Auto'], ['sie', 'ihr', 'ihre Tasche'], ['wir', 'unser', 'unser Lehrer'], ['ihr', 'euer', 'eure Wohnung'], ['sie／Sie', 'ihr／Ihr', 'Ihre Adresse']]) +
        '<p>詞尾跟 <b>ein／kein</b> 一樣變：<i>mein Bruder</i>、<i>meine Schwester</i>、<i>meine Eltern</i>、受格 <i>meinen Bruder</i>、與格 <i>mit meinem Bruder</i>。</p><p>注意 <b>ihr</b> 有三個意思：你們（代名詞）、她的、他們的；大寫 <b>Ihr</b> 是「您的」。</p>' },
    { id: 'demo', tag: '代名詞', title: '指示詞 dieser（這個）', m: { re: w('dieser|diese|diesen|diesem|dieses') },
      body: '<p><b>dieser</b>＝這個，詞尾跟定冠詞很像：</p>' + T2(['', '陽性', '陰性', '中性', '複數'], [['主格', 'dieser', 'diese', 'dieses', 'diese'], ['受格', 'diesen', 'diese', 'dieses', 'diese'], ['與格', 'diesem', 'dieser', 'diesem', 'diesen']]) +
        '<p><i>Dieser Pullover ist zu teuer.</i> 這件毛衣太貴了。口語也常直接說 <i>der</i>：<i>Der ist zu teuer.</i></p><p>指著東西說「這是…」不管性別都用 <b>das</b>：<i>Das ist mein Bruder.</i></p>' },
    { id: 'man', tag: '代名詞', title: 'man（人們、大家）', m: { re: w('man') }, ex: [['Wie schreibt man das?', '這個怎麼寫？']],
      body: '<p><b>man</b> 是泛指的「人」，動詞用第三人稱單數（跟 er 一樣）。中文常常不翻出來。</p><ul><li><i>Hier darf <b>man</b> nicht rauchen.</i> 這裡不可以抽菸。</li><li><i>Wie schreibt <b>man</b> das?</i> 這個怎麼寫？</li></ul>' },
    // ---- 動詞 ----
    { id: 'pres-reg', tag: '動詞', title: '現在式：規則動詞', m: { tok: 'presReg' },
      body: '<p>去掉原形的 <b>-en</b> 得到詞幹，再加詞尾：</p>' + T2(['', 'machen', 'arbeiten', 'tanzen'], [['ich', 'mach<b>e</b>', 'arbeit<b>e</b>', 'tanz<b>e</b>'], ['du', 'mach<b>st</b>', 'arbeit<b>est</b>', 'tanz<b>t</b>'], ['er/sie/es', 'mach<b>t</b>', 'arbeit<b>et</b>', 'tanz<b>t</b>'], ['wir', 'mach<b>en</b>', 'arbeit<b>en</b>', 'tanz<b>en</b>'], ['ihr', 'mach<b>t</b>', 'arbeit<b>et</b>', 'tanz<b>t</b>'], ['sie/Sie', 'mach<b>en</b>', 'arbeit<b>en</b>', 'tanz<b>en</b>']]) +
        '<ul><li>詞幹是 <b>-d、-t</b>（或 öffn-、regn-）結尾：du、er、ihr 前加 <b>e</b> 好唸：arbeit<b>e</b>st、öffn<b>e</b>t</li><li>詞幹是 <b>-s、-ß、-z</b> 結尾：du 只加 <b>-t</b>：du tanzt、du heißt</li><li><b>-eln／-ern</b> 結尾：wir、sie 只加 -n：wir wandern；ich klingle</li></ul><p>德文的現在式也用來說<b>未來</b>：<i>Morgen fahre ich nach Berlin.</i></p>' },
    { id: 'stem', tag: '動詞', title: '母音變化動詞（fahren → fährst）', m: { tok: 'stemChange' },
      body: '<p>很多強變化動詞在 <b>du</b> 和 <b>er/sie/es</b> 時母音會變，其他人稱不變：</p>' + T2(['', 'a → ä', 'e → i', 'e → ie'], [['原形', 'fahren', 'sprechen', 'sehen'], ['ich', 'fahre', 'spreche', 'sehe'], ['du', 'f<b>ä</b>hrst', 'spr<b>i</b>chst', 's<b>ie</b>hst'], ['er/sie/es', 'f<b>ä</b>hrt', 'spr<b>i</b>cht', 's<b>ie</b>ht'], ['wir', 'fahren', 'sprechen', 'sehen']]) +
        '<p>常見的：fahren、schlafen、tragen、laufen（au → äu）、essen（du isst）、geben、nehmen（du nimmst）、helfen、treffen、lesen（du liest）、sehen、sprechen、vergessen。</p><p>e → i(e) 的動詞，<b>命令式 du</b> 也變：<i>Gib!</i> <i>Nimm!</i> <i>Lies!</i> <i>Iss!</i>；a → ä 的不變：<i>Fahr!</i></p>' },
    { id: 'sein', tag: '動詞', title: 'sein（是、在）', m: { tok: 'sein' },
      body: T2(['', '單數', '複數'], [['1', 'ich bin', 'wir sind'], ['2', 'du bist', 'ihr seid'], ['3', 'er/sie/es ist', 'sie/Sie sind']]) +
        '<p>用來說身分、國籍、職業、特質、狀態、位置：</p><p><i>Ich <b>bin</b> Student.</i> <i>Das <b>ist</b> teuer.</i> <i>Wir <b>sind</b> müde.</i> <i>Wo <b>ist</b> die Toilette?</i></p><p>過去式常說 <b>war</b>（見「過去式 war、hatte」）。</p>' },
    { id: 'haben', tag: '動詞', title: 'haben（有）', m: { tok: 'haben' }, ex: [['Ich habe Hunger.', '我餓了。']],
      body: T2(['', '單數', '複數'], [['1', 'ich habe', 'wir haben'], ['2', 'du hast', 'ihr habt'], ['3', 'er/sie/es hat', 'sie/Sie haben']]) +
        '<p>中文說「我餓了」，德文說「我<b>有</b>飢餓」：</p><ul><li>Hunger haben 餓／Durst haben 渴</li><li>Zeit haben 有空／Lust haben 想做（某事）</li><li>Fieber haben 發燒／Schmerzen haben 痛</li><li>Glück haben 運氣好</li></ul><p>haben 後面接<b>受格</b>：<i>Ich habe einen Bruder.</i></p>' },
    { id: 'v2', tag: '句型', title: '動詞放第二位', m: { re: '^(?:Heute|Morgen|Jetzt|Dann|Danach|Hier|Dort|Zuerst|Gestern|Manchmal|Morgens|Abends|Vielleicht|Leider|Natürlich|Am \\S+|Im \\S+|Um \\S+ Uhr|Nächste Woche|Letzte Woche|Im Sommer|Im Winter) (?:\\S+) (?:ich|du|er|sie|es|wir|ihr|man|Sie)' + E, cs: true },
      body: '<p>德文陳述句最重要的規則：<b>變化過的動詞一定在第二個位置</b>。第一個位置可以是主詞，也可以是時間、地點等；如果不是主詞，主詞就跑到動詞後面：</p>' + T2(['第 1 位', '第 2 位（動詞）', '其他'], [['Ich', 'fahre', 'morgen nach Berlin.'], ['Morgen', 'fahre', 'ich nach Berlin.'], ['Nach Berlin', 'fahre', 'ich morgen.']]) +
        '<p>「第一個位置」是一整個詞組，不是一個字：<i>Am Sonntag</i>、<i>Um acht Uhr</i> 都算一個位置。</p><p>und、aber、oder、denn、sondern 不佔位置：<i>Ich bleibe zu Hause, <b>denn</b> ich <b>bin</b> krank.</i></p>' },
    { id: 'satzklammer', tag: '句型', title: '句框：第二個動詞放句尾', m: { tok: 'klammer' },
      body: '<p>德文句子像一個框：<b>變化的動詞在第 2 位</b>，<b>另一個動詞部分放在句尾</b>，中間放其他東西。</p>' + T2(['', '第 2 位', '中間', '句尾'], [['情態動詞', 'Ich <b>muss</b>', 'heute', '<b>arbeiten</b>.'], ['分離動詞', 'Ich <b>stehe</b>', 'um sieben Uhr', '<b>auf</b>.'], ['完成式', 'Ich <b>habe</b>', 'Pizza', '<b>gegessen</b>.']]) +
        '<p>習慣這個框，德文句子就好懂了：先找第 2 位的動詞，再去句尾找另一半。</p>' },
    { id: 'modal', tag: '動詞', title: '情態動詞 können, müssen, wollen…', m: { tok: 'modal' },
      body: T2(['', 'können', 'müssen', 'wollen', 'dürfen', 'sollen', 'mögen'], [['ich', 'kann', 'muss', 'will', 'darf', 'soll', 'mag'], ['du', 'kannst', 'musst', 'willst', 'darfst', 'sollst', 'magst'], ['er/sie/es', 'kann', 'muss', 'will', 'darf', 'soll', 'mag'], ['wir', 'können', 'müssen', 'wollen', 'dürfen', 'sollen', 'mögen'], ['ihr', 'könnt', 'müsst', 'wollt', 'dürft', 'sollt', 'mögt'], ['sie/Sie', 'können', 'müssen', 'wollen', 'dürfen', 'sollen', 'mögen']]) +
        '<p>注意 <b>ich 和 er 一樣</b>，而且<b>沒有詞尾</b>：ich kann、er kann。</p><p>情態動詞在第 2 位，<b>原形動詞放句尾</b>：<i>Ich <b>kann</b> gut <b>schwimmen</b>.</i> <i><b>Darf</b> ich hier <b>rauchen</b>?</i></p><ul><li>können 能、會、可以　müssen 必須　wollen 想要、打算</li><li>dürfen 被允許　sollen 應該（別人要求）　mögen 喜歡（通常直接接名詞：<i>Ich mag Tee.</i>）</li></ul>' },
    { id: 'moechte', tag: '動詞', title: 'möchte（我想要）', m: { re: w('möchte|möchtest|möchten|möchtet') },
      body: '<p><b>möchte</b> 是 mögen 的禮貌形，點餐、買東西、說願望最常用：</p>' + T2(['', ''], [['ich möchte', 'wir möchten'], ['du möchtest', 'ihr möchtet'], ['er/sie/es möchte', 'sie/Sie möchten']]) +
        '<ul><li>＋名詞（受格）：<i>Ich <b>möchte</b> einen Kaffee.</i></li><li>＋原形放句尾：<i>Ich <b>möchte</b> nach Berlin fahren.</i></li></ul><p>更客氣的點餐說法：<i>Ich hätte gern ein Stück Kuchen.</i></p>' },
    { id: 'sep', tag: '動詞', title: '分離動詞（aufstehen → ich stehe … auf）', m: { tok: 'sep' },
      body: '<p>有些動詞有可以「分開」的前綴（重音在前綴上）：<b>auf</b>stehen、<b>an</b>rufen、<b>ein</b>kaufen、<b>fern</b>sehen、<b>mit</b>kommen。</p><p>現在式和命令式時，<b>前綴跑到句尾</b>：</p><ul><li><i>Ich <b>stehe</b> um sieben Uhr <b>auf</b>.</i></li><li><i>Ich <b>rufe</b> dich morgen <b>an</b>.</i></li><li><i><b>Kommst</b> du <b>mit</b>?</i></li><li><i><b>Mach</b> bitte das Licht <b>an</b>!</i></li></ul><p>和情態動詞一起時不分開，整個放句尾：<i>Ich muss früh <b>aufstehen</b>.</i>；過去分詞的 ge- 放中間：auf<b>ge</b>standen、ein<b>ge</b>kauft。</p><p>常見前綴：ab-、an-、auf-、aus-、ein-、mit-、vor-、zu-、zurück-、fern-。be-、ver-、er-、ent- 開頭的<b>不能</b>分開（besuchen、verstehen）。</p>' },
    { id: 'refl', tag: '動詞', title: '反身動詞（sich freuen）', m: { tok: 'refl' },
      body: '<p>有些動詞要加一個指回主詞的代名詞 <b>sich</b>：</p>' + T2(['', 'sich freuen'], [['ich', 'freue <b>mich</b>'], ['du', 'freust <b>dich</b>'], ['er/sie/es', 'freut <b>sich</b>'], ['wir', 'freuen <b>uns</b>'], ['ihr', 'freut <b>euch</b>'], ['sie/Sie', 'freuen <b>sich</b>']]) +
        '<p>只有第三人稱和 Sie 用 sich，其他跟受格代名詞一樣。</p><ul><li><i>Ich <b>freue mich</b> auf das Wochenende.</i> 我期待週末。</li><li><i><b>Setzen Sie sich</b>, bitte.</i> 請坐。</li><li><i><b>Beeil dich</b>!</i> 快點！</li></ul><p>常見的：sich freuen、sich setzen、sich interessieren für、sich fühlen、sich beeilen、sich anziehen、sich treffen。</p>' },
    { id: 'imper', tag: '動詞', title: '命令式（Komm! Kommen Sie!）', m: { tok: 'imper' },
      body: T2(['對象', '做法', '例子'], [['du', '詞幹（去掉 -st）', '<b>Komm</b>! <b>Mach</b> das! <b>Warte</b>!'], ['ihr', '跟現在式一樣', '<b>Kommt</b>! <b>Macht</b> das!'], ['Sie', '原形＋Sie', '<b>Kommen Sie</b>! <b>Warten Sie</b>!'], ['wir', '原形＋wir（我們…吧）', '<b>Gehen wir</b>!']]) +
        '<p>e → i(e) 的動詞，du 的命令式也變：<i>Gib!</i> <i>Nimm!</i> <i>Lies!</i> <i>Sieh mal!</i>；a → ä 的不變：<i>Fahr langsam!</i></p><p>sein 不規則：<i><b>Sei</b> ruhig!</i> <i><b>Seid</b> leise!</i> <i><b>Seien Sie</b> pünktlich!</i></p><p>加上 <b>bitte</b>、<b>mal</b> 語氣比較客氣：<i>Komm mal her!</i> <i>Hilf mir bitte!</i></p>' },
    { id: 'perf-haben', tag: '時態', title: '現在完成式：haben ＋ 過去分詞', m: { tok: 'perfHaben' }, ex: [['Ich habe gestern Pizza gegessen.', '我昨天吃了披薩。'], ['Wir haben am Wochenende Fußball gespielt.', '我們週末踢了足球。'], ['Hast du schon gefrühstückt?', '你吃過早餐了嗎？']],
      body: '<p>德文口語說過去的事，大多用<b>現在完成式 Perfekt</b>：<b>haben／sein 在第 2 位</b>，<b>過去分詞放句尾</b>。</p><p><i>Ich <b>habe</b> gestern Pizza <b>gegessen</b>.</i> 我昨天吃了披薩。</p>' +
        T2(['類型', '過去分詞', '例子'], [['規則動詞', 'ge- … -t', 'machen → <b>ge</b>mach<b>t</b>、arbeiten → <b>ge</b>arbeit<b>et</b>'], ['強變化動詞', 'ge- … -en（母音常變）', 'essen → gegessen、trinken → getrunken'], ['-ieren 結尾', '… -t（沒有 ge-）', 'studieren → studiert'], ['be-、ver-、er- 開頭', '沒有 ge-', 'besuchen → besucht、verstehen → verstanden'], ['分離動詞', 'ge 放中間', 'einkaufen → ein<b>ge</b>kauft']]) +
        '<p>大部分動詞用 <b>haben</b>（尤其是有受詞的）。</p>' },
    { id: 'perf-sein', tag: '時態', title: '現在完成式：sein ＋ 過去分詞', m: { tok: 'perfSein' }, ex: [['Ich bin gestern nach Berlin gefahren.', '我昨天去了柏林。'], ['Wann bist du heute aufgestanden?', '你今天幾點起床的？'], ['Wir sind zu Hause geblieben.', '我們待在家裡。']],
      body: '<p>表示<b>移動</b>（從 A 到 B）或<b>狀態改變</b>的動詞，完成式用 <b>sein</b>：</p><ul><li>移動：gehen → <i>ich <b>bin</b> gegangen</i>、fahren、fliegen、kommen、laufen、reisen、schwimmen、umsteigen</li><li>改變：aufstehen → <i>ich <b>bin</b> aufgestanden</i>、werden、passieren</li><li>還有：sein → <i>ich <b>bin</b> gewesen</i>、bleiben → <i>ich <b>bin</b> geblieben</i></li></ul><p><i>Wir <b>sind</b> nach München <b>umgezogen</b>.</i> 我們搬到慕尼黑了。<i>Was <b>ist</b> <b>passiert</b>?</i> 發生了什麼事？</p>' },
    { id: 'praet', tag: '時態', title: '過去式 war、hatte', m: { re: w('war|warst|waren|wart|hatte|hattest|hatten|hattet|konnte|musste|wollte') },
      body: '<p>sein、haben 和情態動詞說過去時，通常不用完成式，而用<b>過去式 Präteritum</b>：</p>' + T2(['', 'sein', 'haben', 'können'], [['ich', 'war', 'hatte', 'konnte'], ['du', 'warst', 'hattest', 'konntest'], ['er/sie/es', 'war', 'hatte', 'konnte'], ['wir', 'waren', 'hatten', 'konnten'], ['ihr', 'wart', 'hattet', 'konntet'], ['sie/Sie', 'waren', 'hatten', 'konnten']]) +
        '<p><i>Gestern <b>war</b> ich im Kino.</i> 我昨天去看電影了。<i>Ich <b>hatte</b> keine Zeit.</i> 我那時沒空。</p>' },
    // ---- 句型 ----
    { id: 'wfrage', tag: '句型', title: 'W 疑問詞問句', m: { re: '^(?:' + 'Wer|Wen|Wem|Was|Wo|Wohin|Woher|Wann|Wie viel|Wie viele|Wie lange|Wie spät|Wie|Warum|Welche|Welcher|Welches|Welchen' + ')' + E, cs: true },
      body: T2(['疑問詞', '意思'], [['wer／wen／wem', '誰（主格／受格／與格）'], ['was', '什麼'], ['wo', '在哪裡'], ['wohin', '去哪裡'], ['woher', '從哪裡'], ['wann', '什麼時候'], ['wie', '怎麼、如何'], ['warum', '為什麼'], ['wie viel', '多少（錢）'], ['welcher', '哪一個']]) +
        '<p>疑問詞在第 1 位，<b>動詞在第 2 位</b>，主詞在後面：<i><b>Wo wohnst</b> du?</i> <i><b>Was machst</b> du am Wochenende?</i></p><p>wo／wohin／woher 要分清楚：<i>Wo bist du?</i>（在哪）<i>Wohin fährst du?</i>（去哪）<i>Woher kommst du?</i>（從哪來）</p>' },
    { id: 'janein', tag: '句型', title: '是非問句：動詞放最前面', m: { tok: 'jaNein' },
      body: '<p>要問「是不是」的問句，<b>動詞放第 1 位</b>，主詞放第 2 位：</p><ul><li><i>Du kommst aus Taiwan.</i> → <i><b>Kommst</b> du aus Taiwan?</i></li><li><i><b>Hast</b> du Zeit?</i> 你有空嗎？</li><li><i><b>Sprechen</b> Sie Englisch?</i> 您會說英文嗎？</li></ul><p>回答：<b>Ja</b>（是）、<b>Nein</b>（不是）。如果問句是<b>否定</b>的，要回答「有／是」就說 <b>Doch</b>：<i>Kommst du nicht? — Doch!</i></p>' },
    { id: 'esgibt', tag: '句型', title: 'es gibt（有…）', m: { re: w('es gibt|gibt es') },
      body: '<p><b>es gibt ＋ 受格</b>＝「（某處）有…」，說某東西存在：</p><ul><li><i>Hier <b>gibt es</b> einen Supermarkt.</i> 這裡有一家超市。</li><li><i><b>Gibt es</b> hier in der Nähe eine Bank?</i> 這附近有銀行嗎？</li><li><i>Heute <b>gibt es</b> Fisch.</i> 今天吃魚。</li></ul><p>單複數都用 gibt：<i>Es gibt viele Restaurants.</i></p>' },
    { id: 'gern', tag: '句型', title: 'gern、lieber、am liebsten（喜歡做）', m: { re: w('gern|lieber|am liebsten') },
      body: '<p>德文說「喜歡做某事」，是在動詞後面加 <b>gern</b>：</p><ul><li><i>Ich spiele <b>gern</b> Fußball.</i> 我喜歡踢足球。</li><li><i>Ich trinke <b>lieber</b> Tee.</i> 我比較喜歡喝茶。</li><li><i>Ich esse <b>am liebsten</b> Pizza.</i> 我最喜歡吃披薩。</li></ul><p>喜歡「東西」用 <b>mögen</b>：<i>Ich mag Schokolade.</i>；想要用 <b>möchte</b>。</p>' },
    { id: 'gefallen', tag: '句型', title: '與格動詞：gefallen, schmecken, helfen…', m: { re: w('gefällt|gefallen|schmeckt|schmecken|gehört|gehören|hilft|helfen|hilf|danke|dankt') + ' (?:\\S+ ){0,2}' + w('mir|dir|ihm|ihr|uns|euch|ihnen|Ihnen') + '|' + w('mir|dir|ihm|uns|euch|Ihnen') + ' (?:\\S+ )?(?:helfen|danken)' },
      ex: [['Gehört das Buch dir?', '這本書是你的嗎？']],
      body: '<p>這些動詞的「對象」用<b>與格</b>：</p><ul><li><b>gefallen</b>：<i>Die Stadt gefällt <b>mir</b>.</i> 我喜歡這座城市。（城市讓我喜歡）</li><li><b>schmecken</b>：<i>Schmeckt <b>dir</b> die Suppe?</i> 你覺得湯好喝嗎？</li><li><b>gehören</b>：<i>Das Buch gehört <b>mir</b>.</i> 這本書是我的。</li><li><b>helfen</b>：<i>Kannst du <b>mir</b> helfen?</i></li><li><b>danken</b>：<i>Ich danke <b>Ihnen</b>.</i></li></ul><p>gefallen、schmecken 的主詞是「東西」，所以複數東西要用複數：<i>Die Schuhe gefallen mir.</i></p>' },
    // ---- 介係詞 ----
    { id: 'prep-akk', tag: '介係詞', title: '接受格的介係詞：für, ohne, durch, gegen, um', m: { re: w('für|ohne|durch|gegen') },
      body: '<p>這幾個介係詞後面一定接<b>受格</b>：</p><ul><li><b>für</b> 為了、給：<i>Das ist für <b>den</b> Lehrer.</i></li><li><b>ohne</b> 沒有：<i>Kaffee ohne Zucker</i></li><li><b>durch</b> 穿過：<i>durch <b>den</b> Park</i></li><li><b>gegen</b> 對抗；大約（時間）：<i>gegen acht Uhr</i></li><li><b>um</b> 在（幾點）；圍繞：<i>um neun Uhr</i></li></ul><p>口訣：<b>für, ohne, durch, gegen, um</b>（＋bis）。</p>' },
    { id: 'prep-dat', tag: '介係詞', title: '接與格的介係詞：mit, nach, aus, zu, von, bei, seit', m: { re: w('mit|nach|aus|zu|von|bei|seit|gegenüber|zum|zur|vom|beim') },
      body: '<p>這些介係詞後面一定接<b>與格</b>：</p><ul><li><b>mit</b> 和；搭：<i>mit dem Bus</i></li><li><b>nach</b> 往（城市、國家）；之後：<i>nach Berlin</i>、<i>nach dem Essen</i></li><li><b>aus</b> 從…來：<i>aus Taiwan</i>、<i>aus dem Haus</i></li><li><b>zu</b> 到（人、地點）：<i>zum Arzt</i>、<i>zur Schule</i></li><li><b>von</b> 從；…的：<i>von meinem Vater</i></li><li><b>bei</b> 在…那裡：<i>bei meinen Eltern</i></li><li><b>seit</b> 自從、已經：<i>seit zwei Jahren</i></li></ul><p>「回家」是固定說法 <i>nach Hause</i>；「在家」是 <i>zu Hause</i>。</p>' },
    { id: 'prep-wechsel', tag: '介係詞', title: '雙向介係詞：Wo?（與格）或 Wohin?（受格）', m: { tok: 'wechsel' },
      body: '<p>in、an、auf、unter、über、vor、hinter、neben、zwischen 這九個介係詞：</p><ul><li>表示<b>位置</b>（Wo? 在哪裡）→ <b>與格</b>：<i>Ich bin <b>im</b> Kino.</i> <i>Das Buch liegt <b>auf dem</b> Tisch.</i></li><li>表示<b>方向</b>（Wohin? 去哪裡）→ <b>受格</b>：<i>Ich gehe <b>ins</b> Kino.</i> <i>Leg das Buch <b>auf den</b> Tisch.</i></li></ul><p>動詞也成對：<b>liegen／stehen／hängen</b>（在，與格）vs. <b>legen／stellen</b>（放，受格）。</p>' },
    { id: 'contract', tag: '介係詞', title: '介係詞＋冠詞縮寫（im, ins, zum…）', m: { re: w('im|ins|am|ans|zum|zur|vom|beim') },
      body: T2(['縮寫', '＝', '例子'], [['im', 'in dem', 'im Park'], ['ins', 'in das', 'ins Kino'], ['am', 'an dem', 'am Montag'], ['ans', 'an das', 'ans Meer'], ['zum', 'zu dem', 'zum Bahnhof'], ['zur', 'zu der', 'zur Arbeit'], ['vom', 'von dem', 'vom Bahnhof'], ['beim', 'bei dem', 'beim Arzt']]) +
        '<p>這些縮寫非常常用，一般不會說 in dem Kino，而說 <i>im Kino</i>。</p>' },
    // ---- 時間 ----
    { id: 'time', tag: '時間', title: '幾點：um acht Uhr、halb neun', m: { re: '(?:um|gegen|bis|ab) (?:\\S+ )?(?:Uhr)|' + w('(?:halb|Viertel nach|Viertel vor) (?:' + NUMS + ')|(?:' + NUMS + '|zwölf|dreizehn) Uhr') },
      body: '<p>問時間：<i>Wie spät ist es?</i> 或 <i>Wie viel Uhr ist es?</i></p>' + T2(['時間', '正式', '口語'], [['8:00', 'acht Uhr', 'acht'], ['8:15', 'acht Uhr fünfzehn', 'Viertel nach acht'], ['8:30', 'acht Uhr dreißig', '<b>halb neun</b>（！）'], ['8:45', 'acht Uhr fünfundvierzig', 'Viertel vor neun'], ['20:00', 'zwanzig Uhr', 'acht（am Abend）']]) +
        '<p>注意 <b>halb neun</b> 是「往九點走了一半」＝ 8:30，不是 9:30！</p><p>「在幾點」用 <b>um</b>：<i>Der Film beginnt um neun Uhr.</i></p>' },
    { id: 'days', tag: '時間', title: '星期、月份、季節：am Montag、im Mai', m: { re: '(?:am|Am) (?:' + DAYS + ')' + E + '|(?:im|Im) (?:' + MONTHS + ')' + E },
      body: T2(['', '介係詞', '例子'], [['星期幾、一天的時段', '<b>am</b>', 'am Montag、am Wochenende、am Abend'], ['月份、季節', '<b>im</b>', 'im Mai、im Sommer'], ['幾點', '<b>um</b>', 'um acht Uhr'], ['年份', '（不加）', '2026 fahre ich nach Wien.']]) +
        '<p>例外：<b>in der Nacht</b>（晚上）。星期、月份、季節全部都是<b>陽性</b>。</p><p>想說「每個星期一」：<i>montags</i>；「每天晚上」：<i>abends</i>。</p>' },
    { id: 'num', tag: '數字', title: '數字：個位數先唸', m: { tok: 'num' },
      body: '<p>0–12 要背：null, eins, zwei, drei, vier, fünf, sechs, sieben, acht, neun, zehn, elf, zwölf。</p><p>13–19：個位數＋zehn（sechzehn、siebzehn 少一點字母）。</p><p>21 以上：<b>個位數先唸</b>，再加 und 和十位數：<i>21 = einundzwanzig</i>（一和二十）、<i>45 = fünfundvierzig</i>、<i>98 = achtundneunzig</i>。</p>' +
        T2(['十位', ''], [['20 zwanzig', '30 dreißig（ß！）'], ['40 vierzig', '50 fünfzig'], ['60 sechzig', '70 siebzig'], ['80 achtzig', '90 neunzig'], ['100 hundert', '1000 tausend']]) },
    // ---- 形容詞 ----
    { id: 'adj-pred', tag: '形容詞', title: '形容詞放在 sein 後面：不變化', m: { re: w('ist|sind|bin|bist|seid|war') + ' (?:sehr |zu |so |ziemlich |ganz |nicht |noch |schon )?' + w('gut|schlecht|groß|klein|alt|jung|neu|schön|teuer|billig|kalt|warm|heiß|müde|krank|lang|kurz|hoch|nett|lecker|frisch|kaputt|fertig|leer|voll|frei|laut|leise|ruhig|wichtig|richtig|falsch|interessant|langweilig|schwer|leicht|sauber|bequem|pünktlich|klar|sicher|möglich|super|toll') },
      body: '<p>好消息：形容詞放在 <b>sein、werden</b> 後面（當作「是什麼樣子」）時，<b>完全不變化</b>：</p><ul><li><i>Der Tisch ist <b>neu</b>.</i></li><li><i>Die Lampe ist <b>neu</b>.</i></li><li><i>Die Bücher sind <b>neu</b>.</i></li></ul><p>同一個字也可以直接當副詞用：<i>Er spricht <b>langsam</b>.</i>（他說得很慢）</p>' },
    { id: 'adj-end', tag: '形容詞', title: '形容詞放在名詞前：要加詞尾', m: { tok: 'adjAttr' },
      body: '<p>形容詞放在<b>名詞前面</b>就要加詞尾。A1 先記住主格最常見的兩組：</p>' + T2(['', 'der／die／das 後', 'ein／eine 後'], [['陽性', 'der neu<b>e</b> Tisch', 'ein neu<b>er</b> Tisch'], ['陰性', 'die neu<b>e</b> Lampe', 'eine neu<b>e</b> Lampe'], ['中性', 'das neu<b>e</b> Buch', 'ein neu<b>es</b> Buch'], ['複數', 'die neu<b>en</b> Bücher', 'neu<b>e</b> Bücher']]) +
        '<p>規律：冠詞已經看得出性別（der、das）時，形容詞只加 <b>-e</b>；冠詞看不出來（ein）時，形容詞要「補上」性別的記號：ein neu<b>er</b>（像 d<b>er</b>）、ein neu<b>es</b>（像 da<b>s</b>）。</p><p>受格、與格以後加 <b>-en</b> 最多：<i>einen neu<b>en</b> Tisch</i>、<i>mit dem neu<b>en</b> Auto</i>。</p>' },
    { id: 'compar', tag: '形容詞', title: '比較級與最高級（größer als, am größten）', m: { tok: 'compar' }, ex: [['Im Juli ist es am wärmsten.', '七月最熱。'], ['Der Zug ist teurer als der Bus.', '火車比公車貴。']],
      body: T2(['原級', '比較級 -er', '最高級 am …-(e)sten'], [['schnell', 'schnell<b>er</b>', 'am schnell<b>sten</b>'], ['klein', 'klein<b>er</b>', 'am klein<b>sten</b>'], ['alt', '<b>ä</b>lt<b>er</b>', 'am <b>ä</b>lt<b>esten</b>'], ['groß', 'gr<b>ö</b>ß<b>er</b>', 'am gr<b>ö</b>ß<b>ten</b>']]) +
        '<p>「比…更」用 <b>als</b>：<i>Berlin ist größer <b>als</b> München.</i>；「跟…一樣」用 <b>so … wie</b>：<i>Anna ist so alt wie ich.</i></p><p>不規則要背：<b>gut → besser → am besten</b>、<b>gern → lieber → am liebsten</b>、<b>viel → mehr → am meisten</b>、hoch → höher → am höchsten。</p><p>短的形容詞常加變音：alt、jung、kalt、warm、lang、kurz、groß、gesund。</p>' },
    // ---- 連接詞 ----
    { id: 'konj', tag: '連接詞', title: 'und, aber, oder, denn, sondern', m: { re: w('und|aber|oder|denn|sondern') },
      body: '<p>這五個連接詞<b>不影響語序</b>（它們在「第 0 位」），後面照正常句子說：</p><ul><li><i>Ich trinke Tee <b>und</b> ich esse ein Brötchen.</i></li><li><i>Die Wohnung ist klein, <b>aber</b> schön.</i></li><li><i>Möchtest du Tee <b>oder</b> Kaffee?</i></li><li><i>Ich bleibe zu Hause, <b>denn</b> ich bin krank.</i></li><li><i>Nicht Kaffee, <b>sondern</b> Tee.</i>（不是…而是）</li></ul>' },
    { id: 'subord', tag: '連接詞', title: 'weil, dass, wenn：動詞跑到最後', m: { tok: 'subord' },
      body: '<p>weil（因為）、dass（…這件事）、wenn（如果）帶出的子句，<b>變化的動詞要放在子句最後</b>，前面加逗號：</p><ul><li><i>Ich lerne Deutsch, <b>weil</b> ich in Berlin studieren <b>möchte</b>.</i></li><li><i>Ich glaube, <b>dass</b> er krank <b>ist</b>.</i></li><li><i><b>Wenn</b> es <b>regnet</b>, bleibe ich zu Hause.</i></li></ul><p>比較 <b>denn</b>：意思跟 weil 一樣，但語序正常：<i>…, denn ich bin krank.</i> ／ <i>…, weil ich krank bin.</i></p><p>子句放在前面時，主句的動詞緊接在逗號後：<i>Wenn es regnet, <b>bleibe</b> ich zu Hause.</i></p>' },
    // ---- 日常 ----
    { id: 'intro', tag: '日常', title: '自我介紹：heißen, kommen aus, wohnen in', m: { re: w('heiße|heißt|heißen|komme aus|kommst aus|kommen aus|kommt aus|wohne in|wohnst|wohnt|wohnen|bin \\S+ Jahre alt|Jahre alt') },
      body: T2(['問', '答'], [['Wie heißt du? ／ Wie heißen Sie?', 'Ich heiße Lena. ／ Mein Name ist Lena Müller.'], ['Woher kommst du?', 'Ich komme aus Taiwan.'], ['Wo wohnst du?', 'Ich wohne in Taipeh.'], ['Wie alt bist du?', 'Ich bin zwanzig Jahre alt.'], ['Was bist du von Beruf?', 'Ich bin Student. ／ Ich arbeite als Ingenieur.'], ['Welche Sprachen sprichst du?', 'Ich spreche Chinesisch, Englisch und ein bisschen Deutsch.']]) +
        '<p>國家前面通常不加冠詞（aus Deutschland），但有幾個例外：<i>aus <b>der</b> Schweiz</i>、<i>aus <b>der</b> Türkei</i>、<i>aus <b>den</b> USA</i>。</p>' },
    { id: 'zuhause', tag: '日常', title: 'zu Hause 和 nach Hause', m: { re: w('zu Hause|nach Hause') },
      body: '<ul><li><b>zu Hause</b>＝在家（Wo?）：<i>Ich bin zu Hause.</i></li><li><b>nach Hause</b>＝回家（Wohin?）：<i>Ich gehe nach Hause.</i></li></ul><p>這是固定說法，Hause 有一個古老的與格 -e。</p>' }
  ];

  /* ---------- 詞性變化規則頁 ---------- */
  // 規則頁會把好幾個文法點的說明接在一起，每段前面加上小標題，才看得出換了主題
  const gb = id => { const g = DE.GRAMMAR.find(g => g.id === id); return '<h3 class="gb-h">' + g.title + '</h3>' + g.body; };
  const sp = e => DE.spec(e[3]);
  DE.RULES = [
    { id: 'r-noun', title: '名詞的性別與複數', icon: 'n',
      body: gb('noun-gender') + gb('noun-plural'),
      demo: ['Tisch', 'Lampe', 'Buch', 'Tag', 'Hand', 'Kind', 'Frau', 'Lehrerin', 'Lehrer', 'Apfel', 'Auto', 'Mädchen', 'Museum'],
      filter: e => e[1] === 'n' },
    { id: 'r-art', title: '冠詞與格', icon: 'a',
      body: gb('art-def') + gb('cases') + gb('art-indef'),
      demo: ['Mann', 'Frau', 'Kind', 'Tisch', 'Lampe', 'Buch', 'Herr', 'Student', 'Eltern'],
      filter: e => e[1] === 'n' },
    { id: 'r-adj', title: '形容詞', icon: 'g',
      body: gb('adj-pred') + gb('adj-end') + gb('compar'),
      demo: ['neu', 'klein', 'groß', 'alt', 'gut', 'hoch', 'teuer', 'dunkel', 'müde'],
      filter: e => e[1] === 'adj' },
    { id: 'r-reg', title: '規則動詞的現在式', icon: 'v',
      body: gb('pres-reg'), demo: ['machen', 'arbeiten', 'tanzen', 'wandern'],
      filter: e => e[1] === 'v' && !sp(e).sep && !DE.isRefl(e[0]) },
    { id: 'r-st', title: '強變化動詞', icon: 'v',
      body: gb('stem') + gb('perf-sein'), demo: ['fahren', 'essen', 'lesen', 'nehmen', 'schlafen'],
      filter: e => e[1] === 'v-st' && !sp(e).sep && !DE.isRefl(e[0]) },
    { id: 'r-sep', title: '分離動詞', icon: 'v',
      body: gb('sep'), demo: ['aufstehen', 'anrufen', 'einkaufen', 'fernsehen'],
      filter: e => /^v/.test(e[1]) && !!sp(e).sep },
    { id: 'r-refl', title: '反身動詞', icon: 'v',
      body: gb('refl'), demo: ['sich freuen', 'sich setzen', 'sich anziehen'],
      filter: e => /^v/.test(e[1]) && DE.isRefl(e[0]) },
    { id: 'r-sh', title: 'sein、haben、werden', icon: 'v',
      body: gb('sein') + gb('haben') + gb('perf-haben') + gb('praet'), demo: ['sein', 'haben', 'werden'],
      filter: e => ['sein', 'haben', 'werden'].includes(e[0]) && /^v/.test(e[1]) },
    { id: 'r-mod', title: '情態動詞與其他不規則動詞', icon: 'v',
      body: gb('modal') + gb('moechte'), demo: ['können', 'müssen', 'wollen', 'möchten', 'wissen'],
      filter: e => e[1] === 'v-mod' || (e[1] === 'v-irr' && !['sein', 'haben', 'werden'].includes(e[0])) }
  ];

  // 規則頁的示範表（給 App 用）
  DE.demoTable = function (id, list) {
    if (id === 'r-noun') return { head: ['單數', '複數', '性別'], rows: list.filter(e => e[1] === 'n').map(e => { const f = DE.nounForms(e); return [{ t: f.sg, f: 1 }, { t: f.pl || '—', f: 1 }, { t: DE.GENDER[e[2]][1] }]; }) };
    if (id === 'r-art') return { head: ['主格', '受格', '與格'], rows: list.filter(e => e[1] === 'n').map(e => { const C = DE.nounCases(e); const k = e[2] === 'pl' ? 1 : 0; return ['Nom', 'Akk', 'Dat'].map(c => ({ t: C[c][k], f: 1 })); }) };
    if (id === 'r-adj') return { head: ['原級', '比較級', 'der …', 'ein …'], rows: list.filter(e => e[1] === 'adj').map(e => { const a = DE.adjInfo(e), at = DE.adjAttr(e); return [{ t: a.w, f: 1 }, { t: a.cmp || '—', f: 1 }, { t: at ? at.def.m : '—', f: 1 }, { t: at ? at.ind.m : '—', f: 1 }]; }) };
    return null;
  };
})(typeof window !== 'undefined' ? window : globalThis);
