/* 德文變化引擎：冠詞與格、名詞複數、形容詞（比較級、名詞前的詞尾）、動詞變化（含強變化、分離動詞、反身動詞）、斷詞與查詢
   以德國標準德語為主 */
(function (G) {
  'use strict';
  const DE = G.DE || (G.DE = {});
  G.LX = DE;

  const PERSONS = ['ich', 'du', 'er/sie/es', 'wir', 'ihr', 'sie/Sie'];
  const REFL = ['mich', 'dich', 'sich', 'uns', 'euch', 'sich'];
  DE.PERSONS = PERSONS; DE.REFL = REFL;

  /* ---------- 小工具 ---------- */
  // 規格欄：key=value;key=value（沒有值的 key 當作 true）
  function spec(s) {
    const o = {};
    if (!s || s === '-') return o;
    s.split(';').forEach(p => { const i = p.indexOf('='); if (i < 0) o[p.trim()] = true; else o[p.slice(0, i).trim()] = p.slice(i + 1).trim(); });
    return o;
  }
  DE.spec = spec;
  const UML = { ä: 'a', ö: 'o', ü: 'u', Ä: 'A', Ö: 'O', Ü: 'U' };
  function stripAccents(s) { return String(s).replace(/[äöüÄÖÜ]/g, c => UML[c]).replace(/ß/g, 'ss').replace(/ẞ/g, 'SS'); }
  function foldDE(s) { return String(s).toLowerCase().replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss'); }
  DE.stripAccents = stripAccents; DE.foldDE = foldDE;

  /* ---------- 冠詞 ---------- */
  // 格的順序：主格 Nom、受格 Akk、與格 Dat、屬格 Gen
  const CASES = ['Nom', 'Akk', 'Dat', 'Gen'];
  const CASE_ZH = { Nom: '主格', Akk: '受格', Dat: '與格', Gen: '屬格' };
  const DEF = { m: ['der', 'den', 'dem', 'des'], f: ['die', 'die', 'der', 'der'], n: ['das', 'das', 'dem', 'des'], pl: ['die', 'die', 'den', 'der'] };
  const INDEF = { m: ['ein', 'einen', 'einem', 'eines'], f: ['eine', 'eine', 'einer', 'einer'], n: ['ein', 'ein', 'einem', 'eines'] };
  const KEIN = { m: ['kein', 'keinen', 'keinem', 'keines'], f: ['keine', 'keine', 'keiner', 'keiner'], n: ['kein', 'kein', 'keinem', 'keines'], pl: ['keine', 'keine', 'keinen', 'keiner'] };
  const G_ZH = { m: '陽性', f: '陰性', n: '中性', pl: '複數' };
  DE.CASES = CASES; DE.CASE_ZH = CASE_ZH; DE.DEF = DEF; DE.INDEF = INDEF; DE.KEIN = KEIN; DE.G_ZH = G_ZH;
  DE.GENDER = { m: ['陽性', '陽'], f: ['陰性', '陰'], n: ['中性', '中'], pl: ['只有複數', '複'] };
  const gKey = (g, plural) => plural || g === 'pl' ? 'pl' : g;
  const defArt = (g, plural, c) => DEF[gKey(g, plural)][CASES.indexOf(c || 'Nom')];
  const indefArt = (g, plural, c) => plural || g === 'pl' ? '' : INDEF[g][CASES.indexOf(c || 'Nom')];
  DE.defArt = defArt; DE.indefArt = indefArt;
  DE.withArt = (word, g, plural) => defArt(g, plural) + ' ' + word;
  DE.ARTICLES = ['der', 'die', 'das', 'den', 'dem', 'des'];
  DE.ART_INFO = { der: '陽性主格；也是陰性與格、複數屬格', die: '陰性主格／受格；複數主格／受格', das: '中性主格／受格', den: '陽性受格；複數與格', dem: '陽性／中性與格', des: '陽性／中性屬格' };
  DE.INDEF_INFO = { ein: '陽性主格；中性主格／受格', eine: '陰性主格／受格', einen: '陽性受格', einem: '陽性／中性與格', einer: '陰性與格', eines: '陽性／中性屬格' };
  // 介係詞＋冠詞的縮寫
  DE.ART_PREPS = { im: { prep: 'in', art: 'dem' }, ins: { prep: 'in', art: 'das' }, am: { prep: 'an', art: 'dem' }, ans: { prep: 'an', art: 'das' }, zum: { prep: 'zu', art: 'dem' }, zur: { prep: 'zu', art: 'der' }, vom: { prep: 'von', art: 'dem' }, beim: { prep: 'bei', art: 'dem' } };
  const CONTRACT = { 'in dem': 'im', 'in das': 'ins', 'an dem': 'am', 'an das': 'ans', 'zu dem': 'zum', 'zu der': 'zur', 'von dem': 'vom', 'bei dem': 'beim' };
  DE.artPrep = (prep, art) => CONTRACT[prep + ' ' + art] || prep + ' ' + art;
  // 這個冠詞配這個性別、單複數時，可能是哪幾個格
  function casesOf(art, g, plural) {
    const k = gKey(g, plural), out = [];
    const tab = /^(ein|kein)/.test(art) ? (art.startsWith('k') ? KEIN : INDEF) : DEF;
    if (!tab[k]) return out;
    tab[k].forEach((a, i) => { if (a === art) out.push(CASES[i]); });
    return out;
  }
  DE.casesOf = casesOf;
  // 哪些介係詞接哪一格
  DE.PREP_CASE = { mit: 'Dat', nach: 'Dat', aus: 'Dat', zu: 'Dat', von: 'Dat', bei: 'Dat', seit: 'Dat', ab: 'Dat', gegenüber: 'Dat', für: 'Akk', ohne: 'Akk', durch: 'Akk', gegen: 'Akk', um: 'Akk', bis: 'Akk', in: 'Wechsel', an: 'Wechsel', auf: 'Wechsel', über: 'Wechsel', unter: 'Wechsel', vor: 'Wechsel', hinter: 'Wechsel', neben: 'Wechsel', zwischen: 'Wechsel', während: 'Gen', wegen: 'Gen' };

  /* ---------- 名詞 ---------- */
  // 弱變化陽性名詞（n-Deklination）：受格、與格加 -(e)n
  const WEAK = { Herr: 'Herrn', Name: 'Namen', Junge: 'Jungen', Student: 'Studenten', Kunde: 'Kunden', Kollege: 'Kollegen', Nachbar: 'Nachbarn', Mensch: 'Menschen', Polizist: 'Polizisten', Tourist: 'Touristen', Praktikant: 'Praktikanten', Elefant: 'Elefanten', Löwe: 'Löwen', Bär: 'Bären', Affe: 'Affen', Präsident: 'Präsidenten', Neffe: 'Neffen', Fotograf: 'Fotografen', Journalist: 'Journalisten' };
  DE.WEAK = WEAK;
  const datPl = pl => /[ns]$/.test(pl) ? pl : pl + 'n';
  DE.datPl = datPl;
  function nounForms(e) {
    const [w, , g, pl] = e;
    if (g === 'pl') return { sg: 'die ' + w, pl: '', plOnly: true, plGender: g, indef: '' };
    const hasPl = pl && pl !== '-';
    return { sg: 'die der das'.split(' ')[['f', 'm', 'n'].indexOf(g)] + ' ' + w, pl: hasPl ? 'die ' + pl : '', plOnly: false, plGender: g, indef: INDEF[g][0] };
  }
  DE.nounForms = nounForms;
  // 各格的形：{ Nom: [單數, 複數], Akk: …, Dat: … }
  function nounCases(e) {
    const [w, , g, pl] = e;
    const out = {};
    const hasPl = g === 'pl' || (pl && pl !== '-');
    const plW = g === 'pl' ? w : pl;
    CASES.slice(0, 3).forEach((c, i) => {
      let sg = '';
      if (g !== 'pl') { const f = i > 0 && WEAK[w] ? WEAK[w] : w; sg = DEF[g][i] + ' ' + f; }
      const p = hasPl ? DEF.pl[i] + ' ' + (i === 2 ? datPl(plW) : plW) : '';
      out[c] = [sg, p];
    });
    return out;
  }
  DE.nounCases = nounCases;
  // 依詞尾猜複數（只用來檢查資料，德文複數大多要背）
  function plausiblePlural(w, g, pl) {
    if (pl === w) return /(er|el|en|chen|lein)$/.test(w); // der Lehrer → die Lehrer
    const um = s => s.replace(/(au|Au|a|o|u|A|O|U)(?=[^aouäöüAOU]*$)/, m => ({ au: 'äu', Au: 'Äu', a: 'ä', o: 'ö', u: 'ü', A: 'Ä', O: 'Ö', U: 'Ü' })[m]);
    const cands = [w + 'e', w + 'en', w + 'n', w + 'er', w + 's', um(w) + 'e', um(w) + 'er', um(w), w + 'nen'];
    if (/(um|on)$/.test(w)) cands.push(w.slice(0, -2) + 'en'); // Museum → Museen, Zentrum → Zentren
    if (/a$/.test(w)) cands.push(w.slice(0, -1) + 'en'); // Pizza → Pizzen
    return cands.includes(pl);
  }
  DE.plausiblePlural = plausiblePlural;

  /* ---------- 形容詞 ---------- */
  function adjInfo(e) {
    const w = e[0], sp = spec(e[3]);
    const inv = !!sp.inv, pred = !!sp.pred;
    // 名詞前的詞幹：dunkel → dunkl-、teuer → teur-、hoch → hoh-
    let att = sp.att || w;
    if (!sp.att) {
      if (/el$/.test(w)) att = w.slice(0, -2) + 'l';
      else if (/(au|eu)er$/.test(w)) att = w.slice(0, -2) + 'r';
    }
    let cmp = '', sup = '';
    if (!sp.nocmp && !inv && !pred) {
      cmp = sp.cmp || (/e$/.test(w) ? w + 'r' : att + 'er');
      if (sp.sup) sup = sp.sup;
      else if (/e$/.test(w)) sup = w + 'sten';
      else if (/([dtsßxz]|sch)$/.test(w)) sup = w + 'esten';
      else sup = w + 'sten';
    }
    const ends = s => /e$/.test(s) ? [s, s + 'n', s + 'r', s + 's', s + 'm'] : [s + 'e', s + 'en', s + 'er', s + 'es', s + 'em'];
    return { w, att, cmp, sup, inv, pred, ends, attForms: inv || pred ? [] : ends(att) };
  }
  DE.adjInfo = adjInfo;
  function adjForms(e) {
    const a = adjInfo(e);
    return a.cmp ? [a.w, a.cmp, 'am ' + a.sup] : [a.w];
  }
  DE.adjForms = adjForms;
  // 名詞前的形容詞詞尾（主格）：定冠詞後（弱變化）、不定冠詞後（混合變化）
  function adjAttr(e) {
    const a = adjInfo(e);
    if (!a.attForms.length) return null;
    const [xe, xen, xer, xes] = a.attForms;
    return {
      def: { m: 'der ' + xe, f: 'die ' + xe, n: 'das ' + xe, pl: 'die ' + xen },
      ind: { m: 'ein ' + xer, f: 'eine ' + xe, n: 'ein ' + xes, pl: xe }
    };
  }
  DE.adjAttr = adjAttr;

  /* ---------- 動詞 ---------- */
  const IRR = {
    sein: { p: 'bin bist ist sind seid sind', pp: 'gewesen', aux: 'sein', imp: 'sei|seid|seien Sie|seien wir' },
    haben: { p: 'habe hast hat haben habt haben', pp: 'gehabt', imp: 'hab|habt|haben Sie|haben wir' },
    werden: { p: 'werde wirst wird werden werdet werden', pp: 'geworden', aux: 'sein', imp: 'werde|werdet|werden Sie|werden wir' },
    wissen: { p: 'weiß weißt weiß wissen wisst wissen', pp: 'gewusst', imp: '' },
    tun: { p: 'tue tust tut tun tut tun', pp: 'getan', imp: 'tu|tut|tun Sie|tun wir' },
    können: { p: 'kann kannst kann können könnt können', pp: 'gekonnt', imp: '' },
    müssen: { p: 'muss musst muss müssen müsst müssen', pp: 'gemusst', imp: '' },
    dürfen: { p: 'darf darfst darf dürfen dürft dürfen', pp: 'gedurft', imp: '' },
    wollen: { p: 'will willst will wollen wollt wollen', pp: 'gewollt', imp: '' },
    sollen: { p: 'soll sollst soll sollen sollt sollen', pp: 'gesollt', imp: '' },
    mögen: { p: 'mag magst mag mögen mögt mögen', pp: 'gemocht', imp: '' },
    möchten: { p: 'möchte möchtest möchte möchten möchtet möchten', pp: '', imp: '', note: 'mögen 的禮貌形（我想要）；過去要說 wollte' }
  };
  DE.IRR = IRR;
  const INSEP = /^(be|ver|er|ent|emp|ge|zer|miss)/;
  const isRefl = l => /^sich /.test(l);
  const baseOf = l => l.replace(/^sich /, '');
  DE.isRefl = isRefl; DE.baseOf = baseOf;
  // 規則的現在式
  function regPresent(inf) {
    if (/(el|er)n$/.test(inf)) {
      const st = inf.slice(0, -1); // wander, lächel
      const ich = /eln$/.test(inf) ? st.slice(0, -2) + 'le' : st + 'e';
      return { stem: st, eIns: false, sib: false, p: [ich, st + 'st', st + 't', inf, st + 't', inf], imp: ich };
    }
    const st = inf.slice(0, -2);
    const eIns = /[dt]$/.test(st) || /chn$/.test(st) || /[bcdfgkpqstvwxzß][mn]$/.test(st);
    const sib = /(s|ß|z|x)$/.test(st);
    const du = st + (sib ? 't' : eIns ? 'est' : 'st'), er = st + (eIns ? 'et' : 't');
    return { stem: st, eIns, sib, p: [st + 'e', du, er, inf, er, inf], imp: eIns || /ig$/.test(st) ? st + 'e' : st };
  }
  DE.regPresent = regPresent;
  function weakPP(inf) {
    const r = regPresent(inf);
    const tail = r.eIns ? 'et' : 't';
    if (/ieren$/.test(inf)) return r.stem + 't';
    if (INSEP.test(inf) && !/^(geben|gehen|gern)/.test(inf)) return r.stem + tail;
    return 'ge' + r.stem + tail;
  }
  DE.weakPP = weakPP;
  function conjugate(lemma, type) {
    const refl = isRefl(lemma);
    const full = baseOf(lemma);
    const sp = spec((DE._specOf || buildSpec())[lemma]);
    const sep = sp.sep || '';
    const inf = sep ? full.slice(sep.length) : full; // aufstehen → stehen
    const irr = IRR[full];
    let present, ppv, aux = sp.aux || 'haben', impDu, impSpec = null, change = '';
    if (irr) {
      present = irr.p.split(' '); ppv = irr.pp; aux = irr.aux || 'haben';
      impSpec = irr.imp === '' ? null : irr.imp.split('|');
    } else {
      const r = regPresent(inf);
      present = sp.pres ? sp.pres.split(' ') : r.p.slice();
      impDu = r.imp;
      if (sp.du) {
        present[1] = sp.du;
        present[2] = sp.er || (r.sib ? sp.du : sp.du.slice(0, -2) + 't');
        const v0 = (r.stem.match(/[aeiouäöü]+/g) || ['']).pop(), v1 = (sp.du.match(/[aeiouäöü]+/g) || ['']).pop();
        if (v0 !== v1) change = v0 + ' → ' + v1;
        // e → i／ie 的動詞，命令式 du 也變：gib、nimm、lies、iss
        if (/^e/.test(v0) && /^i/.test(v1)) impDu = r.sib ? sp.du.slice(0, -1) : sp.du.slice(0, -2);
      }
      if (sp.imp) impDu = sp.imp;
      ppv = sp.pp || (sep ? sep + weakPP(inf) : weakPP(inf));
    }
    if (sp.pp) ppv = sp.pp;
    if (sp.nopast) ppv = '';
    const tail = (i, f) => f + (refl ? ' ' + REFL[i] : '') + (sep ? ' ' + sep : '');
    const presentFull = present.map((f, i) => tail(i, f));
    const AUX = aux === 'sein' ? IRR.sein.p.split(' ') : IRR.haben.p.split(' ');
    const passato = ppv ? AUX.map((h, i) => h + (refl ? ' ' + REFL[i] : '') + ' ' + ppv) : [];
    let imperative = null;
    const noImp = sp.noimp || (irr && !impSpec) || type === 'v-mod';
    if (!noImp) {
      const base4 = impSpec ? impSpec : [impDu, present[4], inf + ' Sie', inf + ' wir'];
      const rp = ['dich', 'euch', 'sich', 'uns'];
      imperative = base4.map((f, i) => f + (refl ? ' ' + rp[i] : '') + (sep ? ' ' + sep : ''));
    }
    return {
      lemma, type, cls: type, refl, sep, inf, aux, pp: ppv, change,
      present, presentFull, passato, imperative, note: sp.note || (irr && irr.note) || ''
    };
  }
  DE.conjugate = conjugate;
  function buildSpec() {
    const m = {};
    (DE.W || []).forEach(e => { if (/^v/.test(e[1])) m[e[0]] = e[3]; });
    return (DE._specOf = m);
  }

  // 只當查詢用的常見形（過去式 Präteritum 等）
  DE.EXTRA_FORMS = {
    war: ['sein', '過去式 ich／er（是；在）'], warst: ['sein', '過去式 du'], waren: ['sein', '過去式 wir／sie'], wart: ['sein', '過去式 ihr'],
    hatte: ['haben', '過去式 ich／er（有）'], hattest: ['haben', '過去式 du'], hatten: ['haben', '過去式 wir／sie'], hattet: ['haben', '過去式 ihr'],
    konnte: ['können', '過去式 ich／er（能夠）'], konnten: ['können', '過去式 wir／sie'], musste: ['müssen', '過去式 ich／er（必須）'], mussten: ['müssen', '過去式 wir／sie'],
    wollte: ['wollen', '過去式 ich／er（想要）'], wollten: ['wollen', '過去式 wir／sie'], durfte: ['dürfen', '過去式 ich／er（可以）'], sollte: ['sollen', '過去式 ich／er（應該）'],
    gab: ['geben', '過去式（es gab＝那時有）'], wurde: ['werden', '過去式 ich／er（變成）'],
    hätte: ['haben', '虛擬式（ich hätte gern＝我想要）'], wäre: ['sein', '虛擬式（那就是…了）'], würde: ['werden', '虛擬式（我會…）'], könnten: ['können', '虛擬式（可以…嗎，客氣）'], könnte: ['können', '虛擬式（可以…嗎，客氣）']
  };

  /* ---------- 斷詞 ---------- */
  const LET = 'A-Za-zÀ-ÖØ-öø-ÿẞ';
  const TOK_RE = new RegExp('[' + LET + ']+|[^' + LET + ']+', 'g');
  const norm = s => String(s).replace(/[’‘]/g, "'");
  function tokenize(sentence) {
    const out = []; const s = norm(sentence); let m; TOK_RE.lastIndex = 0;
    while ((m = TOK_RE.exec(s))) out.push({ t: m[0], w: new RegExp('^[' + LET + ']').test(m[0]) });
    return out;
  }
  DE.tokenize = tokenize; DE.norm = norm;

  /* ---------- 查詢表 ---------- */
  function buildLookup(words, extra) {
    const map = new Map();
    const add = (form, lemma, desc, idx) => {
      if (!form || form === '-') return;
      const k = norm(form).toLowerCase();
      if (!map.has(k)) map.set(k, []);
      const arr = map.get(k);
      if (!arr.some(e => e.lemma === lemma && e.desc === desc)) arr.push({ lemma, desc, idx });
    };
    const P2 = PERSONS;
    const IMP = ['du', 'ihr', 'Sie', 'wir'];
    words.forEach((e, idx) => {
      const [w, pos, g, pl] = e;
      if (pos === 'expr' || (/ /.test(w) && !/^v/.test(pos))) {
        w.split(' ').forEach(x => { const k = x.toLowerCase(); if (!map.has(k)) add(x, w, '「' + w + '」的一部分', idx); });
        if (pl && pl !== '-' && pos !== 'expr') pl.split('/').forEach(x => add(x, w, '', idx));
        if (pos === 'expr') return;
      }
      if (pos === 'n') {
        if (g === 'pl') { add(w, w, '複數（只有複數）', idx); add(datPl(w), w, '複數與格', idx); return; }
        add(w, w, '單數', idx);
        const hasPl = pl && pl !== '-';
        if (hasPl) { add(pl, w, pl === w ? '單複數同形' : '複數', idx); if (datPl(pl) !== pl) add(datPl(pl), w, '複數與格（-n）', idx); }
        if (WEAK[w]) add(WEAK[w], w, '單數受格／與格（弱變化名詞）', idx);
        if (g !== 'f') { add(w + (/(s|ß|x|z|sch)$/.test(w) ? 'es' : 's'), w, '單數屬格', idx); if (w === 'Name') add('Namens', w, '單數屬格', idx); }
      } else if (pos === 'adj') {
        const a = adjInfo(e);
        add(w, w, '原級', idx);
        a.attForms.forEach(x => add(x, w, '名詞前的詞尾變化', idx));
        if (a.cmp) { add(a.cmp, w, '比較級', idx); a.ends(a.cmp).forEach(x => x !== a.cmp && add(x, w, '比較級＋詞尾', idx)); }
        if (a.sup) { add(a.sup, w, '最高級（am …sten）', idx); const s = a.sup.slice(0, -1); a.ends(s).forEach(x => add(x, w, '最高級＋詞尾', idx)); }
      } else if (/^v/.test(pos)) {
        const c = conjugate(w, pos);
        const shown = c.refl ? w : w;
        add(baseOf(w), shown, '原形', idx);
        c.present.forEach((f, i) => add(f, shown, '現在式 ' + P2[i] + (c.sep ? '（分離：' + f + ' … ' + c.sep + '）' : ''), idx));
        if (c.pp) add(c.pp, shown, '過去分詞（完成式：' + c.aux + ' … ' + c.pp + '）', idx);
        if (c.imperative) c.imperative.forEach((f, i) => add(f.split(' ')[0], shown, '命令式 ' + IMP[i], idx));
        if (c.sep) { add(c.sep, shown, '分離動詞 ' + baseOf(w) + ' 的前綴', idx); add(c.inf, shown, '「' + baseOf(w) + '」去掉前綴的部分', idx); }
        if (c.refl) add('sich', shown, '反身代名詞', idx);
      } else {
        add(w, w, '', idx);
        if (pl && pl !== '-') pl.split('/').forEach(x => add(x, w, '', idx));
      }
    });
    if (extra) for (const k of Object.keys(extra)) add(k, extra[k][0], extra[k][1], -1);
    Object.keys(DE.ART_PREPS).forEach(k => { const a = DE.ART_PREPS[k]; add(k, a.prep, a.prep + ' ＋ ' + a.art, -2); });
    return map;
  }
  DE.buildLookup = buildLookup;

  // 答案比對：大小寫一般不計較，但名詞小寫開頭、變音或 ß 寫錯要提醒
  function checkAnswer(input, answer, w) {
    const a = norm(input).trim().replace(/\s+/g, ' ').replace(/[?!.,]$/g, '');
    const b = norm(answer).trim();
    if (!a) return 'wrong';
    if (a === b) return 'ok';
    if (a.toLowerCase() === b.toLowerCase()) {
      if (w && w.pos === 'n' && /^[A-ZÄÖÜ]/.test(b) && /^[a-zäöü]/.test(a)) return 'accent';
      return 'ok';
    }
    if (foldDE(a) === foldDE(b) || stripAccents(a).toLowerCase() === stripAccents(b).toLowerCase()) return 'accent';
    return 'wrong';
  }
  DE.checkAnswer = checkAnswer;

  /* ---------- 單字頁的變化表（給 App 用） ---------- */
  DE.formsTable = function (e) {
    if (e[1] === 'n') {
      const C = nounCases(e);
      const rows = CASES.slice(0, 3).map(c => [CASE_ZH[c] + ' ' + c + '.', C[c][0], C[c][1]]);
      const f = nounForms(e);
      const note = e[2] === 'pl' ? '這個字只有複數形。' : (!f.pl ? '這個字通常不用複數。' : '') +
        (WEAK[e[0]] ? `弱變化名詞：受格、與格都加 -n／-en（den ${WEAK[e[0]]}、dem ${WEAK[e[0]]}）。` : '') +
        (e[2] !== 'pl' ? `不定冠詞：${INDEF[e[2]][0]} ${e[0]}（受格 ${INDEF[e[2]][1]} ${WEAK[e[0]] || e[0]}，與格 ${INDEF[e[2]][2]} ${WEAK[e[0]] || e[0]}）` : '');
      return { head: ['', '單數', '複數'], rows: rows.map(r => e[2] === 'pl' ? [r[0], r[2]] : r), headPl: e[2] === 'pl' ? ['', '複數'] : null, note };
    }
    if (e[1] === 'adj') {
      const a = adjInfo(e), at = adjAttr(e);
      const rows = [['原級', a.w]];
      if (a.cmp) rows.push(['比較級', a.cmp], ['最高級', 'am ' + a.sup]);
      const t2 = at ? { head: ['名詞前（主格）', '定冠詞後', '不定冠詞後'], rows: [['陽性', at.def.m + ' …', at.ind.m + ' …'], ['陰性', at.def.f + ' …', at.ind.f + ' …'], ['中性', at.def.n + ' …', at.ind.n + ' …'], ['複數', at.def.pl + ' …', at.ind.pl + ' …（沒有冠詞）']] } : null;
      const note = a.inv ? '這個字不變化：放在名詞前也不加詞尾。' : a.pred ? '這個字通常只放在 sein 後面（Ich bin …），不放在名詞前。' : (!a.cmp ? '這個字通常沒有比較級。' : '');
      return { rows, more: t2, note };
    }
    return null;
  };
})(typeof window !== 'undefined' ? window : globalThis);
