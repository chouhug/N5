/* 德文頁的設定 */
window.LANGCFG = {
  id: 'de', name: '德文', short: '德', level: 'A1', glyph: 'ß', tts: 'de-DE',
  ttsSample: 'Hallo! Wie geht es dir? Danke, gut.',
  voiceNames: /anna|markus|petra|yannick|helena|hedda|katja|conrad|amala|stefan|klaus|vicki|marlene|hans|sandy|shelley|eddy|flo|reed|rocko|grandma|grandpa|martin|seraphina|florian|killian/,
  noVoiceHelp: '這台裝置沒有德文語音。iPhone／iPad：到「設定 → 輔助使用 → 朗讀內容 → 聲音 → 德文」下載語音。Android：到「文字轉語音」設定下載德文。',
  persons: ['ich', 'du', 'er/sie/es', 'wir', 'ihr', 'sie/Sie'],
  sayPerson: i => ['ich', 'du', 'er', 'wir', 'ihr', 'sie'][i],
  impPersons: ['du', 'ihr', 'Sie（您）', 'wir（我們…吧）'],
  pastLabel: '現在完成式 Perfekt',
  artLabel: '冠詞・性別',
  accentNote: '，但注意拼寫（變音、ß 或大小寫）',
  posZh: { v: '動詞（規則）', 'v-st': '動詞（強變化）', 'v-irr': '不規則動詞', 'v-mod': '情態動詞' },
  verbTags: c => [{ v: '規則動詞', 'v-st': '強變化動詞', 'v-irr': '不規則動詞', 'v-mod': '情態動詞' }[c.type] || '動詞']
    .concat(c.sep ? ['分離動詞（' + c.sep + '-）'] : [], c.refl ? ['反身動詞'] : [], c.change ? ['母音變化 ' + c.change] : [],
      c.pp ? ['過去分詞 ' + c.pp] : [], c.pp ? ['完成式用 ' + c.aux] : []),
  ruleShort: { 'r-noun': '名詞', 'r-art': '冠詞與格', 'r-adj': '形容詞', 'r-reg': '規則動詞', 'r-st': '強變化', 'r-sep': '分離動詞', 'r-sh': 'sein／haben', 'r-mod': '情態動詞', 'r-refl': '反身動詞' },
  letterGroups: [{ title: '德文字母（26 個）', from: 0, to: 26 }, { title: '變音字母與 ß', from: 26, to: 30 }],
  letterNote: '點字母看發音和例字。德文大致照拼字發音；名詞一律大寫開頭。ä、ö、ü 是變音字母，ß 唸 [s]（大寫寫成 ẞ 或 SS）。'
};
