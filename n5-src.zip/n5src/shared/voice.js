// ================= 語音（日文頁和語言頁共用：n5src/shared/voice.js） =================
// build.js 會把這個檔複製進兩邊的頁面（見 lib-tab.js 開頭的說明）。
// 用瀏覽器內建的語音（speechSynthesis）念單字和句子。各語言怎麼挑聲音由 PAGE.voice 提供：
//   GOOD 比較自然的語音名稱、match(v) 這個語言的語音、score(v) 越高越好、robotic(v) 聽起來很機械（可省略）、
//   saved()／save(uri) 使用者選的語音、text(t) 念之前整理文字（可省略）、uLang(v) 要念的語言代碼、
//   label 設定裡的標題、none 沒有語音時的說明、help(opts) 語音不好時的建議、note 設定說明、sample 試聽的句子
const Voice = {
  list: [], ok: 'speechSynthesis' in window,
  get GOOD() { return PAGE.voice.GOOD; },
  score(v) { return PAGE.voice.score(v); },
  refresh() { if (!this.ok) return; try { this.list = speechSynthesis.getVoices().filter(v => PAGE.voice.match(v)); } catch (e) { this.list = []; } },
  init() {
    if (!this.ok) return;
    const load = () => { this.refresh(); if (UI.tab === 'lib') renderVoiceBox(); };
    load();
    try { speechSynthesis.addEventListener('voiceschanged', load); } catch (e) { speechSynthesis.onvoiceschanged = load; }
  },
  best() {
    if (!this.list.length) this.refresh();
    const saved = PAGE.voice.saved();
    if (saved) { const v = this.list.find(x => x.voiceURI === saved || x.name === saved); if (v) return v; }
    return this.list.slice().sort((a, b) => this.score(b) - this.score(a))[0] || null;
  },
  allRobotic() { const R = PAGE.voice.robotic; return !!R && this.list.length > 0 && this.list.every(R); },
  // voiceOverride：指定用哪個聲音；rate：指定速度（例如慢速播放），沒給就用設定
  speak(text, voiceOverride, rate) {
    if (!this.ok || !text) { if (!this.ok) toast('這個瀏覽器不支援語音播放'); return; }
    const P = PAGE.voice;
    try {
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(P.text ? P.text(text) : text);
      const v = voiceOverride || this.best();
      if (v) u.voice = v;
      u.lang = P.uLang(v);
      u.rate = rate || Number(SET.rate) || 0.9;
      speechSynthesis.speak(u);
    } catch (e) { toast('無法播放聲音'); }
  }
};
// 設定裡的「發音」區：選語音、速度、試聽
function renderVoiceBox() {
  const P = PAGE.voice;
  const box = $('#voiceBox'); if (!box) return;
  if (!Voice.ok) { box.innerHTML = '<div class="warn">這個瀏覽器不支援語音播放。建議改用 Safari、Chrome 或 Edge。</div>'; return; }
  Voice.refresh();
  const best = Voice.best();
  const opts = Voice.list.slice().sort((a, b) => Voice.score(b) - Voice.score(a));
  box.innerHTML = `<div style="display:flex;flex-direction:column;gap:12px">
    <label class="label" for="vsel">${P.label}</label>
    ${opts.length ? `<select id="vsel">${opts.map(v => `<option value="${esc(v.voiceURI)}"${best && v.voiceURI === best.voiceURI ? ' selected' : ''}>${esc(v.name)}${Voice.GOOD.test(v.name) ? '（較自然）' : ''}</option>`).join('')}</select>` : `<div class="meta">${P.none}</div>`}
    <div class="range"><label class="label" for="vrate">速度</label><input id="vrate" type="range" min="0.6" max="1.2" step="0.1" value="${SET.rate}"><span class="meta" id="vrateV">${Number(SET.rate).toFixed(1)} 倍</span></div>
    <div class="row"><button class="play" id="vtest">${ICON.play}試聽</button></div>
    ${P.help(opts)}
    <div class="meta">${P.note}</div>
  </div>`;
  const sel = $('#vsel');
  if (sel) sel.onchange = () => P.save(sel.value);
  const rate = $('#vrate');
  rate.oninput = () => { SET.rate = Number(rate.value); $('#vrateV').textContent = SET.rate.toFixed(1) + ' 倍'; saveSet(); };
  $('#vtest').onclick = () => Voice.speak(P.sample);
}
