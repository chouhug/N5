// ================= 填空（日文頁和語言頁共用：n5src/shared/fill-tab.js） =================
// build.js 會把這個檔複製進兩邊的頁面（見 lib-tab.js 開頭的說明）。
// 共用的是出題和答題流程：選題、送出、判斷、記錄、音效、下一題、手機鍵盤的處理。
// 題目長什麼樣子由 PAGE.fill 決定：
//   top() 來源選單上面的東西、bindTop(host)、alt() 回傳 true＝改走別的模式（日文：聽寫）、
//   recentQueue(pool)「最近學過」的出題順序、
//   make(w, R) 回傳這一題：{ html 卡片內容（要有 #fillIn #fillGo #fillShow #blank #fillAfter，
//     可以有 #fillHintBtn #fillHint）, blankEmpty, live(inp, blank) 打字時, check(v) → 'ok'|'accent'|'wrong',
//     retry(v) 答錯但值得再給一次機會時回傳 true（語言頁：填了同義字）, hintSound 按提示時「滴」一聲,
//     reveal(blank) 答完後空格裡放答案, hideButtons(), verdict(res, shown, v) 對錯標示,
//     correct(v, shown) 答錯時的正確答案, wordRow() 單字那一行, after(ok) 答完之後（語言頁：念例句） }
let fillRound = null;
const FILL_SRCS = [['learn', '待考'], ['recent', '最近學過'], ['fillWrong', '填空錯題'], ['fillReview', '錯題複習'], ['due', '到期複習']];
function renderFill() {
  const P = PAGE.fill;
  const host = $('#tab-fill');
  Quiz.active = null;
  if (P.alt && P.alt()) return;
  const counts = Object.fromEntries(FILL_SRCS.map(([k]) => [k, srcPool(k).length]));
  host.innerHTML = `${P.top()}
    <div class="ctl">${pillSelect('fillSrc', '題目來源', FILL_SRCS.map(([k, l]) => [k, `${l} ${counts[k]}`]), UI.fillSrc)}${UI.fillSrc === 'recent' ? recentCtl().html : posChips()}</div>
    <div id="fq"></div>`;
  P.bindTop(host);
  $('#fillSrc', host).onchange = e => { UI.fillSrc = e.target.value; saveUI(); fillRound = null; renderFill(); };
  recentCtl(renderFill).bind(host);
  bindPos(host, () => { fillRound = null; renderFill(); });
  if (fillRound && fillRound.done) { fillRound.idx++; fillRound.done = false; }
  const valid = fillRound && fillRound.src === UI.fillSrc && (UI.fillSrc === 'recent' || fillRound.pos === UI.pos);
  if (!valid || fillRound.idx >= fillRound.queue.length) {
    if (valid && fillRound.queue.length && fillRound.idx >= fillRound.queue.length) return roundDone($('#fq'), fillRound, () => { fillRound = null; renderFill(); });
    const pool = srcPool(UI.fillSrc);
    if (!pool.length) return emptyWords($('#fq'), UI.fillSrc);
    const isRev = UI.fillSrc === 'fillReview';
    fillRound = { queue: UI.fillSrc === 'recent' ? P.recentQueue(pool) : pickRound(pool, getRec, 'fill', isRev ? REVIEW_ROUND : roundSize(), isRev), idx: 0, total: pool.length, src: UI.fillSrc, pos: UI.pos, right: 0 };
  }
  nextFillQ();
}
function nextFillQ(keepFocus) {
  const R = fillRound, host = $('#fq'); if (!R || !host) return;   // 自動跳下一題前範圍被換掉了（R 已清空）
  if (R.idx >= R.queue.length) { document.body.classList.remove('typing'); return roundDone(host, R, () => { fillRound = null; renderFill(); }); }
  const w = R.queue[R.idx];
  const src = { fillWrong: 'wrong', fillReview: 'review', due: 'due' }[R.src] || 'learn';
  const q = PAGE.fill.make(w, R);
  host.innerHTML = `<div class="card" id="fillCard">
    ${q.html}
  </div>`;
  const inp = $('#fillIn'), blank = $('#blank');
  let answered = false;
  inp.addEventListener('input', () => q.live(inp, blank));
  const hb = $('#fillHintBtn');
  if (hb) hb.onclick = () => {
    const h = $('#fillHint'), on = h.hidden;
    h.hidden = !on; hb.textContent = on ? '收起提示' : '提示'; hb.setAttribute('aria-pressed', String(on));
    if (q.hintSound) Sfx.tick();
  };
  const finish = (res, shown) => {
    answered = true;
    R.done = true;
    const ok = res !== 'wrong';
    if (ok) R.right++;
    record(w, 'fill', ok, src);
    ok ? Sfx.ok() : Sfx.ng(); buzz(ok);
    q.reveal(blank);
    blank.classList.add(ok ? 'ok' : 'ng');
    inp.readOnly = true;
    $('#fillGo').textContent = '下一題';
    q.hideButtons();
    const r = getRec(w.id);
    const learnedNow = ok && r.s === 'learned' && r.lv === 0 && r.due === addDays(today(), 1) && src !== 'due';
    $('#fillAfter').innerHTML = `<div class="afterbox">
      ${q.verdict(res, shown, inp.value)}
      ${!ok ? q.correct(inp.value, shown) : ''}
      ${learnedNow ? `<div class="meta">已學會，明天（${r.due.slice(5).replace('-', '/')}）會出現在到期複習。</div>` : ''}
      ${ok && src === 'due' ? `<div class="meta">下次複習：${r.due.slice(5).replace('-', '/')}</div>` : ''}
      ${q.wordRow()}
      ${exampleBlock(w)}
    </div>`;
    if (q.after) q.after(ok);
  };
  const next = () => { R.idx++; R.done = false; nextFillQ(true); };
  $('#fillForm').addEventListener('submit', e => {
    e.preventDefault();
    if (answered) return next();
    if (!inp.value.trim()) { inp.focus(); return; }
    const res = q.check(inp.value);
    if (res === 'wrong' && q.retry && q.retry(inp.value)) return;
    finish(res, false);
  });
  $('#fillGo').addEventListener('mousedown', e => e.preventDefault()); // 按送出時不讓鍵盤收起
  $('#fillShow').onclick = () => { if (!answered) finish('wrong', true); };
  inp.addEventListener('focus', () => { document.body.classList.add('typing'); setTimeout(scrollFillTop, 280); });
  inp.addEventListener('blur', () => setTimeout(() => { const a = document.activeElement; if (!a || a.id !== 'fillIn') document.body.classList.remove('typing'); }, 250));
  if (keepFocus && window.matchMedia('(pointer:fine)').matches) inp.focus({ preventScroll: true });
  else if (keepFocus && document.body.classList.contains('typing')) { inp.focus({ preventScroll: true }); scrollFillTop(); }
}
// 打字時（鍵盤打開）把題目捲到畫面最上面
function scrollFillTop() {
  const card = $('#fillCard');
  if (!card || !document.body.classList.contains('typing')) return;
  const y = card.getBoundingClientRect().top + window.scrollY - 6;
  window.scrollTo({ top: Math.max(0, y), behavior: 'smooth' });
}
if (window.visualViewport) window.visualViewport.addEventListener('resize', () => { if (document.body.classList.contains('typing')) scrollFillTop(); });
