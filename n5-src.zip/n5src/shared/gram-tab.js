// ================= 文法關卡、練習題、文法點頁（日文頁和語言頁共用：n5src/shared/gram-tab.js） =================
// build.js 會把這個檔複製進兩邊的頁面（見 lib-tab.js 開頭的說明）。
// 共用的是關卡（怎麼打開、過關條件、下一個、過關紀錄）、關卡列表、練習題流程、文法點頁的骨架。
// 文法列表、變化規則頁、範例拆解（gxExamplesHTML）各頁自己畫。各頁不同的地方由 PAGE.gram 提供：
//   prefix 過關紀錄 id 的前綴（日文 'ja:gx:'、語言頁 'it:gx:'…）、path 關卡 [[名稱, 說明, [文法id…]]…]（沒有就不分關）、
//   gx(id) 範例和練習題、title(id) 文法點名稱、
//   quizQ(q, id) 一題練習題 → { head 題號下面的東西, prompt, options, ans, explain }、quizBound(box) 題目畫好之後、
//   head(p) → [標題, 右上角小字（HTML）]、body(p) 說明、exCard(p, exs) 「例句」那張卡片
// 過關紀錄存在 items 的 prefix+id（跟著同步）：{ s:'gx', b:最佳分數, n:題數, p:1 }
const ICON_LOCK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>';
const gxKey = id => PAGE.gram.prefix + id;
const gxNeed = n => n >= 5 ? Math.ceil(n * 0.8) : n;   // 6 題要對 5 題
const gxTotal = id => (PAGE.gram.gx(id) || { q: [] }).q.length;
const gxPassed = id => !!(S.items[gxKey(id)] || {}).p;
function gxStages() {
  let prevDone = true;
  return (PAGE.gram.path || []).map(([title, desc, ids], i) => {
    const done = ids.filter(gxPassed).length;
    const st = done === ids.length ? 'done' : prevDone ? 'open' : 'locked';
    prevDone = prevDone && done === ids.length;
    return { i, title, desc, ids, done, st };
  });
}
const gxStageOf = id => gxStages().find(x => x.ids.includes(id));
function gxNext(after) {
  const flat = (PAGE.gram.path || []).flatMap(x => x[2]);
  const k = after ? flat.indexOf(after) : -1;
  return flat.slice(k + 1).find(id => !gxPassed(id)) || flat.find(id => !gxPassed(id) && id !== after) || '';
}
function gxRecord(id, right, total) {
  reloadShared();
  const old = S.items[gxKey(id)] || {};
  const r = { s: 'gx', b: Math.max(old.b || 0, right), n: total, t: Date.now() };
  if (old.p || right >= gxNeed(total)) r.p = 1;
  putRec(gxKey(id), r);
}
function gxPathHTML() {
  const T = PAGE.gram.title;
  const sts = gxStages();
  const total = sts.reduce((a, x) => a + x.ids.length, 0), passed = sts.reduce((a, x) => a + x.done, 0);
  const nx = gxNext(null), nt = nx && T(nx);
  return `<div class="card gp-top"><div class="gp-tt"><b>文法關卡</b><span>已過關 ${passed} / ${total}</span></div><div class="gp-bar"><i style="width:${(passed / total * 100).toFixed(1)}%"></i></div>
      <p class="meta">照順序學，後面的文法會用到前面的。每個文法點看完說明和範例，練習題答對八成就過關（6 題要對 5 題）；一關全部過關，下一關就會打開。</p>
      ${nt ? `<button class="btn solid block" data-gram="${nx}">繼續學：${esc(nt)}</button>` : '<p class="gp-all">全部過關了！</p>'}</div>` +
    sts.map(x => `<section class="gp-stage ${x.st}">
      <div class="gp-sh"><span class="gp-no">${x.st === 'done' ? ICON.ok : x.st === 'locked' ? ICON_LOCK : x.i + 1}</span><div class="gp-st"><b>第 ${x.i + 1} 關・${esc(x.title)}</b><span>${esc(x.desc)}</span></div><span class="gp-cnt">${x.done}/${x.ids.length}</span></div>
      ${x.st === 'locked' ? `<details class="gp-peek"><summary>完成上一關就會打開・先偷看這關的 ${x.ids.length} 個文法</summary>` : ''}
      ${x.ids.map(id => `<button class="gr-row gp-row${gxPassed(id) ? ' ok' : ''}${id === nx ? ' now' : ''}" data-gram="${id}"><b>${gxPassed(id) ? `<span class="gp-ck">${ICON.ok}</span>` : ''}${esc(T(id))}</b><span class="gn">${id === nx ? '<span class="gp-nowt">下一個</span>' : ''}›</span></button>`).join('')}${x.st === 'locked' ? '</details>' : ''}
    </section>`).join('');
}
function gxWhere(id) {
  const x = gxStageOf(id); if (!x) return '';
  const need = x.st === 'locked' ? gxStages().find(y => y.st !== 'done') : null;
  return `<div class="gp-where ${x.st}"><span>第 ${x.i + 1} 關・${esc(x.title)}</span>${gxPassed(id) ? `<b class="gp-pass">${ICON.ok}已過關</b>` : `<span class="gp-need">練習題答對 ${gxNeed(gxTotal(id))} 題就過關</span>`}${need ? `<p>這關還沒打開，建議先完成第 ${need.i + 1} 關「${esc(need.title)}」，內容一樣可以先看。</p>` : ''}</div>`;
}
// 練習題：四選一，答完一定顯示整句和「為什麼」，不自動跳下一題；算進今日題數，不進錯題和複習
function startGxQuiz(box, gx, id) {
  if (!box) return;
  const P = PAGE.gram;
  const qs = shuffle(gx.q); let i = 0, right = 0;
  const next = () => {
    if (!box.isConnected) return;
    if (i >= qs.length) {
      const all = right >= gxNeed(qs.length), perfect = right === qs.length;
      let nx = '', nt = '';
      if (id && P.path) {
        const before = gxStageOf(id);
        gxRecord(id, right, qs.length);
        const after = gxStageOf(id);
        if (before && after && before.st !== 'done' && after.st === 'done') toast(`第 ${after.i + 1} 關完成！${P.path[after.i + 1] ? `第 ${after.i + 2} 關打開了` : '全部關卡都過了'}`, true);
        nx = gxNext(id); nt = nx ? P.title(nx) : '';
      }
      const msg = all ? (perfect ? '全對，' : '') + (P.path ? '過關！' : '這個文法你會了。') : (P.path ? `答對 ${gxNeed(qs.length)} 題才算過關。` : '') + (right ? '差一點，看一下範例再練一次。' : '先看範例拆解，再回來試試。');
      box.innerHTML = `<div class="gx-done"><div class="gx-score">${right} / ${qs.length}</div><p>${msg}</p><div class="btnrow">${all && nx ? `<button class="btn solid" data-gram="${nx}">下一個：${esc(nt)}</button><button class="btn quiet" id="gxAgain">再練一次</button>` : `<button class="btn solid" id="gxAgain">再練一次</button><button class="btn quiet" data-gpane="ex">看範例</button>`}</div></div>`;
      $('#gxAgain', box).onclick = () => startGxQuiz(box, gx, id);
      $$('[data-gpane]', box).forEach(b => b.onclick = () => { gramPane = b.dataset.gpane; renderGram(); });
      const wh = $('.gp-where', box.closest('.card')); if (wh) wh.outerHTML = gxWhere(id);
      return;
    }
    const q = P.quizQ(qs[i++], id);
    renderChoice(box, {
      head: `<div class="qhead"><span class="meta">文法練習 ${i} / ${qs.length}</span></div>${q.head || ''}`,
      promptHTML: q.prompt,
      options: q.options,
      onAnswer: ok => { if (ok) right++; bumpDay(); const b = $('#blank', box); if (b) { b.textContent = q.ans; b.classList.add(ok ? 'ok' : 'ng'); } },
      explain: q.explain,
      noAuto: true
    }, next);
    if (P.quizBound) P.quizBound(box);
  };
  next();
}
// 文法點頁：說明／看範例／練習題三個分頁，說明下面是 App 裡用到這個文法的例句
function renderGramPoint(host, p, exs) {
  const P = PAGE.gram;
  const gx = P.gx(p.id);
  if (gramPaneId !== p.id) { gramPane = 'body'; gramPaneId = p.id; }
  if (!gx) gramPane = 'body';
  const seg = gx ? `<div class="seg gx-seg" role="group" aria-label="文法分頁">${[['body', '說明'], ['ex', '看範例'], ['q', '練習題']].map(([k, l]) => `<button data-gpane="${k}" aria-pressed="${gramPane === k}">${l}</button>`).join('')}</div>` : '';
  const pane = gramPane === 'ex' ? gxExamplesHTML(gx) : gramPane === 'q' ? '<div id="gxQuiz" class="gx-quiz"></div>' : `${P.body(p)}${gx ? `<div class="btnrow gx-cta"><button class="btn quiet" data-gpane="ex">看範例拆解</button><button class="btn solid" data-gpane="q">練習題（${gx.q.length} 題）</button></div>` : ''}`;
  const [title, lv] = P.head(p);
  host.innerHTML = `<button class="gr-back" id="grBack">‹ 文法列表</button>
    <div class="card">
      <div class="gr-head"><h2>${esc(title)}</h2><span class="lv">${lv}</span></div>
      ${gxWhere(p.id)}${seg}${pane}
    </div>
    ${gramPane !== 'body' ? '' : P.exCard(p, exs)}`;
  $('#grBack', host).onclick = () => { UI.gramSel = ''; saveUI(); renderGram(); window.scrollTo(0, 0); };
  const m = $('#grMore', host); if (m) m.onclick = () => { gramShow += 8; renderGram(); };
  $$('[data-gpane]', host).forEach(b => b.onclick = () => { gramPane = b.dataset.gpane; renderGram(); const c = $('.gr-head', host); if (c && c.getBoundingClientRect().top < 0) c.scrollIntoView({ block: 'start' }); });
  if (gramPane === 'q') startGxQuiz($('#gxQuiz', host), gx, p.id);
}
// 點任何 data-gram 的東西（文法列表、字卡的文法標籤、練習題的「下一個」）就打開那個文法點
function openGram(id) {
  UI.gramSel = id; gramShow = 8; saveUI();
  if (UI.tab !== 'gram') showTab('gram'); else { renderGram(); window.scrollTo(0, 0); }
}
document.addEventListener('click', e => {
  const b = e.target.closest('[data-gram]');
  if (b) { e.preventDefault(); openGram(b.dataset.gram); }
});
