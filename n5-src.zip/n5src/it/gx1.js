/* 義大利文文法的範例拆解與練習題（1）：冠詞、名詞、動詞現在式、基本句型
   IT.GX[文法點 id] = {
     ex: [[句子, 中文, [[字, 意思], …], [逐字說明…], 白話總結]],
     q:  [[題目（___ 是空格）, 答案, [錯的選項…], 中文, 為什麼]]
   } */
(function (G) {
  const IT = G.IT || (G.IT = {});
  IT.GX = Object.assign(IT.GX || {}, {
    // ---------- 冠詞、名詞、形容詞 ----------
    'art-def': {
      ex: [["Il libro è nuovo.", '那本書是新的。', [['Il', '那本'], ['libro', '書'], ['è', '是'], ['nuovo', '新的']],
        ['il：libro 是陽性、子音開頭，所以用 il。'],
        '義大利文的名詞前面幾乎都要帶一個「the」。帶哪一個，看名詞是陽性還是陰性、開頭是什麼字母。'],
        ["Lo studente e la ragazza.", '那個學生和那個女孩。', [['Lo', '那個'], ['studente', '學生'], ['e', '和'], ['la', '那個'], ['ragazza', '女孩']],
        ['lo：studente 是 s＋子音開頭的陽性字，不能用 il，要用 lo。', 'la：ragazza 是陰性（-a 結尾），用 la。'],
        '陽性一般用 il；碰到 s＋子音、z 開頭改 lo；母音開頭變 l\'。陰性用 la。']],
      q: [['___ zaino è nuovo.', 'Lo', ['Il', 'La'], '那個背包是新的。', 'zaino 是 z 開頭的陽性字，用 lo。'],
        ['___ amica di Marco è simpatica.', "L'", ['La', 'Il'], 'Marco 的朋友很親切。', "amica 是母音開頭，la 要縮成 l'。"],
        ['___ ragazzi sono qui.', 'I', ['Gli', 'Le'], '男孩們在這裡。', 'ragazzi 是陽性複數、子音開頭，用 i。']]
    },
    'art-indef': {
      ex: [["Un fratello e una sorella.", '一個哥哥和一個姊姊。', [['Un', '一個'], ['fratello', '哥哥'], ['e', '和'], ['una', '一個'], ['sorella', '姊姊']],
        ['un：fratello 是陽性。', 'una：sorella 是陰性。'],
        '「一個」也分男女：陽性 un，陰性 una。']],
      q: [['___ caffè, per favore.', 'Un', ['Una', 'Uno'], '一杯咖啡，麻煩了。', 'caffè 是陽性、子音開頭，用 un。'],
        ['È ___ studente.', 'uno', ['un', 'una'], '他是一個學生。', 's＋子音開頭的陽性字用 uno。'],
        ['È ___ idea!', "un'", ['un', 'uno'], '這是個好主意！', "idea 是陰性、母音開頭，una 縮成 un'。"]]
    },
    'noun-gender': {
      ex: [["Il gatto e la casa.", '貓和房子。', [['Il', '那隻'], ['gatto', '貓'], ['e', '和'], ['la', '那間'], ['casa', '房子']],
        ['gatto：-o 結尾，通常是陽性。', 'casa：-a 結尾，通常是陰性。'],
        '看最後一個字母：-o 多半是男生、-a 多半是女生。-e 結尾的要一個一個記。']],
      q: [['___ ragazza', 'la', ['il', 'lo'], '那個女孩', 'ragazza 是 -a 結尾，陰性。'],
        ['___ treno', 'il', ['la', 'lo'], '那班火車', 'treno 是 -o 結尾，陽性。'],
        ['___ mano', 'la', ['il', 'lo'], '那隻手', 'mano 是例外：雖然 -o 結尾，卻是陰性。']]
    },
    'noun-plural': {
      ex: [["Due libri e tre case.", '兩本書和三間房子。', [['Due', '兩'], ['libri', '書（複數）'], ['e', '和'], ['tre', '三'], ['case', '房子（複數）']],
        ['libro → libri：-o 變 -i。', 'casa → case：-a 變 -e。'],
        '義大利文的複數不是加 s，而是換最後一個字母：-o→-i、-a→-e、-e→-i。']],
      q: [['due ___ (ragazzo)', 'ragazzi', ['ragazze', 'ragazzos'], '兩個男孩', '-o 結尾的複數改 -i。'],
        ['tre ___ (pizza)', 'pizze', ['pizzi', 'pizzas'], '三個披薩', '-a 結尾的複數改 -e。'],
        ['due ___ (lezione)', 'lezioni', ['lezione', 'lezionie'], '兩堂課', '-e 結尾的複數改 -i。']]
    },
    'adj': {
      ex: [["È una macchina rossa.", '這是一台紅色的車。', [['È', '是'], ['una', '一台'], ['macchina', '車'], ['rossa', '紅色的']],
        ['rossa 放在名詞後面，跟中文順序相反。', 'macchina 是陰性單數，所以 rosso → rossa。'],
        '形容詞通常放在名詞後面，而且要跟名詞同一個性別和單複數。'],
        ["I ragazzi sono simpatici.", '那些男孩很親切。', [['I', '那些'], ['ragazzi', '男孩'], ['sono', '是'], ['simpatici', '親切的']],
        ['ragazzi 是陽性複數，simpatico 也跟著變 simpatici。'],
        '名詞變成複數，形容詞也要一起變。']],
      q: [['una casa ___', 'bianca', ['bianco', 'bianchi'], '一間白色的房子', 'casa 是陰性單數，形容詞用 -a。'],
        ['i libri ___', 'nuovi', ['nuovo', 'nuove'], '那些新書', 'libri 是陽性複數，形容詞用 -i。'],
        ['le ragazze ___', 'italiane', ['italiana', 'italiani'], '那些義大利女孩', 'ragazze 是陰性複數，形容詞用 -e。']]
    },
    // ---------- 基本動詞 ----------
    'essere': {
      ex: [["Io sono Marco, lei è Anna.", '我是 Marco，她是 Anna。', [['Io', '我'], ['sono', '是'], ['Marco', 'Marco'], [',', ''], ['lei', '她'], ['è', '是'], ['Anna', 'Anna']],
        ['sono：essere 的「我」形。', 'è：essere 的「他／她」形，上面有重音符號，跟 e（和）不一樣。'],
        'essere 就是英文的 be，每個人稱長得都不一樣，要整組背：sono、sei、è、siamo、siete、sono。'],
        ["Siamo di Taiwan.", '我們來自台灣。', [['Siamo', '我們是'], ['di', '來自'], ['Taiwan', '台灣']],
        ['siamo：「我們」形。動詞已經看得出是誰，所以 noi 可以省略。', 'essere di ＋ 地方＝「是…人、來自…」。'],
        '義大利文常把主詞省掉，因為動詞的詞尾已經告訴你是誰了。']],
      q: [['Tu ___ italiano?', 'sei', ['è', 'sono'], '你是義大利人嗎？', 'tu 配 sei。'],
        ['Noi ___ studenti.', 'siamo', ['siete', 'sono'], '我們是學生。', 'noi 配 siamo。'],
        ['Il museo ___ chiuso.', 'è', ['e', 'sono'], '博物館關著。', '單數的東西用 è（有重音）；e 是「和」。']]
    },
    'avere': {
      ex: [["Ho un cane.", '我有一隻狗。', [['Ho', '我有'], ['un', '一隻'], ['cane', '狗']],
        ['ho：avere 的「我」形。h 不發音，唸起來像「歐」。'],
        'avere＝「有」。h 只是寫的，不唸：ho、hai、ha、abbiamo、avete、hanno。']],
      q: [['___ una sorella?', 'Hai', ['Ha', 'Ho'], '你有姊妹嗎？', 'tu 的形是 hai。'],
        ['Loro ___ una casa grande.', 'hanno', ['hai', 'avete'], '他們有一間大房子。', 'loro 配 hanno。'],
        ['Anna ___ un gatto.', 'ha', ['è', 'hanno'], 'Anna 有一隻貓。', '「她有」是 ha；è 是「她是」。']]
    },
    'avere-expr': {
      ex: [["Ho fame e ho sete.", '我餓了，也渴了。', [['Ho', '我有'], ['fame', '飢餓'], ['e', '和'], ['ho', '我有'], ['sete', '口渴']],
        ['義大利文不說「我是餓的」，而是說「我有飢餓」。'],
        '餓、渴、冷、熱、怕、幾歲，這幾個都用 avere（有）＋ 名詞。'],
        ["Ho vent'anni.", '我二十歲。', [['Ho', '我有'], ["vent'anni", '二十年']],
        ["年齡也用「有」：我有二十年。", "vent'anni ＝ venti anni，母音碰在一起時縮寫。"],
        '問年齡：Quanti anni hai?（你有幾年？）']],
      q: [['Ho ___ .', 'freddo', ['fredda', 'fredde'], '我很冷。', 'avere freddo 是固定說法，freddo 不跟著人變。'],
        ['Quanti anni ___ ?', 'hai', ['sei', 'fai'], '你幾歲？', '年齡用 avere，不用 essere。'],
        ['Ho ___ !', 'paura', ['fame', 'sete'], '我好怕！', '「害怕」＝ avere paura；fame 是餓、sete 是渴。']]
    },
    'ce': {
      ex: [["C'è un bar qui vicino.", '這附近有一間咖啡館。', [["C'è", '有'], ['un', '一間'], ['bar', '咖啡館'], ['qui', '這裡'], ['vicino', '附近']],
        ["c'è ＝ ci è，單數用。", '這個「有」是「存在」，不是「擁有」（那是 avere）。'],
        '說「某個地方有什麼東西」用 c\'è（一個）或 ci sono（好幾個）。'],
        ["Ci sono due bagni.", '有兩間廁所。', [['Ci', '（那裡）'], ['sono', '有'], ['due', '兩'], ['bagni', '廁所']],
        ['後面是複數，所以用 ci sono。'],
        '一個 → c\'è；兩個以上 → ci sono。']],
      q: [['___ due bar qui.', 'Ci sono', ["C'è", 'Hanno'], '這裡有兩間咖啡館。', 'due bar 是複數（bar 的複數不變），用 ci sono。'],
        ['___ una farmacia qui?', "C'è", ['Ci sono', 'Ha'], '這裡有藥局嗎？', '一間藥局，單數用 c\'è。'],
        ['Non ___ problema.', "c'è", ['ci sono', 'ho'], '沒問題。', 'problema 是單數：non c\'è problema。']]
    },
    'pres-are': {
      ex: [["Io parlo italiano.", '我說義大利文。', [['Io', '我'], ['parlo', '說'], ['italiano', '義大利文']],
        ['parlare 去掉 -are，剩 parl-，「我」加 -o → parlo。'],
        '-are 動詞先切掉 -are，再接人稱詞尾：-o、-i、-a、-iamo、-ate、-ano。'],
        ["Voi abitate a Milano?", '你們住在米蘭嗎？', [['Voi', '你們'], ['abitate', '住'], ['a', '在'], ['Milano', '米蘭']],
        ['abitare → abit- ＋ -ate（你們）。', '城市前面用 a。'],
        '同一個動詞，主詞不同，最後幾個字母就不同。']],
      q: [['Tu ___ molto bene. (parlare)', 'parli', ['parla', 'parlo'], '你說得很好。', 'tu 的詞尾是 -i。'],
        ['Noi ___ la TV. (guardare)', 'guardiamo', ['guardate', 'guardano'], '我們在看電視。', 'noi 的詞尾是 -iamo。'],
        ['Loro ___ in banca. (lavorare)', 'lavorano', ['lavora', 'lavorate'], '他們在銀行工作。', 'loro 的詞尾是 -ano。']]
    },
    'pres-ere': {
      ex: [["Leggo un libro.", '我在讀一本書。', [['Leggo', '我讀'], ['un', '一本'], ['libro', '書']],
        ['leggere → legg- ＋ -o。主詞 io 省略。'],
        '-ere 動詞的詞尾：-o、-i、-e、-iamo、-ete、-ono。']],
      q: [['Lui ___ la pasta. (prendere)', 'prende', ['prendi', 'prenda'], '他點義大利麵。', 'lui 的詞尾是 -e。'],
        ['Voi ___ la lettera? (scrivere)', 'scrivete', ['scrivate', 'scrivono'], '你們在寫信嗎？', 'voi 的詞尾是 -ete（-are 動詞才是 -ate）。'],
        ['Loro ___ il treno. (prendere)', 'prendono', ['prendano', 'prende'], '他們搭火車。', '-ere 動詞的 loro 是 -ono。']]
    },
    'pres-ire': {
      ex: [["Dormo otto ore.", '我睡八個小時。', [['Dormo', '我睡'], ['otto', '八'], ['ore', '小時']],
        ['dormire → dorm- ＋ -o。'],
        '-ire 動詞跟 -ere 幾乎一樣，只有「你們」是 -ite。']],
      q: [['Tu ___ la porta? (aprire)', 'apri', ['apre', 'apra'], '你開門嗎？', 'tu 的詞尾是 -i。'],
        ['Voi ___ bene? (dormire)', 'dormite', ['dormete', 'dormono'], '你們睡得好嗎？', '-ire 動詞的 voi 是 -ite。'],
        ['Il treno ___ domani. (partire)', 'parte', ['parti', 'parto'], '火車明天出發。', '火車是「它」，用 -e。']]
    },
    'pres-isc': {
      ex: [["Non capisco.", '我聽不懂。', [['Non', '不'], ['capisco', '懂']],
        ['capire 的「我」不是 capo，而是中間塞 -isc-：cap-isc-o。'],
        '有些 -ire 動詞在 io、tu、lui、loro 這四個形中間多一個 -isc-，noi 和 voi 不加。']],
      q: [['Tu ___ l\'italiano? (capire)', 'capisci', ['capi', 'capisce'], '你懂義大利文嗎？', 'tu：cap-isc-i。'],
        ['Noi ___ la lezione. (finire)', 'finiamo', ['finisciamo', 'finiscono'], '我們上完課了。', 'noi 不加 -isc-。'],
        ['Lei ___ il lavoro. (finire)', 'finisce', ['fine', 'finisci'], '她做完工作。', 'lei：fin-isc-e。']]
    },
    'pres-irr': {
      ex: [["Vado a casa.", '我回家。', [['Vado', '我去'], ['a', '到'], ['casa', '家']],
        ['andare 是不規則動詞，「我」形是 vado，不是 ando。'],
        'andare、fare、venire、dire、uscire 這些常用動詞不照規則變，要整組背。'],
        ["Cosa fai stasera?", '你今晚做什麼？', [['Cosa', '什麼'], ['fai', '你做'], ['stasera', '今晚']],
        ['fai：fare（做）的「你」形。'],
        '問別人在做什麼、要做什麼，就用 fare。']],
      q: [['Loro ___ al cinema. (andare)', 'vanno', ['andano', 'vadono'], '他們去電影院。', 'andare 的 loro 是 vanno。'],
        ['Io ___ i compiti. (fare)', 'faccio', ['fo', 'faco'], '我寫作業。', 'fare 的 io 是 faccio。'],
        ['Da dove ___ ? (venire)', 'vieni', ['veni', 'viene'], '你從哪裡來？', 'venire 的 tu 是 vieni。']]
    },
    'modal': {
      ex: [["Posso entrare?", '我可以進來嗎？', [['Posso', '我可以'], ['entrare', '進來']],
        ['posso：potere（能夠）的「我」形，會變。', 'entrare 用原形，不用變。'],
        '「想／能／必須 ＋ 做某事」：前面的動詞照人稱變，後面的動詞保持原形。'],
        ["Devo lavorare domani.", '我明天得上班。', [['Devo', '我必須'], ['lavorare', '工作'], ['domani', '明天']],
        ['devo：dovere（必須）的「我」形。'],
        'voglio 想、posso 能、devo 必須，後面一律接原形。']],
      q: [['Vuoi ___ un caffè?', 'prendere', ['prendi', 'prende'], '你想喝杯咖啡嗎？', 'volere 後面的動詞用原形。'],
        ['Noi ___ studiare.', 'dobbiamo', ['dovete', 'devono'], '我們得念書。', 'dovere 的 noi 是 dobbiamo。'],
        ['___ aiutarmi?', 'Può', ['Potere', 'Posso'], '您可以幫我嗎？', '對「您」用第三人稱 può。']]
    },
    'sapere': {
      ex: [["So nuotare, ma non conosco Roma.", '我會游泳，但不熟羅馬。', [['So', '我會'], ['nuotare', '游泳'], [',', ''], ['ma', '但是'], ['non', '不'], ['conosco', '認識'], ['Roma', '羅馬']],
        ['so：sapere，知道一件事、會做一件事。', 'conosco：conoscere，認識人、熟悉地方。'],
        'sapere 是「知道／會」，後面接事情或動詞；conoscere 是「認識」，後面接人或地方。']],
      q: [['___ Maria?', 'Conosci', ['Sai', 'Sei'], '你認識 Maria 嗎？', '認識一個人用 conoscere。'],
        ['Non ___ dov\'è la stazione.', 'so', ['conosco', 'sono'], '我不知道車站在哪。', '知道一件事用 sapere。'],
        ['Lei ___ cucinare bene.', 'sa', ['conosce', 'è'], '她很會做菜。', '「會做某事」用 sapere ＋ 原形。']]
    },
    'piacere': {
      ex: [["Mi piace la pizza.", '我喜歡披薩。', [['Mi', '對我'], ['piace', '討人喜歡'], ['la', '那個'], ['pizza', '披薩']],
        ['字面是「披薩讓我喜歡」：披薩才是主詞。', 'mi＝對我；piace 跟著披薩（單數）。'],
        '義大利文的「喜歡」是倒過來說的：被喜歡的東西是主詞，喜歡的人放前面用 mi、ti、gli…。'],
        ["Mi piacciono i gatti.", '我喜歡貓。', [['Mi', '對我'], ['piacciono', '討人喜歡'], ['i', '那些'], ['gatti', '貓']],
        ['gatti 是複數，所以動詞變 piacciono。'],
        '喜歡一個東西 → piace；喜歡好幾個 → piacciono。']],
      q: [['Ti ___ il caffè?', 'piace', ['piacciono', 'piaci'], '你喜歡咖啡嗎？', 'il caffè 是單數，用 piace。'],
        ['Mi ___ le lingue.', 'piacciono', ['piace', 'piaccio'], '我喜歡語言。', 'le lingue 是複數，用 piacciono。'],
        ['___ piace leggere.', 'Mi', ['Io', 'Me'], '我喜歡閱讀。', '喜歡的人用 mi（對我），不是 io。']]
    },
    'refl': {
      ex: [["Mi chiamo Howard.", '我叫 Howard。', [['Mi', '我自己'], ['chiamo', '叫'], ['Howard', 'Howard']],
        ['字面是「我把自己叫做 Howard」。', 'mi 放在動詞前面。'],
        '反身動詞是「對自己做」：起床＝把自己叫起來，所以前面有 mi、ti、si…。'],
        ["Ci alziamo alle sette.", '我們七點起床。', [['Ci', '我們自己'], ['alziamo', '起'], ['alle', '在…點'], ['sette', '七']],
        ['ci 配 noi，alziamo 也是 noi 形。'],
        '前面的小字和後面的動詞要對到同一個人。']],
      q: [['Come ti ___ ?', 'chiami', ['chiamo', 'chiama'], '你叫什麼名字？', 'ti 配 tu，動詞也用 tu 形。'],
        ['Lui ___ lava le mani.', 'si', ['ti', 'mi'], '他洗手。', '「他自己」用 si。'],
        ['Io ___ alzo presto.', 'mi', ['si', 'ci'], '我早起。', '「我自己」用 mi。']]
    },
    'neg': {
      ex: [["Non parlo tedesco.", '我不會說德文。', [['Non', '不'], ['parlo', '說'], ['tedesco', '德文']],
        ['non 直接放在動詞前面。'],
        '否定很簡單：動詞前面加 non。'],
        ["Non mangio mai la carne.", '我從來不吃肉。', [['Non', '不'], ['mangio', '吃'], ['mai', '從來'], ['la', '那個'], ['carne', '肉']],
        ['non … mai＝從來不，mai 放在動詞後面。', 'non 不能省略。'],
        '義大利文是「雙重否定」：non 在前、mai／niente 在後，兩個一起才表示「從不／什麼都不」。']],
      q: [['___ capisco.', 'Non', ['No', 'Niente'], '我不懂。', '動詞前面用 non，no 是單獨回答的「不」。'],
        ['Non bevo ___ il vino.', 'mai', ['non', 'no'], '我從來不喝酒。', 'non … mai＝從來不。'],
        ['Non vedo ___ .', 'niente', ['mai', 'non'], '我什麼都看不到。', 'non … niente＝什麼都不。']]
    },
    'questions': {
      ex: [["Dove abiti?", '你住在哪裡？', [['Dove', '哪裡'], ['abiti', '你住']],
        ['疑問詞放最前面，動詞緊跟在後。'],
        '問句不用倒裝，只要把疑問詞放前面、句尾語氣上揚。'],
        ["Quanto costa?", '多少錢？', [['Quanto', '多少'], ['costa', '值']],
        ['costa：costare 的「它」形，主詞（那東西）省略了。'],
        '買東西最常用的一句：Quanto costa?']],
      q: [['___ ti chiami?', 'Come', ['Cosa', 'Chi'], '你叫什麼名字？', '字面是「你怎麼叫自己」，用 come。'],
        ['___ è Marco?', 'Chi', ['Cosa', 'Dove'], 'Marco 是誰？', '問人用 chi。'],
        ['___ studi l\'italiano?', 'Perché', ['Quando', 'Quale'], '你為什麼學義大利文？', '問原因用 perché。']]
    },
    'lei': {
      ex: [["Come sta, signora?", '您好嗎，太太？', [['Come', '怎樣'], ['sta', '您好'], [',', ''], ['signora', '太太']],
        ['sta：對「您」用第三人稱（跟「她」一樣），不是 stai。'],
        '對不熟或長輩說「您」，動詞用「他／她」的形，像在跟第三個人說話。']],
      q: [['Lei ___ italiano?', 'parla', ['parli', 'parlo'], '您說義大利文嗎？', '「您」用第三人稱 parla。'],
        ['Scusi, Lei ___ italiana?', 'è', ['sei', 'sono'], '不好意思，您是義大利人嗎？', '對「您」用第三人稱 è。'],
        ['Come si ___ ?', 'chiama', ['chiami', 'chiamo'], '您貴姓大名？', '對「您」：Come si chiama?']]
    },
    'stare': {
      ex: [["Sto bene, grazie.", '我很好，謝謝。', [['Sto', '我（狀態）'], ['bene', '好'], [',', ''], ['grazie', '謝謝']],
        ['sto：stare 的「我」形。', '問候身體狀況用 stare，不用 essere。'],
        'Come stai?（你好嗎）→ Sto bene（我很好）。']],
      q: [['Come ___ ?', 'stai', ['sei', 'stari'], '你好嗎？', '問候用 stare，tu 形是 stai。'],
        ['Anna ___ male.', 'sta', ['è', 'stai'], 'Anna 身體不舒服。', '身體狀況用 stare，她 → sta。'],
        ['Noi ___ bene.', 'stiamo', ['stamo', 'siamo'], '我們很好。', 'stare 的 noi 是 stiamo。']]
    }
  });
})(typeof window !== 'undefined' ? window : globalThis);
