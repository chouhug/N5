/* A1 文法點與詞性變化規則
   每個文法點：id、title、tag（分類）、body（說明 HTML）、m（比對規則）、ex（額外例句）
   比對規則 m：{ re: 正規式字串 } 或 { tok: 判斷函式名稱 } */
(function (G) {
  'use strict';
  const IT = G.IT || (G.IT = {});

  /* ---------- 比對工具 ---------- */
  let LK = null;
  function look() {
    if (!LK) LK = IT.buildLookup(IT.W, Object.assign({}, IT.EXTRA_FORMS, IT.EXTRA_LOOKUP));
    return LK;
  }
  IT.getLookup = look;
  const POS_OF = () => {
    if (IT._posOf) return IT._posOf;
    const m = {}; IT.W.forEach(e => { m[e[0]] = e[1]; }); return (IT._posOf = m);
  };
  function toks(s) {
    const out = []; let i = 0;
    for (const t of IT.tokenize(s)) { out.push({ t: t.t, w: t.w, s: i, e: i + t.t.length, k: IT.norm(t.t).toLowerCase() }); i += t.t.length; }
    return out;
  }
  function info(k) { return look().get(k) || []; }
  function has(k, pred) { return info(k).some(pred); }
  const posOf = l => POS_OF()[l] || '';
  const ESS = 'sono sei è siamo siete'.split(' ');
  const AVE = 'ho hai ha abbiamo avete hanno'.split(' ');
  const isPP = k => has(k, x => /過去分詞/.test(x.desc));
  const isNounish = k => has(k, x => ['n', 'adj', 'det', 'num'].includes(posOf(x.lemma))) || /^[a-zàèéìòù]+$/.test(k) && !!IT.NAMES[k];

  const TOK = {
    defart(T) {
      const r = [];
      T.forEach((t, i) => {
        if (!t.w) return;
        const n = T.slice(i + 1).find(x => x.w);
        if (['il', 'lo', 'la', "l'", 'i', 'gli', 'le'].includes(t.k) && n && isNounish(n.k)) r.push(i);
      });
      return r;
    },
    indef(T) { return T.map((t, i) => (['un', 'uno', 'una', "un'"].includes(t.k) && T.slice(i + 1).find(x => x.w && isNounish(x.k))) ? i : -1).filter(i => i >= 0); },
    plural(T) { return T.map((t, i) => (t.w && has(t.k, x => x.desc === '複數' && posOf(x.lemma) === 'n')) ? i : -1).filter(i => i >= 0); },
    adj(T) { return T.map((t, i) => (t.w && t.k.length > 2 && has(t.k, x => posOf(x.lemma) === 'adj' && !['primo', 'secondo'].includes(x.lemma))) ? i : -1).filter(i => i >= 0); },
    essere(T) { return T.map((t, i) => (ESS.includes(t.k) && !isPP((T.slice(i + 1).find(x => x.w) || {}).k || '')) ? i : -1).filter(i => i >= 0); },
    avere(T) { return T.map((t, i) => (AVE.includes(t.k) && !isPP((T.slice(i + 1).find(x => x.w) || {}).k || '')) ? i : -1).filter(i => i >= 0); },
    are(T) { return presentOf(T, 'v-are'); },
    ere(T) { return presentOf(T, 'v-ere'); },
    ire(T) { return presentOf(T, 'v-ire'); },
    isc(T) { return presentOf(T, 'v-isc'); },
    irr(T) { return T.map((t, i) => (t.w && has(t.k, x => posOf(x.lemma) === 'v-irr' && !['essere', 'avere', 'potere', 'volere', 'dovere', 'sapere', 'piacere'].includes(x.lemma) && /現在式/.test(x.desc))) ? i : -1).filter(i => i >= 0); },
    modal(T) {
      const r = [];
      T.forEach((t, i) => {
        if (!t.w || !has(t.k, x => ['potere', 'volere', 'dovere'].includes(x.lemma))) return;
        const n = T.slice(i + 1).filter(x => x.w)[0];
        if (n && has(n.k, x => x.desc === '原形' || /^原形/.test(x.desc))) { r.push(i); r.push(T.indexOf(n)); }
      });
      return r;
    },
    refl(T) {
      const r = [];
      T.forEach((t, i) => {
        if (!['mi', 'ti', 'si', 'ci', 'vi'].includes(t.k)) return;
        const ws = T.slice(i + 1).filter(x => x.w);
        let n = ws[0];
        if (n && ESS.includes(n.k) && ws[1] && isPP(ws[1].k)) { if (has(ws[1].k, x => IT.isRefl(x.lemma))) { r.push(i, T.indexOf(n), T.indexOf(ws[1])); } return; }
        if (n && has(n.k, x => IT.isRefl(x.lemma) && /現在式/.test(x.desc))) r.push(i, T.indexOf(n));
      });
      // 反身動詞命令式（alzati、lavati）
      T.forEach((t, i) => { if (t.w && has(t.k, x => IT.isRefl(x.lemma) && /命令式/.test(x.desc)) && /(ti|ci|vi)$/.test(t.k)) r.push(i); });
      return r;
    },
    artprep(T) { return T.map((t, i) => (IT.ART_PREPS[t.k] ? i : -1)).filter(i => i >= 0); },
    simpleprep(T) {
      return T.map((t, i) => {
        if (!['di', 'a', 'da', 'in', 'con', 'su', 'per', 'tra', "d'", 'ad'].includes(t.k)) return -1;
        return i;
      }).filter(i => i >= 0);
    },
    poss(T) { return T.map((t, i) => (t.w && has(t.k, x => ['mio', 'tuo', 'suo', 'nostro', 'vostro'].includes(x.lemma)) || (t.k === 'loro' && T.slice(0, i).some(x => ['il', 'la', 'i', 'le'].includes(x.k)) && i > 0 && ['il', 'la', 'i', 'le'].includes((T.slice(0, i).filter(x => x.w).pop() || {}).k)) ? i : -1)).filter(i => i >= 0); },
    demo(T) { return T.map((t, i) => (t.w && has(t.k, x => ['questo', 'quello'].includes(x.lemma))) ? i : -1).filter(i => i >= 0); },
    num(T) { return T.map((t, i) => (t.w && has(t.k, x => posOf(x.lemma) === 'num') && !['sei', 'uno'].includes(t.k) || ['sei'].includes(t.k) && /^(le|alle|ha|hanno|ho)$/.test(((T.slice(0, i).filter(x => x.w).pop()) || {}).k || '')) ? i : -1).filter(i => i >= 0); },
    passAvere(T) { return passato(T, AVE); },
    passEssere(T) { return passato(T, ESS); },
    imper(T) {
      const s = T.map(t => t.t).join('').trim();
      if (/\?$/.test(s)) return [];
      const ws = T.filter(t => t.w);
      let i0 = 0;
      if (ws[0] && ['non'].includes(ws[0].k)) return [];
      // 允許句首是 Mi／Si（Mi scusi、Si sieda）
      if (ws[0] && ['mi', 'si'].includes(ws[0].k) && ws[1]) i0 = 1;
      const f = ws[i0];
      if (!f) return [];
      const inf = info(f.k);
      const isImp = inf.some(x => /命令式/.test(x.desc));
      const isPresTuVoi = inf.some(x => /現在式 (io|lui|noi|loro)/.test(x.desc));
      if (isImp && !isPresTuVoi) return i0 ? [T.indexOf(ws[0]), T.indexOf(f)] : [T.indexOf(f)];
      return [];
    }
  };
  function presentOf(T, type) {
    return T.map((t, i) => (t.w && has(t.k, x => posOf(x.lemma) === type && /現在式/.test(x.desc))) ? i : -1).filter(i => i >= 0);
  }
  function passato(T, auxList) {
    const r = [];
    T.forEach((t, i) => {
      if (!auxList.includes(t.k)) return;
      const ws = T.slice(i + 1).filter(x => x.w);
      let j = 0;
      if (ws[0] && ['già', 'mai', 'ancora', 'sempre'].includes(ws[0].k)) j = 1;
      const n = ws[j];
      if (n && isPP(n.k) && !(auxList === ESS && IT.ESS_ADJ_PP.has(n.k))) {
        r.push(i, T.indexOf(n));
      }
    });
    return r;
  }
  // 用 essere 時這些過去分詞多半是形容詞（è chiuso＝關著的），不算過去式
  IT.ESS_ADJ_PP = new Set(['chiuso', 'chiusa', 'chiusi', 'chiuse', 'aperto', 'aperta', 'aperti', 'aperte', 'occupato', 'occupata', 'stanco', 'preferito', 'sbagliato', 'pulita', 'pulito', 'vestito', 'seduto']);

  function grammarMatch(g, sentence) {
    const s = IT.norm(sentence);
    const ranges = [];
    if (g.m.re) {
      const re = new RegExp(g.m.re, 'gi');
      let m;
      while ((m = re.exec(s))) { if (!m[0]) { re.lastIndex++; continue; } ranges.push([m.index, m.index + m[0].length]); }
    } else if (g.m.tok) {
      const T = toks(s);
      const idx = TOK[g.m.tok](T);
      [...new Set(idx)].sort((a, b) => a - b).forEach(i => ranges.push([T[i].s, T[i].e]));
    }
    return ranges;
  }
  IT.grammarMatch = grammarMatch;

  const B = '(?<![A-Za-zÀ-ÿ\'])';
  const E = '(?![A-Za-zÀ-ÿ])';
  const w = list => B + '(?:' + list + ')' + E;

  IT.GRAMMAR = [
    { id: 'art-def', tag: '冠詞', title: '定冠詞 il, lo, la, l\', i, gli, le', m: { tok: 'defart' },
      body: '<p>義大利文的名詞前面幾乎都要加冠詞。定冠詞（＝英文 the）要看<b>性別</b>、<b>單複數</b>和<b>下一個字的開頭</b>來選。</p><table><tr><th></th><th>單數</th><th>複數</th></tr><tr><td>陽性（一般）</td><td>il libro</td><td>i libri</td></tr><tr><td>陽性（s+子音、z、gn、ps、y）</td><td>lo studente</td><td>gli studenti</td></tr><tr><td>陽性（母音）</td><td>l\'amico</td><td>gli amici</td></tr><tr><td>陰性（子音）</td><td>la casa</td><td>le case</td></tr><tr><td>陰性（母音）</td><td>l\'amica</td><td>le amiche</td></tr></table><p>重點：冠詞是看<b>緊接在後面的字</b>，所以 lo studente 但是 il bravo studente。</p>' },
    { id: 'art-indef', tag: '冠詞', title: '不定冠詞 un, uno, una, un\'', m: { tok: 'indef' },
      body: '<p>不定冠詞＝英文 a／an，表示「一個」。</p><table><tr><th>陽性</th><th>陰性</th></tr><tr><td>un libro、un amico</td><td>una casa</td></tr><tr><td>uno studente、uno zaino</td><td>un\'amica（母音前加撇號）</td></tr></table><p>注意：陽性母音前是 <b>un</b>（不加撇號），陰性才是 <b>un\'</b>。</p>' },
    { id: 'noun-gender', tag: '名詞', title: '名詞的性別', m: { re: w("mano|problema|foto|radio|moto|auto|cinema|panorama|città|università|caffè|chiave|notte|fiore|mare|pane|latte|nome") },
      body: '<p>每個名詞都有性別：陽性（m）或陰性（f）。大部分可以從字尾猜：</p><ul><li><b>-o</b> 通常是陽性：il libro、il ragazzo</li><li><b>-a</b> 通常是陰性：la casa、la ragazza</li><li><b>-e</b> 兩種都有，要一起背：il pane、la notte、il fiore、la chiave</li><li><b>-zione、-tà、-tù</b> 是陰性：la lezione、la città</li></ul><p>常見例外：<b>la mano</b>、<b>la foto</b>、<b>la radio</b>、<b>la moto</b>、<b>l\'auto</b>（陰性）；<b>il problema</b>、<b>il cinema</b>、<b>il panorama</b>（陽性）。</p>' },
    { id: 'noun-plural', tag: '名詞', title: '名詞的複數', m: { tok: 'plural' },
      body: '<table><tr><th>單數</th><th>複數</th><th>例子</th></tr><tr><td>-o</td><td>-i</td><td>libro → libri</td></tr><tr><td>-a（陰性）</td><td>-e</td><td>casa → case</td></tr><tr><td>-e</td><td>-i</td><td>chiave → chiavi、fiore → fiori</td></tr><tr><td>-ca／-ga</td><td>-che／-ghe</td><td>banca → banche</td></tr><tr><td>-co／-go</td><td>-chi／-ghi 或 -ci／-gi</td><td>parco → parchi、amico → amici</td></tr></table><p><b>不變化</b>：重音結尾（città、caffè）、子音結尾的外來語（bar、film、sport）、縮寫字（foto、moto、cinema）。</p><p><b>不規則</b>：l\'uomo → gli uomini；il braccio → le braccia；l\'uovo → le uova；il dito → le dita。</p>' },
    { id: 'adj', tag: '形容詞', title: '形容詞的位置與配合', m: { tok: 'adj' },
      body: '<p>形容詞要跟名詞的<b>性別和單複數一致</b>，通常放在名詞<b>後面</b>。</p><table><tr><th></th><th>-o 型</th><th>-e 型</th></tr><tr><td>陽性單數</td><td>un ragazzo alto</td><td>un libro interessante</td></tr><tr><td>陰性單數</td><td>una ragazza alta</td><td>una città interessante</td></tr><tr><td>陽性複數</td><td>ragazzi alti</td><td>libri interessanti</td></tr><tr><td>陰性複數</td><td>ragazze alte</td><td>città interessanti</td></tr></table><p>常放在名詞前面的：bello、buono、grande、piccolo、nuovo、vecchio（un bel vestito、una buona idea）。顏色 blu、rosa、viola 不變化。</p>' },
    { id: 'essere', tag: '動詞', title: '動詞 essere（是、在）', m: { tok: 'essere' },
      body: '<table class="conj"><tr><th>一個人</th><th>好幾個人</th></tr><tr><td><span class="pn">io<i>我</i></span><span class="vf">sono</span></td><td><span class="pn">noi<i>我們</i></span><span class="vf">siamo</span></td></tr><tr><td><span class="pn">tu<i>你</i></span><span class="vf">sei</span></td><td><span class="pn">voi<i>你們</i></span><span class="vf">siete</span></td></tr><tr><td><span class="pn">lui/lei<i>他／她</i></span><span class="vf">è</span></td><td><span class="pn">loro<i>他們</i></span><span class="vf">sono</span></td></tr></table><p>用來說身分、國籍、個性、位置：<i>Sono taiwanese.</i>（我是台灣人）<i>Il bagno è lì.</i>（廁所在那裡）</p><p>注意 <b>è</b>（是）有重音，<b>e</b>（和）沒有。</p>' },
    { id: 'avere', tag: '動詞', title: '動詞 avere（有）', m: { tok: 'avere' },
      body: '<table class="conj"><tr><th>一個人</th><th>好幾個人</th></tr><tr><td><span class="pn">io<i>我</i></span><span class="vf">ho</span></td><td><span class="pn">noi<i>我們</i></span><span class="vf">abbiamo</span></td></tr><tr><td><span class="pn">tu<i>你</i></span><span class="vf">hai</span></td><td><span class="pn">voi<i>你們</i></span><span class="vf">avete</span></td></tr><tr><td><span class="pn">lui/lei<i>他／她</i></span><span class="vf">ha</span></td><td><span class="pn">loro<i>他們</i></span><span class="vf">hanno</span></td></tr></table><p>h 不發音：ho 唸 [o]。<i>Ho un cane.</i>（我有一隻狗）</p>' },
    { id: 'avere-expr', tag: '動詞', title: 'avere 的慣用說法（ho fame、ho 20 anni）', m: { re: w("ho|hai|ha|abbiamo|avete|hanno") + ' (?:molta |molto |un po\' di )?(?:fame|sete|freddo|caldo|sonno|paura|fretta|bisogno|voglia|ragione|torto|mal|la febbre|il raffreddore|la tosse|[a-z]+ anni)' + E },
      body: '<p>中文說「我餓了」，義大利文說「我<b>有</b>飢餓」：</p><ul><li>ho fame 我餓了／ho sete 我渴了</li><li>ho freddo 我冷／ho caldo 我熱</li><li>ho sonno 我想睡／ho paura 我怕</li><li>ho fretta 我趕時間／ho ragione 我是對的</li><li>ho bisogno di… 我需要／ho voglia di… 我想要</li><li>ho venti anni 我二十歲（年齡用 avere！）</li></ul>' },
    { id: 'ce', tag: '句型', title: 'c\'è／ci sono（有……）', m: { re: B + "(?:c'è|ci sono|non c'è|non ci sono)" + E },
      body: '<p>表示「某處有某物」：</p><ul><li><b>c\'è</b> ＋ 單數：<i>C\'è una farmacia qui vicino?</i></li><li><b>ci sono</b> ＋ 複數：<i>Ci sono molti turisti.</i></li></ul><p>否定：<i>Non c\'è problema.</i>（沒問題）</p>' },
    { id: 'pres-are', tag: '動詞', title: '現在式：-are 規則動詞', m: { tok: 'are' },
      body: '<p>去掉 -are，加上詞尾（以 parlare 為例）：</p><table class="conj"><tr><th>一個人</th><th>好幾個人</th></tr><tr><td><span class="pn">io<i>我</i></span><span class="vf">parl<b>o</b></span></td><td><span class="pn">noi<i>我們</i></span><span class="vf">parl<b>iamo</b></span></td></tr><tr><td><span class="pn">tu<i>你</i></span><span class="vf">parl<b>i</b></span></td><td><span class="pn">voi<i>你們</i></span><span class="vf">parl<b>ate</b></span></td></tr><tr><td><span class="pn">lui/lei<i>他／她</i></span><span class="vf">parl<b>a</b></span></td><td><span class="pn">loro<i>他們</i></span><span class="vf">p<u>a</u>rl<b>ano</b><small>（重音在前面）</small></span></td></tr></table><p>拼字小規則：-care／-gare 在 i 前面加 h（cerchi、paghiamo）；-iare 不要兩個 i（mangi、studiamo）。</p>' },
    { id: 'pres-ere', tag: '動詞', title: '現在式：-ere 規則動詞', m: { tok: 'ere' },
      body: '<p>以 prendere 為例：</p><table class="conj"><tr><th>一個人</th><th>好幾個人</th></tr><tr><td><span class="pn">io<i>我</i></span><span class="vf">prend<b>o</b></span></td><td><span class="pn">noi<i>我們</i></span><span class="vf">prend<b>iamo</b></span></td></tr><tr><td><span class="pn">tu<i>你</i></span><span class="vf">prend<b>i</b></span></td><td><span class="pn">voi<i>你們</i></span><span class="vf">prend<b>ete</b></span></td></tr><tr><td><span class="pn">lui/lei<i>他／她</i></span><span class="vf">prend<b>e</b></span></td><td><span class="pn">loro<i>他們</i></span><span class="vf">prend<b>ono</b></span></td></tr></table><p>發音注意：leggo 的 gg 是硬音 [g]，leggi 的 gg 是軟音 [dʒ]，拼字不變。</p>' },
    { id: 'pres-ire', tag: '動詞', title: '現在式：-ire 規則動詞', m: { tok: 'ire' },
      body: '<p>以 dormire 為例：</p><table class="conj"><tr><th>一個人</th><th>好幾個人</th></tr><tr><td><span class="pn">io<i>我</i></span><span class="vf">dorm<b>o</b></span></td><td><span class="pn">noi<i>我們</i></span><span class="vf">dorm<b>iamo</b></span></td></tr><tr><td><span class="pn">tu<i>你</i></span><span class="vf">dorm<b>i</b></span></td><td><span class="pn">voi<i>你們</i></span><span class="vf">dorm<b>ite</b></span></td></tr><tr><td><span class="pn">lui/lei<i>他／她</i></span><span class="vf">dorm<b>e</b></span></td><td><span class="pn">loro<i>他們</i></span><span class="vf">dorm<b>ono</b></span></td></tr></table><p>和 -ere 只差 voi 的形（-ite）。</p>' },
    { id: 'pres-isc', tag: '動詞', title: '現在式：-ire 加 -isc- 的動詞', m: { tok: 'isc' },
      body: '<p>capire、finire、preferire、pulire、spedire 在 io、tu、lui/lei、loro 加 <b>-isc-</b>：</p><table class="conj"><tr><th>一個人</th><th>好幾個人</th></tr><tr><td><span class="pn">io<i>我</i></span><span class="vf">cap<b>isco</b></span></td><td><span class="pn">noi<i>我們</i></span><span class="vf">capiamo</span></td></tr><tr><td><span class="pn">tu<i>你</i></span><span class="vf">cap<b>isci</b></span></td><td><span class="pn">voi<i>你們</i></span><span class="vf">capite</span></td></tr><tr><td><span class="pn">lui/lei<i>他／她</i></span><span class="vf">cap<b>isce</b></span></td><td><span class="pn">loro<i>他們</i></span><span class="vf">cap<b>iscono</b></span></td></tr></table><p>發音：isco [isko]、isci [iʃi]。哪些動詞加 isc 要一個一個記。</p>' },
    { id: 'pres-irr', tag: '動詞', title: '常見不規則動詞（andare、fare、venire…）', m: { tok: 'irr' },
      body: '<table><tr><th></th><th>andare 去</th><th>fare 做</th><th>venire 來</th><th>uscire 出門</th></tr><tr><td>io<span class="zg">我</span></td><td>vado</td><td>faccio</td><td>vengo</td><td>esco</td></tr><tr><td>tu<span class="zg">你</span></td><td>vai</td><td>fai</td><td>vieni</td><td>esci</td></tr><tr><td>lui/lei<span class="zg">他／她</span></td><td>va</td><td>fa</td><td>viene</td><td>esce</td></tr><tr><td>noi<span class="zg">我們</span></td><td>andiamo</td><td>facciamo</td><td>veniamo</td><td>usciamo</td></tr><tr><td>voi<span class="zg">你們</span></td><td>andate</td><td>fate</td><td>venite</td><td>uscite</td></tr><tr><td>loro<span class="zg">他們</span></td><td>vanno</td><td>fanno</td><td>vengono</td><td>escono</td></tr></table><p>其他：bere（bevo）、dire（dico）、stare（sto）、dare（do）、rimanere（rimango）。完整表請看「詞性變化規則」。</p>' },
    { id: 'modal', tag: '動詞', title: '情態動詞 potere、volere、dovere＋原形', m: { tok: 'modal' },
      body: '<table><tr><th></th><th>potere 能</th><th>volere 想要</th><th>dovere 必須</th></tr><tr><td>io<span class="zg">我</span></td><td>posso</td><td>voglio</td><td>devo</td></tr><tr><td>tu<span class="zg">你</span></td><td>puoi</td><td>vuoi</td><td>devi</td></tr><tr><td>lui/lei<span class="zg">他／她</span></td><td>può</td><td>vuole</td><td>deve</td></tr><tr><td>noi<span class="zg">我們</span></td><td>possiamo</td><td>vogliamo</td><td>dobbiamo</td></tr><tr><td>voi<span class="zg">你們</span></td><td>potete</td><td>volete</td><td>dovete</td></tr><tr><td>loro<span class="zg">他們</span></td><td>possono</td><td>vogliono</td><td>devono</td></tr></table><p>後面直接接<b>原形動詞</b>：<i>Posso entrare?</i> <i>Devo studiare.</i></p>' },
    { id: 'sapere', tag: '動詞', title: 'sapere 和 conoscere 的差別', m: { re: w('so|sai|sa|sappiamo|sapete|sanno|conosco|conosci|conosce|conosciamo|conoscete|conoscono') },
      body: '<ul><li><b>sapere</b>：知道（一件事）、會（技能＋原形）：<i>Sai nuotare?</i> <i>Non so.</i></li><li><b>conoscere</b>：認識（人、地方）：<i>Conosci Marco?</i> <i>Conosco un buon ristorante.</i></li></ul><p>sapere 現在式：so, sai, sa, sappiamo, sapete, sanno。</p>' },
    { id: 'piacere', tag: '句型', title: 'mi piace／mi piacciono（我喜歡）', m: { re: w('(?:non )?(?:mi|ti|gli|le|ci|vi)(?: \\w+)? (?:piace|piacciono|piaceva|è piaciuto|è piaciuta)') },
      body: '<p>義大利文說「某物<b>讓我喜歡</b>」：喜歡的東西是主詞。</p><ul><li>單數或動詞原形 → <b>piace</b>：<i>Mi piace la pizza.</i> <i>Mi piace viaggiare.</i></li><li>複數 → <b>piacciono</b>：<i>Mi piacciono le patate.</i></li></ul><table><tr><td>mi 我</td><td>ti 你</td><td>gli 他</td><td>le 她／您</td><td>ci 我們</td><td>vi 你們</td></tr></table><p>否定：<i>Non mi piace la cipolla.</i></p>' },
    { id: 'refl', tag: '動詞', title: '反身動詞（mi chiamo、mi alzo）', m: { tok: 'refl' },
      body: '<p>原形以 <b>-si</b> 結尾的動詞（chiamarsi、alzarsi、lavarsi），動詞前要加反身代名詞：</p><table class="conj"><tr><th>一個人</th><th>好幾個人</th></tr><tr><td><span class="pn">io<i>我</i></span><span class="vf"><b>mi</b> alzo</span></td><td><span class="pn">noi<i>我們</i></span><span class="vf"><b>ci</b> alziamo</span></td></tr><tr><td><span class="pn">tu<i>你</i></span><span class="vf"><b>ti</b> alzi</span></td><td><span class="pn">voi<i>你們</i></span><span class="vf"><b>vi</b> alzate</span></td></tr><tr><td><span class="pn">lui/lei<i>他／她</i></span><span class="vf"><b>si</b> alza</span></td><td><span class="pn">loro<i>他們</i></span><span class="vf"><b>si</b> alzano</span></td></tr></table><p>過去式一律用 essere：<i>Mi sono alzato alle sette.</i> 命令式黏在後面：<i>Alzati!</i> <i>Lavati le mani!</i></p>' },
    { id: 'neg', tag: '句型', title: '否定句 non、non…mai、non…niente', m: { re: w('non') + '(?:[^.!?]*?' + w('mai|niente|ancora|più') + ')?' },
      body: '<p><b>non</b> 放在動詞前面：<i>Non parlo tedesco.</i></p><p>雙重否定在義大利文是正常的：</p><ul><li>non … mai 從不：<i>Non bevo mai il caffè.</i></li><li>non … niente 什麼都不：<i>Non mangio niente.</i></li><li>non … ancora 還沒：<i>Non ho ancora mangiato.</i></li></ul>' },
    { id: 'questions', tag: '句型', title: '疑問詞 chi、cosa、dove、come、quando、quanto、quale、perché', m: { re: w('chi|che cosa|cosa|dove|dov\'|come|com\'|quando|quanto|quanta|quanti|quante|quale|quali|qual|perché') + '(?=[^.!]*\\?)' },
      body: '<table><tr><td>chi 誰</td><td>cosa／che cosa 什麼</td></tr><tr><td>dove 哪裡（dov\'è）</td><td>come 怎麼</td></tr><tr><td>quando 什麼時候</td><td>quanto 多少（要配合：quanti anni）</td></tr><tr><td>quale 哪一個（qual è）</td><td>perché 為什麼</td></tr></table><p>是非疑問句不用改語序，只要語調上揚：<i>Parli inglese?</i></p>' },
    { id: 'prep', tag: '介係詞', title: '簡單介係詞 di、a、da、in、con、su、per、tra', m: { tok: 'simpleprep' },
      body: '<table><tr><td><b>di</b></td><td>…的；來自（城市）</td><td>il libro di Marco、sono di Roma</td></tr><tr><td><b>a</b></td><td>到／在（城市）、幾點</td><td>vado a Milano、alle otto</td></tr><tr><td><b>da</b></td><td>從；到某人家；自從</td><td>vengo da Napoli、vado dal medico</td></tr><tr><td><b>in</b></td><td>在／到（國家、區域）、交通工具</td><td>in Italia、in centro、in treno</td></tr><tr><td><b>con</b></td><td>和…一起</td><td>con gli amici</td></tr><tr><td><b>su</b></td><td>在…上；關於</td><td>sul tavolo</td></tr><tr><td><b>per</b></td><td>為了；給</td><td>per te</td></tr><tr><td><b>tra／fra</b></td><td>之間；…之後</td><td>tra due giorni</td></tr></table>' },
    { id: 'artprep', tag: '介係詞', title: '介係詞＋冠詞合併（del、al、nella…）', m: { tok: 'artprep' },
      body: '<p>di、a、da、in、su 後面接定冠詞時要合成一個字：</p><table class="wide"><tr><th></th><th>il</th><th>lo</th><th>l\'</th><th>la</th><th>i</th><th>gli</th><th>le</th></tr><tr><td>di</td><td>del</td><td>dello</td><td>dell\'</td><td>della</td><td>dei</td><td>degli</td><td>delle</td></tr><tr><td>a</td><td>al</td><td>allo</td><td>all\'</td><td>alla</td><td>ai</td><td>agli</td><td>alle</td></tr><tr><td>da</td><td>dal</td><td>dallo</td><td>dall\'</td><td>dalla</td><td>dai</td><td>dagli</td><td>dalle</td></tr><tr><td>in</td><td>nel</td><td>nello</td><td>nell\'</td><td>nella</td><td>nei</td><td>negli</td><td>nelle</td></tr><tr><td>su</td><td>sul</td><td>sullo</td><td>sull\'</td><td>sulla</td><td>sui</td><td>sugli</td><td>sulle</td></tr></table><p>con、per 不合併：con il、per la。</p>' },
    { id: 'place', tag: '介係詞', title: '地點：a 和 in 的用法', m: { re: w("a|in|ad") + ' (?:roma|milano|firenze|venezia|napoli|bologna|taipei|siena|italia|taiwan|casa|scuola|centro|montagna|campagna|ufficio|banca|piscina|palestra|biblioteca|pizzeria|vacanza|spiaggia|cucina|giardino|piazza|città|sardegna|toscana|letto|soggiorno|bagno)' + E },
      body: '<ul><li><b>a</b> ＋ 城市：a Roma、a Taipei；也用在 a casa、a scuola、a letto</li><li><b>in</b> ＋ 國家、大區、島：in Italia、in Toscana、in Sardegna</li><li><b>in</b> ＋ 很多場所：in centro、in banca、in ufficio、in montagna、in biblioteca、in vacanza</li><li>有冠詞時用合併形：al mare、al cinema、alla stazione、nel parco</li></ul>' },
    { id: 'transport', tag: '介係詞', title: '交通方式：in treno、a piedi', m: { re: w("in (?:treno|macchina|bicicletta|autobus|aereo|metro|taxi|moto)|a piedi|con la nave") },
      body: '<p>搭交通工具用 <b>in</b>（不加冠詞）：in treno、in macchina、in aereo、in bicicletta、in autobus、in metro。</p><p>走路是 <b>a piedi</b>。</p><p>「搭」也可以用 prendere：<i>Prendo l\'autobus.</i></p>' },
    { id: 'poss', tag: '限定詞', title: '所有格 mio、tuo、suo…', m: { tok: 'poss' },
      body: '<table><tr><th></th><th>陽單</th><th>陰單</th><th>陽複</th><th>陰複</th></tr><tr><td>我的</td><td>il mio</td><td>la mia</td><td>i miei</td><td>le mie</td></tr><tr><td>你的</td><td>il tuo</td><td>la tua</td><td>i tuoi</td><td>le tue</td></tr><tr><td>他／她／您的</td><td>il suo</td><td>la sua</td><td>i suoi</td><td>le sue</td></tr><tr><td>我們的</td><td>il nostro</td><td>la nostra</td><td>i nostri</td><td>le nostre</td></tr><tr><td>你們的</td><td>il vostro</td><td>la vostra</td><td>i vostri</td><td>le vostre</td></tr><tr><td>他們的</td><td>il loro</td><td>la loro</td><td>i loro</td><td>le loro</td></tr></table><p>所有格要配合<b>被擁有的東西</b>，不是擁有者：<i>Marco ama sua moglie.</i></p><p>單數家人<b>不加冠詞</b>：mio padre、mia sorella（但 la mia famiglia、i miei fratelli、il mio ragazzo 要加）。</p>' },
    { id: 'demo', tag: '限定詞', title: '指示詞 questo、quello', m: { tok: 'demo' },
      body: '<p><b>questo</b>（這個）像一般 -o 形容詞：questo, questa, questi, queste（母音前可寫 quest\'）。</p><p><b>quello</b>（那個）在名詞前像定冠詞一樣變化：</p><table><tr><td>il → quel libro</td><td>i → quei libri</td></tr><tr><td>lo → quello studente</td><td>gli → quegli studenti</td></tr><tr><td>l\' → quell\'uomo</td><td>la → quella ragazza、le → quelle ragazze</td></tr></table>' },
    { id: 'numbers', tag: '數字時間', title: '數字 0–1000', m: { tok: 'num' },
      body: '<p>1–10：uno, due, tre, quattro, cinque, sei, sette, otto, nove, dieci</p><p>11–20：undici, dodici, tredici, quattordici, quindici, sedici, diciassette, diciotto, diciannove, venti</p><p>十位：trenta, quaranta, cinquanta, sessanta, settanta, ottanta, novanta, cento, mille（兩千 duemila）</p><p>21、28 去掉母音：ventuno、ventotto；23 寫 ventitré（有重音）。</p>' },
    { id: 'time', tag: '數字時間', title: '幾點了？Che ore sono?', m: { re: w("che ore sono|sono le \\w+(?: e (?:mezza|un quarto|\\w+))?|è l'una|alle \\w+|all'una|a mezzogiorno|a mezzanotte|e mezza|e un quarto") },
      body: '<ul><li><i>Che ore sono?</i> 現在幾點？</li><li><i>Sono le tre.</i>（複數 le，因為是 le ore）</li><li><i>È l\'una.</i> 一點；<i>È mezzogiorno.</i> 中午</li><li>3:30 <i>le tre e mezza</i>；2:15 <i>le due e un quarto</i></li><li>在幾點：<b>alle</b> otto、<b>all\'</b>una、<b>a</b> mezzogiorno</li></ul>' },
    { id: 'dates', tag: '數字時間', title: '星期、月份、季節', m: { re: w('lunedì|martedì|mercoledì|giovedì|venerdì|sabato|domenica|gennaio|febbraio|marzo|aprile|maggio|giugno|luglio|agosto|settembre|ottobre|novembre|dicembre|primavera|estate|autunno|inverno') },
      body: '<p>星期、月份都<b>小寫</b>。星期除了 la domenica 都是陽性。</p><ul><li>加冠詞表示「每個」：<i>il sabato</i> 每個星期六；不加是「這個」：<i>sabato</i> 這個星期六</li><li>月份用 <b>a</b>：a maggio、ad agosto</li><li>季節用 <b>in</b>：in estate、in inverno（也說 d\'estate）</li></ul>' },
    { id: 'weather', tag: '句型', title: '天氣怎麼說', m: { re: w("che tempo fa|fa (?:molto )?(?:caldo|freddo|bel tempo|brutto tempo|brutto)|piove|nevica|c'è (?:il sole|vento|la nebbia|molta neve)") },
      body: '<ul><li><i>Che tempo fa?</i> 天氣怎麼樣？</li><li>用 <b>fare</b>：fa caldo、fa freddo、fa bel tempo、fa brutto tempo</li><li>動詞本身：piove（下雨）、nevica（下雪）</li><li>用 c\'è：c\'è il sole、c\'è vento、c\'è la nebbia</li></ul><p>人覺得冷熱用 avere：<i>Ho freddo.</i></p>' },
    { id: 'pp-avere', tag: '過去式', title: 'passato prossimo（一）：avere＋過去分詞', m: { tok: 'passAvere' }, ex: [['Ho comprato una giacca nuova.', '我買了一件新外套。'], ['Abbiamo mangiato la pizza a Napoli.', '我們在拿坡里吃了披薩。'], ['Hai fatto i compiti?', '你寫作業了嗎？'], ['Ieri sera ho letto un libro.', '昨晚我讀了一本書。']],
      body: '<p>表示「做過、已經做了」：<b>avere 現在式＋過去分詞</b>。</p><p>過去分詞：-are → <b>-ato</b>、-ere → <b>-uto</b>、-ire → <b>-ito</b>（mangiato、avuto、dormito）。</p><table class="conj"><tr><th>一個人</th><th>好幾個人</th></tr><tr><td><span class="pn">io<i>我</i></span><span class="vf">ho mangiato</span></td><td><span class="pn">noi<i>我們</i></span><span class="vf">abbiamo mangiato</span></td></tr><tr><td><span class="pn">tu<i>你</i></span><span class="vf">hai mangiato</span></td><td><span class="pn">voi<i>你們</i></span><span class="vf">avete mangiato</span></td></tr><tr><td><span class="pn">lui/lei<i>他／她</i></span><span class="vf">ha mangiato</span></td><td><span class="pn">loro<i>他們</i></span><span class="vf">hanno mangiato</span></td></tr></table><p>常見不規則分詞：fatto、detto、letto、scritto、preso、visto、messo、aperto、chiuso、bevuto、perso。</p>' },
    { id: 'pp-essere', tag: '過去式', title: 'passato prossimo（二）：essere＋過去分詞', m: { tok: 'passEssere' }, ex: [['Anna è arrivata alle otto.', '安娜八點到了。'], ['Siamo andati al mare.', '我們去了海邊。'], ['Mi sono alzato tardi.', '我起得很晚。'], ['Le ragazze sono uscite ieri sera.', '女孩們昨晚出去了。']],
      body: '<p>移動、狀態改變的動詞（andare、venire、arrivare、partire、uscire、tornare、nascere、restare、stare…）和所有反身動詞用 <b>essere</b>。</p><p>這時分詞要跟主詞<b>配合性別和單複數</b>：</p><ul><li>Marco è andat<b>o</b>／Anna è andat<b>a</b></li><li>Siamo partit<b>i</b>／Le ragazze sono uscit<b>e</b></li></ul><p>App 裡每個動詞的變化表都有標出用 essere 還是 avere。</p>' },
    { id: 'imper', tag: '動詞', title: '命令式（Apri la finestra!）', m: { tok: 'imper' },
      body: '<table><tr><th></th><th>-are（parlare）</th><th>-ere（prendere）</th><th>-ire（aprire）</th></tr><tr><td>tu<span class="zg">你</span></td><td>parla</td><td>prendi</td><td>apri</td></tr><tr><td>Lei（您）</td><td>parli</td><td>prenda</td><td>apra</td></tr><tr><td>noi<span class="zg">我們</span></td><td>parliamo</td><td>prendiamo</td><td>apriamo</td></tr><tr><td>voi<span class="zg">你們</span></td><td>parlate</td><td>prendete</td><td>aprite</td></tr></table><p>注意 -are 和 -ere/-ire 的 tu、Lei 剛好相反。對 tu 的否定用 non＋原形：<i>Non cadere!</i></p><p>不規則：va\'（andare）、fa\'（fare）、vieni、sii、abbi、di\'（dire）。</p>' },
    { id: 'lei', tag: '句型', title: '敬稱 Lei（您）', m: { re: w("scusi|mi scusi|può|desidera|si sieda|vada|giri|compili|firmi|come sta|che taglia porta|ha una camera|ha un documento|mi porta") },
      body: '<p>對陌生人、店員、長輩用 <b>Lei</b>（您），動詞用<b>第三人稱單數</b>：</p><ul><li><i>Come sta?</i>（您好嗎）↔ <i>Come stai?</i>（你好嗎）</li><li><i>Scusi</i>（對您）↔ <i>Scusa</i>（對你）</li><li><i>Può ripetere?</i> 您可以再說一次嗎？</li></ul><p>寫的時候 Lei 常大寫，跟 lei（她）區分。</p>' },
    { id: 'compar', tag: '形容詞', title: '比較 più／meno … di', m: { re: w('più|meno') + '[^.!?]*?(?:' + w('di|del|della|dei|delle') + "|dell')|" + w('più|meno') }, ex: [['Roma è più grande di Firenze.', '羅馬比佛羅倫斯大。'], ['La pizza è meno cara della carne.', '披薩比肉便宜。']],
      body: '<ul><li>A è <b>più</b> + 形容詞 + <b>di</b> B：<i>Lui è più alto di me.</i>（他比我高）</li><li>A è <b>meno</b> + 形容詞 + <b>di</b> B：<i>Il treno è meno caro dell\'aereo.</i></li><li>di 後面接冠詞要合併：dell\'aereo、della pizza</li></ul><p>特別形：buono → <b>migliore</b>（更好的）。</p>' },
    { id: 'molto', tag: '形容詞', title: 'molto、tanto、troppo、poco', m: { re: w("molto|molta|molti|molte|troppo|troppa|troppi|troppe|poco|poca|pochi|poche|un po'|tanto|tanta|tanti|tante") },
      body: '<ul><li>當<b>副詞</b>（修飾形容詞、動詞）不變化：<i>È molto buona.</i> <i>Lavoro troppo.</i></li><li>當<b>形容詞</b>（修飾名詞）要配合：<i>molta gente</i>、<i>molti turisti</i>、<i>molte nuvole</i></li><li><i>un po\' (di)</i> 一點點：<i>Parlo un po\' di italiano.</i></li></ul>' },
    { id: 'vorrei', tag: '句型', title: '禮貌請求 vorrei、potrei', m: { re: w('vorrei|vorresti|vorrebbe|vorremmo|potrei|potresti|potrebbe|per favore') },
      body: '<p>點餐、購物時用 <b>vorrei</b>（我想要，比 voglio 客氣）：</p><ul><li><i>Vorrei un caffè, per favore.</i></li><li><i>Vorrei prenotare un tavolo.</i></li><li><i>Potrebbe ripetere?</i> 您可以再說一次嗎？</li></ul><p>vorrei 是 volere 的條件式，A1 先當成固定說法記住。</p>' },
    { id: 'stare', tag: '動詞', title: 'stare：Come stai? Sto bene.', m: { re: w('come (?:stai|sta|state)|(?:sto|stai|sta|stiamo|state|stanno) (?:bene|male)') },
      body: '<p>問候身體狀況用 <b>stare</b>：</p><ul><li><i>Come stai?</i>（你好嗎）<i>Come sta?</i>（您好嗎）</li><li><i>Sto bene, grazie.</i> <i>Sto male.</i> <i>Così così.</i></li></ul><p>stare 現在式：sto, stai, sta, stiamo, state, stanno。</p>' },
    { id: 'andare', tag: '動詞', title: 'andare a／andare in／venire da', m: { re: w('vado|vai|va|andiamo|andate|vanno|vengo|vieni|viene|veniamo|venite|vengono') + " (?:a|in|al|alla|allo|all'|ai|alle|da|dal|dalla|con|al)" + E },
      body: '<ul><li>andare <b>a</b> ＋ 城市／原形動詞：<i>Vado a Roma.</i> <i>Vado a mangiare.</i></li><li>andare <b>in</b> ＋ 國家、場所：<i>Vado in Italia.</i> <i>Vado in banca.</i></li><li>andare <b>da</b> ＋ 人：<i>Vado dal medico.</i>（去看醫生）</li><li>venire <b>da</b> ＋ 來自的地方：<i>Vengo da Taipei.</i></li></ul>' },
    { id: 'conj', tag: '句型', title: '連接詞 e、ma、o、perché、quando、se', m: { re: w('e|ed|ma|o|perché|quando|se|quindi') + '(?=[^?]*[.!]$)' },
      body: '<table><tr><td>e 和</td><td>ma 但是</td><td>o 或</td></tr><tr><td>perché 因為</td><td>quando 當…的時候</td><td>se 如果</td></tr><tr><td>quindi 所以</td><td>allora 那麼</td><td>anche 也</td></tr></table><p>perché 同時是「為什麼」和「因為」，quando 也是「什麼時候」。</p>' },
    { id: 'freq', tag: '句型', title: '頻率：sempre、spesso、qualche volta、mai', m: { re: w('sempre|spesso|qualche volta|mai|ogni (?:giorno|mattina|sera|domenica)|tutti i giorni|due volte') },
      body: '<p>從多到少：<b>sempre</b>（總是）→ <b>spesso</b>（常常）→ <b>qualche volta</b>（有時）→ <b>non … mai</b>（從不）</p><p>每天：<i>ogni giorno</i>／<i>tutti i giorni</i>；一週兩次：<i>due volte alla settimana</i></p>' },
    { id: 'si', tag: '句型', title: '「一般人」的 si：Come si dice?', m: { re: w('si (?:dice|può|mangia|parla|scrive)') }, ex: [['In Italia si mangia bene.', '在義大利吃得很好。']],
      body: '<p><b>si</b> ＋ 第三人稱動詞，表示「一般人、大家」：</p><ul><li><i>Come si dice “grazie” in italiano?</i> 「謝謝」用義大利文怎麼說？</li><li><i>Qui non si può fumare.</i> 這裡不能抽菸。</li><li><i>In Italia si mangia bene.</i> 在義大利吃得很好。</li></ul>' },
    { id: 'pron-obj', tag: '代名詞', title: '受詞代名詞 mi、ti、ci、vi（Ti chiamo.）', m: { re: '(?!mi chiamo)' + w('(?:mi|ti|ci|vi) (?:chiamo|aspetto|vediamo|regalo|mando|ringrazio|dai|porta|aiuti|fai|spieghi|passi|serve|scrivo)') },
      body: '<p>代名詞放在<b>動詞前面</b>：</p><ul><li><i>Ti chiamo stasera.</i> 我今晚打給你。</li><li><i>Mi aiuti?</i> 你可以幫我嗎？</li><li><i>Ci vediamo domani.</i> 我們明天見。</li></ul><p>「他／她／它」：lo（陽）、la（陰）：<i>Lo compro.</i> 我買它。</p>' }
  ];

  /* ---------- 詞性變化規則頁 ---------- */
  // 規則頁會把好幾個文法點的說明接在一起，每段前面加上小標題
  const gbI = i => '<h3 class="gb-h">' + IT.GRAMMAR[i].title + '</h3>' + IT.GRAMMAR[i].body;
  IT.RULES = [
    { id: 'r-noun', title: '名詞的性別與複數', icon: 'n',
      body: gbI(2) + gbI(3),
      demo: ['libro', 'casa', 'chiave', 'fiore', 'banca', 'parco', 'amico', 'città', 'film', 'uomo', 'braccio', 'mano'],
      filter: e => e[1] === 'n' },
    { id: 'r-art', title: '冠詞', icon: 'a',
      body: gbI(0) + gbI(1),
      demo: ['libro', 'studente', 'zaino', 'amico', 'casa', 'amica', 'uomo', 'sport', 'isola', 'psicologo'],
      filter: e => e[1] === 'n' },
    { id: 'r-adj', title: '形容詞的配合', icon: 'g',
      body: gbI(4) + '<p>-co 結尾：bianco → bianchi（多數加 h）；simpatico → simpatici（重音在前面的不加 h）。-go 結尾一律加 h：lungo → lunghi。</p>',
      demo: ['alto', 'grande', 'bianco', 'simpatico', 'lungo', 'vecchio', 'blu', 'bello'],
      filter: e => e[1] === 'adj' },
    { id: 'r-are', title: '-are 規則動詞', icon: 'v',
      body: gbI(9), demo: ['parlare', 'cercare', 'mangiare'],
      filter: e => e[1] === 'v-are' },
    { id: 'r-ere', title: '-ere 規則動詞', icon: 'v',
      body: gbI(10) + '<p>很多 -ere 動詞的過去分詞不規則：preso、letto、scritto、visto、messo、chiuso…（見各字變化表）。</p>', demo: ['prendere', 'leggere', 'vedere'],
      filter: e => e[1] === 'v-ere' },
    { id: 'r-ire', title: '-ire 規則動詞（含 -isc-）', icon: 'v',
      body: gbI(11) + gbI(12), demo: ['dormire', 'partire', 'capire'],
      filter: e => e[1] === 'v-ire' || e[1] === 'v-isc' },
    { id: 'r-ea', title: 'essere 與 avere', icon: 'v',
      body: gbI(5) + gbI(6) + '<p>兩個動詞也是過去式的助動詞：<i>ho mangiato</i>、<i>sono andato</i>。</p>', demo: ['essere', 'avere'],
      filter: e => e[0] === 'essere' || e[0] === 'avere' },
    { id: 'r-irr', title: '常見不規則動詞', icon: 'v',
      body: gbI(13) + gbI(14), demo: ['andare', 'fare', 'venire', 'potere'],
      filter: e => e[1] === 'v-irr' && e[0] !== 'essere' && e[0] !== 'avere' }
  ];
})(typeof window !== 'undefined' ? window : globalThis);
