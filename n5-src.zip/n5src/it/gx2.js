/* 義大利文文法的範例拆解與練習題（2）：介係詞、限定詞、數字時間、過去式、其他句型 */
(function (G) {
  const IT = G.IT || (G.IT = {});
  IT.GX = Object.assign(IT.GX || {}, {
    // ---------- 介係詞 ----------
    'prep': {
      ex: [["Vado a Roma con Marco.", '我和 Marco 去羅馬。', [['Vado', '我去'], ['a', '到'], ['Roma', '羅馬'], ['con', '和'], ['Marco', 'Marco']],
        ['a：到某個城市。', 'con：和誰一起。'],
        '介係詞放在名詞前面，跟中文的「到、和、從」差不多，只是位置在名詞前。'],
        ["Il libro è di Anna.", '這本書是 Anna 的。', [['Il', '那本'], ['libro', '書'], ['è', '是'], ['di', '…的'], ['Anna', 'Anna']],
        ['di＝「…的」，但要放在人名前面。'],
        '中文說「Anna 的書」，義大利文說「書 di Anna」。']],
      q: [['Sono ___ Taiwan.', 'di', ['a', 'con'], '我是台灣人。', 'essere di ＋ 地方＝來自那裡。'],
        ['Questo regalo è ___ te.', 'per', ['di', 'con'], '這個禮物是給你的。', 'per＝為了、給。'],
        ['Vengo ___ Milano.', 'da', ['a', 'in'], '我從米蘭來。', 'da＝從（某處來）。']]
    },
    'artprep': {
      ex: [["Il gatto è sul letto.", '貓在床上。', [['Il', '那隻'], ['gatto', '貓'], ['è', '在'], ['sul', '在…上'], ['letto', '床']],
        ['sul ＝ su ＋ il，兩個字黏成一個。'],
        'di、a、da、in、su 碰到後面的定冠詞，要合成一個字。'],
        ["Vado alla stazione.", '我去車站。', [['Vado', '我去'], ['alla', '到那個'], ['stazione', '車站']],
        ['alla ＝ a ＋ la，因為 stazione 是陰性。'],
        '先決定冠詞（il、la、lo…），再跟前面的介係詞合起來。']],
      q: [['Il libro è ___ tavolo. (su + il)', 'sul', ['sulla', 'su il'], '書在桌上。', 'su ＋ il ＝ sul。'],
        ['Abito ___ centro. (in + il)', 'nel', ['nella', 'in il'], '我住在市中心。', 'in ＋ il ＝ nel。'],
        ['La casa ___ ragazzi. (di + i)', 'dei', ['degli', 'di i'], '男孩們的家。', 'di ＋ i ＝ dei。']]
    },
    'place': {
      ex: [["Abito a Taipei, in Taiwan.", '我住在台灣的台北。', [['Abito', '我住'], ['a', '在'], ['Taipei', '台北'], [',', ''], ['in', '在'], ['Taiwan', '台灣']],
        ['城市前用 a。', '國家、地區前用 in。'],
        '小的地方（城市）用 a，大的地方（國家）用 in。']],
      q: [['Vivo ___ Italia.', 'in', ['a', 'di'], '我住在義大利。', '國家用 in。'],
        ['Andiamo ___ Firenze.', 'a', ['in', 'da'], '我們去佛羅倫斯。', '城市用 a。'],
        ['Sono ___ casa.', 'a', ['in la', 'di'], '我在家。', '固定說法：a casa。']]
    },
    'transport': {
      ex: [["Vado al lavoro in treno, ma torno a piedi.", '我搭火車去上班，但走路回家。', [['Vado', '我去'], ['al', '到'], ['lavoro', '工作'], ['in', '搭'], ['treno', '火車'], [',', ''], ['ma', '但是'], ['torno', '我回來'], ['a', '用'], ['piedi', '腳']],
        ['交通工具前用 in，不加冠詞：in treno、in macchina。', '走路是例外：a piedi。'],
        '「搭什麼去」＝ in ＋ 交通工具；「走路」＝ a piedi。']],
      q: [['Vengo ___ autobus.', 'in', ['a', 'con il'], '我搭公車來。', '交通工具用 in。'],
        ['Vado a scuola ___ piedi.', 'a', ['in', 'con'], '我走路上學。', '走路固定是 a piedi。'],
        ['Andiamo a Roma ___ aereo.', 'in', ['a', 'su'], '我們搭飛機去羅馬。', '交通工具用 in。']]
    },
    // ---------- 限定詞 ----------
    'poss': {
      ex: [["La mia casa è piccola.", '我的房子很小。', [['La', '那間'], ['mia', '我的'], ['casa', '房子'], ['è', '是'], ['piccola', '小的']],
        ['mia：casa 是陰性，「我的」用 mia。', '所有格前面還要加冠詞 la。'],
        '「我的」跟著後面的東西變性別，而且前面通常要有冠詞。'],
        ["Mia sorella si chiama Lucia.", '我妹妹叫 Lucia。', [['Mia', '我的'], ['sorella', '妹妹'], ['si', '自己'], ['chiama', '叫'], ['Lucia', 'Lucia']],
        ['家人（單數）是例外：不加冠詞，直接 mia sorella。'],
        '一個家人：mia madre、mio padre；好幾個家人就要加冠詞：le mie sorelle。']],
      q: [['Il ___ libro è nuovo.', 'mio', ['mia', 'miei'], '我的書是新的。', 'libro 是陽性單數，用 mio。'],
        ['___ padre è medico.', 'Mio', ['Il mio', 'Mia'], '我爸爸是醫生。', '單數家人不加冠詞。'],
        ['Dove sono le ___ chiavi?', 'mie', ['mia', 'miei'], '我的鑰匙在哪？', 'chiavi 是陰性複數，用 mie。']]
    },
    'demo': {
      ex: [["Questo libro è bello, quella borsa no.", '這本書很好看，那個包包不好看。', [['Questo', '這本'], ['libro', '書'], ['è', '是'], ['bello', '好看'], [',', ''], ['quella', '那個'], ['borsa', '包包'], ['no', '不']],
        ['questo：近的東西，libro 陽性 → questo。', 'quella：遠的東西，borsa 陰性 → quella。'],
        'questo＝這、quello＝那，兩個都要跟著名詞變 -o／-a／-i／-e。']],
      q: [['___ ragazza è mia sorella.', 'Questa', ['Questo', 'Questi'], '這個女孩是我妹妹。', 'ragazza 是陰性單數，用 questa。'],
        ['Mi piacciono ___ scarpe.', 'queste', ['questi', 'questa'], '我喜歡這雙鞋。', 'scarpe 是陰性複數，用 queste。'],
        ['Quanto costa ___ ?', 'questo', ['questi', 'queste'], '這個多少錢？', '單獨指一個東西就說 questo。']]
    },
    // ---------- 數字時間 ----------
    'numbers': {
      ex: [["Ho ventuno anni.", '我二十一歲。', [['Ho', '我有'], ['ventuno', '二十一'], ['anni', '年']],
        ['venti ＋ uno → ventuno：碰到 uno 或 otto 時，venti 的 i 會掉。'],
        '十位數＋個位數直接黏在一起寫：ventidue、trentatré。']],
      q: [['Ho ___ anni. (28)', 'ventotto', ['ventiotto', 'venti otto'], '我二十八歲。', 'venti ＋ otto，i 掉了。'],
        ['Costa ___ euro. (13)', 'tredici', ['treddici', 'trenta'], '十三歐元。', '13 是 tredici；30 是 trenta。'],
        ['Siamo in ___ . (100)', 'cento', ['mille', 'centi'], '我們有一百個人。', '100 是 cento，1000 是 mille。']]
    },
    'time': {
      ex: [["Sono le tre e mezza.", '現在三點半。', [['Sono', '是'], ['le', '那些'], ['tre', '三（點）'], ['e', '加'], ['mezza', '半']],
        ['幾點用 sono le ＋ 數字（因為 ore 是複數）。', 'e mezza＝再加半小時。'],
        '問：Che ore sono? 答：Sono le … ；只有一點是 È l\'una。'],
        ["Il treno parte alle otto.", '火車八點出發。', [['Il', '那班'], ['treno', '火車'], ['parte', '出發'], ['alle', '在…點'], ['otto', '八']],
        ['「在幾點」用 alle（a ＋ le）。'],
        '「現在幾點」用 sono le，「在幾點做某事」用 alle。']],
      q: [['___ le cinque.', 'Sono', ['È', 'Ci sono'], '現在五點。', '兩點以後都用 sono le。'],
        ["___ l'una.", 'È', ['Sono', 'Ha'], '現在一點。', '一點是單數：è l\'una。'],
        ['Ci vediamo ___ nove.', 'alle', ['le', 'a'], '我們九點見。', '「在幾點」用 alle。']]
    },
    'dates': {
      ex: [["Il lunedì vado in palestra.", '我每週一去健身房。', [['Il', '每個'], ['lunedì', '星期一'], ['vado', '我去'], ['in', '到'], ['palestra', '健身房']],
        ['il lunedì＝每週一；只說 lunedì＝這個星期一。'],
        '星期前面加 il 表示「每週的那一天」。'],
        ["A luglio fa caldo.", '七月很熱。', [['A', '在'], ['luglio', '七月'], ['fa', '（天氣）是'], ['caldo', '熱']],
        ['月份前面用 a 或 in。', '月份、星期都小寫開頭。'],
        '在幾月：a luglio、in luglio 都可以。']],
      q: [['Il mio compleanno è ___ maggio.', 'a', ['il', 'di'], '我的生日在五月。', '在幾月用 a（或 in）。'],
        ['___ domenica dormo tanto.', 'La', ['Il', 'A'], '每週日我睡很多。', 'domenica 是陰性，每週日＝la domenica。'],
        ['In ___ fa freddo.', 'inverno', ['estate', 'luglio'], '冬天很冷。', 'inverno 是冬天；estate 是夏天。']]
    },
    'weather': {
      ex: [["Oggi fa bel tempo.", '今天天氣很好。', [['Oggi', '今天'], ['fa', '做（天氣）'], ['bel', '好的'], ['tempo', '天氣']],
        ['天氣用 fare（做）：fa caldo、fa freddo、fa bel tempo。'],
        '義大利文說天氣「做熱、做冷」，動詞用 fa。'],
        ["Oggi piove.", '今天在下雨。', [['Oggi', '今天'], ['piove', '下雨']],
        ['一個字就是一句話，沒有主詞。'],
        '下雨 piove、下雪 nevica，不用說「天」。']],
      q: [['Oggi ___ freddo.', 'fa', ['è', 'ha'], '今天很冷。', '天氣冷熱用 fa。'],
        ['Che tempo ___ ?', 'fa', ['è', 'ha'], '天氣怎麼樣？', '問天氣：Che tempo fa?'],
        ['Domani ___ .', 'piove', ['fa piove', 'è pioggia'], '明天會下雨。', '下雨直接說 piove。']]
    },
    // ---------- 過去式 ----------
    'pp-avere': {
      ex: [["Ieri ho mangiato la pizza.", '我昨天吃了披薩。', [['Ieri', '昨天'], ['ho', '我有'], ['mangiato', '吃了'], ['la', '那個'], ['pizza', '披薩']],
        ['過去式＝avere（照人稱變）＋ 過去分詞（不變）。', 'mangiare → mangiato：-are 變 -ato。'],
        '像英文的 I have eaten：前面的 ho、hai、ha 告訴你是誰，後面的 -ato／-uto／-ito 告訴你做了什麼。']],
      q: [['Ieri ___ visto un film.', 'ho', ['sono', 'ha visto'], '我昨天看了一部電影。', 'vedere 用 avere 當助動詞。'],
        ['Hai ___ la cena? (preparare)', 'preparato', ['preparata', 'preparare'], '你做了晚餐嗎？', '-are 的過去分詞是 -ato。'],
        ['Abbiamo ___ tutto. (capire)', 'capito', ['capato', 'capisco'], '我們都懂了。', '-ire 的過去分詞是 -ito。']]
    },
    'pp-essere': {
      ex: [["Anna è andata a Roma.", 'Anna 去了羅馬。', [['Anna', 'Anna'], ['è', '是'], ['andata', '去了'], ['a', '到'], ['Roma', '羅馬']],
        ['去、來、出發、留下這類動詞用 essere 當助動詞。', '用 essere 時，分詞要跟主詞配：Anna 是女生 → andata。'],
        '「移動、改變狀態」的動詞用 essere，而且分詞的字尾要跟主詞的性別、單複數一樣。']],
      q: [['Marco ___ partito ieri.', 'è', ['ha', 'sono'], 'Marco 昨天出發了。', 'partire 用 essere。'],
        ['Le ragazze sono ___ . (uscire)', 'uscite', ['uscito', 'usciti'], '女孩們出去了。', '用 essere，分詞跟主詞配：陰性複數 -e。'],
        ['Siamo ___ a casa. (tornare)', 'tornati', ['tornato', 'tornare'], '我們回家了。', 'noi（陽性或混合）→ 分詞 -i。']]
    },
    'imper': {
      ex: [["Apri la finestra, per favore.", '請打開窗戶。', [['Apri', '打開'], ['la', '那扇'], ['finestra', '窗戶'], [',', ''], ['per', '請'], ['favore', '（幫忙）']],
        ['apri：對「你」的命令，跟 tu apri 一樣。'],
        '-ere、-ire 動詞對「你」的命令跟現在式一樣；-are 動詞改成 -a：parla!、guarda!'],
        ["Non toccare!", '不要碰！', [['Non', '不要'], ['toccare', '碰']],
        ['對「你」說「不要」＝ non ＋ 原形。'],
        '禁止別人：non ＋ 原形，很簡單。']],
      q: [['___ qui! (guardare)', 'Guarda', ['Guardi', 'Guardo'], '看這裡！', '-are 動詞對 tu 的命令是 -a。'],
        ['Non ___ ! (parlare)', 'parlare', ['parla', 'parli'], '不要說話！', '否定命令用 non ＋ 原形。'],
        ['___ ! (venire)', 'Vieni', ['Veni', 'Viene'], '過來！', 'venire 對 tu 的命令是 vieni。']]
    },
    // ---------- 形容詞、數量 ----------
    'compar': {
      ex: [["Marco è più alto di Luca.", 'Marco 比 Luca 高。', [['Marco', 'Marco'], ['è', '是'], ['più', '更'], ['alto', '高'], ['di', '比'], ['Luca', 'Luca']],
        ['più ＋ 形容詞＝更…。', 'di ＋ 被比的人＝比…。'],
        '順序是「A 是 更高 比 B」：più … di。']],
      q: [['Roma è ___ grande di Firenze.', 'più', ['molto', 'di'], '羅馬比佛羅倫斯大。', '比較用 più … di。'],
        ['Il treno è meno caro ___ aereo.', "dell'", ['di', 'che'], '火車比飛機便宜。', "di ＋ l' 合成 dell'。"],
        ['Anna è ___ alta di me.', 'meno', ['più di', 'molto'], 'Anna 沒有我高。', 'meno … di＝沒有…那麼。']]
    },
    'molto': {
      ex: [["Ho molti amici e poco tempo.", '我有很多朋友，時間很少。', [['Ho', '我有'], ['molti', '很多'], ['amici', '朋友'], ['e', '和'], ['poco', '很少'], ['tempo', '時間']],
        ['molti：放在名詞前面當「很多」時，要跟名詞變（amici 陽性複數）。', 'poco：tempo 陽性單數。'],
        'molto 修飾名詞時會變；修飾形容詞或動詞時不變：molto bello、lavoro molto。']],
      q: [['Ci sono ___ persone.', 'molte', ['molto', 'molti'], '有很多人。', 'persone 是陰性複數。'],
        ['Questa casa è ___ bella.', 'molto', ['molta', 'molte'], '這間房子很漂亮。', '修飾形容詞時不變。'],
        ['Hai ___ lavoro?', 'troppo', ['troppa', 'troppi'], '你工作太多嗎？', 'lavoro 是陽性單數。']]
    },
    // ---------- 句型 ----------
    'vorrei': {
      ex: [["Vorrei un cappuccino, per favore.", '我想要一杯卡布奇諾，麻煩了。', [['Vorrei', '我想要'], ['un', '一杯'], ['cappuccino', '卡布奇諾'], [',', ''], ['per', '請'], ['favore', '（幫忙）']],
        ['vorrei 比 voglio 客氣，像英文的 I would like。'],
        '點餐、請求的時候說 vorrei，不要說 voglio（聽起來太直接）。']],
      q: [['___ un bicchiere d\'acqua.', 'Vorrei', ['Voglio', 'Vuoi'], '我想要一杯水。', '客氣的請求用 vorrei。'],
        ['___ aiutarmi, per favore?', 'Potrebbe', ['Potere', 'Posso'], '可以請您幫我嗎？', 'potrebbe＝您能不能（很客氣）。'],
        ['Vorrei ___ un tavolo.', 'prenotare', ['prenoto', 'prenotato'], '我想訂位。', 'vorrei 後面接原形。']]
    },
    'andare': {
      ex: [["Vado in Italia, poi vado a Roma.", '我去義大利，然後去羅馬。', [['Vado', '我去'], ['in', '到'], ['Italia', '義大利'], [',', ''], ['poi', '然後'], ['vado', '我去'], ['a', '到'], ['Roma', '羅馬']],
        ['國家用 in，城市用 a。'],
        'andare a ＋ 城市、andare in ＋ 國家。'],
        ["Vengo da Taiwan.", '我從台灣來。', [['Vengo', '我來'], ['da', '從'], ['Taiwan', '台灣']],
        ['venire da＝從哪裡來。'],
        '去：andare a／in；來自：venire da。']],
      q: [['Vado ___ Spagna.', 'in', ['a', 'da'], '我去西班牙。', '國家用 in。'],
        ['Domani andiamo ___ Venezia.', 'a', ['in', 'da'], '我們明天去威尼斯。', '城市用 a。'],
        ['Vieni ___ Giappone?', 'dal', ['in', 'a'], '你從日本來嗎？', 'da ＋ il Giappone ＝ dal Giappone。']]
    },
    'conj': {
      ex: [["Studio perché voglio andare in Italia.", '我讀書是因為想去義大利。', [['Studio', '我讀書'], ['perché', '因為'], ['voglio', '我想'], ['andare', '去'], ['in', '到'], ['Italia', '義大利']],
        ['perché 在問句是「為什麼」，在句中是「因為」。'],
        '連接詞把兩個句子接起來，順序跟中文一樣。'],
        ["Se piove, resto a casa.", '如果下雨，我就待在家。', [['Se', '如果'], ['piove', '下雨'], [',', ''], ['resto', '我待'], ['a', '在'], ['casa', '家']],
        ['se＝如果。'],
        '「如果…就…」：Se ＋ 條件, ＋ 結果。']],
      q: [['Mi piace il tè ___ non il caffè.', 'ma', ['e', 'se'], '我喜歡茶，但不喜歡咖啡。', '轉折用 ma（但是）。'],
        ['Vuoi il tè ___ il caffè?', 'o', ['ma', 'perché'], '你要茶還是咖啡？', '選擇用 o（或）。'],
        ['___ arrivo, ti chiamo.', 'Quando', ['Perché', 'Ma'], '我到的時候打給你。', 'quando＝…的時候。']]
    },
    'freq': {
      ex: [["Vado spesso al cinema.", '我常常去看電影。', [['Vado', '我去'], ['spesso', '常常'], ['al', '到'], ['cinema', '電影院']],
        ['頻率副詞通常放在動詞後面，不像中文放在動詞前。'],
        'sempre 總是、spesso 常常、qualche volta 有時候，放在動詞後面。']],
      q: [['Mangio ___ a casa.', 'sempre', ['mai', 'non'], '我總是在家吃飯。', '總是＝sempre，放動詞後。'],
        ['Non bevo ___ il caffè.', 'mai', ['sempre', 'spesso'], '我從不喝咖啡。', '和 non 配在一起的是 mai。'],
        ['___ volta vado a piedi.', 'Qualche', ['Spesso', 'Mai'], '我有時候走路去。', 'qualche volta＝有時候。']]
    },
    'si': {
      ex: [["Come si dice «grazie» in cinese?", '「grazie」中文怎麼說？', [['Come', '怎麼'], ['si', '人們'], ['dice', '說'], ['«grazie»', '「謝謝」'], ['in', '用'], ['cinese', '中文']],
        ['si ＋ 第三人稱動詞＝「一般人會…」，不指特定的人。'],
        '問「這裡怎麼做、這個怎麼說」都用 si：Come si dice? Come si fa?']],
      q: [['Qui non ___ fuma.', 'si', ['ci', 'se'], '這裡不能抽菸。', '「一般人不…」用 si ＋ 動詞。'],
        ['Come si ___ «book»?', 'dice', ['dici', 'dire'], '「book」怎麼說？', 'si 後面用第三人稱 dice。'],
        ['In Italia si ___ bene.', 'mangia', ['mangi', 'mangiare'], '在義大利吃得很好。', 'si ＋ 第三人稱單數。']]
    },
    'pron-obj': {
      ex: [["Ti chiamo domani.", '我明天打給你。', [['Ti', '你'], ['chiamo', '我打電話'], ['domani', '明天']],
        ['ti＝「你」當受詞，放在動詞前面。', 'chiamo 是「我」形，所以主詞是我。'],
        '中文是「我 打給 你」，義大利文把「你」放到動詞前面：ti chiamo。'],
        ["Mi aiuti?", '你可以幫我嗎？', [['Mi', '我'], ['aiuti', '你幫']],
        ['mi＝我（被幫的人）；aiuti 是「你」形。'],
        '看動詞詞尾知道誰在做，看前面的 mi／ti 知道對誰做。']],
      q: [['___ amo.', 'Ti', ['Tu', 'Te'], '我愛你。', '受詞「你」用 ti，放在動詞前。'],
        ['Marco ___ aspetta.', 'ci', ['noi', 'vi'], 'Marco 在等我們。', '受詞「我們」用 ci。'],
        ['Non ___ capisco.', 'ti', ['tu', 'tuo'], '我聽不懂你說的。', '受詞放在動詞前、non 後面。']]
    }
  });
})(typeof window !== 'undefined' ? window : globalThis);
