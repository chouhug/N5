(function (G) { const IT = G.IT || (G.IT = {});
/* 義大利文文法關卡：由淺到深，後面的關卡會用到前面學過的東西 */
IT.GX_PATH = [
  ['開口說', '「我是…」、問好、問問題、說「不」', ['essere', 'stare', 'lei', 'questions', 'neg']],
  ['冠詞和名詞', '名詞分男女，前面的冠詞和後面的形容詞都要跟著變', ['noun-gender', 'art-indef', 'art-def', 'noun-plural', 'adj']],
  ['「有」和點東西', 'avere（有）、c\'è（那裡有）、禮貌地說「我想要」、數字', ['avere', 'avere-expr', 'ce', 'vorrei', 'numbers']],
  ['現在式', '三種規則動詞，換掉字尾就能說「誰做什麼」', ['pres-are', 'pres-ere', 'pres-ire', 'pres-isc', 'freq']],
  ['常用動詞和去哪裡', '不規則動詞、想／能／必須，去哪個城市、搭什麼車', ['pres-irr', 'modal', 'sapere', 'place', 'andare', 'transport']],
  ['介係詞和「我的、這個」', '介係詞和冠詞合併、所有格、指示詞、很多', ['prep', 'artprep', 'poss', 'demo', 'molto']],
  ['時間和天氣', '幾點、星期、月份，天氣怎麼說', ['time', 'dates', 'weather']],
  ['喜歡、自己和代名詞', '倒過來說的「喜歡」、反身動詞、受詞代名詞、si', ['piacere', 'refl', 'pron-obj', 'si']],
  ['過去式和命令', '「做了什麼」的兩種助動詞，還有請人做事', ['pp-avere', 'pp-essere', 'imper']],
  ['長句子', '把句子接起來，還有比較', ['conj', 'compar']]
];
})(typeof window !== 'undefined' ? window : globalThis);
