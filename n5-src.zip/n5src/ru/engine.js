/* 俄文變化引擎：名詞六格、形容詞與代名詞的變化、動詞變位（第一／第二變位、-ся、體、過去式、命令式）、斷詞與查詢
   - 單字的原形（第一欄）可以加重音符號（U+0301），例句和變化形不加；比對、查詢時一律去掉重音、ё 當 е
   - 名詞第 4 欄是規格 key=value;…：anim（有生命）、gen=（單數屬格，用來算出母音脫落的詞幹）、pl=（複數主格）、gpl=（複數屬格）、
     es（重音在詞尾：ж ш щ ч ц 後面寫 о、ё）、loc=（第二前置格 в саду）、indecl（不變化）、nopl（沒有複數）、adj（照形容詞變化）、
     sg=／plf=（六個格全部指定，用逗號分開）、ipl=（複數工具格）
   - 動詞第 4 欄：p=я,ты（現在式或完成體將來式的前兩個形，其他自動推出）、pres=（六個形全部指定，空白分開）、pf（完成體）、pair=（另一個體）、
     past=陽,陰,中,複、imp=ты,вы、noimp、fut（變位是將來式，例如 быть）、motion=uni／multi（運動動詞）、note= */
(function (G) {
  'use strict';
  const RU = G.RU || (G.RU = {});
  G.LX = RU;

  /* ---------- 小工具 ---------- */
  const ACC = '́';
  // 去掉重音：手機鍵盤長按打出來的可能是拉丁字母 á、é、ó（U+00E1 等），也可能是母音＋U+0301，
  // 兩種都換回俄文字母；й、ё 本身保留
  const LAT = { a: 'а', e: 'е', o: 'о', y: 'у', i: 'и', A: 'А', E: 'Е', O: 'О', Y: 'У', I: 'И' };
  const plain = s => String(s).normalize('NFD').replace(/([aeoyiAEOYI])[\u0300\u0301]/g, (m, c) => LAT[c]).replace(/[\u0300\u0301]/g, '').normalize('NFC');
  const fold = s => plain(s).toLowerCase().replace(/ё/g, 'е');
  const norm = s => plain(String(s).replace(/[’‘]/g, "'")).replace(/ё/g, 'е').replace(/Ё/g, 'Е');
  // 搜尋用：去掉重音、ё 當 е
  const stripAccents = s => plain(s).replace(/ё/g, 'е').replace(/Ё/g, 'Е');
  RU.plain = plain; RU.fold = fold; RU.norm = norm; RU.stripAccents = stripAccents;
  function spec(s) {
    const o = {};
    if (!s || s === '-') return o;
    s.split(';').forEach(p => { const i = p.indexOf('='); if (i < 0) o[p.trim()] = true; else o[p.slice(0, i).trim()] = p.slice(i + 1).trim(); });
    return o;
  }
  RU.spec = spec;
  const VOW = 'аеёиоуыэюя';
  const isVow = c => !!c && VOW.includes(c.toLowerCase());
  const VEL = /[гкх]$/, HUSH = /[жшщч]$/, HUSHC = /[жшщчц]$/;
  RU.isVow = isVow;

  /* ---------- 格 ---------- */
  const CASES = ['Nom', 'Gen', 'Dat', 'Acc', 'Ins', 'Prep'];
  const CASE_ZH = { Nom: '主格', Gen: '屬格', Dat: '與格', Acc: '受格', Ins: '工具格', Prep: '前置格' };
  const CASE_RU = { Nom: 'Им.', Gen: 'Род.', Dat: 'Дат.', Acc: 'Вин.', Ins: 'Твор.', Prep: 'Пред.' };
  const CASE_Q = { Nom: 'кто? что?', Gen: 'кого? чего?', Dat: 'кому? чему?', Acc: 'кого? что?', Ins: 'кем? чем?', Prep: 'о ком? о чём?' };
  RU.CASES = CASES; RU.CASE_ZH = CASE_ZH; RU.CASE_RU = CASE_RU; RU.CASE_Q = CASE_Q;
  RU.GENDER = { m: ['陽性', '陽'], f: ['陰性', '陰'], n: ['中性', '中'], pl: ['只有複數', '複'] };
  RU.G_ZH = { m: '陽性', f: '陰性', n: '中性', pl: '複數' };
  // 介係詞接哪些格
  RU.PREP_CASE = {
    'в': ['Prep', 'Acc'], 'во': ['Prep', 'Acc'], 'на': ['Prep', 'Acc'], 'о': ['Prep'], 'об': ['Prep'], 'обо': ['Prep'], 'при': ['Prep'],
    'у': ['Gen'], 'из': ['Gen'], 'от': ['Gen'], 'до': ['Gen'], 'без': ['Gen'], 'для': ['Gen'], 'после': ['Gen'], 'около': ['Gen'], 'кроме': ['Gen'], 'напротив': ['Gen'], 'из-за': ['Gen'], 'вместо': ['Gen'],
    'к': ['Dat'], 'ко': ['Dat'], 'по': ['Dat'],
    'с': ['Ins', 'Gen'], 'со': ['Ins', 'Gen'], 'за': ['Ins', 'Acc'], 'под': ['Ins', 'Acc'], 'перед': ['Ins'], 'над': ['Ins'], 'между': ['Ins'], 'рядом с': ['Ins'],
    'через': ['Acc'], 'про': ['Acc']
  };

  /* ---------- 名詞 ---------- */
  function nounKind(w, g) {
    const last = w.slice(-1);
    if (/мя$/.test(w) && g === 'n') return 'MYA';
    if (g === 'n') {
      if (last === 'о') return 'O';
      if (/ие$/.test(w)) return 'IE';
      if (last === 'е') return HUSHC.test(w.slice(0, -1)) ? 'EH' : 'E';
      return 'O';
    }
    if (last === 'а') return 'A';
    if (last === 'я') return /ия$/.test(w) ? 'IY' : 'Y';
    if (last === 'ь') return g === 'f' ? 'F' : 'S';
    if (last === 'й') return 'J';
    return 'C';
  }
  RU.nounKind = nounKind;
  // 單數詞幹（去掉詞尾）
  function nounStem(w, kind) {
    if (kind === 'C') return w;
    return w.slice(0, -1);
  }
  function plObl(nomPl) {
    const ps = nomPl.slice(0, -1), last = nomPl.slice(-1);
    const soft = last === 'я' || (last === 'и' && !/[гкхжшщчц]$/.test(ps));
    return soft ? [ps + 'ям', ps + 'ями', ps + 'ях'] : [ps + 'ам', ps + 'ами', ps + 'ах'];
  }
  // 回傳 { sg: [6], pl: [6] 或 null, anim, kind, ... }；受格已經依有生命／無生命算好
  function nounDecl(e) {
    const w = plain(e[0]), g = e[2], sp = spec(e[3]);
    const anim = !!sp.anim;
    if (sp.indecl) { const f = CASES.map(() => w); return { sg: g === 'pl' ? null : f, pl: g === 'pl' || !sp.nopl ? f.slice() : null, anim, kind: 'X', indecl: true }; }
    if (sp.adj) {
      const a = adjDecl(w, g === 'pl' ? 'pl' : g);
      const pick = (k, an) => a[k].map((x, i) => i === 3 && Array.isArray(x) ? x[an ? 1 : 0] : x);
      return { sg: g === 'pl' ? null : pick(g, anim), pl: g === 'pl' || !sp.nopl ? pick('pl', anim) : null, anim, kind: 'ADJ' };
    }
    let sg = null, nomPl, gpl, kind = g === 'pl' ? 'PL' : nounKind(w, g);
    if (g !== 'pl') {
      if (sp.sg) sg = sp.sg.split(',');
      else {
        let st = nounStem(w, kind), k = kind;
        if (sp.gen) { // 母音脫落、詞幹改變：отец → отца、день → дня
          st = sp.gen.slice(0, -1);
          if (kind === 'C' || kind === 'S' || kind === 'J') k = /я$/.test(sp.gen) ? 'S' : 'C';
        }
        const es = !!sp.es, hc = HUSHC.test(st), velH = /[гкхжшщч]$/.test(st);
        let f;
        switch (k) {
          case 'C': f = [w, st + 'а', st + 'у', null, st + (hc && !es ? 'ем' : 'ом'), st + 'е']; break;
          case 'S': f = [w, st + 'я', st + 'ю', null, st + (es ? 'ём' : 'ем'), st + 'е']; break;
          case 'J': f = [w, st + 'я', st + 'ю', null, st + (es ? 'ём' : 'ем'), st + (/и$/.test(st) ? 'и' : 'е')]; break;
          case 'A': f = [w, st + (velH ? 'и' : 'ы'), st + 'е', st + 'у', st + (hc && !es ? 'ей' : 'ой'), st + 'е']; break;
          case 'Y': f = [w, st + 'и', st + 'е', st + 'ю', st + (es ? 'ёй' : 'ей'), st + 'е']; break;
          case 'IY': f = [w, st + 'и', st + 'и', st + 'ю', st + 'ей', st + 'и']; break;
          case 'F': { const ob = sp.gen ? sp.gen : st + 'и'; f = [w, ob, ob, w, w + 'ю', ob]; break; }
          case 'O': f = [w, st + 'а', st + 'у', w, st + 'ом', st + 'е']; break;
          case 'E': f = [w, st + 'я', st + 'ю', w, st + 'ем', st + 'е']; break;
          case 'IE': f = [w, st + 'я', st + 'ю', w, st + 'ем', st + 'и']; break;
          case 'EH': f = [w, st + 'а', st + 'у', w, st + 'ем', st + 'е']; break;
          default: f = CASES.map(() => w);
        }
        if (f[3] === null) f[3] = anim ? f[1] : w;
        sg = f;
      }
      if (sp.ins) sg[4] = sp.ins;
      if (sp.prep) sg[5] = sp.prep;
      if (sp.dat) sg[2] = sp.dat;
      if (sp.acc) sg[3] = sp.acc;
    }
    let pl = null;
    if (!(sp.nopl || sp.pl === '-')) {
      if (sp.plf) pl = sp.plf.split(',');
      else {
        let st = g === 'pl' ? '' : nounStem(w, kind), k = kind;
        if (sp.gen && (kind === 'C' || kind === 'S' || kind === 'J')) { st = sp.gen.slice(0, -1); k = /я$/.test(sp.gen) ? 'S' : 'C'; }
        const velH = /[гкхжшщч]$/.test(st);
        if (g === 'pl') nomPl = w;
        else if (sp.pl) nomPl = sp.pl;
        else nomPl = { C: st + (velH ? 'и' : 'ы'), S: st + 'и', J: st + 'и', A: st + (velH ? 'и' : 'ы'), Y: st + 'и', IY: st + 'и', F: st + 'и', O: st + 'а', E: st + 'я', IE: st + 'я', EH: st + 'а' }[k] || w;
        if (sp.gpl) gpl = sp.gpl;
        else if (g === 'pl') gpl = '';
        else {
          const ces = /ц$/.test(st) ? (sp.es ? 'ов' : 'ев') : 'ов';
          gpl = {
            C: st + (HUSH.test(st) ? 'ей' : ces), S: st + 'ей', J: st + 'ев', A: st, Y: st + 'ь', IY: st + 'й', F: (sp.gen ? sp.gen.slice(0, -1) : st) + 'ей',
            O: st, E: st + 'ей', IE: st + 'й', EH: st
          }[k];
        }
        const [d, i, p] = plObl(nomPl);
        pl = [nomPl, gpl, d, anim ? gpl : nomPl, sp.ipl || i, p];
      }
    }
    return { sg, pl, anim, kind, loc: sp.loc || '', gen: sp.gen || '' };
  }
  RU.nounDecl = nounDecl;
  function nounForms(e) {
    const d = nounDecl(e);
    return { sg: e[0], pl: d.pl && e[2] !== 'pl' ? d.pl[0] : '', plOnly: e[2] === 'pl', plGender: e[2], indef: '' };
  }
  RU.nounForms = nounForms;

  /* ---------- 形容詞（也用在照形容詞變化的名詞、限定詞、疑問詞） ---------- */
  const H = { m: ['ый', 'ого', 'ому', '', 'ым', 'ом'], n: ['ое', 'ого', 'ому', 'ое', 'ым', 'ом'], f: ['ая', 'ой', 'ой', 'ую', 'ой', 'ой'], pl: ['ые', 'ых', 'ым', '', 'ыми', 'ых'] };
  const SFT = { m: ['ий', 'его', 'ему', '', 'им', 'ем'], n: ['ее', 'его', 'ему', 'ее', 'им', 'ем'], f: ['яя', 'ей', 'ей', 'юю', 'ей', 'ей'], pl: ['ие', 'их', 'им', '', 'ими', 'их'] };
  function adjBase(w) {
    const end = w.slice(-2), st = w.slice(0, -2);
    if (end === 'ой') return { st, soft: false, stressed: true };
    if (end === 'ый' || end === 'ая' || end === 'ое' || end === 'ые') return { st, soft: false, stressed: false };
    if (end === 'ий' || end === 'ее' || end === 'ие' || end === 'яя') return { st, soft: !VEL.test(st) && !HUSH.test(st), stressed: false };
    return null;
  }
  RU.adjBase = adjBase;
  // 回傳 { m: [6], n: [6], f: [6], pl: [6] }；陽性和複數的受格是 [無生命, 有生命]
  function adjDecl(w, g, stressedHint) {
    const b = adjBase(w); if (!b) return null;
    const stressed = b.stressed || !!stressedHint;
    const out = {};
    for (const k of ['m', 'n', 'f', 'pl']) {
      out[k] = (b.soft ? SFT : H)[k].map(x => {
        if (!x) return x;
        if (b.soft) return b.st + x;
        let y = x;
        if ((VEL.test(b.st) || HUSH.test(b.st)) && y[0] === 'ы') y = 'и' + y.slice(1);
        if (HUSH.test(b.st) && !stressed && y[0] === 'о') y = 'е' + y.slice(1);
        if (k === 'm' && y === x && x === 'ый' && stressed) y = 'ой';
        return b.st + y;
      });
      if (k === 'm' && b.stressed) out.m[0] = b.st + 'ой';
    }
    if (!b.soft && (VEL.test(b.st) || HUSH.test(b.st)) && !b.stressed) out.m[0] = b.st + 'ий';
    out.m[3] = [out.m[0], out.m[1]];
    out.pl[3] = [out.pl[0], out.pl[1]];
    return out;
  }
  RU.adjDecl = adjDecl;
  function adjInfo(e) {
    const w = plain(e[0]), sp = spec(e[3]);
    const short = sp.short ? sp.short.split(',') : null;
    if (sp.pred) return { w, decl: null, short, cmp: '', pred: true };
    const decl = adjDecl(w, 'm');
    let cmp = '';
    if (!sp.nocmp && decl) cmp = sp.cmp || (/[гкхжшщчц]$/.test(adjBase(w).st) || adjBase(w).soft ? '' : adjBase(w).st + 'ее');
    return { w, decl, short, cmp, pred: false };
  }
  RU.adjInfo = adjInfo;
  // 單字卡上的一行：陽、陰、中、複的主格
  function adjForms(e) {
    const a = adjInfo(e);
    if (a.pred) return a.short || [a.w];
    return [a.decl.m[0], a.decl.f[0], a.decl.n[0], a.decl.pl[0]];
  }
  RU.adjForms = adjForms;

  /* ---------- 代名詞、限定詞 ---------- */
  // 人稱代名詞：[主格, 屬格, 與格, 受格, 工具格, 前置格]；有兩個形的是 [一般, 介係詞後]
  const PRON = {
    'я': ['я', 'меня', 'мне', 'меня', 'мной', 'мне'],
    'ты': ['ты', 'тебя', 'тебе', 'тебя', 'тобой', 'тебе'],
    'он': ['он', ['его', 'него'], ['ему', 'нему'], ['его', 'него'], ['им', 'ним'], 'нём'],
    'она': ['она', ['её', 'неё'], ['ей', 'ней'], ['её', 'неё'], ['ей', 'ней'], 'ней'],
    'оно': ['оно', ['его', 'него'], ['ему', 'нему'], ['его', 'него'], ['им', 'ним'], 'нём'],
    'мы': ['мы', 'нас', 'нам', 'нас', 'нами', 'нас'],
    'вы': ['вы', 'вас', 'вам', 'вас', 'вами', 'вас'],
    'они': ['они', ['их', 'них'], ['им', 'ним'], ['их', 'них'], ['ими', 'ними'], 'них'],
    'кто': ['кто', 'кого', 'кому', 'кого', 'кем', 'ком'],
    'что': ['что', 'чего', 'чему', 'что', 'чем', 'чём'],
    'себя': ['', 'себя', 'себе', 'себя', 'собой', 'себе'],
    'никто': ['никто', 'никого', 'никому', 'никого', 'никем', 'ни о ком'],
    'ничто': ['ничто', 'ничего', 'ничему', 'ничего', 'ничем', 'ни о чём'],
    'Вы': ['Вы', 'Вас', 'Вам', 'Вас', 'Вами', 'Вас']
  };
  RU.PRON = PRON;
  const T6 = (m, n, f, pl) => ({ m: m.split(' '), n: n.split(' '), f: f.split(' '), pl: pl.split(' ') });
  const poss = s => T6(`${s}й ${s}его ${s}ему - ${s}им ${s}ём`, `${s}ё ${s}его ${s}ему ${s}ё ${s}им ${s}ём`, `${s}я ${s}ей ${s}ей ${s}ю ${s}ей ${s}ей`, `${s}и ${s}их ${s}им - ${s}ими ${s}их`);
  const possN = s => T6(`${s} ${s}его ${s}ему - ${s}им ${s}ем`, `${s}е ${s}его ${s}ему ${s}е ${s}им ${s}ем`, `${s}а ${s}ей ${s}ей ${s}у ${s}ей ${s}ей`, `${s}и ${s}их ${s}им - ${s}ими ${s}их`);
  const DET = {
    'мой': poss('мо'), 'твой': poss('тво'), 'свой': poss('сво'), 'наш': possN('наш'), 'ваш': possN('ваш'), 'Ваш': possN('Ваш'),
    'этот': T6('этот этого этому - этим этом', 'это этого этому это этим этом', 'эта этой этой эту этой этой', 'эти этих этим - этими этих'),
    'тот': T6('тот того тому - тем том', 'то того тому то тем том', 'та той той ту той той', 'те тех тем - теми тех'),
    'весь': T6('весь всего всему - всем всём', 'всё всего всему всё всем всём', 'вся всей всей всю всей всей', 'все всех всем - всеми всех'),
    'третий': T6('третий третьего третьему - третьим третьем', 'третье третьего третьему третье третьим третьем', 'третья третьей третьей третью третьей третьей', 'третьи третьих третьим - третьими третьих'),
    'один': T6('один одного одному - одним одном', 'одно одного одному одно одним одном', 'одна одной одной одну одной одной', 'одни одних одним - одними одних'),
    'чей': T6('чей чьего чьему - чьим чьём', 'чьё чьего чьему чьё чьим чьём', 'чья чьей чьей чью чьей чьей', 'чьи чьих чьим - чьими чьих')
  };
  for (const k of Object.keys(DET)) { const t = DET[k]; t.m[3] = [t.m[0], t.m[1]]; t.pl[3] = [t.pl[0], t.pl[1]]; }
  RU.DET = DET;
  // 任何會照形容詞變化的字（形容詞、限定詞、какой、который…），沒有就回傳 null
  function declOf(e) {
    const w = plain(e[0]), sp = spec(e[3]);
    if (DET[w]) return DET[w];
    if (e[1] === 'adj') { const a = adjInfo(e); return a.decl; }
    if (sp.adj && e[1] !== 'n') return adjDecl(w, 'm');
    return null;
  }
  RU.declOf = declOf;

  /* ---------- 動詞 ---------- */
  const PERSONS = ['я', 'ты', 'он/она', 'мы', 'вы', 'они'];
  RU.PERSONS = PERSONS;
  const isRefl = l => /(ся|сь)$/.test(plain(l));
  RU.isRefl = isRefl;
  const addRefl = f => f + (isVow(f.slice(-1)) ? 'сь' : 'ся');
  RU.addRefl = addRefl;
  let SPEC = null;
  function specMap() {
    if (SPEC && SPEC.n === (RU.W || []).length) return SPEC.m;
    const m = {};
    (RU.W || []).forEach(e => { if (/^v/.test(e[1])) m[plain(e[0])] = e[3]; });
    SPEC = { n: (RU.W || []).length, m };
    return m;
  }
  // 沒寫 p= 時，從原形推現在式的 я、ты
  function defaultP(base, type) {
    if (type === 'v2') {
      const st = base.replace(/(ить|еть|ать|ять)$/, '');
      return [st + (HUSH.test(st) ? 'у' : 'ю'), st + 'ишь'];
    }
    // -давать、-ставать、-знавать：даю、встаю、узнаю（плавать 不是這一類）
    if (/(да|ста|зна)вать$/.test(base)) { const st = base.slice(0, -4); return [st + 'ю', st + 'ёшь']; }
    // -овать、ц／ж／ш 後的 -евать：рисовать → рисую、танцевать → танцую（одевать 不是這一類）
    if (/овать$/.test(base) || /[цжшчщ]евать$/.test(base)) { const st = base.replace(/(о|е)вать$/, ''); return [st + 'ую', st + 'уешь']; }
    if (/(ать|ять|еть)$/.test(base)) { const st = base.slice(0, -2); return [st + 'ю', st + 'ешь']; }
    return null;
  }
  RU.defaultP = defaultP;
  function presFromP(ya, ty) {
    const conj2 = /ишь$/.test(ty);
    const v = conj2 ? 'и' : ty.slice(-3, -2); // е 或 ё
    const tyStem = ty.slice(0, -3);
    const yaStem = ya.slice(0, -1);
    if (conj2) return [ya, ty, tyStem + 'ит', tyStem + 'им', tyStem + 'ите', tyStem + (HUSH.test(tyStem) ? 'ат' : 'ят')];
    return [ya, ty, tyStem + v + 'т', tyStem + v + 'м', tyStem + v + 'те', yaStem + (ya.slice(-1) === 'ю' ? 'ют' : 'ут')];
  }
  RU.presFromP = presFromP;
  function conjugate(lemma, type) {
    const full = plain(lemma);
    const refl = isRefl(full);
    const base = refl ? full.slice(0, -2) : full;
    const sp = spec(specMap()[full]);
    const pf = !!sp.pf;
    let present;
    if (sp.pres) present = sp.pres.split(' ');
    else {
      const p = sp.p ? sp.p.split(',') : defaultP(base, type);
      present = p ? presFromP(p[0], p[1]) : [];
    }
    let past;
    if (sp.past) past = sp.past.split(',');
    else { const st = base.replace(/ть$/, ''); past = [st + 'л', st + 'ла', st + 'ло', st + 'ли']; }
    let imp = null;
    if (!sp.noimp && present.length) {
      if (sp.imp) imp = sp.imp.split(',');
      else {
        let t;
        if (/(да|ста|зна)вать$/.test(base)) t = base.slice(0, -2) + 'й';
        else {
          const st = present[5].replace(/(ют|ут|ят|ат)$/, '');
          t = isVow(st.slice(-1)) ? st + 'й' : st + 'и';
        }
        imp = [t, t + 'те'];
      }
    }
    if (refl) {
      present = present.map(addRefl);
      past = past.map(addRefl);
      if (imp) imp = imp.map(addRefl);
    }
    const presLabel = sp.fut || pf ? '將來式' + (pf ? '（完成體）' : '') : '現在式';
    return {
      lemma, type, cls: type, refl, pf, pair: sp.pair || '', motion: sp.motion || '', inf: full,
      present, presentFull: present, passato: past, past, imperative: imp,
      presLabel, presTab: sp.fut || pf ? '將來式' : '現在式', note: sp.note || '', fut: !!sp.fut
    };
  }
  RU.conjugate = conjugate;

  /* ---------- 斷詞 ---------- */
  const L = 'А-Яа-яЁё́';
  const TOK_RE = new RegExp('[' + L + ']+(?:-[' + L + ']+)*|[^' + L + ']+', 'g');
  const IS_W = new RegExp('^[' + L + ']');
  function tokenize(sentence) {
    const out = []; const s = String(sentence).replace(/[’‘]/g, "'"); let m; TOK_RE.lastIndex = 0;
    while ((m = TOK_RE.exec(s))) out.push({ t: m[0], w: IS_W.test(m[0]) });
    return out;
  }
  RU.tokenize = tokenize;
  RU.LETTERS = L;

  /* ---------- 查詢表 ---------- */
  const NUM_LBL = ['單數', '複數'];
  function caseLabels(forms, prefix) {
    // forms：[6]，回傳 Map 形 → 標籤陣列
    const m = new Map();
    forms.forEach((f, i) => {
      if (!f) return;
      [].concat(f).forEach((x, j) => {
        if (!x) return;
        const extra = Array.isArray(f) && f.length === 2 && i === 3 ? (j ? '（有生命）' : '（無生命）') : '';
        const lbl = prefix + CASE_ZH[CASES[i]] + extra;
        if (!m.has(x)) m.set(x, []);
        if (!m.get(x).includes(lbl)) m.get(x).push(lbl);
      });
    });
    return m;
  }
  function buildLookup(words, extra) {
    const map = new Map();
    const add = (form, lemma, desc, idx) => {
      if (!form || form === '-') return;
      const k = norm(form).toLowerCase();
      if (!map.has(k)) map.set(k, []);
      const arr = map.get(k);
      if (!arr.some(e => e.lemma === lemma && e.desc === desc)) arr.push({ lemma, desc, idx });
    };
    const addMap = (mm, lemma, idx) => mm.forEach((lbls, f) => add(f, lemma, lbls.join('、'), idx));
    words.forEach((e, idx) => {
      const [w, pos, , other] = e;
      const pw = plain(w);
      if (pos === 'expr' || (/ /.test(pw) && !/^v/.test(pos))) {
        pw.split(' ').forEach(x => { const k = norm(x).toLowerCase(); if (!map.has(k)) add(x, w, '「' + pw + '」的一部分', idx); });
        if (pos === 'expr') return;
      }
      if (pos === 'n') {
        const d = nounDecl(e);
        const all = new Map();
        if (d.sg) caseLabels(d.sg, d.indecl ? '' : '單數').forEach((v, k) => all.set(k, (all.get(k) || []).concat(v)));
        if (d.pl && !d.indecl) caseLabels(d.pl, '複數').forEach((v, k) => all.set(k, (all.get(k) || []).concat(v)));
        if (d.indecl) { add(pw, w, '不變化（各格同形）', idx); return; }
        all.forEach((lbls, f) => add(f, w, lbls.join('、'), idx));
        if (d.loc) add(d.loc, w, '單數前置格（в／на 後面表示地點：' + d.loc + '）', idx);
      } else if (pos === 'adj') {
        const a = adjInfo(e);
        if (a.decl) {
          add(pw, w, '原形（陽性單數主格）', idx);
          ['m', 'n', 'f', 'pl'].forEach(g => addMap(caseLabels(a.decl[g], { m: '陽性', n: '中性', f: '陰性', pl: '複數' }[g]), w, idx));
        }
        if (a.short) a.short.forEach((x, i) => add(x, w, '短尾形 ' + ['陽性', '陰性', '中性', '複數'][i], idx));
        if (a.cmp) add(a.cmp, w, '比較級', idx);
      } else if (/^v/.test(pos)) {
        const c = conjugate(w, pos);
        add(pw, w, '原形', idx);
        const pl = c.pf ? '將來式（完成體）' : c.fut ? '將來式' : '現在式';
        c.present.forEach((f, i) => add(f, w, pl + ' ' + PERSONS[i], idx));
        c.past.forEach((f, i) => add(f, w, '過去式 ' + ['陽性', '陰性', '中性', '複數'][i], idx));
        if (c.imperative) c.imperative.forEach((f, i) => add(f, w, '命令式 ' + ['ты', 'вы'][i], idx));
      } else {
        const t = PRON[pw] || null;
        const dt = declOf(e);
        if (t) {
          t.forEach((f, i) => {
            if (!f) return;
            [].concat(f).forEach((x, j) => add(x, w, (i ? CASE_ZH[CASES[i]] : '主格') + (Array.isArray(f) && j ? '（介係詞後）' : ''), idx));
          });
          if (/ /.test(t[5])) add(t[5].split(' ').pop(), w, '前置格', idx);
        } else if (dt) {
          ['m', 'n', 'f', 'pl'].forEach(g => addMap(caseLabels(dt[g], { m: '陽性', n: '中性', f: '陰性', pl: '複數' }[g]), w, idx));
        } else add(pw, w, '', idx);
        if (other && other !== '-' && !/=/.test(other)) other.split('/').forEach(x => add(x, w, '', idx));
      }
    });
    if (extra) for (const k of Object.keys(extra)) add(k, extra[k][0], extra[k][1], -1);
    return map;
  }
  RU.buildLookup = buildLookup;

  // 答案比對：不分大小寫，不管重音符號；ё 寫成 е 也算對（俄文平常就這樣寫）
  // 跟俄文字母長得一樣的拉丁字母（a e o p c x y k m t…），比對答案時當成俄文
  const HOMO = { a: 'а', e: 'е', o: 'о', p: 'р', c: 'с', x: 'х', y: 'у', k: 'к', m: 'м', t: 'т', b: 'в', h: 'н' };
  const deLat = s => s.replace(/[aeopcxykmtbh]/gi, ch => { const r = HOMO[ch.toLowerCase()]; return ch === ch.toLowerCase() ? r : r.toUpperCase(); });
  function checkAnswer(input, answer) {
    input = deLat(plain(input));
    const a = String(input).trim().replace(/\s+/g, ' ').replace(/[?!.,]$/g, '');
    if (!a) return 'wrong';
    return fold(a) === fold(answer) ? 'ok' : 'wrong';
  }
  RU.checkAnswer = checkAnswer;

  /* ---------- 單字頁的變化表（給 App 用） ---------- */
  const lbl = c => CASE_ZH[c] + ' ' + CASE_RU[c];
  const cell = x => Array.isArray(x) ? (x[0] === x[1] ? x[0] : x[0] + '／' + x[1]) : (x || '—');
  RU.formsTable = function (e) {
    const pw = plain(e[0]);
    if (e[1] === 'n') {
      const d = nounDecl(e);
      if (d.indecl) return { rows: [['各格', pw]], note: '外來語，不變化：每一格都是 ' + pw + '（' + RU.G_ZH[e[2]] + '）。' };
      const notes = [];
      if (e[2] === 'pl') notes.push('這個字只有複數形。');
      else if (!d.pl) notes.push('這個字通常不用複數。');
      if (d.anim) notes.push('有生命名詞：' + (e[2] === 'm' && d.sg ? '單數和' : '') + '複數的受格和屬格一樣。');
      if (d.gen && d.sg && d.gen !== d.sg[0] + 'а') notes.push('變格時詞幹會變：' + pw + ' → ' + d.gen + '。');
      if (d.loc) notes.push('在 в／на 後面表示地點時用 ' + d.loc + '（в／на ' + d.loc + '）。');
      if (/ь$/.test(pw) && e[2] !== 'pl') notes.push('-ь 結尾，這個字是' + RU.G_ZH[e[2]] + '。');
      const rows = CASES.map((c, i) => e[2] === 'pl' ? [lbl(c), d.pl[i]] : [lbl(c), d.sg[i], d.pl ? d.pl[i] : '—']);
      return { head: e[2] === 'pl' ? ['', '複數'] : ['', '單數', '複數'], rows, note: notes.join('') };
    }
    const dt = e[1] === 'adj' ? (adjInfo(e).pred ? null : adjInfo(e).decl) : (e[1] !== 'n' ? declOf(e) : null);
    if (e[1] === 'adj' && adjInfo(e).pred) {
      const a = adjInfo(e);
      return { head: ['短尾形', ''], rows: [['陽性', a.short[0]], ['陰性', a.short[1]], ['中性', a.short[2]], ['複數', a.short[3]]], note: '這個字只用短尾形，放在主詞後面（Я рад.／Она рада.）。' };
    }
    if (dt) {
      // 手機寬度放不下五欄：分成「陽性、中性」和「陰性、複數」兩張表
      const rows = CASES.map((c, i) => [CASE_ZH[c], cell(dt.m[i]), cell(dt.n[i])]);
      const rows2 = CASES.map((c, i) => [CASE_ZH[c], cell(dt.f[i]), cell(dt.pl[i])]);
      const t = { head: ['', '陽性', '中性'], rows, more: { head: ['', '陰性', '複數'], rows: rows2 }, note: '受格寫兩個形的：前面用在東西，後面用在人或動物（跟屬格一樣）。' };
      if (e[1] === 'adj') {
        const a = adjInfo(e), more = [];
        if (a.cmp) more.push(['比較級', a.cmp]);
        more.push(['最高級', 'самый ' + pw]);
        if (a.short) more.push(['短尾形', a.short.join('、')]);
        t.more.more = { head: ['', ''], rows: more };
      }
      return t;
    }
    const pt = PRON[pw];
    if (pt) {
      const rows = CASES.map((c, i) => [lbl(c), pt[i] ? (Array.isArray(pt[i]) ? pt[i][0] + '／' + pt[i][1] : pt[i]) : '—']);
      return { rows, note: pw === 'себя' ? 'себя 沒有主格，指回句子的主詞（自己）。' : /^(он|она|оно|они)$/.test(pw) ? '寫兩個形的，後面那個用在介係詞後面（у него、с ней、о них）。前置格一定跟著介係詞。' : '' };
    }
    return null;
  };
})(typeof window !== 'undefined' ? window : globalThis);
