/* 俄文文法關卡：由淺到深，後面的關卡會用到前面學過的東西 */
RU.GX_PATH = [
  ['開口說', '不用變化就能說的句子：打招呼、「這是…」、問問題', ['greet', 'polite', 'no-be', 'eto', 'questions']],
  ['名詞的基本', '先學會看字尾分性別，形容詞和「我的」都要跟著性別變', ['noun-gender', 'noun-plural', 'spelling', 'poss', 'adj-agree']],
  ['動詞現在式', '動詞跟著「誰」換詞尾，加上否定和連接詞就能說完整句子', ['pres-1', 'pres-2', 'negation', 'conj', 'adverb', 'languages']],
  ['格入門：在哪裡', '第一個要變的格：前置格，「在哪裡」「關於什麼」', ['cases', 'prep-loc', 'prep-o', 'where', 'pron-cases']],
  ['受格：做什麼、去哪', '動作的對象和要去的地方，字尾要改', ['acc', 'mutation', 'animate', 'acc-dir']],
  ['有和沒有', '「我有」「沒有」「…的」，學會屬格', ['u-menya', 'net', 'gen-of', 'poss-inv', 'gen-preps']],
  ['數量和時間', '數字後面的名詞怎麼變，幾點、星期、月份', ['numbers', 'quantity', 'clock', 'days', 'months']],
  ['與格：給誰、對誰', '「給誰」「我喜歡」「我覺得冷」「幾歲」都用與格', ['dat', 'nravitsya', 'impers', 'modal-pred', 'age']],
  ['工具格和更多代名詞', '「和…一起」「用…」，還有形容詞的格、這個那個、自己的', ['ins-with', 'ins', 'adj-case', 'etot', 'kakoj', 'ves', 'svoj']],
  ['過去和將來', '過去式、將來式，還有俄文最重要的「體」', ['refl', 'past', 'future', 'aspect']],
  ['去哪裡、想做什麼', '走路還是坐車、想要／能夠、請人做事', ['motion', 'modal', 'imp', 'davaj']],
  ['長句子', '把兩個句子接起來：因為、所以、我知道…，還有比較', ['because', 'clause', 'compar']]
];
