/* 建置語言頁：node build.js <App 根目錄> [語言代碼…]
   - 從根目錄的 index.html（日文頁）抽出樣式和 Firebase 設定，讓每一頁外觀、帳號完全一樣
   - 每個語言的資料放在 <代碼>/ 資料夾，輸出 <根目錄>/<代碼>.html */
'use strict';
const fs = require('fs');
const path = require('path');
const ROOT = path.resolve(process.argv[2] || '../n5work');
const ONLY = process.argv.slice(3);
const S = p => fs.readFileSync(path.join(__dirname, p), 'utf8');
const ja = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
const sm = ja.match(/<style>\s*(\/\* 版面[\s\S]*?)<\/style>/);
if (!sm) throw new Error('在日文頁找不到主要樣式');
const fm = ja.match(/window\.N5_FIREBASE=\{[^}]*\};/);
if (!fm) throw new Error('在日文頁找不到 Firebase 設定');

// ---- 背景插畫：和日文頁的富士山同一組顏色、同一種扁平幾何畫法 ----
const LIGHT = { sun: '#f7e6cc', cloud: '#e6ebf3', bird: '#cdd5e2', h1: '#e6ebf3', h2: '#d8e0ec', h3: '#cfd8e6', tree: '#c3cede', town: '#dde4ef', roof: '#d3dbe8', road: '#eef3fa', white: '#f2f5fa' };
const DARK = { sun: '#252d3a', cloud: '#161c26', bird: '#2a3342', h1: '#141a23', h2: '#18202b', h3: '#1c2531', tree: '#111720', town: '#1a212c', roof: '#202836', road: '#10151d', white: '#222a37' };
const sky = c => `<circle cx='330' cy='150' r='46' fill='${c.sun}'/>` +
  `<rect x='40' y='120' width='90' height='12' rx='6' fill='${c.cloud}'/><rect x='70' y='140' width='60' height='12' rx='6' fill='${c.cloud}'/>` +
  `<rect x='250' y='250' width='110' height='12' rx='6' fill='${c.cloud}'/><rect x='290' y='270' width='70' height='12' rx='6' fill='${c.cloud}'/>` +
  `<path d='M80 210 q6 -6 12 0 q6 -6 12 0' fill='none' stroke='${c.bird}' stroke-width='2' stroke-linecap='round'/><path d='M110 232 q6 -6 12 0 q6 -6 12 0' fill='none' stroke='${c.bird}' stroke-width='2' stroke-linecap='round'/>`;
const cypress = (c, x, base, h, w) => `<path d='M${x} ${base} q${w * .5} ${-h * .55} ${w * .5} ${-h} q0 ${h * .45} ${w * .5} ${h}z' fill='${c.tree}'/>`;
// 義大利：托斯卡尼山丘、絲柏、塔樓小鎮
function sceneIT(c) {
  return sky(c) +
    `<path d='M-10 640 C 60 585 130 585 200 610 C 260 630 320 580 430 600 L430 910 L-10 910Z' fill='${c.h1}'/>` +
    `<g fill='${c.town}'><rect x='238' y='548' width='9' height='44'/><path d='M236 548 l6.5 -10 l6.5 10z'/><rect x='252' y='572' width='18' height='22'/><rect x='272' y='566' width='14' height='28'/><rect x='288' y='576' width='20' height='18'/><rect x='218' y='578' width='16' height='16'/><path d='M200 594 a16 16 0 0 1 32 0z'/></g>` +
    `<g fill='${c.roof}'><path d='M251 572 l10 -7 l10 7z'/><path d='M271 566 l8 -6 l8 6z'/><path d='M287 576 l11 -6 l11 6z'/><path d='M217 578 l9 -6 l9 6z'/></g>` +
    `<path d='M-10 720 C 70 670 150 690 220 705 C 290 720 350 670 430 685 L430 910 L-10 910Z' fill='${c.h2}'/>` +
    cypress(c, 40, 706, 64, 16) + cypress(c, 62, 708, 46, 13) + cypress(c, 338, 690, 70, 16) + cypress(c, 360, 694, 50, 13) +
    `<path d='M-10 800 C 60 760 150 770 230 785 C 320 802 370 760 430 768 L430 910 L-10 910Z' fill='${c.h3}'/>` +
    cypress(c, 286, 790, 80, 18) + cypress(c, 310, 792, 58, 15) + cypress(c, 330, 794, 40, 12) +
    `<path d='M150 900 C 175 870, 230 860, 222 835 S 255 800, 300 790 L 308 795 C 270 806, 240 820, 245 840 S 200 875, 190 900 Z' fill='${c.road}'/>`;
}
// 西班牙：拉曼查的風車、平頂台地、橄欖樹
const mill = (c, x, base, s) => {
  const w = 22 * s, h = 46 * s, cx = x + w / 2, top = base - h, hub = top + 6 * s, L = 30 * s;
  const blade = (dx, dy) => `<path d='M${cx} ${hub} l${dx} ${dy}' stroke='${c.roof}' stroke-width='${2.2 * s}' stroke-linecap='round'/>`;
  return `<path d='M${x} ${base} L${x + 3 * s} ${top} L${x + w - 3 * s} ${top} L${x + w} ${base}Z' fill='${c.white}'/>` +
    `<path d='M${x + 1 * s} ${top} L${cx} ${top - 12 * s} L${x + w - 1 * s} ${top}Z' fill='${c.roof}'/>` +
    blade(L * .7, -L * .7) + blade(-L * .7, L * .7) + blade(L * .7, L * .7) + blade(-L * .7, -L * .7) +
    `<circle cx='${cx}' cy='${hub}' r='${2.6 * s}' fill='${c.roof}'/>`;
};
const olive = (c, x, base, s) => `<rect x='${x - 1.5 * s}' y='${base - 10 * s}' width='${3 * s}' height='${10 * s}' fill='${c.tree}'/><ellipse cx='${x}' cy='${base - 14 * s}' rx='${11 * s}' ry='${7 * s}' fill='${c.tree}'/>`;
function sceneES(c) {
  return sky(c) +
    `<path d='M-10 640 L60 640 L80 610 L190 610 L210 640 L430 630 L430 910 L-10 910Z' fill='${c.h1}'/>` +
    `<path d='M-10 720 C 80 680 170 690 250 700 C 320 708 370 676 430 680 L430 910 L-10 910Z' fill='${c.h2}'/>` +
    mill(c, 240, 692, 1) + mill(c, 292, 686, .85) + mill(c, 336, 682, .7) +
    `<path d='M-10 800 C 70 765 160 775 240 790 C 320 805 370 772 430 776 L430 910 L-10 910Z' fill='${c.h3}'/>` +
    olive(c, 40, 786, 1) + olive(c, 78, 780, .8) + olive(c, 112, 782, .9) + olive(c, 372, 776, .9) +
    `<path d='M150 900 C 175 870, 230 860, 222 835 S 255 800, 300 790 L 308 795 C 270 806, 240 820, 245 840 S 200 875, 190 900 Z' fill='${c.road}'/>`;
}
const SCENES = { it: sceneIT, es: sceneES };
function pat(scene, c) {
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 420 900' preserveAspectRatio='xMidYMax slice'>${scene(c)}</svg>`;
  return 'url("data:image/svg+xml,' + svg.replace(/#/g, '%23').replace(/</g, '%3C').replace(/>/g, '%3E') + '")';
}

// ---- 各語言 ----
const LANGS = {
  it: { files: ['engine.js', 'data1.js', 'data2.js', 'data3.js', 'data4.js', 'data5.js', 'grammar.js', 'quiz.js'] },
  es: { files: ['engine.js', 'data1.js', 'data2.js', 'data3.js', 'data4.js', 'data5.js', 'grammar.js', 'quiz.js'] }
};
for (const code of Object.keys(LANGS)) {
  if (ONLY.length && !ONLY.includes(code)) continue;
  const dir = path.join(__dirname, code);
  if (!fs.existsSync(path.join(dir, 'config.js'))) continue;
  const cfgSrc = fs.readFileSync(path.join(dir, 'config.js'), 'utf8');
  const get = k => (cfgSrc.match(new RegExp(k + ":\\s*'([^']*)'")) || [])[1];
  const light = pat(SCENES[code], LIGHT), dark = pat(SCENES[code], DARK);
  const patCss = `:root{--pat:${light}}\n@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--pat:${dark}}}\n:root[data-theme="dark"]{--pat:${dark}}`;
  const scripts = [cfgSrc].concat(LANGS[code].files.map(f => fs.readFileSync(path.join(dir, f), 'utf8')), [S('lang-app.js')]).join('\n;\n');
  const html = S('lang-template.html')
    .replace(/\{\{NAME\}\}/g, get('name')).replace(/\{\{LEVEL\}\}/g, get('level')).replace(/\{\{GLYPH\}\}/g, get('glyph')).replace(/\{\{CODE\}\}/g, code)
    .replace('/*FIREBASE*/', () => fm[0])
    .replace('/*N5STYLE*/', () => sm[1])
    .replace('/*LANGSTYLE*/', () => S('lang-style.css'))
    .replace('/*PAT*/', () => patCss)
    .replace('/*SCRIPTS*/', () => scripts.replace(/<\/script/gi, '<\\/script'));
  fs.writeFileSync(path.join(ROOT, code + '.html'), html);
  console.log(code + '.html', (html.length / 1024).toFixed(0) + ' KB');
}
