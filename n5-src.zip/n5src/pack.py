"""把資料夾打包成 n5-src.zip：python3 n5src/pack.py <資料夾> <zip 檔>
用 Python 的 zipfile，中文檔名會以 UTF-8 存（解開時不會變亂碼）；檔案順序固定，內容一樣時 zip 也一樣"""
import os, sys, zipfile
src, out = sys.argv[1], sys.argv[2]
names = []
for d, subdirs, files in os.walk(src):
    subdirs.sort()
    for f in sorted(files):
        names.append(os.path.relpath(os.path.join(d, f), src).replace(os.sep, '/'))
with zipfile.ZipFile(out + '.tmp', 'w', zipfile.ZIP_DEFLATED) as z:
    for n in names:
        info = zipfile.ZipInfo(n, date_time=(2026, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o644 << 16
        with open(os.path.join(src, n), 'rb') as fh: z.writestr(info, fh.read())
os.replace(out + '.tmp', out)
print(f'{out}：{len(names)} 個檔案')
