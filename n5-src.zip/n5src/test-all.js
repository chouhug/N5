/* 跑全部測試：node n5src/test-all.js <網站資料夾，例如 n5work>
   五個語言的資料和變化引擎、core.js（作答規則、備份碼）、sync.js（雲端同步），任何一項失敗就回傳錯誤 */
'use strict';
const path = require('path');
const { spawnSync } = require('child_process');
const WORK = path.resolve(process.argv[2] || path.join(__dirname, '../n5work'));
const runs = [
  ...['it', 'es', 'de', 'ru', 'en'].map(l => [l + ' 語言包', [path.join(__dirname, l, 'test.js')]]),
  ['core.js', [path.join(__dirname, 'core-test.js'), WORK]],
  ['sync.js', [path.join(__dirname, 'sync-test.js'), path.join(WORK, 'sync.js')]]
];
let bad = 0;
for (const [name, args] of runs) {
  const r = spawnSync('node', args, { cwd: __dirname, encoding: 'utf8' });
  const last = (r.stdout || '').trim().split('\n').filter(l => !l.startsWith('[sync]')).pop() || '';
  console.log(`${r.status === 0 ? '✓' : '✗'} ${name}：${last}`);
  if (r.status !== 0) { bad++; console.log((r.stdout || '') + (r.stderr || '')); }
}
console.log(bad ? `${bad} 組測試失敗` : '全部測試通過');
process.exit(bad ? 1 : 0);
