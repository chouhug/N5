/* 語言頁（義大利文、西班牙文、德文、俄文…）：放在日文 N5 App 裡
   語言專屬的文字和設定放在 window.LANGCFG，資料和變化引擎放在 window.LX
   - 介面、音效、下拉選單、間隔複習規則都跟日文頁一樣
   - 進度存在同一份 n5:progress（id 以語言代碼開頭，例如 it:、es:），所以 Google 同步、每日目標直接共用
   - 外觀、音效、震動、每輪題數、單字意思語言這些設定和日文頁共用（n5:settings） */
(function () {
'use strict';
const IT = window.LX || window.IT;
const LC = window.LANGCFG;
const LP = LC.id + ':';
// 名詞性別的名稱（德文多一個中性），語言包沒給就用陽／陰
const GEN = IT.GENDER || { m: ['陽性', '陽'], f: ['陰性', '陰'] };
const genOf = g => GEN[g] || GEN.f || ['', ''];
// 英文這類沒有名詞性別的語言：LX.GENDER 給空物件，就不顯示性別
const hasGen = g => !!GEN[g];

// ================= 基本工具 =================
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* 存不了也能用 */ } }
};
function ymd(d = new Date()) {
  const y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, '0'), dd = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${dd}`;
}
function addDays(dateStr, n) { const [y, m, d] = dateStr.split('-').map(Number); return ymd(new Date(y, m - 1, d + n, 12)); }
const today = () => ymd();
const SRS = [1, 3, 7, 14, 30, 60];
const GOAL = 20;
const ICON = {
  play: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M3 9v6h4l5 4V5L7 9H3z"/><path d="M15.5 8.5a5 5 0 0 1 0 7M18 6a8.5 8.5 0 0 1 0 12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
  ok: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7"/></svg>',
  ng: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>',
  sun: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>',
  moon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/></svg>'
};
const playBtn = (text, label, extra = '') => `<button class="play" data-say="${esc(text)}" ${extra}>${ICON.play}${esc(label)}</button>`;
const iconPlay = (text, label) => `<button class="iplay" data-say="${esc(text)}" aria-label="${esc(label)}">${ICON.play}</button>`;

// ================= 資料 =================
const POS_ZH = { n: '名詞', adj: '形容詞', adv: '副詞', prep: '介係詞', art: '冠詞', pron: '代名詞', conj: '連接詞', num: '數字', det: '限定詞', q: '疑問詞', expr: '常用語', 'v-are': '動詞 -are', 'v-ere': '動詞 -ere', 'v-ire': '動詞 -ire', 'v-isc': '動詞 -ire（-isc-）', 'v-irr': '不規則動詞', ...(LC.posZh || {}) };
const isVerbPos = p => /^v/.test(p);
const pgOf = p => isVerbPos(p) ? 'v' : (p === 'n' || p === 'adj' ? p : 'o');
const WORDS = IT.W.map(e => {
  const pos = e[1];
  const title = pos === 'n' ? IT.nounForms(e).sg : e[0];
  return { id: LP + e[0] + '|' + pos, e, word: e[0], title, pos, pg: pgOf(pos), zh: e[4], en: e[5], sent: e[6], sentZh: e[7], ans: e[8], kind: 'w' };
});
const WMAP = Object.fromEntries(WORDS.map(w => [w.id, w]));
const ALL_IDS = WORDS.map(w => w.id);
const LOOK = IT.getLookup();
const idOfEntry = e => LP + e[0] + '|' + e[1];
// 字卡順序：常用語先，再讓名詞、動詞、形容詞、其他輪流出現
const ORDER = (() => {
  const g = { expr: [], n: [], v: [], adj: [], o: [] };
  WORDS.forEach(w => (w.pos === 'expr' ? g.expr : g[w.pg]).push(w));
  const out = g.expr.slice(), lists = [g.n, g.v, g.adj, g.o, g.n, g.v], idx = lists.map(() => 0), used = new Set();
  let added = true;
  while (added) {
    added = false;
    lists.forEach((L, i) => {
      while (idx[i] < L.length && used.has(L[idx[i]].id)) idx[i]++;
      if (idx[i] < L.length) { const w = L[idx[i]++]; used.add(w.id); out.push(w); added = true; }
    });
  }
  return out;
})();

// ================= 進度與設定（和日文頁共用） =================
let S = store.get('n5:progress', null);
if (!S || typeof S !== 'object' || !S.items) S = { items: {}, days: {} };
S.days = S.days || {};
const SET = Object.assign({ vib: 'on', sfx: 'on', round: 20, recent: 'd1', mean: 'zh', theme: 'system', rate: 0.9 }, store.get('n5:settings', {}));
const ISET = Object.assign({ voice: '' }, store.get(LP + 'settings', {}));
const UI = Object.assign({ tab: 'card', pronSec: 'abc', pronMode: 'listen', mcMode: 'it2zh', mcSrc: 'learn', fillSrc: 'learn', cardSrc: 'new', pos: 'all', gramSel: '', gramQ: '' }, store.get(LP + 'ui', {}));
// 每次都重新讀一次共用設定再寫回，避免蓋掉日文頁剛改的值
const saveSet = () => { const cur = store.get('n5:settings', {}); store.set('n5:settings', Object.assign(cur, SET)); };
const saveISet = () => store.set(LP + 'settings', ISET);
const saveUI = () => store.set(LP + 'ui', UI);
const saveLocal = () => store.set('n5:progress', S);
// 別的分頁（日文頁）改了進度時，先合併再寫，不會互相覆蓋
function reloadShared() { const cur = store.get('n5:progress', null); if (cur && cur.items) S = mergeState(S, cur); }

function blankRec() { return { s: 'new', n: 0, w: {}, lv: 0, due: '', st: 0, t: 0 }; }
const getRec = id => S.items[id] || blankRec();
function putRec(id, rec) { reloadShared(); S.items[id] = rec; saveLocal(); Cloud.schedule(); }
function touch(id, patch) {
  const old = getRec(id), now = Date.now();
  const r = Object.assign(JSON.parse(JSON.stringify(old)), patch, { t: now });
  if (patch.s === 'queued' && old.s !== 'queued' && old.s !== 'learned') r.q = now;
  else if (!r.q && (old.s === 'queued' || old.s === 'learned') && old.t) r.q = old.t;
  putRec(id, r);
}
// 和日文頁相同的作答規則：填空答對才算學會；到期複習答對才延長間隔
// 間隔加一點隨機（7 天以上 ±15%），同一天學的字之後才不會全部擠在同一天到期
const spread = n => n < 7 ? n : Math.max(1, n + Math.round((Math.random() * 0.3 - 0.15) * n));
function applyAnswer(rec, mode, correct, source, today, now) {
  rec = JSON.parse(JSON.stringify(rec || blankRec()));
  rec.w = rec.w || {};
  rec.n = (rec.n || 0) + 1;
  rec.t = now;
  // w：1＝錯題（現在還不會）、2＝以前錯過（錯題複習會輪流抽）
  // 答錯 → 錯題；在任何地方答對一次 → 離開錯題，留在錯題複習；錯題複習答錯 → 回到錯題
  const w = rec.w[mode] || 0;
  if (!correct) rec.w[mode] = 1;
  else if (w === 1) rec.w[mode] = 2;
  if (!rec.w[mode]) delete rec.w[mode];
  if (source === 'review') { rec.rv = rec.rv || {}; rec.rv[mode] = now; }   // 上次在錯題複習出現的時間，用來輪流抽
  if (source === 'due') rec.dd = today;                                    // 今天做過到期複習（算每日上限）
  const learn = () => { rec.s = 'learned'; rec.lv = 0; rec.due = addDays(today, SRS[0]); };
  // 學會的字答錯：降兩級（不是直接打回第一級），避免複習量一下子爆掉
  const reset = () => { rec.lv = Math.max(0, (rec.lv || 0) - 2); rec.due = addDays(today, SRS[rec.lv]); };
  if (mode === 'fill') {
    if (correct) {
      if (rec.s === 'learned') {
        if (source === 'due' && rec.due && rec.due <= today) { rec.lv = Math.min((rec.lv || 0) + 1, SRS.length - 1); rec.due = addDays(today, spread(SRS[rec.lv])); }
      } else if (rec.s !== 'excluded') learn();
    } else if (rec.s === 'learned') reset();
  }
  return rec;
}
function bumpDay() {
  reloadShared();
  const d = today();
  S.days[d] = (S.days[d] || 0) + 1;
  const keys = Object.keys(S.days).sort();
  while (keys.length > 90) delete S.days[keys.shift()];
  saveLocal(); renderGoal();
  if (S.days[d] === GOAL) toast(`今天的 ${GOAL} 題完成了！`, true);
}
function record(w, mode, correct, source) {
  reloadShared();
  const old = getRec(w.id), now = Date.now();
  const rec = applyAnswer(old, mode, correct, source, today(), now);
  if (!rec.q && (rec.s === 'queued' || rec.s === 'learned')) rec.q = (old.s === 'queued' || old.s === 'learned') && old.t ? old.t : now;
  S.items[w.id] = rec;
  bumpDay();
  Cloud.schedule();
}
function mergeState(a, b) {
  const out = { items: {}, days: {} };
  const ia = (a && a.items) || {}, ib = (b && b.items) || {};
  for (const id of new Set([...Object.keys(ia), ...Object.keys(ib)])) { const x = ia[id], y = ib[id]; out.items[id] = !x ? y : !y ? x : ((y.t || 0) > (x.t || 0) ? y : x); }
  const da = (a && a.days) || {}, db = (b && b.days) || {};
  for (const d of new Set([...Object.keys(da), ...Object.keys(db)])) out.days[d] = Math.max(da[d] || 0, db[d] || 0);
  return out;
}
function shuffle(a) { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
function pickRound(items, mode, size, randomOnly) {
  if (randomOnly) {
    const last = it => (((getRec(it.id) || {}).rv) || {})[mode] || 0;
    return shuffle(shuffle(items).sort((a, b) => last(a) - last(b)).slice(0, size));
  }
  const scored = items.map(it => { const r = getRec(it.id); return { it, wrong: (r.w && r.w[mode]) ? 0 : 1, n: r.n || 0, rnd: Math.random() }; });
  scored.sort((a, b) => a.wrong - b.wrong || a.n - b.n || a.rnd - b.rnd);
  return shuffle(scored.slice(0, size).map(x => x.it));
}

// ---- 備份碼：和日文頁同一種格式，同一串碼兩邊都能匯入（各自只取自己的字） ----
const PACK_EPOCH = Date.UTC(2026, 0, 1);
const ST2C = { new: 'n', queued: 'q', learned: 'l', excluded: 'x' }, C2ST = { n: 'new', q: 'queued', l: 'learned', x: 'excluded' };
function shortKey(id) { let h = 0x811c9dc5; for (const ch of id) { h ^= ch.codePointAt(0); h = Math.imul(h, 0x01000193) >>> 0; } return (h % 1679616).toString(36).padStart(4, '0'); }
function dayNum(d) { const [y, m, dd] = d.split('-').map(Number); return Math.round((Date.UTC(y, m - 1, dd) - PACK_EPOCH) / 864e5); }
function numDay(n) { const d = new Date(PACK_EPOCH + n * 864e5); return d.getUTCFullYear() + '-' + String(d.getUTCMonth() + 1).padStart(2, '0') + '-' + String(d.getUTCDate()).padStart(2, '0'); }
function packState(st, todayStr) {
  const b36 = n => (n ? Math.max(0, Math.round(n)).toString(36) : '');
  const days = Object.keys(st.days || {}).filter(d => d > addDays(todayStr, -7) && st.days[d] > 0).sort().map(d => b36(dayNum(d)) + ':' + b36(st.days[d])).join(',');
  const recs = [];
  for (const id in st.items || {}) {
    const r = st.items[id]; if (!r) continue;
    const w = r.w || {};
    const blank = (r.s || 'new') === 'new' && !r.n && !w.mc && !w.fill && !w.kana;
    if (blank && !r.t) continue;
    const wc = (w.mc || 0) + 3 * (w.fill || 0) + 9 * (w.kana || 0);
    const f = [b36(r.n), wc ? wc.toString(36) : '', b36(r.lv), r.due ? b36(dayNum(r.due) + 1) : '', b36(r.st), b36((r.t || 0) - PACK_EPOCH > 0 ? ((r.t - PACK_EPOCH) / 6e4) : 0), b36((r.q || 0) - PACK_EPOCH > 0 ? ((r.q - PACK_EPOCH) / 6e4) : 0)];
    while (f.length && f[f.length - 1] === '') f.pop();
    recs.push(shortKey(id) + (ST2C[r.s] || 'n') + f.join(','));
  }
  return 'N5.' + days + '~' + recs.join(';');
}
function unpackState(code, allIds) {
  code = String(code).replace(/\s+/g, '');
  const m = code.match(/^N5\.([^~]*)~(.*)$/);
  if (!m) return null;
  const byKey = {}; for (const id of allIds) byKey[shortKey(id)] = id;
  const p = x => (x ? parseInt(x, 36) : 0);
  const days = {};
  if (m[1]) for (const part of m[1].split(',')) { const [d, n] = part.split(':'); days[numDay(p(d))] = p(n); }
  const items = {};
  if (m[2]) for (const rec of m[2].split(';')) {
    const id = byKey[rec.slice(0, 4)];
    if (!id || !C2ST[rec[4]]) continue;
    const [n, wc, lv, due, st, t, q] = rec.slice(5).split(',');
    const wv = p(wc), w = {};
    if (wv % 3) w.mc = wv % 3; if (Math.floor(wv / 3) % 3) w.fill = Math.floor(wv / 3) % 3;
    items[id] = { s: C2ST[rec[4]], n: p(n), w, lv: p(lv), due: due ? numDay(p(due) - 1) : '', st: p(st), t: t ? PACK_EPOCH + p(t) * 6e4 : 0 };
    if (q) items[id].q = PACK_EPOCH + p(q) * 6e4;
  }
  return { items, days };
}
async function zipCode(code) {
  try {
    if (typeof CompressionStream === 'undefined') return code;
    const buf = await new Response(new Blob([code]).stream().pipeThrough(new CompressionStream('deflate-raw'))).arrayBuffer();
    let bin = ''; const u8 = new Uint8Array(buf);
    for (let i = 0; i < u8.length; i++) bin += String.fromCharCode(u8[i]);
    const z = 'N5Z.' + btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    return z.length < code.length ? z : code;
  } catch (e) { return code; }
}
async function unzipCode(z) {
  if (typeof DecompressionStream === 'undefined') throw new Error('nozip');
  let b = z.slice(4).replace(/-/g, '+').replace(/_/g, '/'); while (b.length % 4) b += '=';
  const bin = atob(b), u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return await new Response(new Blob([u8]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).text();
}

// ================= 語音 =================
const Voice = {
  list: [], ok: 'speechSynthesis' in window,
  GOOD: /natural|neural|premium|enhanced|online|google|siri/i,
  score(v) {
    let s = 0; const n = (v.name + ' ' + v.voiceURI).toLowerCase();
    if (v.lang.replace('_', '-').toLowerCase() === LC.tts.toLowerCase()) s += 10;
    if (this.GOOD.test(n)) s += 40;
    if (/google/.test(n)) s += 30;
    if (LC.voiceNames && LC.voiceNames.test(n)) s += 8;
    if (/compact|espeak/.test(n)) s -= 30;
    return s;
  },
  refresh() { if (this.ok) this.list = speechSynthesis.getVoices().filter(v => v.lang.toLowerCase().startsWith(LC.id)); },
  best() {
    if (!this.list.length) this.refresh();
    if (ISET.voice) { const v = this.list.find(x => x.voiceURI === ISET.voice); if (v) return v; }
    return this.list.slice().sort((a, b) => this.score(b) - this.score(a))[0] || null;
  },
  speak(text, rate) {
    if (!this.ok) { toast('這個瀏覽器不支援語音播放'); return; }
    try {
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(String(text).replace(/_+/g, ' '));
      const v = this.best(); if (v) u.voice = v;
      u.lang = v ? v.lang : LC.tts;
      u.rate = rate || Number(SET.rate) || 0.9;
      speechSynthesis.speak(u);
    } catch (e) { /* 忽略 */ }
  },
  init() { if (!this.ok) return; this.refresh(); speechSynthesis.onvoiceschanged = () => { this.refresh(); renderVoiceBox(); }; }
};

// ================= 音效（和日文頁同一套） =================
const Sfx = {
  ctx: null,
  vol() { return { on: 1, low: 0.45, off: 0 }[SET.sfx] ?? 1; },
  ac() {
    if (!this.ctx) { try { this.ctx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { return null; } }
    if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
    return this.ctx;
  },
  tone(f, dur, type = 'sine', v = 0.08, f2 = 0, at = 0) {
    const k = this.vol(); if (!k) return;
    const c = this.ac(); if (!c) return;
    const t = c.currentTime + at, o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(f, t);
    if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(v * k, t + 0.008); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(c.destination); o.start(t); o.stop(t + dur + 0.02);
  },
  buf(c) { if (!this.nbuf) { const n = c.sampleRate * 0.2; this.nbuf = c.createBuffer(1, n, c.sampleRate); const d = this.nbuf.getChannelData(0); for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1; } return this.nbuf; },
  noise(dur, freq, q, v, at = 0) {
    const k = this.vol(); if (!k) return;
    const c = this.ac(); if (!c) return;
    this.buf(c);
    const t = c.currentTime + at, src = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    src.buffer = this.nbuf; f.type = 'bandpass'; f.frequency.value = freq; f.Q.value = q;
    g.gain.setValueAtTime(v * k, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f).connect(g).connect(c.destination); src.start(t); src.stop(t + dur + 0.02);
  },
  soft() { this.noise(0.045, 1100, 0.9, 0.14); this.tone(130, 0.045, 'sine', 0.07, 85); },
  blue() {
    this.noise(0.008, 4200, 2.5, 0.55); this.noise(0.022, 1900, 1.1, 0.22);
    this.tone(210, 0.035, 'triangle', 0.09, 120);
    this.noise(0.010, 3300, 2.2, 0.30, 0.055); this.tone(160, 0.025, 'sine', 0.05, 110, 0.055);
  },
  wood() { this.tone(820, 0.07, 'sine', 0.11, 620); this.tone(1640, 0.03, 'sine', 0.03, 1240); this.noise(0.01, 2000, 1, 0.08); },
  toggle(on) { const a = on ? 660 : 990, b = on ? 990 : 660; this.tone(a, 0.05, 'sine', 0.07); this.tone(b, 0.07, 'sine', 0.07, 0, 0.055); },
  tick() { this.noise(0.012, 5200, 2, 0.18); this.tone(1900, 0.025, 'sine', 0.035); },
  mallet(col) { const f = [523.3, 587.3, 659.3, 784, 880][col % 5] || 659.3; this.tone(f, 0.22, 'sine', 0.09); this.tone(f * 4, 0.05, 'sine', 0.025); },
  flip() {
    const k = this.vol(); if (!k) return; const c = this.ac(); if (!c) return;
    const t = c.currentTime, src = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    src.buffer = this.buf(c); f.type = 'bandpass'; f.Q.value = 0.9;
    f.frequency.setValueAtTime(700, t); f.frequency.exponentialRampToValueAtTime(3200, t + 0.09);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.16 * k, t + 0.03); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.11);
    src.connect(f).connect(g).connect(c.destination); src.start(t); src.stop(t + 0.13);
  },
  peek() { this.tone(1200, 0.05, 'sine', 0.05, 1700); },
  slide() { this.noise(0.06, 1800, 0.8, 0.12); this.tone(150, 0.035, 'sine', 0.1, 100, 0.05); this.noise(0.015, 3000, 1.2, 0.25, 0.05); },
  pop() { this.tone(520, 0.06, 'sine', 0.08, 900); this.noise(0.012, 2600, 1.5, 0.18); },
  unpop() { this.tone(900, 0.06, 'sine', 0.07, 480); },
  ok() { this.tone(880, 0.12, 'sine', 0.09); this.tone(1318.5, 0.2, 'sine', 0.09, 0, 0.09); },
  ng() { this.tone(240, 0.22, 'triangle', 0.09, 150); },
  done() { [523.3, 659.3, 784, 1046.5].forEach((f, i) => this.tone(f, 0.18, 'sine', 0.08, 0, i * 0.09)); }
};
function sfxKind(el) {
  if (el.closest('.opt, [data-say], .iplay, .play, #fillGo, [data-sfx]')) return '';
  if (el.closest('.pk-opt')) return '';
  if (el.closest('.tk')) return 'peek';
  if (el.closest('.tabbar')) return 'wood';
  if (el.closest('.seg')) return 'slide';
  if (el.classList.contains('pw')) return 'pop';
  if (el.closest('.pk-x')) return 'unpop';
  if (el.closest('.iconbtn')) return 'toggle';
  if (el.closest('.kc')) return 'mallet';
  if (el.closest('summary, .gr-row, .rc-tile, .rc-w, .posbtn, [data-word], [data-gram], .gr-back')) return 'flip';
  if (el.closest('.chip, [data-list], .chips button')) return 'tick';
  if (el.closest('.btn.solid, .btn.known, [data-a], [data-next], [data-q], [data-go], #again, .gbtn-signin')) return 'blue';
  return 'soft';
}
document.addEventListener('click', e => {
  const t = e.target.closest('[data-sfx]');
  if (t) { const k = t.dataset.sfx; return k === 'toggle' ? Sfx.toggle(true) : k === 'mallet' ? [0, 1, 2, 3, 4].forEach(i => setTimeout(() => Sfx.mallet(i), i * 140)) : Sfx[k](); }
  const el = e.target.closest('button, .pw, summary, .tk');
  if (!el || el.disabled) return;
  const k = sfxKind(el);
  if (k === 'toggle') { const on = el.getAttribute('aria-pressed'); return Sfx.toggle(on !== 'true'); }
  if (k === 'mallet') { const cells = [...el.parentElement.children]; return Sfx.mallet(Math.max(0, cells.indexOf(el))); }
  if (k) Sfx[k]();
}, true);
document.addEventListener('change', e => { if (e.target.matches('select') && !e.target.closest('.pw') && e.target.id !== 'sfxSel') Sfx.tick(); });
const canVibrate = 'vibrate' in navigator;
const inFrame = (() => { try { return window.top !== window.self; } catch (e) { return true; } })();
function buzz(ok) { if (SET.vib === 'on' && canVibrate) try { navigator.vibrate(ok ? 45 : [70, 80, 70]); } catch (e) {} }
function testBuzz() {
  if (!canVibrate) return toast('這個瀏覽器不支援震動（iPhone 的網頁都不支援）');
  let ok = false;
  try { ok = navigator.vibrate([200, 100, 200]); } catch (e) {}
  if (!ok) toast(inFrame ? '在預覽裡不能震動，請用 Chrome 或主畫面上的 App 開' : '瀏覽器擋下了震動，請檢查勿擾模式或震動設定');
  else toast('已送出震動；如果沒感覺，請關掉勿擾模式，並確認系統的震動有開');
}

// ================= 顯示工具 =================
function revealAboveTabbar(el) {
  requestAnimationFrame(() => {
    const bar = $('.tabbar'), r = el.getBoundingClientRect();
    const lim = innerHeight - (bar ? bar.getBoundingClientRect().height : 0) - 12;
    if (r.bottom > lim) window.scrollBy({ top: r.bottom - lim, behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
  });
}
function meanText(zh, en) {
  if (SET.mean === 'en' && en) return `<span lang="en">${esc(en)}</span>`;
  if (SET.mean === 'both' && en) return `${esc(zh)} <span class="en" lang="en">${esc(en)}</span>`;
  return esc(zh);
}
const meanW = w => meanText(w.zh, w.en);
const meanPlain = w => SET.mean === 'en' && w.en ? w.en : SET.mean === 'both' && w.en ? `${w.zh} / ${w.en}` : w.zh;
function verdict(ok, extra = '', warn) { return `<div class="verdict ${ok ? (warn ? 'warn' : 'ok') : 'ng'}">${ok ? ICON.ok + '答對了' : ICON.ng + '答錯了'}${extra}</div>`; }
let toastT = 0;
function toast(msg, goal = false) {
  const t = $('#toast'); t.textContent = msg; t.className = 'toast on' + (goal ? ' goal' : '');
  clearTimeout(toastT); toastT = setTimeout(() => t.className = 'toast' + (goal ? ' goal' : ''), goal ? 3200 : 1800);
}
function applyTheme() {
  if (SET.theme !== 'light' && SET.theme !== 'dark') { SET.theme = matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'; saveSet(); }
  document.documentElement.setAttribute('data-theme', SET.theme);
  const b = $('#themeBtn');
  const [ic, lb] = { light: [ICON.sun, '外觀：淺色'], dark: [ICON.moon, '外觀：深色'] }[SET.theme];
  b.innerHTML = ic; b.setAttribute('aria-label', lb + '（點一下切換）'); b.title = lb;
  const m = $('meta[name="theme-color"]'); if (m) m.setAttribute('content', SET.theme === 'dark' ? '#181e27' : '#ffffff');
}
function renderGoal() {
  const n = S.days[today()] || 0;
  $('#goalText').textContent = `今日 ${n}/${GOAL} 題${n >= GOAL ? ' ✓' : ''}`;
  $('#goalBar').style.width = Math.min(100, n / GOAL * 100) + '%';
}
// 名詞上方的性別小字（像日文的假名，可以在上方按鈕開關）
// 只在這個字一定是名詞、而且性別只有一種時才標；例句裡同形的其他詞性（德文 Sie、俄文 дома）不標
const GCACHE = new Map();
function genOfToken(form) {
  const k = IT.norm(form).toLowerCase();
  if (GCACHE.has(k)) return GCACHE.get(k);
  let g = null;
  const inf = (LOOK.get(k) || []).filter(x => !/的一部分/.test(x.desc || ''));
  if (inf.length && inf.every(x => x.idx >= 0 && IT.W[x.idx][1] === 'n')) {
    const gs = new Set(inf.map(x => IT.W[x.idx][2]));
    if (gs.size === 1) { const one = [...gs][0]; if (GEN[one]) g = one; }
  }
  if (g && LC.id === 'de' && !/^[A-ZÄÖÜ]/.test(form)) g = null; // 德文名詞一定大寫
  GCACHE.set(k, g);
  return g;
}
const genOn = () => SET.gender !== false;
function applyGen() {
  document.body.classList.toggle('hide-gen', !genOn());
  const b = $('#genBtn'); if (!b) return;
  b.setAttribute('aria-pressed', String(genOn()));
  b.title = '名詞上的性別：' + (genOn() ? '開' : '關');
}
// 句子：每個字都能點；ranges 是要標黃的範圍；blank 是挖空的位置；noGen 不標性別（考性別、格的題目）
function sentHTML(s, o = {}) {
  const ranges = o.ranges || [];
  const inR = i => ranges.some(r => i >= r[0] && i < r[1]);
  let pos = 0, out = '';
  for (const t of IT.tokenize(s)) {
    const start = pos; pos += t.t.length;
    if (o.blank && start === o.blank[0]) { out += o.blankHTML; continue; }
    if (o.blank && start > o.blank[0] && start < o.blank[1]) continue;
    if (!t.w) { out += esc(t.t); continue; }
    let tk = `<span class="tk" role="button" tabindex="0" data-w="${esc(t.t)}">${esc(t.t)}</span>`;
    const g = o.noGen ? null : genOfToken(t.t);
    if (g) tk = `<ruby class="gr">${tk}<rt class="gt g-${g}" aria-hidden="true">${esc(GEN[g][1])}</rt></ruby>`;
    out += inR(start) ? `<mark>${tk}</mark>` : tk;
  }
  return out;
}
function exampleBlock(w) {
  return `<div class="example"><div class="ex-row"><div class="sent" lang="${LC.id}">${sentHTML(w.sent)}</div>${iconPlay(w.sent, '播放例句')}</div><div class="zhline">${esc(w.sentZh)}</div></div>`;
}
// 很長的字（здравствуйте、Entschuldigung）縮小字級，避免在字中間斷行
const lenCls = t => { const n = String(t).replace(/[\u0300-\u036f]/g, '').length; return n > 14 ? ' xlong' : n > 10 ? ' long' : ''; };
const posBadge = w => `<button class="posbtn" data-word="${esc(w.id)}" aria-label="看「${esc(w.word)}」的詞性和變化">${esc(POS_ZH[w.pos])}${w.pos === 'n' && hasGen(w.e[2]) ? '・' + genOf(w.e[2])[1] : ''}<span aria-hidden="true">›</span></button>`;

// ================= 拉起式面板（點字、單字詳細、字母） =================
const Sheet = {
  el: null, back: null, prev: null,
  build() {
    this.back = document.createElement('div'); this.back.className = 'pk-back'; this.back.hidden = true;
    this.el = document.createElement('div'); this.el.className = 'pk'; this.el.hidden = true;
    this.el.setAttribute('role', 'dialog'); this.el.setAttribute('aria-modal', 'true');
    document.body.append(this.back, this.el);
    this.back.onclick = () => this.close();
    this.el.addEventListener('click', e => { if (e.target.closest('.pk-x')) this.close(); });
  },
  open(title, body, label) {
    if (!this.el) this.build();
    if (this.el.hidden) this.prev = document.activeElement;
    this.el.setAttribute('aria-label', label || title.replace(/<[^>]+>/g, ''));
    this.el.innerHTML = `<div class="pk-grab" aria-hidden="true"></div><div class="pk-top"><b>${title}</b><button class="pk-x" aria-label="關閉">${ICON.ng}</button></div><div class="sheet-body">${body}</div>`;
    this.back.hidden = false; this.el.hidden = false;
    requestAnimationFrame(() => { this.back.classList.add('in'); this.el.classList.add('in'); $('.pk-x', this.el).focus({ preventScroll: true }); });
    return this.el;
  },
  close() {
    if (!this.el || this.el.hidden) return;
    this.back.classList.remove('in'); this.el.classList.remove('in');
    setTimeout(() => { this.back.hidden = true; this.el.hidden = true; }, 180);
    if (this.prev && document.contains(this.prev)) try { this.prev.focus({ preventScroll: true }); } catch (e) {}
  },
  isOpen() { return this.el && !this.el.hidden; }
};
document.addEventListener('keydown', e => { if (e.key === 'Escape' && Sheet.isOpen()) { e.stopPropagation(); Sheet.close(); } }, true);

function openToken(form) {
  const k = IT.norm(form).toLowerCase();
  const infos = LOOK.get(k) || [];
  const nm = IT.NAMES[k];
  let body = '';
  if (nm) body += `<div class="an"><div class="grow"><b lang="${LC.id}">${esc(nm[0])}</b><div class="meta">${esc(nm[1])}</div></div></div>`;
  const seen = new Set();
  for (const x of infos) {
    const key = x.lemma + '|' + x.desc; if (seen.has(key)) continue; seen.add(key);
    const e = x.idx >= 0 ? IT.W[x.idx] : null;
    if (e) {
      const w = WMAP[idOfEntry(e)];
      body += `<div class="an tk-an"><div class="grow"><div class="tk-h"><b lang="${LC.id}">${esc(w.title)}</b><span class="pos">${esc(POS_ZH[w.pos])}</span></div>${x.desc ? `<div class="meta">${esc(x.desc)}</div>` : ''}<p class="mean-big tk-m">${meanW(w)}</p>
        <div class="tk-ex"><div class="grow"><div lang="${LC.id}">${esc(w.sent)}</div><div class="meta">${esc(w.sentZh)}</div></div>${iconPlay(w.sent, '播放例句')}</div>
        <button class="btn quiet tk-more" data-word="${esc(w.id)}">看完整${isVerbPos(w.pos) ? '變化表' : '說明'}</button></div></div>`;
    } else {
      const ex = IT.EXTRA_FORMS[k] || IT.EXTRA_LOOKUP[k];
      body += `<div class="an"><div class="grow"><b lang="${LC.id}">${esc(x.lemma)}</b><div class="meta">${esc(x.desc || (ex && ex[1]) || '')}</div></div></div>`;
    }
  }
  if (!infos.length && !nm) body += '<p class="meta">找不到這個字。</p>';
  Sheet.open('查字', `<div class="rowx tk-top"><div class="grow"><div class="w1" lang="${LC.id}">${esc(form)}</div></div>${iconPlay(form, '播放 ' + form)}</div>${body}`, form);
}
function conjTable(w, which) {
  const c = IT.conjugate(w.word, w.pos);
  const P = LC.persons;
  let rows;
  if (which === 'pres') rows = c.presentFull.map((f, i) => [P[i], f, LC.sayPerson(i) + ' ' + f]);
  else if (which === 'pass') { const PP = LC.pastPersons || P, SP = LC.sayPast || LC.sayPerson; rows = c.passato.map((f, i) => [PP[i], f, SP(i) + ' ' + f.split('/')[0]]); }
  else rows = c.imperative ? c.imperative.map((f, i) => [LC.impPersons[i], f, f.split('/')[0]]).filter(r => r[1]) : [];
  if (!rows.length) return `<p class="meta">${which === 'pass' ? '這個動詞通常不用完成式。' : '這個動詞沒有常用的命令式。'}</p>`;
  return `<table class="t"><tbody>${rows.map(([p, f, say]) => `<tr><td class="p">${esc(p)}</td><td class="f" lang="${LC.id}">${esc(f)}</td><td class="a">${iconPlay(say, '播放 ' + f)}</td></tr>`).join('')}</tbody></table>`;
}
function verbInfo(w) {
  const c = IT.conjugate(w.word, w.pos);
  const tags = LC.verbTags(c);
  return `<div class="row">${tags.map(t => `<span class="pos">${esc(t)}</span>`).join('')}</div>${c.note ? `<div class="meta">${esc(c.note)}</div>` : ''}`;
}
// 語言包自己提供的變化表（德文：名詞的格、形容詞比較級與詞尾）
function tableHTML(t, play) {
  const head = t.headPl || t.head;
  const cells = r => r.slice(1).map(x => `<td class="f" lang="${LC.id}">${esc(x)}</td>`).join('');
  const say = r => r.slice(1).filter(Boolean)[0] || '';
  let h = `<div class="scroll-x" style="flex-shrink:0"><table class="t">${head ? `<thead><tr>${head.map(x => `<th>${esc(x)}</th>`).join('')}${play ? '<th></th>' : ''}</tr></thead>` : ''}<tbody>${t.rows.map(r => `<tr><td class="p">${esc(r[0])}</td>${cells(r)}${play ? `<td class="a">${say(r) ? iconPlay(say(r), '播放 ' + say(r)) : ''}</td>` : ''}</tr>`).join('')}</tbody></table></div>`;
  if (t.more) h += tableHTML(t.more, false);
  if (t.note) h += `<div class="meta">${esc(t.note)}</div>`;
  return h;
}
function formsHTML(w) {
  const e = w.e;
  // 語言包的變化表：義、西沒有；德文給名詞、形容詞；俄文也給代名詞、限定詞（沒有就回傳 null，照下面的做法）
  if (IT.formsTable && (!isVerbPos(w.pos) || IT.VERB_TABLE)) { const t = IT.formsTable(e); if (t) return (isVerbPos(w.pos) ? verbInfo(w) : '') + tableHTML(t, true); }
  if (w.pos === 'n') {
    const f = IT.nounForms(e);
    let h = `<table class="t"><tbody><tr><td class="p">${f.plOnly ? '複數（只用複數）' : '單數'}</td><td class="f" lang="${LC.id}">${esc(f.sg)}</td><td class="a">${iconPlay(f.sg, '播放')}</td></tr>`;
    if (f.pl) h += `<tr><td class="p">複數</td><td class="f" lang="${LC.id}">${esc(f.pl)}</td><td class="a">${iconPlay(f.pl, '播放')}</td></tr>`;
    if (f.indef) h += `<tr><td class="p">一個</td><td class="f" lang="${LC.id}">${esc(f.indef + (f.indef.endsWith("'") ? '' : ' ') + e[0])}</td><td class="a"></td></tr>`;
    h += '</tbody></table>';
    if (f.plGender !== e[2]) h += `<div class="meta">注意：複數變成陰性（${esc(f.pl)}）。</div>`;
    return h;
  }
  if (w.pos === 'adj') {
    const f = IT.adjForms(e);
    return `<table class="t"><thead><tr><th></th><th>單數</th><th>複數</th></tr></thead><tbody><tr><td class="p">陽性</td><td class="f" lang="${LC.id}">${esc(f[0])}</td><td class="f" lang="${LC.id}">${esc(f[2])}</td></tr><tr><td class="p">陰性</td><td class="f" lang="${LC.id}">${esc(f[1])}</td><td class="f" lang="${LC.id}">${esc(f[3])}</td></tr></tbody></table>` +
      (e[3].split('/').length > 3 ? `<div class="meta">放在名詞前面的形：${esc(e[3].split('/').slice(3).join('、'))}</div>` : '');
  }
  if (isVerbPos(w.pos)) {
    return verbInfo(w) + `<div class="seg" role="group" aria-label="動詞時態"><button data-tense="pres" aria-pressed="true">${esc(IT.conjugate(w.word, w.pos).presTab || '現在式')}</button><button data-tense="pass" aria-pressed="false">過去式</button><button data-tense="imp" aria-pressed="false">命令式</button></div><div id="conj">${conjTable(w, 'pres')}</div>`;
  }
  if (e[3] && e[3] !== '-') return `<div>其他形：<span lang="${LC.id}">${esc(e[3].split('/').join('、'))}</span></div>`;
  return '';
}
const STATUS_TXT = { new: '未學', queued: '待考', learned: '已學會', excluded: '已排除' };
function openWord(id) {
  const w = WMAP[id]; if (!w) return;
  const r = getRec(id);
  const tags = [`<span class="st ${r.s}">${STATUS_TXT[r.s] || '未學'}</span>`];
  if (r.w && r.w.mc) tags.push(`<span class="st wr">單選${r.w.mc === 1 ? '錯題' : '錯題複習'}</span>`);
  if (r.w && r.w.fill) tags.push(`<span class="st wr">填空${r.w.fill === 1 ? '錯題' : '錯題複習'}</span>`);
  const dueTxt = r.s === 'learned' && r.due ? `<div class="meta">下次複習：${r.due.slice(5).replace('-', '/')}（第 ${(r.lv || 0) + 1} 級）</div>` : '';
  const btns = r.s === 'new' || r.s === 'excluded'
    ? `<div class="btnrow"><button class="btn known" data-wa="known">${ICON.ok}已經會了</button><button class="btn solid" data-wa="queue">列入考題</button></div>`
    : `<button class="btn quiet block" data-wa="reset">移回未學</button>`;
  const body = `<div class="rowx"><div class="grow"><div class="w1" lang="${LC.id}">${esc(w.title)}</div><div class="row" style="margin-top:6px"><span class="pos">${esc(POS_ZH[w.pos])}</span>${w.pos === 'n' && hasGen(w.e[2]) ? `<span class="pos ${w.e[2]}">${genOf(w.e[2])[0]}</span>` : ''}${tags.join('')}</div></div>${iconPlay(w.title, '播放單字')}</div>
    <p class="mean-big">${esc(w.zh)}</p><div class="meta" style="margin-top:-8px">${esc(w.en)}</div>
    ${formsHTML(w)}
    <div class="gp-title">例句</div>
    <div class="ex-row"><div class="sent sm" lang="${LC.id}">${sentHTML(w.sent)}</div>${iconPlay(w.sent, '播放例句')}</div><div class="zhline" style="margin-top:-6px">${esc(w.sentZh)}</div>
    ${dueTxt}${btns}`;
  const el = Sheet.open(esc(POS_ZH[w.pos]) + ' · 單字', body, w.word);
  $$('[data-tense]', el).forEach(b => b.onclick = () => { $$('[data-tense]', el).forEach(x => x.setAttribute('aria-pressed', String(x === b))); $('#conj', el).innerHTML = conjTable(w, b.dataset.tense); });
  $$('[data-wa]', el).forEach(b => b.onclick = () => {
    const a = b.dataset.wa;
    if (a === 'queue') { touch(id, { s: 'queued' }); toast('已列入考題'); }
    if (a === 'known') { const gap = SRS[1] + Math.floor(Math.random() * 8); touch(id, { s: 'learned', lv: 1, due: addDays(today(), gap) }); toast(`已標記為學會，${gap} 天後會再考一次`); }
    if (a === 'reset') { touch(id, { s: 'new', lv: 0, due: '', w: {} }); toast('已移回未學'); }
    Sheet.close(); deck = null; refreshPassive(true);
  });
}
document.addEventListener('click', e => {
  const say = e.target.closest('[data-say]');
  if (say) { e.preventDefault(); Voice.speak(say.dataset.say); return; }
  const tk = e.target.closest('.tk[data-w]');
  if (tk && !tk.closest('.opt')) { e.preventDefault(); openToken(tk.dataset.w); return; }
  const wd = e.target.closest('[data-word]');
  if (wd) { e.preventDefault(); openWord(wd.dataset.word); }
});
document.addEventListener('keydown', e => { if ((e.key === 'Enter' || e.key === ' ') && e.target.matches && e.target.matches('.tk[data-w]')) { e.preventDefault(); Sfx.peek(); openToken(e.target.dataset.w); } });

// ================= 自訂下拉選單（和日文頁一樣） =================
const Picker = {
  el: null, back: null, sel: null,
  build() {
    this.back = document.createElement('div'); this.back.className = 'pk-back'; this.back.hidden = true;
    this.el = document.createElement('div'); this.el.className = 'pk'; this.el.hidden = true;
    this.el.setAttribute('role', 'dialog'); this.el.setAttribute('aria-modal', 'true');
    document.body.append(this.back, this.el);
    this.back.onclick = () => this.close();
    this.el.addEventListener('click', e => {
      if (e.target.closest('.pk-x')) return this.close();
      const b = e.target.closest('[data-v]');
      if (!b || !this.sel) return;
      Sfx.tick(); const sel = this.sel; this.close();
      if (sel.value !== b.dataset.v) { sel.value = b.dataset.v; sel.dispatchEvent(new Event('change', { bubbles: true })); }
    });
  },
  open(sel) {
    if (!this.el) this.build();
    this.sel = sel;
    const title = sel.getAttribute('aria-label') || '選擇';
    const rows = [...sel.options].map(o => {
      const m = o.textContent.match(/^(.*?)\s+(\d+)$/);
      let name = m ? m[1] : o.textContent; const n = m ? +m[2] : null;
      if (o.value === 'all' && sel.hasAttribute('data-possel')) name = '全部';
      const on = o.value === sel.value;
      return `<button class="pk-opt${on ? ' on' : ''}${n === 0 ? ' zero' : ''}" data-v="${esc(o.value)}" role="option" aria-selected="${on}"><span class="pk-n">${esc(name)}</span>${n !== null ? `<span class="pk-c">${n}</span>` : ''}<span class="pk-ck" aria-hidden="true">${on ? ICON.ok : ''}</span></button>`;
    }).join('');
    this.el.setAttribute('aria-label', title);
    this.el.innerHTML = `<div class="pk-grab" aria-hidden="true"></div><div class="pk-top"><b>${esc(title)}</b><button class="pk-x" aria-label="關閉">${ICON.ng}</button></div><div class="pk-list" role="listbox">${rows}</div>`;
    this.back.hidden = false; this.el.hidden = false;
    requestAnimationFrame(() => { this.back.classList.add('in'); this.el.classList.add('in'); const cur = $('.pk-opt.on', this.el); (cur || $('.pk-opt', this.el)).focus({ preventScroll: true }); if (cur) cur.scrollIntoView({ block: 'nearest' }); });
  },
  close() {
    if (!this.el || this.el.hidden) return;
    this.back.classList.remove('in'); this.el.classList.remove('in');
    const sel = this.sel; this.sel = null;
    setTimeout(() => { this.back.hidden = true; this.el.hidden = true; }, 180);
    if (sel && document.contains(sel)) sel.focus({ preventScroll: true });
  }
};
document.addEventListener('click', e => {
  const w = e.target.closest('.pw'); if (!w) return;
  const sel = $('select', w);
  if (sel && !sel.disabled) { e.preventDefault(); Picker.open(sel); }
});
document.addEventListener('keydown', e => { if (e.key === 'Escape' && Picker.el && !Picker.el.hidden) { e.stopPropagation(); Picker.close(); } }, true);
const segPrev = {};
new MutationObserver(() => {
  const todo = [];
  document.querySelectorAll('.seg').forEach(seg => {
    const btns = [...seg.children].filter(b => b.tagName === 'BUTTON');
    const idx = btns.findIndex(b => b.getAttribute('aria-pressed') === 'true');
    if (idx < 0 || seg.dataset.segi === String(idx)) return;
    const key = seg.getAttribute('aria-label') || '', prev = segPrev[key];
    seg.dataset.segi = idx; segPrev[key] = idx;
    seg.style.setProperty('--n', btns.length);
    seg.classList.add('seg-noanim');
    seg.style.setProperty('--i', prev != null ? prev : idx);
    todo.push([seg, idx]);
  });
  if (!todo.length) return;
  void document.body.offsetWidth;
  for (const [seg, idx] of todo) { seg.classList.remove('seg-noanim'); seg.style.setProperty('--i', idx); }
}).observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['aria-pressed'] });

// ================= 題庫篩選 =================
const POS_FILTERS = [['all', '全部'], ['n', '名詞'], ['v', '動詞'], ['adj', '形容詞'], ['o', '其他']];
const posOK = w => UI.pos === 'all' || w.pg === UI.pos;
const wrongOf = (id, m) => (getRec(id).w || {})[m] || 0;
// 今天要做的到期複習：到期越久、等級越低的先出；每天最多 SET.dueCap 個（做過的也算在內）
const DUE_CAPS = [10, 20, 30, 50, 'all'];
const dueCap = () => SET.dueCap === 'all' ? Infinity : (Number(SET.dueCap) || 30);
function dueAll() { const t = today(); return WORDS.filter(w => { const r = getRec(w.id); return r.s === 'learned' && r.due && r.due <= t; }); }
function dueToday() {
  const t = today();
  const done = WORDS.filter(w => getRec(w.id).dd === t).length;
  const left = Math.max(0, dueCap() - done);
  const list = dueAll().sort((a, b) => { const x = getRec(a.id), y = getRec(b.id); return x.due < y.due ? -1 : x.due > y.due ? 1 : (x.lv || 0) - (y.lv || 0); });
  return new Set(list.slice(0, left).map(w => w.id));
}
function wordPool(src) {
  const t = today();
  const f = {
    new: w => getRec(w.id).s === 'new',
    learn: w => getRec(w.id).s === 'queued',
    queued: w => getRec(w.id).s === 'queued',
    learned: w => getRec(w.id).s === 'learned',
    recent: (() => { let set; return w => (set || (set = recentIds())).has(w.id); })(),
    due: (() => { let set; return w => (set || (set = dueToday())).has(w.id); })(),
    mcWrong: w => wrongOf(w.id, 'mc') === 1,
    mcReview: w => wrongOf(w.id, 'mc') === 2,
    fillWrong: w => wrongOf(w.id, 'fill') === 1,
    fillReview: w => wrongOf(w.id, 'fill') === 2,
    excluded: w => getRec(w.id).s === 'excluded'
  }[src];
  return (src === 'new' ? ORDER : WORDS).filter(w => f(w));
}
const filtered = src => wordPool(src).filter(posOK);
const srcPool = src => src === 'recent' ? wordPool('recent') : filtered(src);
function pillSelect(id, label, opts, val) {
  return `<span class="pw"><select class="pill" id="${id}" aria-label="${label}">${opts.map(([k, l]) => `<option value="${k}"${k === val ? ' selected' : ''}>${l}</option>`).join('')}</select></span>`;
}
function posChips() {
  return `<span class="pw"><select class="pill${UI.pos !== 'all' ? ' on' : ''}" data-possel aria-label="詞性">${POS_FILTERS.map(([k, l]) => `<option value="${k}"${UI.pos === k ? ' selected' : ''}>${k === 'all' ? '詞性' : l}</option>`).join('')}</select></span>`;
}
function bindPos(root, cb) { const sel = $('[data-possel]', root); if (sel) sel.onchange = () => { UI.pos = sel.value; saveUI(); cb(); }; }
const REVIEW_ROUND = 10;
const roundSize = () => SET.round === 'all' ? 100000 : (Number(SET.round) || 20);
const RECENT_OPTS = [['d1', '最近 1 天'], ['d3', '最近 3 天'], ['d7', '最近 7 天'], ['c10', '最近 10 個字'], ['c20', '最近 20 個字'], ['c30', '最近 30 個字'], ['c50', '最近 50 個字']];
function recentLabel() { return (RECENT_OPTS.find(x => x[0] === SET.recent) || RECENT_OPTS[0])[1]; }
const recentT = id => { const r = getRec(id); return r.q || r.t || 0; };
function recentIds() {
  const v = SET.recent || 'd1', n = parseInt(v.slice(1), 10) || 1;
  const cand = WORDS.filter(w => { const r = getRec(w.id); return (r.s === 'queued' || r.s === 'learned') && recentT(w.id) > 0; });
  if (v[0] === 'c') return new Set(cand.sort((a, b) => recentT(b.id) - recentT(a.id)).slice(0, n).map(w => w.id));
  const since = Date.now() - n * 864e5;
  return new Set(cand.filter(w => recentT(w.id) >= since).map(w => w.id));
}
function recentCtl(onChange) { return { html: pillSelect('recentSel', '最近學過的範圍', RECENT_OPTS, SET.recent), bind: host => { const rs = $('#recentSel', host); if (rs) rs.onchange = e => { SET.recent = e.target.value; saveSet(); mcRound = null; fillRound = null; onChange(); }; } }; }
function progressLine(round, total) {
  const left = round.queue.length - round.idx;
  const done = round.queue.length ? (round.idx / round.queue.length) * 100 : 0;
  return `<span class="qprog" aria-label="本輪還剩 ${left} 題，此分類共 ${total} 題"><i style="width:${done}%"></i></span><span class="meta">剩 ${left} · 共 ${total}</span>`;
}
function roundDone(host, R, again) {
  Quiz.active = null;
  Sfx.done(); if (SET.vib === 'on' && canVibrate) try { navigator.vibrate([20, 40, 20, 40, 70]); } catch (e) {}
  host.innerHTML = `<div class="card empty"><p style="color:var(--fg);font-size:18px;font-weight:700">這一輪完成了</p><p>答對 ${R.right} / ${R.queue.length} 題</p><button class="btn solid" id="again">再來一輪</button></div>`;
  $('#again', host).onclick = again;
}
function emptyWords(host, src) {
  Quiz.active = null;
  const goCard = () => { UI.cardSrc = 'new'; saveUI(); deck = null; showTab('card'); };
  const m = {
    learn: ['還沒有待考的字。先到「字卡」把想練的字「列入考題」。', '去字卡挑字', goCard],
    mcWrong: ['目前沒有單選錯題。', '練習待考的字', () => { UI.mcSrc = 'learn'; saveUI(); renderMC(); }],
    mcReview: ['目前沒有單選錯題複習。', '練習待考的字', () => { UI.mcSrc = 'learn'; saveUI(); renderMC(); }],
    learned: ['還沒有已學會的字。填空答對就算學會。', '去填空', () => showTab('fill')],
    recent: [`「${recentLabel()}」範圍內還沒有學過的字。可以在上方把範圍調大，或先到字卡把字列入考題。`, '去字卡挑字', goCard],
    fillWrong: ['目前沒有填空錯題。', '練習待考的字', () => { UI.fillSrc = 'learn'; saveUI(); renderFill(); }],
    fillReview: ['目前沒有填空錯題複習。', '練習待考的字', () => { UI.fillSrc = 'learn'; saveUI(); renderFill(); }],
    due: ['今天沒有到期要複習的字。', '練習待考的字', () => { UI.fillSrc = 'learn'; saveUI(); renderFill(); }]
  }[src] || ['這個分類沒有題目。', '去字卡挑字', goCard];
  const posNote = UI.pos !== 'all' && src !== 'recent' ? `<p>目前只顯示「${POS_FILTERS.find(x => x[0] === UI.pos)[1]}」，可以改選「全部」。</p>` : '';
  host.innerHTML = `<div class="card empty"><p>${m[0]}</p>${posNote}<button class="btn solid" id="emptyGo">${m[1]}</button></div>`;
  $('#emptyGo', host).onclick = m[2];
}

// ================= 通用選擇題（和日文頁一樣） =================
const Quiz = { active: null };
function renderChoice(host, q, onNext) {
  const letters = 'ABCD';
  host.innerHTML = `<div class="card qcard">${q.head}<div class="prompt">${q.promptHTML}</div>
    <div class="opts">${q.options.map((o, i) => `<button class="opt" data-i="${i}"${o.lang ? ` lang="${o.lang}"` : ''}><span class="k">${letters[i]}</span><span class="t">${o.html}</span></button>`).join('')}</div><div class="after"></div></div>`;
  const state = { answered: false, host };
  Quiz.active = state;
  const choose = i => {
    if (state.answered) return;
    state.answered = true;
    const ok = !!q.options[i].correct;
    $$('.opt', host).forEach((b, j) => { b.disabled = true; if (q.options[j].correct) b.classList.add('right'); else if (j === i) b.classList.add('wrong'); });
    q.onAnswer(ok, i);
    ok ? Sfx.ok() : Sfx.ng(); buzz(ok);
    const after = $('.after', host);
    after.innerHTML = `<div class="afterbox">${verdict(ok)}${q.explain || ''}<button class="btn solid block" data-next>下一題（Enter）</button>${!ok && q.afterHTML ? q.afterHTML(false) : ''}</div>`;
    if (ok && !q.noAuto) state.timer = setTimeout(() => { if (Quiz.active === state) onNext(); }, 900);
    const nb = $('[data-next]', after);
    nb.onclick = () => { clearTimeout(state.timer); onNext(); };
    if (!ok) { nb.focus({ preventScroll: true }); revealAboveTabbar(nb); }
  };
  state.choose = choose;
  state.goNext = () => { if (state.answered) { clearTimeout(state.timer); onNext(); } };
  $$('.opt', host).forEach(b => b.onclick = () => choose(+b.dataset.i));
}
document.addEventListener('keydown', e => {
  const tag = (e.target.tagName || '').toLowerCase();
  if (tag === 'input' || tag === 'textarea' || tag === 'select') return;
  if (e.metaKey || e.ctrlKey || e.altKey || Sheet.isOpen()) return;
  const st = Quiz.active;
  if (!st || !st.host.isConnected || st.host.closest('.tab').hidden) return;
  const k = e.key.toLowerCase();
  const idx = '1234'.indexOf(k) >= 0 ? '1234'.indexOf(k) : 'abcd'.indexOf(k);
  if (idx >= 0 && k.length === 1 && !st.answered) { e.preventDefault(); if ($$('.opt', st.host)[idx]) st.choose(idx); }
  else if (k === 'enter' && st.answered) { e.preventDefault(); st.goNext(); }
});
function meaningKeys(s) { return String(s).split(/[；;、,，／/]/).map(x => x.replace(/[（(][^）)]*[）)]/g, '').replace(/的$/, '').trim().toLowerCase()).filter(Boolean); }
function sameMeaning(a, b) { const A = meaningKeys(a), B = meaningKeys(b); return A.some(x => B.includes(x)); }
function pickWordDistractors(target, qmode, n = 3) {
  const ok = w => w.id !== target.id && w.word !== target.word && w.title !== target.title && !sameMeaning(w.zh, target.zh) && !sameMeaning(w.en, target.en);
  const chosen = [];
  const accept = w => { if (chosen.length >= n) return; if (chosen.some(c => c.title === w.title || sameMeaning(c.zh, w.zh) || sameMeaning(c.en, w.en))) return; chosen.push(w); };
  shuffle(WORDS.filter(w => w.pg === target.pg && ok(w))).forEach(accept);
  if (chosen.length < n) shuffle(WORDS.filter(ok)).forEach(accept);
  return chosen;
}

// ================= 分頁 =================
const TABS = ['pron', 'mc', 'card', 'fill', 'gram', 'lib'];
function showTab(t) {
  if (!TABS.includes(t)) t = 'card';
  UI.tab = t; saveUI();
  TABS.forEach(x => { $('#tab-' + x).hidden = x !== t; });
  $$('.tabbar button').forEach(b => b.setAttribute('aria-current', b.dataset.tab === t ? 'page' : 'false'));
  document.body.classList.remove('typing');
  Quiz.active = null; Sheet.close();
  ({ pron: renderPron, mc: renderMC, card: renderCard, fill: renderFill, gram: renderGram, lib: renderLib })[t]();
  window.scrollTo(0, 0);
}
$$('.tabbar button').forEach(b => b.onclick = () => showTab(b.dataset.tab));
$('#themeBtn').onclick = () => { SET.theme = SET.theme === 'dark' ? 'light' : 'dark'; saveSet(); applyTheme(); };
{
  const gb = $('#genBtn');
  if (gb && !Object.keys(GEN).length) gb.remove();
  else if (gb) {
    gb.innerHTML = `<ruby>名<rt>${['m', 'f', 'n'].filter(k => GEN[k]).map(k => GEN[k][1]).join('')}</rt></ruby>`;
    gb.onclick = () => { SET.gender = !genOn(); saveSet(); applyGen(); toast(genOn() ? '名詞上方標出性別' : '已隱藏性別，點單字可以看詞性'); };
  }
  applyGen();
}

// ================= 發音 =================
let pronRound = null;
function renderPron() {
  const host = $('#tab-pron');
  Quiz.active = null;
  const seg = `<div class="seg" role="group" aria-label="發音分頁">${[['abc', '字母'], ['rules', '規則'], ['practice', '練習']].map(([k, l]) => `<button data-psec="${k}" aria-pressed="${UI.pronSec === k}">${l}</button>`).join('')}</div>`;
  let body = '';
  if (UI.pronSec === 'abc') {
    const cell = (a, i, fo) => `<button class="kc${fo ? ' fo' : ''}" data-letter="${i}" aria-label="${esc(a[0])}，${LC.letterNameLabel || '字母名稱'} ${esc(a[1])}"><span class="kk">${LC.letterAsIs ? esc(a[0]) : a[0].length > 1 ? a[0].toLowerCase() : a[0] + a[0].toLowerCase()}</span><span class="rr" lang="${LC.id}">${esc(a[1])}</span></button>`;
    body = `<div class="card ksec">${LC.letterGroups.map((g, k) => `<h3${k ? '' : ' style="margin-top:0"'}>${esc(g.title)}</h3><div class="ktable c5">${IT.ALPHABET.slice(g.from, g.to).map((a, i) => cell(a, g.from + i, g.fo)).join('')}</div>`).join('')}
      <p class="meta" style="margin:12px 0 0">${LC.letterNote}</p></div>`;
  } else if (UI.pronSec === 'rules') {
    body = IT.PRON_RULES.map(r => `<div class="card"><div class="gr-head"><h2 style="font-size:18px">${esc(r.t)}</h2></div><p class="gr-desc">${r.d}</p><div class="say-chips">${r.ex.map(x => `<button class="play" data-say="${esc(x[0])}">${ICON.play}<span lang="${LC.id}">${esc(x[0])}</span><em>${esc(x[1])}</em></button>`).join('')}</div></div>`).join('');
  } else {
    body = `<div class="ctl">${pillSelect('pronMode', '練習方式', [['listen', '聽音選拼字'], ['read', '看拼字選讀法']], UI.pronMode)}</div><div id="prq"></div>`;
  }
  host.innerHTML = seg + body;
  $$('[data-psec]', host).forEach(b => b.onclick = () => { if (UI.pronSec === b.dataset.psec) return; UI.pronSec = b.dataset.psec; saveUI(); pronRound = null; renderPron(); });
  $$('[data-letter]', host).forEach(b => b.onclick = () => openLetter(+b.dataset.letter));
  const pm = $('#pronMode', host);
  if (pm) {
    pm.onchange = e => { UI.pronMode = e.target.value; saveUI(); pronRound = null; renderPron(); };
    if (!pronRound || pronRound.mode !== UI.pronMode || pronRound.idx >= pronRound.queue.length) startPron();
    else nextPronQ();
  }
}
function openLetter(i) {
  const a = IT.ALPHABET[i];
  const w = WORDS.find(x => x.word === a[4]);
  Sheet.open(`${LC.letterTitle || '字母'} ${esc(a[0])}`, `<div class="rowx"><div class="grow"><div class="w1">${LC.letterAsIs ? esc(a[0]) : a[0] + ' ' + a[0].toLowerCase()}</div><div class="meta">${LC.letterNameLabel || '字母名稱'}：<span lang="${LC.id}">${esc(a[1])}</span></div></div>${iconPlay(a[1], '播放' + (LC.letterNameLabel || '字母名稱'))}</div>
    <p class="mean-big">${esc(a[2])}</p><p style="margin:0">${esc(a[3])}</p>
    <div class="gp-title">例字</div>
    <div class="an"><div class="grow"><b lang="${LC.id}" style="font-size:22px">${esc(w ? w.title : a[4])}</b>${w ? `<div class="meta">${meanW(w)}</div>` : ''}</div>${iconPlay(w ? w.title : a[4], '播放例字')}${w ? `<button class="btn quiet" data-word="${esc(w.id)}">詳細</button>` : ''}</div>`, a[0]);
  setTimeout(() => Voice.speak(a[1]), 150);
}
function startPron() {
  const mode = UI.pronMode;
  const queue = mode === 'listen'
    ? shuffle(IT.LISTEN_PAIRS).slice(0, 10).map(p => { const ans = p[Math.floor(Math.random() * p.length)]; return { say: ans, answer: ans, options: shuffle(p) }; })
    : shuffle(IT.READ_ITEMS).slice(0, 10).map(r => ({ say: r.w, w: r.w, part: r.part, answer: r.ans, options: shuffle(r.opts) }));
  pronRound = { mode, queue, idx: 0, right: 0 };
  nextPronQ();
}
function boldPart(w, part) { const i = w.toLowerCase().indexOf(part.toLowerCase()); if (i < 0) return esc(w); return esc(w.slice(0, i)) + `<u style="text-decoration-thickness:3px;text-underline-offset:6px;color:var(--pri)">${esc(w.slice(i, i + part.length))}</u>` + esc(w.slice(i + part.length)); }
function nextPronQ() {
  const R = pronRound, host = $('#prq'); if (!host) return;
  if (R.idx >= R.queue.length) return roundDone(host, R, () => { pronRound = null; renderPron(); });
  const q = R.queue[R.idx];
  const prompt = R.mode === 'listen'
    ? `<button class="dict-big" data-say="${esc(q.say)}" aria-label="再聽一次">${ICON.play}</button><span class="meta">聽發音，選出你聽到的拼法</span>`
    : `<div class="word-row"><div class="big" lang="${LC.id}">${boldPart(q.w, q.part)}</div>${iconPlay(q.w, '播放')}</div><span class="meta">畫線的「${esc(q.part)}」怎麼唸？</span>`;
  renderChoice(host, {
    head: `<div class="qhead">${progressLine(R, R.queue.length)}</div>`,
    promptHTML: prompt,
    options: q.options.map(o => ({ html: esc(o), correct: o === q.answer, lang: R.mode === 'listen' ? LC.id : '' })),
    onAnswer: ok => { if (ok) R.right++; bumpDay(); },
    afterHTML: () => R.mode === 'listen' ? `<div class="say-chips">${q.options.map(o => `<button class="play" data-say="${esc(o)}">${ICON.play}<span lang="${LC.id}">${esc(o)}</span></button>`).join('')}</div>` : ''
  }, () => { R.idx++; nextPronQ(); });
  if (R.mode === 'listen') setTimeout(() => Voice.speak(q.say), 250);
}

// ================= 單選 =================
let mcRound = null;
const MC_MODES = [['it2zh', LC.short + '→中'], ['zh2it', '中→' + LC.short], ['listen', '聽→中'], ['verb', '動詞變化'], ['art', LC.artLabel]];
const MC_SRCS = [['learn', '待考'], ['recent', '最近學過'], ['mcWrong', '單選錯題'], ['mcReview', '錯題複習'], ['learned', '複習已學會']];
function mcPool(src) {
  let pool = srcPool(src);
  if (UI.mcMode === 'verb') pool = pool.filter(w => isVerbPos(w.pos));
  if (UI.mcMode === 'art') pool = pool.filter(w => IT.makeArtQuestion(w.e, LOOK));
  return pool;
}
function renderMC() {
  const host = $('#tab-mc');
  const counts = Object.fromEntries(MC_SRCS.map(([k]) => [k, srcPool(k).length]));
  host.innerHTML = `<div class="ctl">${pillSelect('mcMode', '題型', MC_MODES, UI.mcMode)}${pillSelect('mcSrc', '題目來源', MC_SRCS.map(([k, l]) => [k, `${l} ${counts[k]}`]), UI.mcSrc)}${UI.mcSrc === 'recent' ? recentCtl().html : posChips()}</div><div id="mcq"></div>`;
  $('#mcMode', host).onchange = e => { UI.mcMode = e.target.value; saveUI(); mcRound = null; renderMC(); };
  $('#mcSrc', host).onchange = e => { UI.mcSrc = e.target.value; saveUI(); mcRound = null; renderMC(); };
  recentCtl(renderMC).bind(host);
  bindPos(host, () => { mcRound = null; renderMC(); });
  if (mcRound && mcRound.done) { mcRound.idx++; mcRound.done = false; }
  const valid = mcRound && mcRound.mode === UI.mcMode && mcRound.src === UI.mcSrc && (UI.mcSrc === 'recent' || mcRound.pos === UI.pos);
  if (!valid || mcRound.idx >= mcRound.queue.length) {
    if (valid && mcRound.queue.length && mcRound.idx >= mcRound.queue.length) return roundDone($('#mcq'), mcRound, () => { mcRound = null; renderMC(); });
    const pool = mcPool(UI.mcSrc);
    if (!pool.length || (UI.mcMode === 'art' && IT.DRILLS_ONLY)) {
      if (UI.mcMode === 'art' && (srcPool(UI.mcSrc).length || IT.DRILLS_ONLY)) {
        // 範圍裡的例句挖不出冠詞時，改出固定的介係詞練習句
        const queue = shuffle(IT.PREP_DRILLS).slice(0, Math.min(10, roundSize())).map(d => ({ drill: d }));
        mcRound = { mode: 'art', queue, idx: 0, total: IT.PREP_DRILLS.length, src: UI.mcSrc, pos: UI.pos, right: 0 };
        return nextMCQ();
      }
      if (UI.mcMode === 'verb' && srcPool(UI.mcSrc).length) { $('#mcq').innerHTML = '<div class="card empty"><p>這個來源裡沒有動詞。可以換一個題目來源，或先到字卡把動詞列入考題。</p></div>'; return; }
      return emptyWords($('#mcq'), UI.mcSrc);
    }
    const isRev = UI.mcSrc === 'mcReview';
    const queue = UI.mcSrc === 'recent' ? shuffle(pool) : pickRound(pool, 'mc', isRev ? REVIEW_ROUND : roundSize(), isRev);
    mcRound = { mode: UI.mcMode, queue, idx: 0, total: pool.length, src: UI.mcSrc, pos: UI.pos, right: 0 };
  }
  nextMCQ();
}
function artHint(x) {
  if (x.info) return x.info;
  if (x.kind === 'artprep') { const a = IT.ART_PREPS[x.answer]; return `${x.answer} ＝ ${a.prep} ＋ ${a.art}（${IT.ART_INFO[a.art]}）`; }
  if (x.kind === 'art') return `${x.answer}：${IT.ART_INFO[x.answer] || ''}`;
  return `${x.answer}：${(IT.INDEF_INFO || { un: '陽性', uno: '陽性（s+子音、z 前）', una: '陰性', "un'": '陰性（母音前）' })[x.answer] || ''}`;
}
function nextMCQ() {
  const R = mcRound, host = $('#mcq'); if (!host) return;
  if (R.idx >= R.queue.length) return roundDone(host, R, () => { mcRound = null; renderMC(); });
  const item = R.queue[R.idx];
  const src = { mcWrong: 'wrong', mcReview: 'review' }[R.src] || (R.src === 'learned' ? 'learned' : 'learn');
  const head = `<div class="qhead">${progressLine(R, R.total)}</div>`;
  const next = () => { R.idx++; R.done = false; nextMCQ(); };
  const wordAfter = w => `<div class="example"><div class="row" style="gap:12px;align-items:center"><b lang="${LC.id}" style="font-size:22px">${esc(w.title)}</b><span>${meanW(w)}</span>${iconPlay(w.title, '播放單字')}</div></div>${exampleBlock(w)}`;
  if (R.mode === 'art') {
    if (item.drill) {
      const d = item.drill;
      return renderChoice(host, {
        head, promptHTML: `<div class="sent" lang="${LC.id}">${esc(d[0]).replace('___', '<span class="blank" id="blank">？</span>')}</div><div class="zhline">${esc(d[3])}</div>`,
        options: shuffle([d[1]].concat(d[2])).map(o => ({ html: esc(o), correct: o === d[1], lang: LC.id })),
        onAnswer: ok => { if (ok) R.right++; R.done = true; bumpDay(); const b = $('#blank'); b.textContent = d[1]; b.classList.add(ok ? 'ok' : 'ng'); }
      }, next);
    }
    const w = item, x = IT.makeArtQuestion(w.e, LOOK);
    return renderChoice(host, {
      head, promptHTML: `<div class="sent" lang="${LC.id}">${sentHTML(x.sentence, { blank: [x.before.length, x.before.length + x.answer.length], blankHTML: '<span class="blank" id="blank">？</span>', noGen: true })}</div><div class="zhline">${esc(x.zh)}</div>`,
      options: x.options.map(o => ({ html: esc(o), correct: o === x.answer, lang: LC.id })),
      onAnswer: ok => { if (ok) R.right++; R.done = true; bumpDay(); const b = $('#blank'); b.textContent = x.answer; b.classList.add(ok ? 'ok' : 'ng'); },
      afterHTML: () => `<div class="hint"><span>${esc(artHint(x))}</span></div>${wordAfter(w)}`
    }, next);
  }
  const w = item;
  if (R.mode === 'verb') {
    const q = IT.makeVerbQuestion(w.e);
    return renderChoice(host, {
      head, promptHTML: `<div class="mid" lang="${LC.id}">${esc(q.subj)} ＋ ${esc(w.word)}</div><span class="meta">${esc(q.label || (q.tense === 'passato' ? LC.pastLabel : '現在式'))}・${esc(w.zh)}</span>`,
      options: q.options.map(o => ({ html: esc(o), correct: o === q.answer, lang: LC.id })),
      onAnswer: ok => { if (ok) R.right++; R.done = true; record(w, 'mc', ok, src); },
      afterHTML: () => `<div class="hint"><span>正確答案：<b lang="${LC.id}">${esc(q.answer)}</b></span><button class="linkbtn" data-word="${esc(w.id)}" style="align-self:flex-start">看完整變化表</button></div>`
    }, next);
  }
  const opts = shuffle([w, ...pickWordDistractors(w, R.mode)]);
  let prompt;
  if (R.mode === 'it2zh') prompt = `<div class="word-row"><div class="big${lenCls(w.title)}" lang="${LC.id}">${esc(w.title)}</div>${iconPlay(w.title, '播放單字')}</div><span class="pos">${esc(POS_ZH[w.pos])}</span>`;
  else if (R.mode === 'zh2it') prompt = `<div class="zh">${meanW(w)}</div><span class="pos">${esc(POS_ZH[w.pos])}</span>`;
  else prompt = `<button class="btn solid" data-say="${esc(w.title)}" style="min-width:160px">${ICON.play}播放發音</button><span class="meta">按下按鈕聽發音，再選出意思</span>`;
  renderChoice(host, {
    head, promptHTML: prompt,
    options: opts.map(o => R.mode === 'zh2it' ? { html: esc(o.title), correct: o.id === w.id, lang: LC.id } : { html: meanW(o), correct: o.id === w.id }),
    onAnswer: ok => { if (ok) R.right++; R.done = true; record(w, 'mc', ok, src); },
    afterHTML: () => wordAfter(w)
  }, next);
  if (R.mode === 'it2zh' || R.mode === 'listen') setTimeout(() => Voice.speak(w.title), 250);
}

// ================= 字卡 =================
let deck = null;
const CARD_SRCS = [['new', '新字'], ['queued', '待考'], ['mcWrong', '單選錯題'], ['fillWrong', '填空錯題'], ['mcReview', '單選錯題複習'], ['fillReview', '填空錯題複習'], ['learned', '複習已學會']];
function renderCard() {
  const host = $('#tab-card');
  Quiz.active = null;
  const counts = Object.fromEntries(CARD_SRCS.map(([k]) => [k, filtered(k).length]));
  host.innerHTML = `<div class="ctl">${pillSelect('cardSrc', '字卡來源', CARD_SRCS.map(([k, l]) => [k, `${l} ${counts[k]}`]), UI.cardSrc)}${posChips()}</div><div id="fcHost"></div>`;
  $('#cardSrc', host).onchange = e => { UI.cardSrc = e.target.value; saveUI(); deck = null; renderCard(); };
  bindPos(host, () => { deck = null; renderCard(); });
  const valid = deck && deck.src === UI.cardSrc && deck.pos === UI.pos;
  if (!valid || !deck.cards.length) {
    const pool = filtered(UI.cardSrc);
    if (!pool.length) {
      const msg = { new: '這個分類的新字都看過了。', queued: '還沒有待考的字。' }[UI.cardSrc] || '這個分類目前沒有字。';
      $('#fcHost').innerHTML = `<div class="card empty"><p>${msg}</p>${UI.cardSrc !== 'new' ? '<button class="btn solid" id="toNew">看新字</button>' : ''}</div>`;
      const b = $('#toNew'); if (b) b.onclick = () => { UI.cardSrc = 'new'; saveUI(); deck = null; renderCard(); };
      return;
    }
    const isRev = /Review$/.test(UI.cardSrc);
    const cards = UI.cardSrc === 'new' ? pool.slice(0, roundSize()) : pickRound(pool, /^fill/.test(UI.cardSrc) ? 'fill' : 'mc', isRev ? REVIEW_ROUND : roundSize(), isRev);
    deck = { src: UI.cardSrc, pos: UI.pos, cards, total: pool.length };
  }
  showFlash();
}
function formsLine(w) {
  if (IT.formsLine) { const h = IT.formsLine(w.e); if (h != null) return h ? `<span lang="${LC.id}">${esc(h)}</span>` : ''; }
  if (w.pos === 'n') { const f = IT.nounForms(w.e); return f.pl ? `複數：<span lang="${LC.id}">${esc(f.pl)}</span>` : (f.plOnly ? '只用複數' : ''); }
  if (w.pos === 'adj') return `<span lang="${LC.id}">${esc(IT.adjForms(w.e).join(' / '))}</span>`;
  if (isVerbPos(w.pos)) { const c = IT.conjugate(w.word, w.pos); return `<span lang="${LC.id}">${esc(c.presentFull.slice(0, 3).join('、'))}…</span>`; }
  return '';
}
function showFlash() {
  const host = $('#fcHost');
  if (!deck.cards.length) {
    host.innerHTML = '<div class="card empty"><p style="color:var(--fg);font-weight:700">這一疊看完了</p><button class="btn solid" id="moreCards">再拿一疊</button></div>';
    $('#moreCards').onclick = () => { deck = null; renderCard(); };
    return;
  }
  const w = deck.cards[0];
  const r = getRec(w.id);
  const isWrong = /Wrong|Review/.test(deck.src);
  const tags = [];
  if (r.w && r.w.mc) tags.push(`單選${r.w.mc === 1 ? '答錯' : '錯題複習中'}`);
  if (r.w && r.w.fill) tags.push(`填空${r.w.fill === 1 ? '答錯' : '錯題複習中'}`);
  const btns = deck.src === 'new'
    ? `<button class="btn known" data-a="known">${ICON.ok}已經會了</button><button class="btn solid" data-a="queue">列入考題</button>`
    : '<button class="btn solid wide" data-a="next">下一張</button>';
  const fl = formsLine(w);
  host.innerHTML = `<div class="card fc">
    <div class="qhead"><div class="qh-l">${posBadge(w)}<span class="meta">剩 ${deck.cards.length} · 共 ${deck.total}</span></div></div>
    ${isWrong && tags.length ? `<div class="row">${tags.map(t => `<span class="tag">${t}</span>`).join('')}</div>` : ''}
    <div class="word-row"><div class="word${lenCls(w.title)}" lang="${LC.id}">${esc(w.title)}</div>${iconPlay(w.title, '播放單字')}</div>
    <div class="zh">${meanW(w)}</div>
    ${fl ? `<div class="forms">${fl}</div>` : ''}
    ${exampleBlock(w)}
    <div class="fcbtns">${btns}</div>
  </div>`;
  $$('[data-a]', host).forEach(b => b.onclick = () => {
    const a = b.dataset.a;
    deck.cards.shift();
    if (a === 'queue') { touch(w.id, { s: 'queued' }); toast('已列入考題'); }
    if (a === 'known') { const gap = SRS[1] + Math.floor(Math.random() * 8); touch(w.id, { s: 'learned', lv: 1, due: addDays(today(), gap) }); toast(`已標記為學會，${gap} 天後會再考一次`); }
    showFlash();
    if (a !== 'next') updateCardCounts();
  });
}
function updateCardCounts() {
  const sel = $('#cardSrc'); if (!sel) return;
  [...sel.options].forEach(o => { const l = CARD_SRCS.find(x => x[0] === o.value); if (l) o.textContent = `${l[1]} ${filtered(o.value).length}`; });
}

// ================= 填空 =================
let fillRound = null;
const FILL_SRCS = [['learn', '待考'], ['recent', '最近學過'], ['fillWrong', '填空錯題'], ['fillReview', '錯題複習'], ['due', '到期複習']];
function renderFill() {
  const host = $('#tab-fill');
  Quiz.active = null;
  const counts = Object.fromEntries(FILL_SRCS.map(([k]) => [k, srcPool(k).length]));
  host.innerHTML = `<div class="ctl">${pillSelect('fillSrc', '題目來源', FILL_SRCS.map(([k, l]) => [k, `${l} ${counts[k]}`]), UI.fillSrc)}${UI.fillSrc === 'recent' ? recentCtl().html : posChips()}</div><div id="fq"></div>`;
  $('#fillSrc', host).onchange = e => { UI.fillSrc = e.target.value; saveUI(); fillRound = null; renderFill(); };
  recentCtl(renderFill).bind(host);
  bindPos(host, () => { fillRound = null; renderFill(); });
  if (fillRound && fillRound.done) { fillRound.idx++; fillRound.done = false; }
  const valid = fillRound && fillRound.src === UI.fillSrc && (UI.fillSrc === 'recent' || fillRound.pos === UI.pos);
  if (!valid || fillRound.idx >= fillRound.queue.length) {
    if (valid && fillRound.queue.length && fillRound.idx >= fillRound.queue.length) return roundDone($('#fq'), fillRound, () => { fillRound = null; renderFill(); });
    const pool = srcPool(UI.fillSrc);
    if (!pool.length) return emptyWords($('#fq'), UI.fillSrc);
    const isRev = UI.fillSrc === 'fillReview';
    fillRound = { queue: UI.fillSrc === 'recent' ? shuffle(pool) : pickRound(pool, 'fill', isRev ? REVIEW_ROUND : roundSize(), isRev), idx: 0, total: pool.length, src: UI.fillSrc, pos: UI.pos, right: 0 };
  }
  nextFillQ();
}
// 答案在例句裡的位置
function answerSpan(w) {
  const toks = []; let p = 0;
  for (const t of IT.tokenize(w.sent)) { toks.push({ t: t.t, w: t.w, s: p }); p += t.t.length; }
  const aw = IT.tokenize(w.ans).filter(t => t.w).map(t => IT.norm(t.t).toLowerCase());
  const ws = toks.filter(t => t.w);
  for (let i = 0; i + aw.length <= ws.length; i++) {
    if (aw.every((x, j) => IT.norm(ws[i + j].t).toLowerCase() === x)) { const last = ws[i + aw.length - 1]; return [ws[i].s, last.s + last.t.length]; }
  }
  return [0, 0];
}
const letterCount = s => s.replace(/[^\p{L}]/gu, '').length;
function nextFillQ(keepFocus) {
  const R = fillRound, host = $('#fq'); if (!host) return;
  if (R.idx >= R.queue.length) { document.body.classList.remove('typing'); return roundDone(host, R, () => { fillRound = null; renderFill(); }); }
  const w = R.queue[R.idx];
  const src = { fillWrong: 'wrong', fillReview: 'review', due: 'due' }[R.src] || 'learn';
  const [a0, a1] = answerSpan(w);
  const ans = w.sent.slice(a0, a1);
  const n = letterCount(ans);
  const blankEmpty = '＿'.repeat(Math.max(2, Math.min(Math.ceil(ans.length / 2), 6)));
  const showHint = SET.fillHint === 'show';
  const hint = n > 1 ? `<span class="meta" id="fillHint"${showHint ? '' : ' hidden'}>提示：第一個字母是 <b style="color:var(--fg)">${esc(ans[0])}</b>，共 ${n} 個字母${/ /.test(ans) ? `（${ans.split(' ').length} 個字）` : ''}</span>` : '';
  host.innerHTML = `<div class="card" id="fillCard">
    <div class="qhead">${progressLine(R, R.total)}</div>
    <div class="row" style="margin-top:6px">${posBadge(w)}<b>${meanW(w)}</b></div>
    <div class="sent" lang="${LC.id}" style="margin-top:8px">${sentHTML(w.sent, { blank: [a0, a1], blankHTML: `<span class="blank" id="blank">${blankEmpty}</span>` })}</div>
    <div class="hint" style="margin-top:8px"><span>${esc(w.sentZh)}</span>${hint}</div>
    <form class="answerrow" id="fillForm" style="margin-top:12px" autocomplete="off">
      <input id="fillIn" type="text" lang="${LC.id}" inputmode="text" autocapitalize="off" autocorrect="off" spellcheck="false" enterkeyhint="go" placeholder="輸入${LC.name}" aria-label="填入答案">
      <button class="btn solid" type="submit" id="fillGo">送出</button>
    </form>
    <div class="btnrow" style="margin-top:12px">${n > 1 ? `<button class="btn quiet" id="fillHintBtn" aria-pressed="${showHint}">${showHint ? '收起提示' : '提示'}</button>` : ''}<button class="btn quiet" id="fillShow">看答案</button></div>
    <div id="fillAfter"></div>
  </div>`;
  const inp = $('#fillIn'), blank = $('#blank');
  let answered = false, triedSyn = false;
  inp.addEventListener('input', () => { blank.textContent = inp.value || blankEmpty; });
  const hb = $('#fillHintBtn');
  if (hb) hb.onclick = () => {
    const h = $('#fillHint'); const on = h.hidden;
    h.hidden = !on; hb.textContent = on ? '收起提示' : '提示'; hb.setAttribute('aria-pressed', String(on));
    Sfx.tick && Sfx.tick();
  };
  const finish = (res, shown) => {
    answered = true; R.done = true;
    const ok = res !== 'wrong';
    if (ok) R.right++;
    record(w, 'fill', ok, src);
    ok ? Sfx.ok() : Sfx.ng(); buzz(ok);
    blank.textContent = ans; blank.classList.add(ok ? 'ok' : 'ng');
    inp.readOnly = true;
    $('#fillGo').textContent = '下一題';
    $('#fillShow').hidden = true; if (hb) hb.hidden = true; const fh = $('#fillHint'); if (fh) fh.hidden = true;
    const r = getRec(w.id);
    const learnedNow = ok && r.s === 'learned' && r.lv === 0 && r.due === addDays(today(), 1) && src !== 'due';
    $('#fillAfter').innerHTML = `<div class="afterbox">
      ${verdict(ok, shown ? '（看了答案）' : res === 'accent' ? (LC.accentNote || '，但注意重音') : '', res === 'accent')}
      ${res === 'accent' ? `<div class="hl-warn">正確寫法：<b lang="${LC.id}">${markDiff(ans, inp.value.trim())}</b>（你寫的是 ${esc(inp.value.trim())}）</div>` : ''}
      ${!ok ? `<div>正確答案：<b lang="${LC.id}" style="font-size:20px">${esc(ans)}</b>${inp.value && !shown ? `<br><span class="meta">你的答案：${esc(inp.value)}</span>` : ''}</div>` : ''}
      ${learnedNow ? `<div class="meta">已學會，明天（${r.due.slice(5).replace('-', '/')}）會出現在到期複習。</div>` : ''}
      ${ok && src === 'due' ? `<div class="meta">下次複習：${r.due.slice(5).replace('-', '/')}</div>` : ''}
      <div class="row" style="gap:12px;align-items:center"><b lang="${LC.id}" style="font-size:20px">${esc(w.title)}</b><span>${meanW(w)}</span>${iconPlay(w.title, '播放單字')}</div>
      ${exampleBlock(w)}
    </div>`;
    if (!ok) revealAboveTabbar($('#fillGo'));
    Voice.speak(w.sent);
  };
  const next = () => { R.idx++; R.done = false; nextFillQ(true); };
  $('#fillForm').addEventListener('submit', e => {
    e.preventDefault();
    if (answered) return next();
    if (!inp.value.trim()) { inp.focus(); return; }
    const res = IT.checkAnswer(inp.value, ans, w);
    // 填了意思相同的另一個字（例如「您好」填了 привет）：不算錯，提示再試一次
    const syn = res === 'wrong' ? synonymOf(inp.value, w) : null;
    if (syn && !triedSyn) {
      triedSyn = true;
      $('#fillAfter').innerHTML = `<div class="hl-warn"><b lang="${LC.id}">${esc(syn.title)}</b> 是「${esc(meanPlain(syn))}」，意思很接近，但這題要的是另一個字，再想想看。</div>`;
      const h = $('#fillHint'); if (h) h.hidden = false; if (hb) hb.hidden = true;
      inp.select(); Sfx.tick && Sfx.tick();
      return;
    }
    finish(res, false);
  });
  $('#fillGo').addEventListener('mousedown', e => e.preventDefault());
  $('#fillShow').onclick = () => { if (!answered) finish('wrong', true); };
  inp.addEventListener('focus', () => { document.body.classList.add('typing'); setTimeout(scrollFillTop, 280); });
  inp.addEventListener('blur', () => setTimeout(() => { const a = document.activeElement; if (!a || a.id !== 'fillIn') document.body.classList.remove('typing'); }, 250));
  if (keepFocus && window.matchMedia('(pointer:fine)').matches) inp.focus({ preventScroll: true });
  else if (keepFocus && document.body.classList.contains('typing')) { inp.focus({ preventScroll: true }); scrollFillTop(); }
}
// 填的字是不是另一個意思相同的單字（看原形和它的變化形）
function synonymOf(input, w) {
  const k = IT.norm(String(input).trim()).toLowerCase().replace(/[?!.,]$/, '');
  if (!k) return null;
  const cands = [];
  WORDS.forEach(x => { if (x.id !== w.id && IT.checkAnswer(input, IT.plain ? IT.plain(x.word) : x.word, x) !== 'wrong') cands.push(x); });
  (LOOK.get(k) || []).forEach(x => { if (x.idx >= 0) { const o = WMAP[idOfEntry(IT.W[x.idx])]; if (o && o.id !== w.id) cands.push(o); } });
  return cands.find(o => sameMeaning(o.zh, w.zh) || sameMeaning(o.en, w.en)) || null;
}
// 拼寫提醒：把和你寫的不一樣的字母畫底線（長度一樣才逐字比）
function markDiff(ans, mine) {
  const A = [...ans], B = [...(IT.plain ? IT.plain(mine) : mine)];
  if (A.length !== B.length) return esc(ans);
  return A.map((c, i) => c.toLowerCase() !== B[i].toLowerCase() ? `<u style="text-decoration-thickness:2px;text-underline-offset:4px">${esc(c)}</u>` : esc(c)).join('');
}
function scrollFillTop() {
  const card = $('#fillCard');
  if (!card || !document.body.classList.contains('typing')) return;
  window.scrollTo({ top: Math.max(0, card.getBoundingClientRect().top + window.scrollY - 6), behavior: 'smooth' });
}
if (window.visualViewport) window.visualViewport.addEventListener('resize', () => { if (document.body.classList.contains('typing')) scrollFillTop(); });

// ================= 文法 =================
let GIDX = null, gramShow = 8, gramPane = 'body', gramPaneId = '';
function gramIndex() {
  if (GIDX) return GIDX;
  GIDX = {};
  for (const g of IT.GRAMMAR) {
    const out = (g.ex || []).map(x => ({ s: x[0], zh: x[1], r: IT.grammarMatch(g, x[0]) }));
    for (const w of WORDS) { const r = IT.grammarMatch(g, w.sent); if (r.length) out.push({ s: w.sent, zh: w.sentZh, r, w }); }
    const seen = new Set();
    GIDX[g.id] = out.filter(x => !seen.has(x.s) && seen.add(x.s)).sort((a, b) => (a.w ? 1 : 0) - (b.w ? 1 : 0) || a.s.length - b.s.length);
  }
  return GIDX;
}
const plain = h => h.replace(/<[^>]+>/g, '');
// 文法列表的預覽：跳過表格，取說明文字；整段都是表格時，把格子用空白分開
const gramPreview = h => { const t = plain(h.replace(/<table[\s\S]*?<\/table>/g, ' ')).trim(); return (t || plain(h.replace(/<\/t[dh]>/g, ' '))).replace(/\s+/g, ' ').trim().slice(0, 60); };
const RULE_SHORT = LC.ruleShort || {};
function ruleDemo(R) {
  const find = (word, pos) => WORDS.find(w => w.word === word && (!pos || w.pos === pos || (pos === 'v' && isVerbPos(w.pos))));
  if (IT.demoTable) {
    const t = IT.demoTable(R.id, R.demo.map(x => find(x, 'n') || find(x, 'adj') || (IT.VERB_TABLE ? find(x) : null)).filter(Boolean).map(w => w.e));
    if (t) return `<div class="scroll-x" style="flex-shrink:0"><table class="t"><thead><tr>${t.head.map(x => `<th>${esc(x)}</th>`).join('')}</tr></thead><tbody>${t.rows.map(r => '<tr>' + r.map(c => c.f ? `<td class="f" lang="${LC.id}">${esc(c.t)}</td>` : `<td class="p">${esc(c.t)}</td>`).join('') + '</tr>').join('')}</tbody></table></div>`;
  }
  if (R.id === 'r-noun') return `<table class="t"><thead><tr><th>單數</th><th>複數</th><th>性別</th></tr></thead><tbody>${R.demo.map(x => find(x, 'n')).filter(Boolean).map(w => { const f = IT.nounForms(w.e); return `<tr><td class="f" lang="${LC.id}">${esc(f.sg)}</td><td class="f" lang="${LC.id}">${esc(f.pl)}</td><td class="p">${genOf(w.e[2])[1]}${f.plGender !== w.e[2] ? '→複數陰' : ''}</td></tr>`; }).join('')}</tbody></table>`;
  if (R.id === 'r-art') {
    const extra = IT.ART_DEMO_EXTRA || { psicologo: ['psicologo', 'n', 'm', 'psicologi'] };
    return `<table class="t"><thead><tr><th>定冠詞</th><th>複數</th><th>不定冠詞</th></tr></thead><tbody>${R.demo.map(x => { const w = find(x, 'n'); return w ? w.e : extra[x]; }).filter(Boolean).map(e => { const f = IT.nounForms(e); return `<tr><td class="f" lang="${LC.id}">${esc(f.sg)}</td><td class="f" lang="${LC.id}">${esc(f.pl)}</td><td lang="${LC.id}">${esc(f.indef + (f.indef.endsWith("'") ? '' : ' ') + e[0])}</td></tr>`; }).join('')}</tbody></table>`;
  }
  if (R.id === 'r-adj') return `<div class="scroll-x"><table class="t"><thead><tr><th>陽單</th><th>陰單</th><th>陽複</th><th>陰複</th></tr></thead><tbody>${R.demo.map(x => find(x, 'adj')).filter(Boolean).map(w => '<tr>' + IT.adjForms(w.e).map(x => `<td class="f" lang="${LC.id}">${esc(x)}</td>`).join('') + '</tr>').join('')}</tbody></table></div>`;
  return R.demo.map(x => find(x, 'v')).filter(Boolean).map(w => `<div class="rc-row" data-vk="${esc(w.id)}"><div class="rc-h"><b lang="${LC.id}">${esc(w.word)}</b><span class="meta">${esc(w.zh)}</span></div>${verbInfo(w)}
    <div class="seg" role="group" aria-label="時態 ${esc(w.word)}" style="margin:8px 0"><button data-tense="pres" aria-pressed="true">${esc(IT.conjugate(w.word, w.pos).presTab || '現在式')}</button><button data-tense="pass" aria-pressed="false">過去式</button><button data-tense="imp" aria-pressed="false">命令式</button></div><div class="vt">${conjTable(w, 'pres')}</div></div>`).join('');
}
// ================= 文法範例拆解＋練習題（IT.GX） =================
// 說明裡的外文字標上 lang，字型和顏色跟中文分開
function gxNote(t) {
  const re = LC.id === 'ru' ? /[Ѐ-ӿ́]+(?:[ -‑][Ѐ-ӿ́]+)*/g : /[A-Za-zÀ-ÿ̀-ͯ'’]+(?:[ -][A-Za-zÀ-ÿ̀-ͯ'’]+)*/g;
  return esc(t).replace(re, m => `<span class="gx-fw" lang="${LC.id}">${m}</span>`);
}
function gxExamplesHTML(gx) {
  return `<p class="meta gx-tip">上面是整句，中間每個字下面是它的中文，最後一條一條說明為什麼這樣排。點句子裡的字可以查意思。</p>` + gx.ex.map(([s, zh, parts, notes, pl], i) => `<div class="gx-ex">
    <div class="gx-n">範例 ${i + 1}</div>
    <div class="ex-row"><div class="sent" lang="${LC.id}">${sentHTML(s, { noGen: true })}</div>${iconPlay(s, '播放範例')}</div>
    <div class="zhline">${esc(zh)}</div>
    <div class="gx-gloss">${parts.map(([w, g]) => g ? `<span class="gx-w"><b lang="${LC.id}">${esc(w)}</b><i>${esc(g)}</i></span>` : `<span class="gx-p" lang="${LC.id}">${esc(w)}</span>`).join('')}</div>
    <ul class="gx-notes">${notes.map(n => `<li>${gxNote(n)}</li>`).join('')}</ul>
    <div class="gx-plain"><b>白話</b><span>${gxNote(pl)}</span></div>
  </div>`).join('') + `<button class="btn solid block gx-go" data-gpane="q">看懂了，來練習（${gx.q.length} 題）</button>`;
}
function startGxQuiz(box, gx) {
  if (!box) return;
  const qs = shuffle(gx.q); let i = 0, right = 0;
  const next = () => {
    if (!box.isConnected) return;
    if (i >= qs.length) {
      box.innerHTML = `<div class="gx-done"><div class="gx-score">${right} / ${qs.length}</div><p>${right === qs.length ? '全對！這個文法你會了。' : right ? '差一點，看一下範例再練一次。' : '先看範例拆解，再回來試試。'}</p><div class="btnrow"><button class="btn solid" id="gxAgain">再練一次</button><button class="btn quiet" data-gpane="ex">看範例</button></div></div>`;
      $('#gxAgain', box).onclick = () => startGxQuiz(box, gx);
      $$('[data-gpane]', box).forEach(b => b.onclick = () => { gramPane = b.dataset.gpane; renderGram(); });
      return;
    }
    const [pr, ans, wr, zh, why] = qs[i++];
    const full = pr.replace('___', ans).replace(/\s+([.,!?…])/g, '$1');
    renderChoice(box, {
      head: `<div class="qhead"><span class="meta">文法練習 ${i} / ${qs.length}</span></div>`,
      promptHTML: `<div class="sent" lang="${LC.id}">${esc(pr).replace('___', '<span class="blank" id="blank">？</span>')}</div><div class="zhline">${esc(zh)}</div>`,
      options: shuffle([ans].concat(wr)).map(o => ({ html: esc(o), correct: o === ans, lang: LC.id })),
      onAnswer: ok => { if (ok) right++; bumpDay(); const b = $('#blank', box); if (b) { b.textContent = ans; b.classList.add(ok ? 'ok' : 'ng'); } },
      explain: `<div class="gx-why"><div class="ex-row"><div class="sent" lang="${LC.id}">${esc(full)}</div>${iconPlay(full, '播放整句')}</div><p><b>為什麼：</b>${gxNote(why)}</p></div>`,
      noAuto: true
    }, next);
  };
  next();
}
function renderGram() {
  const host = $('#tab-gram');
  Quiz.active = null;
  const back = () => { UI.gramSel = ''; saveUI(); renderGram(); window.scrollTo(0, 0); };
  const rule = IT.RULES.find(r => r.id === UI.gramSel);
  if (rule) {
    const words = WORDS.filter(w => rule.filter(w.e));
    host.innerHTML = `<button class="gr-back" id="grBack">‹ 文法列表</button>
      <div class="card"><div class="gr-head"><h2>${esc(rule.title)}</h2><span class="lv">詞性變化規則</span></div><div class="gbody scroll-x">${rule.body}</div></div>
      <div class="card"><div class="gp-title">實際變化例子</div><div class="rc-list">${ruleDemo(rule)}</div></div>
      <div class="card"><div class="gp-title">App 裡的字（${words.length}）</div><p class="meta" style="margin:4px 0 10px">點一下看完整的變化表。</p><div class="rc-words">${words.map(w => `<button class="rc-w" data-word="${esc(w.id)}" lang="${LC.id}">${esc(w.title)}</button>`).join('')}</div></div>`;
    $('#grBack', host).onclick = back;
    $$('[data-vk]', host).forEach(box => $$('[data-tense]', box).forEach(b => b.onclick = () => { $$('[data-tense]', box).forEach(x => x.setAttribute('aria-pressed', String(x === b))); $('.vt', box).innerHTML = conjTable(WMAP[box.dataset.vk], b.dataset.tense); }));
    return;
  }
  const idx = gramIndex();
  const p = IT.GRAMMAR.find(g => g.id === UI.gramSel);
  if (!p) {
    const q = (UI.gramQ || '').trim().toLowerCase();
    const hit = g => !q || (g.title + g.tag + plain(g.body)).toLowerCase().includes(q);
    const rhit = IT.RULES.filter(r => !q || (r.title + plain(r.body)).toLowerCase().includes(q));
    const tags = []; IT.GRAMMAR.forEach(g => { if (!tags.includes(g.tag)) tags.push(g.tag); });
    const groups = tags.map(t => [t, IT.GRAMMAR.filter(g => g.tag === t && hit(g))]).filter(x => x[1].length);
    host.innerHTML = `<input class="gr-search" id="grQ" type="search" placeholder="${esc(LC.gramPh || '搜尋文法：冠詞、piace、過去式…')}" value="${esc(UI.gramQ || '')}" aria-label="搜尋文法">
      ${rhit.length ? `<div class="gr-group"><h3>詞性變化規則</h3><div class="rc-grid">${rhit.map(r => `<button class="gr-row rc-tile" data-gram="${r.id}"><b>${esc(RULE_SHORT[r.id] || r.title)}</b><span class="gd">${WORDS.filter(w => r.filter(w.e)).length} 個字</span></button>`).join('')}</div></div>` : ''}
      ${groups.map(([h, ps]) => `<div class="gr-group"><h3>${esc(h)}</h3>${ps.map(g => `<button class="gr-row" data-gram="${g.id}"><b>${esc(g.title)}</b><span class="gn"><span>${(idx[g.id] || []).length}</span>›</span><span class="gd">${esc(gramPreview(g.body))}</span></button>`).join('')}</div>`).join('')}
      ${!rhit.length && !groups.length ? '<p class="meta">找不到符合的文法。</p>' : ''}`;
    const inp = $('#grQ', host);
    inp.oninput = () => { UI.gramQ = inp.value; const pos = inp.selectionStart; renderGram(); const i = $('#grQ'); i.focus(); try { i.setSelectionRange(pos, pos); } catch (e) {} };
    return;
  }
  const exs = idx[p.id] || [];
  const gx = IT.GX && IT.GX[p.id];
  if (gramPaneId !== p.id) { gramPane = 'body'; gramPaneId = p.id; }
  if (!gx) gramPane = 'body';
  const seg = gx ? `<div class="seg gx-seg" role="group" aria-label="文法分頁">${[['body', '說明'], ['ex', '看範例'], ['q', '練習題']].map(([k, l]) => `<button data-gpane="${k}" aria-pressed="${gramPane === k}">${l}</button>`).join('')}</div>` : '';
  const pane = gramPane === 'ex' ? gxExamplesHTML(gx) : gramPane === 'q' ? '<div id="gxQuiz" class="gx-quiz"></div>' : `<div class="gbody scroll-x">${p.body}</div>${gx ? `<div class="btnrow gx-cta"><button class="btn quiet" data-gpane="ex">看範例拆解</button><button class="btn solid" data-gpane="q">練習這個文法（${gx.q.length} 題）</button></div>` : ''}`;
  host.innerHTML = `<button class="gr-back" id="grBack">‹ 文法列表</button>
    <div class="card"><div class="gr-head"><h2>${esc(p.title)}</h2><span class="lv">${esc(p.tag)}</span></div>${seg}${pane}</div>
    ${gramPane !== 'body' ? '' : `<div class="card"><div class="gp-title" style="margin-bottom:8px">App 裡用到的例句（${exs.length}）</div><p class="meta" style="margin:0 0 6px">黃色是這個文法點，點任何一個字可以查意思。</p>
      ${exs.length ? `<div class="gr-exs">${exs.slice(0, gramShow).map(x => `<div class="gr-ex"><div class="ex-row"><div class="sent" lang="${LC.id}">${sentHTML(x.s, { ranges: x.r })}</div>${iconPlay(x.s, '播放例句')}</div><div class="zhline">${esc(x.zh)}</div>${x.w ? `<div class="from">出自單字：<span lang="${LC.id}">${esc(x.w.title)}</span>（${esc(meanPlain(x.w))}）</div>` : ''}</div>`).join('')}</div>${exs.length > gramShow ? `<button class="btn quiet gr-more" id="grMore">再顯示 ${Math.min(8, exs.length - gramShow)} 句（共 ${exs.length} 句）</button>` : ''}` : '<p class="meta">目前的例句裡還沒有用到這個文法。</p>'}
    </div>`}`;
  $('#grBack', host).onclick = back;
  $$('[data-gpane]', host).forEach(b => b.onclick = () => { gramPane = b.dataset.gpane; renderGram(); const c = $('.gr-head', host); if (c && c.getBoundingClientRect().top < 0) c.scrollIntoView({ block: 'start' }); });
  if (gramPane === 'q') startGxQuiz($('#gxQuiz', host), gx);
  const m = $('#grMore', host); if (m) m.onclick = () => { gramShow += 8; renderGram(); };
}
document.addEventListener('click', e => {
  const b = e.target.closest('[data-gram]');
  if (b) { e.preventDefault(); UI.gramSel = b.dataset.gram; gramShow = 8; saveUI(); if (UI.tab !== 'gram') showTab('gram'); else { renderGram(); window.scrollTo(0, 0); } }
});

// ================= 單字庫 =================
let libList = 'queued';
function libCounts() {
  const t = today(), rset = recentIds();
  const c = { total: WORDS.length, learned: 0, queued: 0, excluded: 0, due: 0, dueAll: 0, mcW: 0, mcR: 0, fillW: 0, fillR: 0, recent: 0 };
  for (const w of WORDS) {
    const r = getRec(w.id);
    if (r.s === 'learned') { c.learned++; if (r.due && r.due <= t) c.dueAll++; }
    if (r.s === 'queued') c.queued++;
    if (r.s === 'excluded') c.excluded++;
    if (rset.has(w.id)) c.recent++;
    const ww = r.w || {};
    if (ww.mc === 1) c.mcW++; if (ww.mc === 2) c.mcR++;
    if (ww.fill === 1) c.fillW++; if (ww.fill === 2) c.fillR++;
  }
  c.due = dueToday().size;
  return c;
}
// 切換語言選單裡的進度條（lang.js）
if (window.AppLangs && AppLangs.stats) AppLangs.stats(() => { const c = libCounts(); return { l: c.learned, t: Math.max(1, c.total - c.excluded) }; });
const entryBtn = (tab, src, title, n) => `<button data-go="${tab}:${src}"${n ? '' : ' class="zero"'}><span>${title}</span><b>${n}</b></button>`;
function renderLib() {
  Quiz.active = null;
  const host = $('#tab-lib');
  const c = libCounts();
  const pct = Math.round(c.learned / Math.max(1, c.total - c.excluded) * 100);
  const ents = [['fill', 'due', '到期複習', c.due], ['mc', 'mcWrong', '單選錯題', c.mcW], ['fill', 'fillWrong', '填空錯題', c.fillW], ['mc', 'mcReview', '單選錯題複習', c.mcR], ['fill', 'fillReview', '填空錯題複習', c.fillR], ['mc', 'recent', '單選最近學過', c.recent], ['fill', 'recent', '填空最近學過', c.recent], ['mc', 'learned', '複習單選', c.learned], ['card', 'learned', '複習字卡', c.learned]].filter(x => x[3] > 0);
  host.innerHTML = `<div id="authTop"></div>
    <div class="stats">
      <div class="stat"><b>${pct}%</b><span>已學會</span></div><div class="stat"><b>${c.due}</b><span>今天到期</span></div><div class="stat"><b>${c.queued}</b><span>待考</span></div><div class="stat"><b>${c.mcW}</b><span>單選錯題</span></div><div class="stat"><b>${c.fillW}</b><span>填空錯題</span></div>
    </div>
    <div class="search"><input id="q" type="search" placeholder="搜尋：${LC.name}、中文或英文" aria-label="搜尋單字" autocomplete="off" autocapitalize="off" spellcheck="false" value="${esc(UI.libQ || '')}"></div>
    <div class="results" id="results"></div>
    ${ents.length ? `<div class="entry">${ents.map(x => entryBtn(...x)).join('')}</div>` : '<p class="meta" style="margin:0">目前沒有要複習的題目。練習時答錯的字、到期的字會出現在這裡。</p>'}
    <details class="lst" id="listBox"><summary>清單（待考、已學會、錯題）</summary>
      <div class="chips lst-chips">${[['queued', '待考', c.queued], ['learned', '已學會', c.learned], ['mcWrong', '單選錯題', c.mcW], ['mcReview', '單選複習', c.mcR], ['fillWrong', '填空錯題', c.fillW], ['fillReview', '填空複習', c.fillR]].map(([k, l, n]) => `<button class="chip" data-list="${k}" aria-pressed="${libList === k}">${l}<span class="n">${n}</span></button>`).join('')}</div>
      <div class="lrows"></div>
    </details>
    <details class="lst"${Cloud.mode === 'google' && !Cloud.user ? ' open' : ''}><summary>設定<span class="n sync${Cloud.ref ? ' on' : ''}" id="syncState"><i></i><span>${esc(Cloud.chip())}</span></span></summary>
      <div class="setgrp">
        <section><h4>${LC.name}發音</h4><div id="voiceBox"></div></section>
        <section><h4>音效</h4>
          <label class="label" for="sfxSel">按鈕和答題音效</label>
          <select id="sfxSel">${[['on', '開'], ['low', '小聲'], ['off', '關']].map(([k, l]) => `<option value="${k}"${SET.sfx === k ? ' selected' : ''}>${l}</option>`).join('')}</select>
          <div class="meta">答對、答錯、按按鈕時的短音效。手機開靜音模式時通常不會出聲。</div>
          <label class="label" for="vibSel" style="margin-top:6px">答題震動</label>
          <select id="vibSel"${canVibrate ? '' : ' disabled'}>${[['on', '開'], ['off', '關']].map(([k, l]) => `<option value="${k}"${SET.vib === k ? ' selected' : ''}>${l}</option>`).join('')}</select>
          <div class="meta">${canVibrate ? '答對短震一下，答錯震兩下。' : '這個瀏覽器不支援震動（iPhone 的網頁 App 目前都不支援）。'}</div>
          <button class="btn quiet" id="vibTest" style="min-height:40px;margin-top:6px">測試震動</button>
          <div class="label" style="margin-top:6px">試聽（同一類按鈕用同一個聲音）</div>
          <div class="sfx-try">${[['blue', '青軸：列入考題、下一題'], ['soft', '輕聲嘎：次要按鈕'], ['wood', '木魚：底部分頁'], ['toggle', '開關：上方按鈕'], ['slide', '滑動開關'], ['tick', '滴：篩選標籤'], ['mallet', '木琴：字母'], ['flip', '翻頁：文法、清單'], ['peek', '啾：點單字'], ['pop', '啵：打開選單'], ['ok', '答對'], ['ng', '答錯'], ['done', '一輪完成']].map(([k, l]) => `<button class="chip" data-sfx="${k}">${l}</button>`).join('')}</div>
        </section>
        <section><h4>練習</h4>
          <label class="label" for="roundSel">每輪題數</label>
          <select id="roundSel">${[10, 15, 20, 30, 50, 'all'].map(n => `<option value="${n}"${String(SET.round) === String(n) ? ' selected' : ''}>${n === 'all' ? '全部' : n + ' 題'}</option>`).join('')}</select>
          <label class="label" for="recentSet">「最近學過」的範圍</label>
          <select id="recentSet">${RECENT_OPTS.map(([k, l]) => `<option value="${k}"${SET.recent === k ? ' selected' : ''}>${l}</option>`).join('')}</select>
          <label class="label" for="hintSel">填空的提示（第一個字母、字母數）</label>
          <select id="hintSel"><option value="tap"${SET.fillHint !== 'show' ? ' selected' : ''}>按「提示」才顯示</option><option value="show"${SET.fillHint === 'show' ? ' selected' : ''}>一開始就顯示</option></select>
          <div class="meta">每輪題數會套用到發音練習、單選、字卡和填空。「最近學過」一輪會出完範圍內的全部字；錯題複習每輪 10 題，從以前錯過的字輪流抽，抽過的要等其他字都出過才會再出現。</div>
          <label class="label" for="dueCapSel">每天到期複習最多幾個字</label>
          <select id="dueCapSel">${DUE_CAPS.map(n => `<option value="${n}"${String(SET.dueCap || 30) === String(n) ? ' selected' : ''}>${n === 'all' ? '不限' : n + ' 個'}</option>`).join('')}</select>
          <div class="meta">到期的字很多時，先出到期最久的；今天沒做到的明天接著做。答錯一次只降兩級，不會整個重來。</div>
        </section>
        <section><h4>介面語言 Language</h4>
          <label class="label" for="langSel">介面語言</label>
          <select id="langSel"><option value="zh"${SET.lang !== 'en' ? ' selected' : ''}>中文（繁體）</option><option value="en"${SET.lang === 'en' ? ' selected' : ''}>English</option></select>
          <div class="meta">${LC.name}頁目前只有中文介面；選 English 會套用到日語頁。</div>
        </section>
        <section><h4>單字意思</h4>
          <label class="label" for="meanSel">顯示哪種語言的意思</label>
          <select id="meanSel"><option value="zh"${SET.mean === 'zh' ? ' selected' : ''}>中文</option><option value="en"${SET.mean === 'en' ? ' selected' : ''}>English</option><option value="both"${SET.mean === 'both' ? ' selected' : ''}>中文＋English</option></select>
          <div class="meta">字卡、單選、單字庫和點字看意思都會跟著換。</div>
        </section>
        <section><h4>同步與備份</h4>
          <div class="meta" id="syncLong">${esc(Cloud.label())}</div>
          <div id="authBox"></div>
          <div class="row"><button class="btn quiet" id="exp">匯出進度</button><button class="btn quiet" id="imp">匯入進度</button></div>
          <div class="meta">各語言的進度存在同一個帳號裡；備份碼也是同一串，每個語言頁都能匯入。所有設定（外觀、音效、題數、意思、介面語言）各語言共用，在哪一頁改都一樣。</div>
          <div id="bk"></div>
        </section>
        <section><h4>重設</h4>
          <button class="btn quiet" id="resetIt" style="min-height:40px">清除${LC.name}的學習紀錄</button>
          <div class="meta">只清${LC.name}，其他語言的進度不會動。</div>
        </section>
      </div>
    </details>`;
  $$('[data-go]', host).forEach(b => b.onclick = () => {
    const [tab, src] = b.dataset.go.split(':');
    UI.pos = 'all';
    if (tab === 'mc') { UI.mcSrc = src; if (UI.mcMode === 'art') UI.mcMode = 'it2zh'; mcRound = null; }
    if (tab === 'fill') { UI.fillSrc = src; fillRound = null; }
    if (tab === 'card') { UI.cardSrc = src; deck = null; }
    saveUI(); showTab(tab);
  });
  const lb = $('#listBox');
  lb.addEventListener('toggle', () => { if (lb.open) fillList(lb); });
  $$('[data-list]', lb).forEach(b => b.onclick = () => { libList = b.dataset.list; $$('[data-list]', lb).forEach(x => x.setAttribute('aria-pressed', String(x === b))); fillList(lb); });
  const q = $('#q');
  q.addEventListener('input', () => { UI.libQ = q.value; doSearch(q.value); });
  if (q.value) doSearch(q.value);
  renderVoiceBox(); renderAuthBox();
  $('#roundSel').onchange = e => { SET.round = e.target.value === 'all' ? 'all' : Number(e.target.value); saveSet(); mcRound = null; fillRound = null; deck = null; toast(SET.round === 'all' ? '每輪：全部' : `每輪 ${SET.round} 題`); };
  $('#recentSet').onchange = e => { SET.recent = e.target.value; saveSet(); mcRound = null; fillRound = null; toast(`最近學過：${recentLabel()}`); renderLib(); };
  $('#vibSel').onchange = e => { SET.vib = e.target.value; saveSet(); buzz(true); };
  $('#vibTest').onclick = testBuzz;
  $('#sfxSel').onchange = e => { SET.sfx = e.target.value; saveSet(); if (SET.sfx !== 'off') Sfx.ok(); };
  $('#dueCapSel').onchange = e => { SET.dueCap = e.target.value === 'all' ? 'all' : Number(e.target.value); saveSet(); fillRound = null; toast(SET.dueCap === 'all' ? '到期複習：不限' : `到期複習：每天最多 ${SET.dueCap} 個`); };
  $('#hintSel').onchange = e => { SET.fillHint = e.target.value; saveSet(); fillRound = null; toast(SET.fillHint === 'show' ? '填空提示：一開始就顯示' : '填空提示：按了才顯示'); };
  $('#langSel').onchange = e => { SET.lang = e.target.value; saveSet(); toast(SET.lang === 'en' ? '日語頁會換成英文介面' : '介面語言：中文'); };
  $('#meanSel').onchange = e => { SET.mean = e.target.value; saveSet(); mcRound = null; toast({ zh: '單字意思：中文', en: '單字意思：English', both: '單字意思：中文＋English' }[SET.mean]); };
  $('#resetIt').onclick = () => {
    const el = Sheet.open(`清除${LC.name}紀錄`, `<p style="margin:0">確定要清除${LC.name}的所有學習紀錄嗎？這個動作不能復原，可以先「匯出進度」備份。其他語言的進度不會動。</p><div class="btnrow"><button class="btn quiet" id="rsNo">取消</button><button class="btn solid" id="rsYes">清除</button></div>`);
    $('#rsNo', el).onclick = () => Sheet.close();
    $('#rsYes', el).onclick = () => {
      reloadShared();
      const now = Date.now();
      // 留下空白紀錄（帶時間），同步時其他裝置也會一起清掉
      for (const id in S.items) if (id.startsWith(LP)) S.items[id] = Object.assign(blankRec(), { t: now });
      saveLocal(); Cloud.schedule(); Sheet.close(); deck = null; mcRound = null; fillRound = null; renderLib(); toast(`已清除${LC.name}的紀錄`);
    };
  };
  $('#exp').onclick = async () => {
    reloadShared();
    const txt = await zipCode(packState(S, today()));
    $('#bk').innerHTML = `<textarea id="bkText" readonly aria-label="備份碼" style="min-height:72px">${esc(txt)}</textarea><div class="row" style="margin-top:8px"><button class="btn solid" id="copyBk">複製</button><span class="meta">共 ${txt.length} 字，包含所有語言。</span></div>`;
    $('#copyBk').onclick = () => {
      const ta = $('#bkText');
      const fallback = () => { ta.focus(); ta.select(); toast('已選取，請按複製'); };
      try { navigator.clipboard.writeText(txt).then(() => toast('已複製'), fallback); } catch (e) { fallback(); }
    };
  };
  $('#imp').onclick = () => {
    $('#bk').innerHTML = `<textarea id="impText" placeholder="貼上備份碼（N5 開頭）" aria-label="貼上備份碼"></textarea><div class="row" style="margin-top:8px"><button class="btn solid" id="doImp">合併匯入</button><span class="meta">這裡只匯入${LC.name}；其他語言請在各自的頁面匯入同一串碼。</span></div><div id="impMsg" class="meta"></div>`;
    $('#doImp').onclick = async () => {
      try {
        const raw = $('#impText').value.replace(/\s+/g, '');
        const d = raw.startsWith('N5Z.') ? unpackState(await unzipCode(raw), ALL_IDS) : raw.startsWith('N5.') ? unpackState(raw, ALL_IDS) : JSON.parse(raw);
        if (!d || typeof d.items !== 'object') throw new Error('bad');
        const clean = {};
        for (const id in d.items) if (WMAP[id]) clean[id] = d.items[id];
        reloadShared();
        S = mergeState(S, { items: clean, days: d.days || {} });
        saveLocal(); Cloud.schedule(); renderGoal(); renderLib();
        toast(`已匯入 ${Object.keys(clean).length} 筆${LC.name}紀錄`);
      } catch (e) { $('#impMsg').textContent = '無法讀取：請貼上完整的備份碼（以 N5 開頭）。'; }
    };
  };
}
function fillList(d) {
  const key = libList;
  let arr = wordPool(key);
  if (key === 'learned') arr = arr.slice().sort((a, b) => (getRec(a.id).due || '').localeCompare(getRec(b.id).due || ''));
  const box = $('.lrows', d);
  if (!arr.length) { box.innerHTML = '<div class="lrow"><span class="z">目前是空的</span></div>'; return; }
  const act = { queued: '移除', learned: '移回未學', mcWrong: '移除', mcReview: '移除', fillWrong: '移除', fillReview: '移除' }[key];
  box.innerHTML = arr.map(w => {
    const r = getRec(w.id);
    const dd = key === 'learned' ? `<span class="d">${r.due ? r.due.slice(5).replace('-', '/') : ''} · 第${(r.lv || 0) + 1}級</span>` : '';
    return `<div class="lrow"><span class="w" lang="${LC.id}" data-word="${esc(w.id)}" style="cursor:pointer;font-family:var(--font-ui)">${esc(w.title)}</span><span class="z">${meanW(w)}</span>${dd}<button data-id="${esc(w.id)}">${act}</button></div>`;
  }).join('');
  $$('button[data-id]', box).forEach(b => b.onclick = () => {
    const id = b.dataset.id, r = getRec(id);
    if (key === 'queued') touch(id, { s: 'new' });
    else if (key === 'learned') touch(id, { s: 'new', lv: 0, due: '' });
    else { const w = Object.assign({}, r.w); delete w[/^mc/.test(key) ? 'mc' : 'fill']; touch(id, { w }); }
    b.closest('.lrow').remove();
    const n = $(`[data-list="${key}"] .n`, d); if (n) n.textContent = Math.max(0, +n.textContent - 1);
  });
}
function doSearch(qs) {
  const box = $('#results');
  const q = qs.trim().toLowerCase();
  if (!q) { box.innerHTML = ''; return; }
  const qa = IT.stripAccents(q);
  let hits = WORDS.filter(w => IT.stripAccents((w.word + ' ' + w.title + ' ' + w.e[3]).toLowerCase()).includes(qa) || w.zh.includes(qs.trim()) || (q.length > 1 && /^[a-z ]+$/.test(q) && w.en.toLowerCase().includes(q)));
  hits.sort((a, b) => (IT.stripAccents(a.word.toLowerCase()).startsWith(qa) ? 0 : 1) - (IT.stripAccents(b.word.toLowerCase()).startsWith(qa) ? 0 : 1));
  hits = hits.slice(0, 30);
  if (!hits.length) { box.innerHTML = '<div class="meta">找不到符合的字。</div>'; return; }
  box.innerHTML = hits.map(w => {
    const r = getRec(w.id);
    const canQ = r.s === 'new' || r.s === 'excluded';
    return `<div class="res">
      <div class="hd"><span class="w" lang="${LC.id}" style="font-family:var(--font-ui);font-weight:700">${esc(w.title)}</span><span>${meanW(w)}</span>${posBadge(w)}</div>
      <div class="row"><span class="st ${r.s}">${STATUS_TXT[r.s] || '未學'}</span><span class="meta">作答 ${r.n || 0} 次</span></div>
      <div class="sent sm" lang="${LC.id}">${sentHTML(w.sent)}</div>
      <div class="meta" style="color:var(--fg)">${esc(w.sentZh)}</div>
      <div class="row">${playBtn(w.title, '單字')}${playBtn(w.sent, '例句')}${canQ ? `<button class="btn" data-q="${esc(w.id)}" style="min-height:44px">列入考題</button>` : ''}</div>
    </div>`;
  }).join('');
  $$('[data-q]', box).forEach(b => b.onclick = () => { touch(b.dataset.q, { s: 'queued' }); toast('已列入考題'); doSearch($('#q').value); });
}
function renderVoiceBox() {
  const box = $('#voiceBox'); if (!box) return;
  if (!Voice.ok) { box.innerHTML = '<div class="warn">這個瀏覽器不支援語音播放。建議改用 Safari、Chrome 或 Edge。</div>'; return; }
  Voice.refresh();
  const best = Voice.best();
  const opts = Voice.list.slice().sort((a, b) => Voice.score(b) - Voice.score(a));
  box.innerHTML = `<div style="display:flex;flex-direction:column;gap:12px">
    <label class="label" for="vsel">${LC.name}語音（這台裝置）</label>
    ${opts.length ? `<select id="vsel">${opts.map(v => `<option value="${esc(v.voiceURI)}"${best && v.voiceURI === best.voiceURI ? ' selected' : ''}>${esc(v.name)}${Voice.GOOD.test(v.name) ? '（較自然）' : ''}</option>`).join('')}</select>` : `<div class="meta">還沒有讀到${LC.name}語音，系統會用預設聲音。</div>`}
    <div class="range"><label class="label" for="vrate">速度</label><input id="vrate" type="range" min="0.6" max="1.2" step="0.1" value="${SET.rate}"><span class="meta" id="vrateV">${Number(SET.rate).toFixed(1)} 倍</span></div>
    <div class="row"><button class="play" id="vtest">${ICON.play}試聽</button></div>
    ${!opts.length ? `<div class="warn">${LC.noVoiceHelp}</div>` : ''}
    <div class="meta">語音只存在這台裝置；速度和日文共用。</div>
  </div>`;
  const sel = $('#vsel'); if (sel) sel.onchange = () => { ISET.voice = sel.value; saveISet(); };
  const rate = $('#vrate');
  rate.oninput = () => { SET.rate = Number(rate.value); $('#vrateV').textContent = SET.rate.toFixed(1) + ' 倍'; saveSet(); };
  $('#vtest').onclick = () => Voice.speak(LC.ttsSample);
}

// ================= 帳號同步（和日文頁同一份資料） =================
const Cloud = {
  ref: null, remote: null, state: 'local', timer: 0, writing: false, again: false, mode: 'local', user: null, unsub: null, fb: null,
  label() {
    return {
      local: '進度只存在這台裝置',
      signedout: '還沒登入。登入 Google 後，進度會存到雲端，換手機也能接著練。',
      connecting: '正在連線帳號…',
      synced: this.mode === 'google' ? `已同步到 Google 帳號${this.user && this.user.email ? `（${this.user.email}）` : ''}` : '已同步到你的帳號',
      saving: '正在同步…',
      error: '暫時無法同步，進度仍存在這台裝置',
      readonly: '這個連結無法寫入你的帳號，進度只存在這台裝置'
    }[this.state];
  },
  chip() { return this.ref ? (this.mode === 'google' ? '已登入' : '已連帳號') : (this.mode === 'google' ? '未登入' : '只存本機'); },
  set(st) {
    this.state = st;
    const el = $('#syncState');
    if (el) { el.className = 'n sync' + (this.ref ? ' on' : ''); $('span', el).textContent = this.chip(); }
    const lg = $('#syncLong'); if (lg) lg.textContent = this.label();
    renderAuthBox();
  },
  init() {
    try {
      if (!window.firebase || !window.N5_FIREBASE) return;
      if (!firebase.apps.length) firebase.initializeApp(window.N5_FIREBASE);
      this.fb = { auth: firebase.auth(), db: firebase.firestore() };
      this.mode = 'google';
      this.set('signedout');
      this.fb.auth.getRedirectResult().catch(e => this.authError(e));
      this.fb.auth.onAuthStateChanged(u => {
        if (u) { this.user = u; this.attach(this.fb.db.collection('users').doc(u.uid)); }
        else { this.detach(); this.user = null; this.set('signedout'); }
      });
    } catch (e) { this.mode = 'local'; this.set('local'); }
  },
  async signIn() {
    if (!this.fb) return;
    const prov = new firebase.auth.GoogleAuthProvider();
    prov.setCustomParameters({ prompt: 'select_account' });
    try { await this.fb.auth.signInWithPopup(prov); }
    catch (e) {
      if (e && /popup-blocked|operation-not-supported/.test(e.code || '')) { try { await this.fb.auth.signInWithRedirect(prov); } catch (e2) { this.authError(e2); } }
      else this.authError(e);
    }
  },
  async signOut() { if (!this.fb) return; await this.upload(); await this.fb.auth.signOut(); toast('已登出，進度仍保留在這台裝置'); },
  authError(e) {
    const c = (e && e.code) || '';
    if (/popup-closed|cancelled-popup/.test(c)) return;
    toast(/unauthorized-domain/.test(c) ? '登入失敗：Firebase 還沒允許這個網址' : /network/.test(c) ? '登入失敗：請確認網路連線' : '登入失敗，請再試一次');
  },
  attach(ref) {
    this.detach();
    this.ref = ref; this.remote = null;
    this.set('connecting');
    this.unsub = ref.onSnapshot(snap => {
      const d = snap && snap.exists ? (snap.data() || {}) : {};
      this.remote = { items: d.items || {}, days: d.days || {} };
      this.absorb(this.remote);
      if (this.state === 'connecting' || this.state === 'error') this.set('synced');
      this.schedule(300);
    }, () => this.set('error'));
  },
  detach() { if (this.unsub) { try { this.unsub(); } catch (e) {} } this.unsub = null; this.ref = null; this.remote = null; },
  absorb(remote) {
    reloadShared();
    const merged = mergeState(S, remote);
    if (JSON.stringify(merged) === JSON.stringify({ items: S.items, days: S.days })) return;
    S = merged; saveLocal(); refreshPassive();
  },
  needsUpload() {
    if (!this.remote) return false;
    const ri = this.remote.items, rd = this.remote.days;
    for (const id in S.items) { const a = S.items[id], b = ri[id]; if (!b || (a.t || 0) > (b.t || 0)) return true; }
    for (const d in S.days) if ((S.days[d] || 0) > (rd[d] || 0)) return true;
    return false;
  },
  schedule(ms = 2500) { if (!this.ref) return; clearTimeout(this.timer); this.timer = setTimeout(() => this.upload(), ms); },
  async upload() {
    if (!this.ref || !this.remote || this.state === 'readonly') return;
    if (this.writing) { this.again = true; return; }
    reloadShared();
    if (!this.needsUpload()) return;
    this.writing = true; this.set('saving');
    try {
      const snap = await this.ref.get();
      const d = snap && snap.exists ? (snap.data() || {}) : {};
      S = mergeState(S, { items: d.items || {}, days: d.days || {} }); saveLocal();
      await this.ref.set({ items: S.items, days: S.days, v: 1, updated: Date.now() });
      this.remote = JSON.parse(JSON.stringify({ items: S.items, days: S.days }));
      this.set('synced');
    } catch (e) {
      if (e && (e.code === 'invalid_argument' || e.code === 'permission-denied')) this.set('error');
      else if (e && e.code === 'unavailable') { this.set('error'); setTimeout(() => this.schedule(500), 3000 + Math.random() * 2000); }
      else this.set('error');
    } finally { this.writing = false; if (this.again) { this.again = false; this.schedule(800); } }
  }
};
const GOOGLE_G = '<svg viewBox="0 0 48 48" width="18" height="18" aria-hidden="true"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.4-.4-3.5z"/><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-7.9l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z"/></svg>';
function renderAuthBox() {
  const top = $('#authTop');
  if (top) {
    if (Cloud.mode === 'google' && !Cloud.user) {
      top.innerHTML = `<div class="authcard"><div><b>用 Google 帳號存進度</b><div class="meta">每個語言的進度會一起存到雲端。</div></div><button class="btn solid gbtn-signin" id="gInTop">${GOOGLE_G}登入</button></div>`;
      $('#gInTop', top).onclick = () => Cloud.signIn();
    } else top.innerHTML = '';
  }
  const box = $('#authBox'); if (!box) return;
  if (Cloud.mode !== 'google') { box.innerHTML = ''; return; }
  if (Cloud.user) {
    box.innerHTML = `<div class="row"><span class="meta">${esc(Cloud.user.email || Cloud.user.displayName || '已登入')}</span><button class="btn quiet" id="gOut" style="min-height:40px">登出</button></div>`;
    $('#gOut', box).onclick = () => Cloud.signOut();
  } else {
    box.innerHTML = `<button class="btn solid block gbtn-signin" id="gIn">${GOOGLE_G}用 Google 登入</button>`;
    $('#gIn', box).onclick = () => Cloud.signIn();
  }
}
// 從雲端或日文頁合併進來後，只更新不會打斷作答的地方
function refreshPassive(force) {
  renderGoal();
  if (UI.tab === 'lib' && (force || (!$('#bk')?.innerHTML && !document.activeElement?.matches?.('#q')))) renderLib();
  if (force && UI.tab === 'card') renderCard();
}
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') { reloadShared(); renderGoal(); Cloud.schedule(500); } });
// 同一台裝置在別的分頁改了進度（例如日文頁）
window.addEventListener('storage', e => { if (e.key === 'n5:progress') { reloadShared(); renderGoal(); } if (e.key === 'n5:settings') { Object.assign(SET, store.get('n5:settings', {})); applyTheme(); applyGen(); } });

// ================= 啟動 =================
applyTheme();
renderGoal();
Voice.init();
showTab(UI.tab);
Cloud.init();
window.ITApp = { showTab, openWord, openToken, getRec, record, touch, S: () => S, UI, SET, WORDS };
})();
