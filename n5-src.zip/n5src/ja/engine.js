// ===== 核心邏輯（不碰 DOM，方便測試）=====

// ---- 假名工具 ----
const toKata = s => s.replace(/[ぁ-ゖ]/g, c => String.fromCharCode(c.charCodeAt(0) + 0x60));
const toHira = s => s.replace(/[ァ-ヶ]/g, c => String.fromCharCode(c.charCodeAt(0) - 0x60));
const isKanaChar = c => /[ぁ-ゖゝゞァ-ヺーヽヾ]/.test(c);
const isPunct = c => /[。、！？「」『』（）()・\s,.!?〜~：:]/.test(c);

// ---- 建立五十音資料：[假名, 羅馬拼音, 類別, 所屬行, 例字, 例字中文] ----
function buildKana() {
  const H = [], K = [];
  for (const [cat, row, list] of KANA_ROWS) {
    for (const pair of list.split(' ')) {
      const [h, r] = pair.split(':');
      const k = toKata(h);
      const eh = KANA_EX_H[h] || ['', ''];
      const ek = KANA_EX_K[k] || ['', ''];
      H.push([h, r, cat, row, eh[0], eh[1]]);
      K.push([k, r, cat, toKata(row.replace('行', '')) + (row.endsWith('行') ? '行' : ''), ek[0], ek[1]]);
    }
  }
  return { H, K };
}

// ---- 羅馬拼音表 ----
const K2R = {};   // 平假名 → 羅馬拼音
const R2K = {};   // 羅馬拼音 → 平假名
(function buildRomaji() {
  for (const [, , list] of KANA_ROWS) for (const pair of list.split(' ')) {
    const [h, r] = pair.split(':'); K2R[h] = r;
  }
  K2R['ぢ'] = 'ji'; K2R['づ'] = 'zu'; K2R['を'] = 'o';
  Object.assign(K2R, { 'ぁ':'a','ぃ':'i','ぅ':'u','ぇ':'e','ぉ':'o','ゔ':'vu',
    'しぇ':'she','ちぇ':'che','じぇ':'je','ふぁ':'fa','ふぃ':'fi','ふぇ':'fe','ふぉ':'fo','てぃ':'ti','でぃ':'di','うぃ':'wi','うぇ':'we','ゔぁ':'va' });
  const add = (r, k) => { if (!(r in R2K)) R2K[r] = k; };
  for (const [, , list] of KANA_ROWS) for (const pair of list.split(' ')) {
    const [h, r] = pair.split(':');
    if (h === 'ぢ' || h === 'づ' || h === 'ぢゃ') continue;
    add(r, h);
  }
  const extra = {
    si:'し', ti:'ち', tu:'つ', hu:'ふ', zi:'じ', di:'ぢ', du:'づ', wo:'を',
    sya:'しゃ', syu:'しゅ', syo:'しょ', tya:'ちゃ', tyu:'ちゅ', tyo:'ちょ', cya:'ちゃ', cyu:'ちゅ', cyo:'ちょ',
    jya:'じゃ', jyu:'じゅ', jyo:'じょ', zya:'じゃ', zyu:'じゅ', zyo:'じょ', dya:'ぢゃ', dyu:'ぢゅ', dyo:'ぢょ',
    she:'しぇ', che:'ちぇ', je:'じぇ', fa:'ふぁ', fi:'ふぃ', fe:'ふぇ', fo:'ふぉ', wi:'うぃ', we:'うぇ',
    la:'ら', li:'り', lu:'る', le:'れ', lo:'ろ',
    xa:'ぁ', xi:'ぃ', xu:'ぅ', xe:'ぇ', xo:'ぉ', xya:'ゃ', xyu:'ゅ', xyo:'ょ', xtu:'っ', ltu:'っ', xtsu:'っ',
    lya:'ゃ', lyu:'ゅ', lyo:'ょ', va:'ゔぁ', vu:'ゔ', ca:'か', cu:'く', co:'こ', qa:'くぁ'
  };
  for (const r in extra) add(r, extra[r]);
})();

// 羅馬拼音 → 平假名。final=false 時，結尾還沒拼完的字母保留原樣（給即時顯示用）
function romaToKana(input, final = true) {
  const s = input.toLowerCase();
  let out = '', i = 0;
  while (i < s.length) {
    const c = s[i], n1 = s[i + 1], n2 = s[i + 2];
    if (!/[a-z'\-]/.test(c)) { out += c; i++; continue; }
    if (c === '-') { out += 'ー'; i++; continue; }
    if (c === "'") { i++; continue; }
    if (c === 'n') {
      if (n1 === 'n') {
        if (n2 && /[aiueoy]/.test(n2)) { out += 'ん'; i += 1; continue; }
        out += 'ん'; i += 2; continue;
      }
      if (n1 === "'") { out += 'ん'; i += 2; continue; }
      if (n1 === undefined) { if (final) { out += 'ん'; } else { out += 'n'; } i++; continue; }
      if (!/[aiueoy]/.test(n1)) { out += 'ん'; i++; continue; }
    }
    if (n1 === c && /[bcdfghjkmpqrstvwxz]/.test(c)) { out += 'っ'; i++; continue; }
    if (c === 't' && n1 === 'c') { out += 'っ'; i++; continue; }
    let hit = false;
    for (let L = 4; L >= 1; L--) {
      const k = s.substr(i, L);
      if (k.length === L && R2K[k]) { out += R2K[k]; i += L; hit = true; break; }
    }
    if (!hit) { out += c; i++; }
  }
  return out;
}

// 平假名/片假名 → 羅馬拼音
function kanaToRoma(str) {
  const s = toHira(str);
  let out = '', i = 0, lastV = '';
  while (i < s.length) {
    const c = s[i], two = s.substr(i, 2);
    if (c === 'っ') {
      // 下一個音的子音重複
      let nx = '';
      const t2 = s.substr(i + 1, 2);
      if (K2R[t2] && /[ゃゅょぁぃぅぇぉ]/.test(t2[1])) nx = K2R[t2]; else if (K2R[s[i + 1]]) nx = K2R[s[i + 1]];
      if (nx) out += nx.startsWith('ch') ? 't' : nx[0];
      i++; continue;
    }
    if (c === 'ー') { out += lastV; i++; continue; }
    if (c === 'ん') {
      const nx = s[i + 1];
      out += (nx && /[あいうえおやゆよ]/.test(nx)) ? "n'" : 'n';
      i++; continue;
    }
    if (K2R[two] && two.length === 2 && /[ゃゅょぁぃぅぇぉ]/.test(two[1])) { out += K2R[two]; lastV = K2R[two].slice(-1); i += 2; continue; }
    if (K2R[c]) { out += K2R[c]; lastV = K2R[c].slice(-1); i++; continue; }
    if (c === '、') { out += ', '; i++; continue; }
    if (c === '。') { out += '. '; i++; continue; }
    if (c === '？') { out += '? '; i++; continue; }
    if (c === '！') { out += '! '; i++; continue; }
    if (c === '「' || c === '」') { out += '"'; i++; continue; }
    out += c; i++;
  }
  return out.replace(/\s+/g, ' ').trim();
}

// 比對用：統一成平假名，長音符號換成母音，去掉標點與空白
const VOWEL_KANA = { a: 'あ', i: 'い', u: 'う', e: 'え', o: 'お' };
function normKana(s) {
  s = toHira(String(s)).replace(/[|\s。、！？!?.,・「」]/g, '');
  let out = '';
  for (const ch of s) {
    if (ch === 'ー' && out) {
      const r = kanaToRoma(out);
      out += VOWEL_KANA[r.slice(-1)] || 'ー';
    } else out += ch;
  }
  return out;
}

// ---- 振り仮名對齊 ----
function tokenize(t) {
  const out = []; let buf = '';
  for (const c of t) {
    if (isKanaChar(c) || isPunct(c)) { if (buf) { out.push({ k: 1, t: buf }); buf = ''; } out.push({ k: 0, t: c }); }
    else buf += c;
  }
  if (buf) out.push({ k: 1, t: buf });
  return out;
}
const escRe = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
function alignPiece(t, r, greedy) {
  const toks = tokenize(t);
  const re = new RegExp('^' + toks.map(x => x.k ? (greedy ? '(.+)' : '(.+?)') : escRe(x.t)).join('') + '$', 'u');
  const m = r.match(re);
  if (!m) return null;
  let g = 1;
  return toks.map(x => x.k ? { t: x.t, r: m[g++] } : { t: x.t, r: null });
}
function align(text, reading, greedy = false) {
  const tp = text.split('|'), rp = reading.split('|');
  if (tp.length !== rp.length) return null;
  const segs = [];
  for (let i = 0; i < tp.length; i++) {
    const s = alignPiece(tp[i], rp[i], greedy);
    if (!s) return null;
    segs.push(...s);
  }
  // 漢字詞的假名逐字對到每個漢字上（学生 → 学がく 生せい）；拆不開的（熟字訓）維持整個詞一起標
  for (const g of segs) if (g.r && [...g.t].length > 1) { const sub = splitFuri(g.t, g.r); if (sub) g.sub = sub; }
  return segs;
}
// ---- 振り仮名逐字對齊 ----
// 每個漢字的音讀與訓讀（取自 KANJIDIC2，CC BY-SA 4.0；只收 App 裡出現的字）。新增單字用到沒收的字時，那個詞會整個一起標，不會出錯
const KYOMI = (() => {
  const m = {};
  for (const e of '私し,わたくし,わたし 学がく,まな 生せい,しょう,い,う,うま,うまれ,お,は,き,なま,な,む 日にち,じつ,ひ,び,か 本ほん,もと 人じん,にん,ひと,り,と 弟てい,だい,で,おとうと 先せん,さき,ま 友ゆう,とも 達たつ,だ,たち 映えい,うつ,は,ば 画が,かく,え,かい,えが,かぎ,はかりごと,はか 見けん,み 家か,け,いえ,や,うち 族ぞく 四し,よ,よっ,よん 父ふ,ちち 銀ぎん,しろがね 行こう,ぎょう,あん,い,ゆ,ゆき,いき,おこな,おこ 働どう,はたら 母ぼ,はは,も 傘さん,かさ 兄けい,きょう,あに 背はい,せ,せい,そむ 高こう,たか,だか 姉し,あね,はは 東とう,ひがし 京きょう,けい,きん,みやこ 住じゅう,ぢゅう,ちゅう,す,ず 十じゅう,じっ,じゅっ,とお,と 歳さい,せい,とし,とせ,よわい 妹まい,いもうと 猫びょう,ねこ 好こう,この,す,よ,い 元げん,がん,もと 気き,け,いき 何か,なに,なん 優ゆう,う,やさ,すぐ,まさ 朝ちょう,あさ 散さん,ち,ばら 歩ほ,ぶ,ふ,ある,あゆ 一いち,いつ,ひと 緒しょ,ちょ,お,いとぐち 両りょう,てる,ふたつ 親しん,おや,した 台だい,たい,うてな,われ,つかさ 南なん,な,みなみ 奥おう,おく,くま 公こう,く,おおやけ 園えん,その 子し,す,つ,こ,ね 供きょう,く,くう,ぐ,そな,とも,ども 大だい,たい,おお 千せん,ち 円えん,まる,まど,まろ 男だん,なん,おとこ,お 来らい,たい,く,きた,き,こ 女じょ,にょ,にょう,おんな,め 歌か,うた 写しゃ,じゃ,うつ 真しん,ま,まこと 撮さつ,と,つま,ど 店てん,みせ,たな 客きゃく,かく 会かい,え,あ,あつ 社しゃ,やしろ 員いん 医い,くすし 者しゃ,もの 道どう,とう,みち,いう 分ぶん,ふん,ぶ,わ 警けい,いまし 官かん 聞ぶん,もん,き 名めい,みょう,な 前ぜん,まえ 食しょく,じき,く,た,は 駅えき 教きょう,おし,おそ 室しつ,むろ 座ざ,すわ 物ぶつ,もつ,もの 湾わん,いりえ 町ちょう,まち 国こく,くに 外がい,げ,そと,ほか,はず,と 多た,おお,まさ 語ご,かた 英えい,はなぶさ 授じゅ,さず 業ぎょう,ごう,わざ 月げつ,がつ,つき 曜よう 言げん,ごん,い,こと 葉よう,は 意い 味み,あじ 漢かん 字じ,あざ,あざな,な 難なん,かた,がた,むずか,むづか,むつか,にく 八はち,や,やっ,よう 時じ,とき,どき 校こう,きょう 勉べん,つと 強きょう,ごう,つよ,し,こわ 二に,じ,ふた,ふたたび 三さん,ぞう,み,みっ 終しゅう,お,おわ,つい 宿しゅく,やど 題だい 明めい,みょう,みん,あ,あか,あき 試し,こころ,ため 験けん,げん,あかし,しるし,ため,ためし 質しつ,しち,ち,たち,ただ,もと,わりふ 問もん,と,とん 図ず,と,え,はか 書しょ,か,が,がき 館かん,やかた,たて 仕し,じ,つか 事じ,ず,こと,つか 九きゅう,く,ここの 近きん,こん,ちか 休きゅう,やす 夏か,が,げ,なつ 長ちょう,なが,おさ 誕たん 土ど,と,つち 旅りょ,たび 買ばい,か 音おん,いん,-のん,おと,ね 楽がく,らく,ごう,たの,この 知ち,し 絵かい,え 上じょう,しょう,しゃん,うえ,うわ,かみ,あ,のぼ,たてまつ 手しゅ,ず,て,た 泳えい,およ 弾だん,たん,ひ,はず,たま,はじ,ただ 電でん 車しゃ,くるま 自じ,し,みずか,おの 転てん,ころ,まろ,うたた,うつ,くる 飛ひ,と 機き,はた 帰き,かえ,おく,とつ 切せつ,さい,き,ぎ 符ふ 地ち,じ 入にゅう,じゅ,い,はい 角かく,かど,つの 屋おく,や 橋きょう,はし 渡と,わた 静せい,じょう,しず 所しょ,ところ,どころ,とこ 安あん,やす 服ふく 夜や,よ,よる 辞じ,や,いな 百ひゃく,びゃく,もも 野や,しょ,の 菜さい,な 喫きつ,の 茶ちゃ,さ 待たい,ま 昼ちゅう,ひる 飯はん,めし 堂どう 金きん,こん,ごん,かね,かな,がね 出しゅつ,すい,で,だ,い 郵ゆう 便べん,びん,たよ 局きょく,つぼね 病びょう,へい,や,やまい 院いん 読どく,とく,とう,よ 交こう,まじ,ま,か,かわ,こもごも 番ばん,つが 新しん,あたら,あら,にい 都と,つ,みやこ 寺じ,てら 白はく,びゃく,しろ,しら 建けん,こん,た,だ 門もん,かど,と 晩ばん 部ぶ,べ 机き,つくえ 風ふう,ふ,かぜ,かざ 呂ろ,りょ,せぼね 浴よく,あ 庭てい,にわ 犬けん,いぬ 遊ゆう,ゆ,あそ 池ち,いけ 魚ぎょ,うお,さかな,ざかな 階かい,きざはし 段だん,たん 五ご,いつ 窓そう,す,まど,てんまど,けむだし 開かい,ひら,びら,あ 閉へい,と,し,た 椅い 皿べい,さら 冷れい,つめ,ひ,さ 蔵ぞう,そう,くら,おさ,かく 庫こ,く,くら 牛ぎゅう,うし 乳にゅう,ちち,ち 消しょう,き,け 話わ,はな,はなし 花か,け,はな 計けい,はか 冊さつ,さく,ふみ 雑ざつ,ぞう,まじ 誌し 貸たい,か,かし 紙し,かみ 鉛えん,なまり 筆ひつ,ふで 中ちゅう,なか,うち,あた 財ざい,さい,ぞく,たから 布ふ,ぬの 忘ぼう,わす 雨う,あめ,あま,さめ 持じ,も 鍵けん,かぎ 箱そう,はこ 荷か,に 重じゅう,ちょう,え,おも,かさ 枚まい,ばい 寒かん,さむ 着ちゃく,じゃく,き,ぎ,つ 黒こく,くろ 靴か,くつ 脱だつ,ぬ 下か,げ,した,しも,もと,さ,くだ,お 帽ぼう,もう,ずきん,おお 眼がん,げん,まなこ,め 鏡きょう,けい,かがみ 毎まい,ごと 七しち,なな,なの 弁べん,へん,かんむり,わきま,わ,はなびら,あらそ 当とう,あ,まさ 飲いん,おん,の 料りょう 理り,ことわり 肉にく,しし 果か,は,はた 卵らん,たまご 菓か 今こん,きん,いま 作さく,さ,つく,づく 紅こう,く,べに,くれない,あか 砂さ,しゃ,すな 糖とう 塩えん,しお 少しょう,すく,すこ 水すい,みず 酒しゅ,さけ,さか 洗せん,あら 天てん,あまつ,あめ,あま 午ご,うま 後ご,こう,のち,うし,うしろ,あと,おく 降こう,ご,お,ふ,くだ 冬とう,ふゆ 雪せつ,ゆき 空くう,そら,あ,から,す,むな 青せい,しょう,あお 山さん,せん,やま 川せん,かわ 海かい,うみ 木ぼく,もく,き,こ 鳥ちょう,とり 動どう,うご 体たい,てい,からだ,かたち 頭とう,ず,と,あたま,かしら,がしら,かぶり 痛つう,いた 顔がん,かお 目もく,ぼく,め,ま 耳じ,みみ 象しょう,ぞう,かたど 鼻び,はな 口こう,く,くち 歯し,よわい,は,よわ 小しょう,ちい,こ,お,さ 足そく,あし,た 腹ふく,はら 邪じゃ,よこし 寝しん,ね,い,みたまや,や 薬やく,くすり 色しょく,しき,いろ 声せい,しょう,こえ,こわ 次じ,し,つ,つぎ 右う,ゆう,みぎ 曲きょく,ま,くま 左さ,しゃ,ひだり 隣りん,とな,となり 横おう,よこ 間かん,けん,あいだ,ま,あい 向こう,む,むこ,むか 西せい,さい,す,にし 赤せき,しゃく,あか 暖だん,のん,あたた 北ほく,きた 六ろく,りく,む,むっ,むい 度ど,と,たく,たび,た 売ばい,う 起き,お,おこ,た 疲ひ,つか,づか 掃そう,しゅ,は 除じょ,じ,のぞ,よ 濯たく,すす,ゆす 結けつ,けち,むす,ゆ 婚こん 使し,つか,づか 走そう,はし 習しゅう,じゅ,なら 乗じょう,しょう,の 阪はん,さか 立りつ,りゅう,りっとる,た,たて,だ 取しゅ,と,とり,ど 借しゃく,か 返へん,かえ 呼こ,よ 始し,はじ 覚かく,おぼ,さ,さと 困こん,こま 吸きゅう,す 並へい,ほう,な,なみ,なら 春しゅん,はる 桜おう,よう,さくら 咲しょう,さ,ざき 置ち,お 引いん,ひ,び 答とう,こた 要よう,い,かなめ 押おう,お,おさ 磨ま,みが,す 登とう,と,どう,しょう,ちょう,のぼ,あ 晴せい,は,ば 古こ,ふる 低てい,ひく 短たん,みじか 暑しょ,あつ 涼りょう,すず,うす,ひや,まことに 熱ねつ,あつ 甘かん,あま,うま 辛しん,から,つら,づら,かのと 村そん,むら 遠えん,おん,とお 広こう,ひろ 狭きょう,こう,せま,せば,さ 軽けい,きょう,きん,かる,かろ 早そう,さっ,はや,さ 幹かん,みき 線せん,すじ 速そく,はや,すみ 遅ち,おく,おそ 暗あん,くら,くれ 弱じゃく,よわ 易えき,い,やさ,やす 忙ぼう,もう,いそが,せわ,おそ,うれえるさま 面めん,べん,おも,おもて,つら 若じゃく,にゃく,にゃ,わか,も,ごと 汚お,けが,よご,きたな 悪あく,お,わる,あ,にく,ああ,いずくに,いずくんぞ 欲よく,ほっ,ほ 太たい,た,ふと 細さい,ほそ,こま 危き,あぶ,あや 丸がん,まる 嫌けん,げん,きら,いや 有ゆう,う,あ 利り,き 丈じょう,たけ,だけ 夫ふ,ふう,ぶ,おっと,それ 暇か,ひま,いとま 簡かん,けん,えら,ふだ 単たん,ひとえ 変へん,か 同どう,おな 全ぜん,まった,すべ 然ぜん,ねん,しか,さ 初しょ,はじ,はつ,うい,そ,ぞ 昨さく 万まん,ばん,よろず 週しゅう 年ねん,とし 去きょ,こ,さ 半はん,なか 火か,ひ,び,ほ 秋しゅう,あき,とき 田でん,た 林りん,はやし 願がん,ねが,ねがい 失しつ,うしな,う 礼れい,らい 方ほう,かた,がた 徒と,いたずら,あだ 練れん,ね 皆かい,みな,みんな 戸こ,と 号ごう,さけ,よびな 曇どん,くも 鉄てつ,くろがね 玄げん,くろ 関かん,せき,ぜき,かか,からくり,かんぬき 留りゅう,る,と,とど,るうぶる 文ぶん,もん,ふみ,あや 章しょう 夕せき,ゆう 箸ちょ,ちゃく,はし 碗わん,こばち 豚とん,ぶた 鶏けい,にわとり,とり 廊ろう 棚ほう,たな,だな 灰かい,はい 瓶びん,かめ 封ふう,ほう 筒とう,つつ 洋よう 巡じゅん,めぐ 板はん,ばん,いた 勢せい,ぜい,いきお,はずみ 頃けい,きょう,ころ,ごろ,しばら 匹ひつ,ひき 緑りょく,ろく,みどり 違い,ちが,たが 勤きん,ごん,つと,づと,いそ 死し 頼らい,たの,たよ 止し,と,ど,とど,や,よ,さ 締てい,し,じ 鳴めい,な 泣きゅう,な 貼てん,ちょう,は,つ 吹すい,ふ 薄はく,うす,すすき 厚こう,あつ,あか 黄こう,おう,き,こ 派は 構こう,かま 個こ,か 回かい,え,まわ,もとお,か 杯はい,さかずき 過か,す,あやま,よ'.split(' ')) { const c = [...e][0]; m[c] = e.slice(c.length).split(','); }
  return m;
})();
// 特殊讀法：寫成逐字的讀音；null＝熟字訓，整個詞一起標（今日、大人、明日…自動就是整個一起）
const FURI_FIX = {
  '日本|にほん': ['に', 'ほん'], '日本人|にほんじん': ['に', 'ほん', 'じん'], '日本語|にほんご': ['に', 'ほん', 'ご'],
  '切符|きっぷ': ['きっ', 'ぷ'], '切手|きって': ['きっ', 'て'], '建物|たてもの': ['たて', 'もの'], '入口|いりぐち': ['いり', 'ぐち'],
  '台北|たいぺい': ['たい', 'ぺい'], '一人|ひとり': null, '二人|ふたり': null
};
const FURI_DAK = { か: 'が', き: 'ぎ', く: 'ぐ', け: 'げ', こ: 'ご', さ: 'ざ', し: 'じ', す: 'ず', せ: 'ぜ', そ: 'ぞ', た: 'だ', ち: 'じ', つ: 'ず', て: 'で', と: 'ど', は: 'ば', ひ: 'び', ふ: 'ぶ', へ: 'べ', ほ: 'ぼ' };
const FURI_HAN = { は: 'ぱ', ひ: 'ぴ', ふ: 'ぷ', へ: 'ぺ', ほ: 'ぽ' };
// 回傳每個字的讀音陣列；拆不開或有兩種拆法時回傳 null
function splitFuri(t, r) {
  const key = t + '|' + r;
  if (key in FURI_FIX) return FURI_FIX[key];
  const ch = [...t], n = ch.length;
  let best = null, bestScore = Infinity, tie = false;
  const rec = (i, pos, acc, score, prev) => {
    if (score > bestScore) return;
    if (i === n) {
      if (pos !== r.length) return;
      if (score < bestScore) { best = acc.slice(); bestScore = score; tie = false; }
      else if (acc.join(',') !== best.join(',')) tie = true;
      return;
    }
    const cands = ch[i] === '々' ? prev : KYOMI[ch[i]];
    if (!cands) return;
    const seen = new Set();
    cands.forEach(r0 => {
      // 連濁（が、ざ、だ、ば、ぱ）只在第二個字以後；促音（っ）只在最後一個字以外
      const vs = [[r0, 0]];
      if (i > 0) { const c = r0[0]; if (FURI_DAK[c]) vs.push([FURI_DAK[c] + r0.slice(1), 1]); if (FURI_HAN[c]) vs.push([FURI_HAN[c] + r0.slice(1), 1]); }
      if (i < n - 1 && r0.length > 1 && /[つくちき]$/.test(r0)) for (const [x, s] of vs.slice()) vs.push([x.slice(0, -1) + 'っ', s + 1]);
      for (const [x, s] of vs) {
        if (seen.has(x) || !r.startsWith(x, pos)) continue;
        seen.add(x); acc.push(x); rec(i + 1, pos + x.length, acc, score + s, cands); acc.pop();
      }
    });
  };
  rec(0, 0, [], 0, null);
  return best && !tie ? best : null;
}

// 是否為助詞「は／へ」（決定羅馬拼音要寫 wa / e）
const HA_BEFORE = /(これ|それ|あれ|どれ|ここ|そこ|あそこ|どこ|あなた|さん|かばん|りんご|みんな|だれ|いま|ぼく|には|では)$/;
function isParticleAt(segs, i) {
  const prev = segs[i - 1];
  if (!prev) return false;
  if (prev.r !== null) return true;
  if (/[ァ-ヺー]/.test(prev.t)) return true;
  if (/[でにとの]/.test(prev.t)) return true;
  const before = segs.slice(0, i).map(s => s.r === null ? s.t : s.r).join('');
  return HA_BEFORE.test(before);
}
const PARTS = 'はがをにでともへやの';
function segsRomaji(segs, from = 0, to = segs.length) {
  let s = '';
  const isHira = g => g && g.r === null && /[\u3041-\u3096]/.test(g.t);
  for (let i = from; i < to; i++) {
    const g = segs[i];
    if (g.r !== null) { s += g.r; continue; }
    const t = g.t, next = segs[i + 1], prev = segs[i - 1];
    if (PARTS.includes(t) && isParticleAt(segs, i) && ('はをへ'.includes(t) || !isHira(next))) {
      s += ' ' + (t === 'は' ? 'わ' : t === 'へ' ? 'え' : t === 'を' ? 'お' : t) + ' ';
      continue;
    }
    if (t === 'で' && next && next.t === 'す' && prev && !isHira(prev)) { s += ' で'; continue; }
    s += t;
  }
  s = s.replace(/こんにちは/g, 'こんにちわ').replace(/こんばんは/g, 'こんばんわ');
  return kanaToRoma(s).replace(/\s+([,.?!"])/g, '$1').replace(/\s+/g, ' ').trim();
}

// ---- 單字資料整理 ----
const POS_GROUP = p => p.startsWith('動詞') ? '動詞' : p;
const POS_LIST = ['名詞', '動詞', 'い形容詞', 'な形容詞', '副詞', '指示詞・連接詞', '數字與時間', '招呼語與常用句', '文法'];

function prepWords(raw) {
  const seen = {};
  return raw.map(a => {
    const [word, reading, romaji, pos, zh, sent, sentR, sentZh, ans] = a;
    let id = 'v:' + word + '|' + zh;
    if (seen[id]) id += '#' + (++seen[id]); else seen[id] = 1;
    const segs = align(sent, sentR) || [{ t: sent.replace(/\|/g, ''), r: null }];
    const wsegs = align(word, reading) || [{ t: word, r: null }];
    const plain = sent.replace(/\|/g, '');
    // 填空答案在句中的位置（以 segment 為單位）
    let a0 = -1, a1 = -1, ansR = '';
    const idx = plain.indexOf(ans);
    if (idx >= 0) {
      let pos0 = 0;
      for (let i = 0; i < segs.length; i++) {
        const st = pos0, en = pos0 + segs[i].t.length;
        if (st === idx) a0 = i;
        if (en === idx + ans.length) a1 = i + 1;
        pos0 = en;
      }
      if (a0 >= 0 && a1 > a0) ansR = segs.slice(a0, a1).map(s => s.r === null ? s.t : s.r).join('');
    }
    return { id, word, reading, romaji, pos, pg: POS_GROUP(pos), zh, sent: plain, sentR: sentR.replace(/\|/g, ''), sentZh, ans, segs, wsegs, a0, a1, ansR, kind: 'w' };
  });
}

// ---- 意思比對（避免兩個選項都對）----
function meaningKeys(zh) {
  return zh.split(/[；;、,，／/]/).map(x => x.replace(/[（(][^）)]*[）)]/g, '').replace(/的$/, '').trim()).filter(Boolean);
}
function sameMeaning(a, b) {
  const A = meaningKeys(a), B = meaningKeys(b);
  return A.some(x => B.includes(x));
}

// ---- 填空答案檢查 ----
const romaNorm = s => s.toLowerCase().replace(/[\s'’\-]/g, '');
// 平常寫假名、但也有漢字寫法的字：[假名開頭, 漢字開頭]，輸入漢字也算對（だれ → 誰）
const KANJI_ALT = {
  だれ: [['だれ', '誰']], どこ: [['どこ', '何処']], いつ: [['いつ', '何時']], なぜ: [['なぜ', '何故']], みんな: [['みんな', '皆']], あなた: [['あなた', '貴方']],
  おじいさん: [['おじい', 'お祖父']], おばあさん: [['おばあ', 'お祖母']], おじさん: [['おじ', '叔父'], ['おじ', '伯父']], おばさん: [['おば', '叔母'], ['おば', '伯母']],
  かばん: [['かばん', '鞄']], りんご: [['りんご', '林檎']], たばこ: [['たばこ', '煙草']], しょうゆ: [['しょうゆ', '醤油']], そば: [['そば', '蕎麦'], ['そば', '側']], ほか: [['ほか', '他'], ['ほか', '外']],
  ひらがな: [['ひらがな', '平仮名']], カタカナ: [['カタカナ', '片仮名']],
  ある: [['あ', '有'], ['あ', '在']], いる: [['い', '居']], つける: [['つ', '付'], ['つ', '点']], かぶる: [['かぶ', '被']], あげる: [['あ', '上']], もらう: [['もら', '貰']], かける: [['か', '掛']],
  なる: [['な', '成']], できる: [['でき', '出来']], なくす: [['な', '無'], ['な', '失']], はく: [['は', '履'], ['は', '穿']], さす: [['さ', '差']], かかる: [['か', '掛']],
  おいしい: [['おいし', '美味し']], かわいい: [['かわい', '可愛']], いい: [['い', '良']], うるさい: [['うるさ', '煩']], きれい: [['きれい', '綺麗']], いろいろ: [['いろいろ', '色々']],
  たくさん: [['たくさん', '沢山']], ちょっと: [['ちょっと', '一寸']], たぶん: [['たぶん', '多分']], また: [['また', '又']], まだ: [['まだ', '未だ']], すぐ: [['すぐ', '直ぐ']],
  だんだん: [['だんだん', '段々']], たいてい: [['たいてい', '大抵']], ちょうど: [['ちょうど', '丁度']], まっすぐ: [['まっすぐ', '真っ直ぐ']],
  おはようございます: [['おはよう', 'お早う']], こんにちは: [['こんにち', '今日']], こんばんは: [['こんばん', '今晩']], ありがとうございます: [['ありがとう', '有難う']],
  いただきます: [['いただ', '頂']], ごちそうさまでした: [['ごちそうさま', 'ご馳走様'], ['ごちそうさま', '御馳走様']],
  いくら: [['いくら', '幾ら']], これ: [['これ', '此れ']], それ: [['それ', '其れ']], あれ: [['あれ', '彼れ']], ここ: [['ここ', '此処']], そこ: [['そこ', '其処']], あそこ: [['あそこ', '彼処']],
  こちら: [['こちら', '此方']], どちら: [['どちら', '何方']], まずい: [['まず', '不味']], つまらない: [['つまら', '詰まら']], にぎやか: [['にぎやか', '賑やか']],
  よく: [['よく', '良く']], いつも: [['いつも', '何時も']], あまり: [['あまり', '余り']], しかし: [['しかし', '然し']], ぐらい: [['ぐらい', '位']], など: [['など', '等']], やる: [['や', '遣']],
  おやすみなさい: [['おやすみ', 'お休み']], すみません: [['すみ', '済み']], ごめんなさい: [['ごめん', '御免']], ごめんください: [['ごめんください', '御免下さい']],
  いってきます: [['いってき', '行って来']], いってらっしゃい: [['いって', '行って']], おかえりなさい: [['おかえり', 'お帰り']], はじめまして: [['はじめ', '初め']]
};
function kanjiAltOK(w, input) {
  const alts = KANJI_ALT[w.word];
  if (!alts) return false;
  return alts.some(([k, j]) => w.ans.startsWith(k) && normKana(j + w.ans.slice(k.length)) === input);
}
function checkFill(w, input) {
  const raw = String(input).trim().replace(/[。.]$/, '');
  if (!raw) return false;
  if (kanjiAltOK(w, normKana(raw))) return true;
  const kana = normKana(romaToKana(raw, true));
  const targets = [normKana(w.ans), normKana(w.ansR)];
  if (targets.includes(kana) || targets.includes(normKana(raw))) return true;
  if ((w.ans === w.word || w.ansR === w.reading) && romaNorm(raw) === romaNorm(w.romaji)) return true;
  return mixedOK(w.ans, w.ansR, normKana(raw));
}
// 漢字、假名混寫也算對：食べ物 → 食べもの／たべ物
function mixedOK(text, reading, input) {
  if (!text || !reading) return false;
  for (const greedy of [false, true]) {
    const segs = align(text, reading, greedy);
    if (!segs || !segs.some(x => x.r)) continue;
    const re = new RegExp('^' + segs.map(x => x.r ? `(?:${escRe(normKana(x.t))}|${escRe(normKana(x.r))})` : escRe(normKana(x.t))).join('') + '$', 'u');
    if (re.test(input)) return true;
  }
  return false;
}
function kanaLen(s) { return [...normKana(s)].length; }

// 日期、作答規則 applyAnswer、複習間隔、出題 pickRound：在 core.js（和其他語言頁共用）

// ---- 單字選擇題的錯誤選項 ----
function pickWordDistractors(target, all, qmode, n = 3) {
  const ok = w => w.id !== target.id && w.word !== target.word && !sameMeaning(w.zh, target.zh) && !(w.en && target.en && sameMeaning(w.en, target.en))
    && !(qmode === 'listen' && normKana(w.reading) === normKana(target.reading))
    && !(qmode === 'zh2jp' && w.zh === target.zh);
  const same = shuffle(all.filter(w => w.pg === target.pg && ok(w)));
  const chosen = [];
  const accept = w => { if (chosen.length >= n) return; if (chosen.some(c => c.word === w.word || sameMeaning(c.zh, w.zh) || (c.en && w.en && sameMeaning(c.en, w.en)) || (qmode === 'listen' && normKana(c.reading) === normKana(w.reading)))) return; chosen.push(w); };
  same.forEach(accept);
  if (chosen.length < n) shuffle(all.filter(ok)).forEach(accept);
  return chosen;
}

// ---- 假名選擇題的錯誤選項：容易混淆的字優先 ----
function confuseMap() {
  const m = {};
  for (const g of KANA_CONFUSE) {
    const units = g.includes('/') ? g.split('/') : [...g];
    for (const u of units) { m[u] = m[u] || new Set(); units.forEach(v => v !== u && m[u].add(v)); }
  }
  return m;
}
function pickKanaDistractors(target, all, n = 3, cmap) {
  const snd = r => r === 'wo' ? 'o' : r;   // を／ヲ 和 お／オ 發音相同
  const ok = k => k.kana !== target.kana && snd(k.romaji) !== snd(target.romaji) && k.script === target.script;
  const chosen = [];
  const accept = k => { if (chosen.length < n && ok(k) && !chosen.some(c => snd(c.romaji) === snd(k.romaji) || c.kana === k.kana)) chosen.push(k); };
  const conf = cmap[target.kana] ? [...cmap[target.kana]] : [];
  shuffle(all.filter(k => conf.includes(k.kana))).forEach(accept);
  shuffle(all.filter(k => k.cat === target.cat)).forEach(accept);
  shuffle(all).forEach(accept);
  return chosen;
}

// 合併 mergeState、備份碼 packState／unpackState：在 core.js

// ===== 漢字讀音題：照 JLPT 的方式做錯誤選項（長音、促音、濁音、拗音） =====
const hasKanji = s => /[一-鿿々]/.test(s);
const DAKU = { か: 'が', き: 'ぎ', く: 'ぐ', け: 'げ', こ: 'ご', さ: 'ざ', し: 'じ', す: 'ず', せ: 'ぜ', そ: 'ぞ', た: 'だ', ち: 'ぢ', つ: 'づ', て: 'で', と: 'ど', は: 'ば', ひ: 'び', ふ: 'ぶ', へ: 'べ', ほ: 'ぼ' };
const UNDAKU = Object.fromEntries(Object.entries(DAKU).map(([a, b]) => [b, a]));
const O_ROW = 'おこごそぞとどのほぼぽもよろょ', U_ROW = 'うくぐすずつづぬふぶぷむゆるゅ', E_ROW = 'えけげせぜてでねへべぺめれ';
function readingVariants(r) {
  const out = new Set(), ch = [...r];
  // 長音：刪掉「う／い」或在 お段・う段 後面加「う」
  ch.forEach((c, i) => {
    const p = ch[i - 1];
    if (i > 0 && c === 'う' && (O_ROW.includes(p) || U_ROW.includes(p))) out.add(ch.slice(0, i).join('') + ch.slice(i + 1).join(''));
    if (i > 0 && c === 'い' && E_ROW.includes(p)) out.add(ch.slice(0, i).join('') + ch.slice(i + 1).join(''));
    // 加長音：只在「ゅ／ょ」後面，或字尾的 お段・う段（とうきょ→とうきょう 這類考試常見的錯法）
    if ((c === 'ゅ' || c === 'ょ') && ch[i + 1] !== 'う') out.add(ch.slice(0, i + 1).join('') + 'う' + ch.slice(i + 1).join(''));

  });
  // 促音：刪掉「っ」，或在中間的 か、さ、た、ぱ 行前面加「っ」
  ch.forEach((c, i) => {
    if (c === 'っ') out.add(ch.slice(0, i).join('') + ch.slice(i + 1).join(''));
    if (i > 0 && /[かきくけこさしすせそたちつてとぱぴぷぺぽ]/.test(c) && ch[i - 1] !== 'っ' && ch[i - 1] !== 'ん') out.add(ch.slice(0, i).join('') + 'っ' + ch.slice(i).join(''));
  });
  // 濁音：清濁互換
  ch.forEach((c, i) => { const d = DAKU[c] || UNDAKU[c]; if (d && ch[i - 1] !== 'っ' && d !== 'ぢ' && d !== 'づ') out.add(ch.slice(0, i).join('') + d + ch.slice(i + 1).join('')); });
  // 拗音：ゅ↔ょ
  ch.forEach((c, i) => { const d = { ゅ: 'ょ', ょ: 'ゅ' }[c]; if (d) out.add(ch.slice(0, i).join('') + d + ch.slice(i + 1).join('')); });
  out.delete(r);
  return [...out].filter(x => x && !/^[っんー]/.test(x) && !/っっ|っ$/.test(x));
}
function pickReadingDistractors(w, words, rnd = Math.random) {
  const sh = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  const bad = new Set([w.reading]);
  // 同一個漢字寫法的其他讀音（例：一日＝いちにち／ついたち）都不能當錯誤選項
  for (const o of words) if (o.word === w.word) bad.add(o.reading);
  const fakes = sh(readingVariants(w.reading)).filter(x => !bad.has(x));
  const kanji = [...w.word].filter(c => hasKanji(c));
  const real = sh(words.filter(o => o !== w && hasKanji(o.word) && !bad.has(o.reading) && kanji.some(k => o.word.includes(k)) && Math.abs(o.reading.length - w.reading.length) <= 2 && (o.pg === w.pg || o.pg === '名詞' && w.pg === '數字與時間' || o.pg === '數字與時間' && w.pg === '名詞'))).map(o => o.reading);
  const cand = words.filter(o => o !== w && hasKanji(o.word) && !bad.has(o.reading) && o.pg !== '文法');
  const score = o => (o.pg === w.pg ? 0 : 2) + Math.abs(o.reading.length - w.reading.length);
  const near = sh(cand).sort((a, b) => score(a) - score(b)).map(o => o.reading);
  const out = [];
  const add = x => { if (x && !bad.has(x) && !out.includes(x) && out.length < 3) out.push(x); };
  fakes.slice(0, 2).forEach(add); real.slice(0, 1).forEach(add);
  fakes.slice(2).forEach(add); real.forEach(add); near.forEach(add);
  return out;
}

// ===== 助詞填空：可以互換的助詞不會同時出現在選項裡 =====
const PARTICLES = ['は', 'が', 'を', 'に', 'で', 'へ', 'と', 'も', 'の', 'や', 'から', 'まで'];
const PART_DISTRACT = {
  // は／が／も 不用「を」當錯誤選項：「この本は読みました／この本を読みました」兩個都對
  'は': ['に', 'で', 'へ', 'と'], 'が': ['に', 'で', 'へ', 'と'], 'も': ['に', 'で', 'へ', 'と'],
  'を': ['に', 'で', 'と', 'へ'], 'に': ['で', 'を', 'と', 'が'], 'へ': ['で', 'を', 'と', 'が'], 'で': ['に', 'を', 'と', 'が'],
  'と': ['に', 'で', 'を', 'が'], 'や': ['に', 'で', 'を', 'が'], 'の': ['に', 'で', 'を', 'が'],
  'から': ['に', 'で', 'を', 'と'], 'まで': ['に', 'で', 'を', 'と']
};
function pickParticleDistractors(p, rnd = Math.random) {
  const a = (PART_DISTRACT[p] || []).slice();
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a.slice(0, 3);
}

if (typeof module !== 'undefined') module.exports = { buildKana, romaToKana, kanaToRoma, normKana, align, prepWords, checkFill, kanaLen, applyAnswer, addDays, ymd, SRS, pickRound, pickWordDistractors, pickKanaDistractors, confuseMap, mergeState, sameMeaning, segsRomaji, toHira, toKata, blankRec, readingVariants, pickReadingDistractors, pickParticleDistractors, PART_DISTRACT, PARTICLES, hasKanji };

// ===== 句子斷詞與點字查義 =====

// 功能詞（助詞、助動詞、常見小詞）：[讀音, 說明]
const FUNC = {
  'は': ['わ', '助詞：標出主題（這裡念 wa）'],
  'が': ['が', '助詞：標出主語、喜好或存在的對象；也可當「但是」'],
  'を': ['お', '助詞：標出動作的對象（念 o）'],
  'に': ['に', '助詞：在（時間點、存在的地方）、給（對象）、往'],
  'で': ['で', '助詞：在（動作的地方）、用（工具、手段）、因為'],
  'へ': ['え', '助詞：往（方向，念 e）'],
  'と': ['と', '助詞：和（一起）、…和…'],
  'も': ['も', '助詞：也'],
  'の': ['の', '助詞：的；也可把動作變成名詞'],
  'から': ['から', '助詞：從（起點）；接在句子後是「因為」'],
  'まで': ['まで', '助詞：到（終點）'],
  'や': ['や', '助詞：…和…等（列舉一部分）'],
  'より': ['より', '助詞：比…'],
  'か': ['か', '助詞：放句尾表示疑問「嗎」'],
  'ね': ['ね', '句尾助詞：…呢（希望對方同意）'],
  'よ': ['よ', '句尾助詞：…喔（告訴對方）'],
  'な': ['な', 'な形容詞接名詞時的連接詞'],
  'お': ['お', '敬語的前綴，讓詞語更禮貌'],
  'ご': ['ご', '敬語的前綴'],
  'さん': ['さん', '接在人名後的敬稱：先生、小姐'],
  'です': ['です', '是（禮貌的斷定）'],
  'でした': ['でした', '是（過去，禮貌）'],
  'ですか': ['ですか', '是…嗎'],
  'じゃありません': ['じゃありません', '不是（禮貌）'],
  'ではありません': ['ではありません', '不是（禮貌，較正式）'],
  'でしょう': ['でしょう', '…吧（推測）'],
  'だ': ['だ', '是（普通體）'],
  'ので': ['ので', '因為'],
  'ながら': ['ながら', '一邊…一邊…（接在動詞ます形後面）'],
  'この': ['この', '這個（後面接名詞）'],
  'その': ['その', '那個（靠近對方，後面接名詞）'],
  'あの': ['あの', '那個（遠處，後面接名詞）'],
  'どの': ['どの', '哪個（後面接名詞）'],
  'どんな': ['どんな', '什麼樣的'],
  'どちら': ['どちら', '哪裡、哪邊（禮貌）'],
  'そう': ['そう', '那樣、是的'],
  'ます': ['ます', '動詞的禮貌語尾'],
  'ました': ['ました', '動詞的禮貌語尾（過去）'],
  'ません': ['ません', '動詞的禮貌語尾（否定）'],
  'ませんでした': ['ませんでした', '動詞的禮貌語尾（過去否定）'],
  'ましょう': ['ましょう', '…吧（提議）'],
  'ませんか': ['ませんか', '要不要…（邀請）'],
  'たい': ['たい', '想要（做某事）'],
  'たいです': ['たいです', '想要（做某事，禮貌）'],
  'てください': ['てください', '請…'],
  'ないでください': ['ないでください', '請不要…'],
  'ています': ['ています', '正在…；…著的狀態'],
  'ない': ['ない', '不（否定）'],
  'くない': ['くない', 'い形容詞的否定'],
  'なる': ['なる', '變成'],
  'なりました': ['なりました', '變成了'],
  'する': ['する', '做'],
  'して': ['して', '「する」的て形'],
  'たす': ['たす', '加（算數）'],
  'ひく': ['ひく', '減（算數）'],
  'では': ['では', '那麼'],
  'ずつ': ['ずつ', '各、每'],
  'ぐらい': ['ぐらい', '大約'],
  'くらい': ['くらい', '大約'],
  'ごろ': ['ごろ', '…左右（時間）'],
  'だけ': ['だけ', '只有'],
  'しか': ['しか', '只（後面接否定）'],
  'など': ['など', '等等'],
  'ください': ['ください', '請給我…；接て形是「請…」'],
  'ですから': ['ですから', '因為是…'],
  'なくて': ['なくて', '因為沒有…'],
  'し': ['し', '「する」（做）的變化形'],
};
// 只在句子開頭（或標點後）才當成這個詞，避免「は＋い…」被誤認成「はい」
const START_ONLY = new Set(['はい', 'いいえ', 'もしもし', 'では', 'ありがとう']);

// 單字表沒有、但例句裡出現的詞：[讀音, 中文, 詞性]
const EXTRA = {
  '三人': ['さんにん', '三個人', '數字與時間'],
  '五人': ['ごにん', '五個人', '數字與時間'],
  '六人': ['ろくにん', '六個人', '數字與時間'],
  '七人': ['しちにん', '七個人', '數字與時間'],
  '八人': ['はちにん', '八個人', '數字與時間'],
  '九人': ['きゅうにん', '九個人', '數字與時間'],
  '十人': ['じゅうにん', '十個人', '數字與時間'],
  '日本人': ['にほんじん', '日本人', '名詞'],
  '台湾人': ['たいわんじん', '台灣人', '名詞'],
  '何歳': ['なんさい', '幾歲', '名詞'],
  '十歳': ['じゅっさい', '十歲', '名詞'],
  '四人': ['よにん', '四個人', '名詞'],
  '二十人': ['にじゅうにん', '二十個人', '名詞'],
  '三十人': ['さんじゅうにん', '三十個人', '名詞'],
  '背': ['せ', '身高、背', '名詞'],
  '高': ['たか', '高（い形容詞的一部分）', 'い形容詞'],
  '優しい': ['やさしい', '溫柔的', 'い形容詞'],
  'コンビニ': ['コンビニ', '便利商店', '名詞'],
  '台南': ['たいなん', '台南', '名詞'],
  '台北': ['たいぺい', '台北', '名詞'],
  '京都': ['きょうと', '京都', '名詞'],
  '大阪': ['おおさか', '大阪', '名詞'],
  '林': ['りん', '林（姓氏）', '名詞'],
  '田中': ['たなか', '田中（姓氏）', '名詞'],
  '桜': ['さくら', '櫻花', '名詞'],
  '村': ['むら', '村子', '名詞'],
  '象': ['ぞう', '大象', '名詞'],
  'うさぎ': ['うさぎ', '兔子', '名詞'],
  'みかん': ['みかん', '橘子', '名詞'],
  'すし': ['すし', '壽司', '名詞'],
  'ラーメン': ['ラーメン', '拉麵', '名詞'],
  'たばこ': ['たばこ', '香菸', '名詞'],
  'はさみ': ['はさみ', '剪刀', '名詞'],
  'ボタン': ['ボタン', '按鈕', '名詞'],
  'テスト': ['テスト', '考試、測驗', '名詞'],
  'コンピューター': ['コンピューター', '電腦', '名詞'],
  '新幹線': ['しんかんせん', '新幹線（高鐵）', '名詞'],
  'パン屋': ['パンや', '麵包店', '名詞'],
  '花屋': ['はなや', '花店', '名詞'],
  '屋': ['や', '…店', '名詞'],
  '二階': ['にかい', '二樓', '名詞'],
  '五階': ['ごかい', '五樓', '名詞'],
  '三冊': ['さんさつ', '三本（書）', '數字與時間'],
  '三枚': ['さんまい', '三張', '數字與時間'],
  '一本': ['いっぽん', '一瓶、一枝（細長的東西）', '數字與時間'],
  '一度': ['いちど', '一次', '數字與時間'],
  '八時': ['はちじ', '八點', '數字與時間'],
  '九時': ['くじ', '九點', '數字與時間'],
  '十時': ['じゅうじ', '十點', '數字與時間'],
  '七時': ['しちじ', '七點', '數字與時間'],
  '六時': ['ろくじ', '六點', '數字與時間'],
  '五時': ['ごじ', '五點', '數字與時間'],
  '四時': ['よじ', '四點', '數字與時間'],
  '十一時': ['じゅういちじ', '十一點', '數字與時間'],
  '十二時': ['じゅうにじ', '十二點', '數字與時間'],
  '千円': ['せんえん', '一千日圓', '數字與時間'],
  '百円': ['ひゃくえん', '一百日圓', '數字與時間'],
  '五十': ['ごじゅう', '五十', '數字與時間'],
  '五百': ['ごひゃく', '五百', '數字與時間'],
  '次': ['つぎ', '下一個', '名詞'],
  '前': ['まえ', '前面；之前', '名詞'],
  '少': ['すこ', '少（「少し」的一部分）', '副詞'],
  'もう少し': ['もうすこし', '再…一點', '副詞'],
  'みなさん': ['みなさん', '各位、大家', '名詞'],
  '何': ['なに', '什麼', '名詞'],
  '何も': ['なにも', '（後接否定）什麼都不', '副詞'],
  'あと': ['あと', '之後', '名詞'],
  'あとで': ['あとで', '等一下、之後', '副詞'],
  'ありがとう': ['ありがとう', '謝謝（口語）', '招呼語與常用句'],
  'おいしかった': ['おいしかった', '（過去）很好吃', 'い形容詞'],
  '気': ['き', '心、精神（「気をつける」的一部分）', '名詞'],
  'つけて': ['つけて', '「つける」的て形（小心、注意）', '動詞'],
  '遅れて': ['おくれて', '遲到（「遅れる」的て形）', '動詞'],
  '遅れる': ['おくれる', '遲到', '動詞'],
  '上手': ['じょうず', '擅長', 'な形容詞'],
  'のが': ['のが', '把前面的動作變成名詞＋が', '文法'],
  '開け': ['あけ', '「開ける」（打開）的變化形', '動詞'],
  '入っ': ['はいっ', '「入る」（進入）的變化形', '動詞'],
  'かきます': ['かきます', '畫（「かく」的ます形）', '動詞'],
  'はきます': ['はきます', '穿（鞋、襪、褲子；「はく」的ます形）', '動詞'],
  'はいています': ['はいています', '穿著（鞋、襪、褲子）', '動詞'],
};

// 動詞、形容詞的變化形 → 原形
function verbForms(w, cls) {
  // 回傳 [表層, 說明]
  const out = [];
  const d = w;
  const last = d.slice(-1);
  let M, N, T, A, irregularN = null;
  if (/する$/.test(d)) { const b = d.slice(0, -2); M = b + 'し'; N = b + 'し'; T = b + 'して'; A = b + 'した'; }
  else if (d === '来る') { M = '来'; N = '来'; T = '来て'; A = '来た'; }
  else if (d === 'くる') { M = 'き'; N = 'こ'; T = 'きて'; A = 'きた'; }
  else if (cls === '二類') { const b = d.slice(0, -1); M = b; N = b; T = b + 'て'; A = b + 'た'; }
  else {
    const b = d.slice(0, -1);
    const I = { う: 'い', く: 'き', ぐ: 'ぎ', す: 'し', つ: 'ち', ぬ: 'に', ぶ: 'び', む: 'み', る: 'り' }[last];
    const Aa = { う: 'わ', く: 'か', ぐ: 'が', す: 'さ', つ: 'た', ぬ: 'な', ぶ: 'ば', む: 'ま', る: 'ら' }[last];
    const Te = { う: 'って', つ: 'って', る: 'って', む: 'んで', ぶ: 'んで', ぬ: 'んで', く: 'いて', ぐ: 'いで', す: 'して' }[last];
    if (!I) return out;
    M = b + I; N = b + Aa;
    T = (d === '行く' || d === 'いく') ? b + 'って' : b + Te;
    A = T.replace(/て$/, 'た').replace(/で$/, 'だ');
    if (d === 'ある') irregularN = 'ない';
  }
  const hasK = /[^぀-ゟ゠-ヿ]/.test(d);
  out.push([d, '原形（字典形）']);
  out.push([M + 'ます', 'ます形：禮貌的說法']);
  out.push([M + 'ません', 'ます形否定：不…']);
  out.push([M + 'ました', 'ます形過去：…了']);
  out.push([M + 'ませんでした', 'ます形過去否定：沒有…']);
  out.push([M + 'ましょう', '…吧（提議）']);
  out.push([M + 'ませんか', '要不要…（邀請）']);
  out.push([M + 'たい', '想要…']);
  out.push([M + 'に', 'ます形＋に：去做…（目的）']);
  out.push([T, 'て形：連接下一個動作']);
  out.push([T + 'います', 'ています：正在…、…著']);
  out.push([T + 'いました', 'ていました：過去一直…']);
  out.push([T + 'いません', 'ていません：還沒…']);
  out.push([T + 'ください', 'てください：請…']);
  out.push([T + 'もいいですか', 'てもいいですか：可以…嗎']);
  out.push([T + 'も', 'ても']);
  out.push([A, 'た形：…了（普通體）']);
  out.push([A + 'り', 'たり：…啦…啦（列舉幾個動作）']);
  if (irregularN) out.push([irregularN, '否定']);
  else {
    out.push([N + 'ない', 'ない形：不…']);
    out.push([N + 'ないで', 'ないで：不要…']);
    out.push([N + 'ないでください', 'ないでください：請不要…']);
    out.push([N + 'なくて', 'なくて：因為沒有…']);
  }
  if (hasK) { out.push([M, '連用形']); out.push([N, '未然形（接ない等）']); out.push([T.slice(0, -1), 'て形的一部分']); }
  return out;
}
function adjForms(w) {
  const out = [[w, '原形']];
  if (w === 'いい') return out.concat([['よかった', '過去：（那時）很好'], ['よく', '副詞形'], ['よくない', '否定：不好']]);
  const b = w.slice(0, -1);
  return out.concat([
    [b + 'かった', '過去：（那時）很…'], [b + 'く', '副詞形：…地；接なる是「變得…」'], [b + 'くない', '否定：不…'],
    [b + 'くなかった', '過去否定'], [b + 'くて', 'て形：連接下一句'], [b + 'くなりました', '變得…了']
  ]);
}

// 建立斷詞字典：表層 → {e: 條目, f: 說明}
const NUM_KANJI = ['一', '二', '三', '四', '五', '六', '七', '八', '九', '十', '何', '百', '二十', '三十', '五十'];
const COUNTERS = new Set(['枚', '冊', '本', '匹', '台', '個', '階', '回', '歳', '杯', '週間', 'か月', '年', '時', '分', '時間', '円', '人']);
function buildGlossary(words) {
  const D = new Map();
  const put = (k, v, prio) => { if (!k) return; const cur = D.get(k); if (!cur || (prio || 0) > (cur.p || 0)) D.set(k, Object.assign({ p: prio || 0 }, v)); };
  for (const k in FUNC) put(k, { e: 'f:' + k, f: '' }, 1);
  for (const k in EXTRA) put(k, { e: 'x:' + k, f: '' }, 2);
  for (const w of words) {
    if (w.pg === '文法') continue;
    if (w.pg === '動詞') {
      const cls = (w.pos.match(/[一二三]類/) || [''])[0];
      for (const [s, f] of verbForms(w.word, cls)) put(s, { e: w.id, f: s === w.word ? '' : f }, 3);
    } else if (w.pg === 'い形容詞') {
      for (const [s, f] of adjForms(w.word)) put(s, { e: w.id, f: s === w.word ? '' : f }, 3);
    } else if (w.pg === 'な形容詞') {
      put(w.word, { e: w.id, f: '' }, 3);
      put(w.word + 'な', { e: w.id, f: '＋な：修飾後面的名詞' }, 3);
      put(w.word + 'に', { e: w.id, f: '＋に：副詞用法' }, 3);
    } else {
      put(w.word, { e: w.id, f: '' }, 3);
    }
    // 量詞：數字＋量詞（二匹、三時、一週間）整段都能點；已有的單字（一日、二人）優先
    if (w.pg === '數字與時間' && COUNTERS.has(w.word)) {
      for (const n of NUM_KANJI) put(n + w.word, { e: w.id, f: '數字＋量詞' }, 2);
    }
    // 漢字詞也接受全假名寫法（例：面白い ↔ おもしろい），但太短的不收
    if (w.word !== w.reading && w.reading.length >= 4 && w.pg !== '動詞') {
      if (w.pg === 'い形容詞') for (const [s2, f] of adjForms(w.reading)) put(s2, { e: w.id, f: s2 === w.reading ? '' : f }, 1);
      else put(w.reading, { e: w.id, f: '' }, 1);
    }
  }
  return D;
}

// 以 segment 為單位，最長匹配斷詞。漢字段（有振り仮名的 seg）不會被切開。
function tokenizeSegs(segs, from, to, D) {
  const toks = [];
  let i = from;
  while (i < to) {
    const s = segs[i];
    if (s.r === null && isPunct(s.t)) { toks.push({ s0: i, s1: i + 1, e: null }); i++; continue; }
    let best = null, str = '';
    for (let j = i; j < to && j < i + 16; j++) {
      if (segs[j].r === null && isPunct(segs[j].t)) break;
      str += segs[j].t;
      const hit = D.get(str);
      if (hit && START_ONLY.has(str) && i > 0 && !(segs[i - 1].r === null && isPunct(segs[i - 1].t))) continue;
      if (hit) best = { s0: i, s1: j + 1, e: hit.e, f: hit.f };
    }
    if (best) { toks.push(best); i = best.s1; continue; }
    // 沒對到：漢字段自己一個，片假名連成一段，其他單字一段
    if (s.r !== null) { toks.push({ s0: i, s1: i + 1, e: null }); i++; continue; }
    let j = i + 1;
    const isKata = c => /[゠-ヿ]/.test(c);
    if (isKata(s.t)) while (j < to && segs[j].r === null && isKata(segs[j].t)) j++;
    toks.push({ s0: i, s1: j, e: null });
    i = j;
  }
  return toks;
}
function tokenizeWord(w, D) {
  const n = w.segs.length;
  if (w.a0 < 0) return tokenizeSegs(w.segs, 0, n, D);
  return tokenizeSegs(w.segs, 0, w.a0, D)
    .concat([{ s0: w.a0, s1: w.a1, e: w.id, f: w.ans !== w.word && w.pg !== '文法' ? '這句裡的變化形' : '', self: true }])
    .concat(tokenizeSegs(w.segs, w.a1, n, D));
}

// ===== 語法補充：每個文法點標上等級，之後可依等級隱藏已經會的 =====
// m(c)：在句子 c 裡找到就回傳句中的那段文字，找不到回傳 null
// c.toks = [{s: 表層, e: 條目 id, f: 變化說明}]，c.sent = 句子
const GLOSS_LEVELS = ['N5', 'N4', 'N3', 'N2', 'N1'];
const byE = (e) => c => { const t = c.toks.find(t => t.e === e); return t ? t.s : null; };
const byF = (re) => c => { const t = c.toks.find(t => t.f && re.test(t.f)); return t ? t.s : null; };
const GRAMMAR_POINTS = [
  { id: 'wa', lv: 'N5', t: '「は」主題', d: '放在主題後面，意思像「說到…的話」。助詞的「は」念 wa。', m: byE('f:は') },
  { id: 'ga', lv: 'N5', t: '「が」主語', d: '標出「誰／什麼」做這件事或存在；喜歡、討厭、擅長、懂、有的對象也用「が」。', m: byE('f:が') },
  { id: 'o', lv: 'N5', t: '「を」動作的對象', d: '放在動作的對象後面，例如「パンを食べます」（吃麵包）。念 o。', m: byE('f:を') },
  { id: 'ni', lv: 'N5', t: '「に」時間、地點、對象', d: '表示時間點（七時に）、人或物存在的地方（部屋に）、動作的對象（母に）或目的地。', m: byE('f:に') },
  { id: 'de', lv: 'N5', t: '「で」地點、手段', d: '表示動作發生的地方（公園で），或使用的工具、交通方式（バスで）。', m: byE('f:で') },
  { id: 'e', lv: 'N5', t: '「へ」方向', d: '表示移動的方向，常和「行きます、来ます、帰ります」一起用。念 e。', m: byE('f:へ') },
  { id: 'to', lv: 'N5', t: '「と」和', d: '「AとB」是 A 和 B；「人と」是和某人一起。', m: byE('f:と') },
  { id: 'mo', lv: 'N5', t: '「も」也', d: '取代「は、が、を」，表示「也是這樣」。', m: byE('f:も') },
  { id: 'no', lv: 'N5', t: '「の」的', d: '連接兩個名詞，表示所屬或說明，例如「先生の傘」（老師的傘）。', m: byE('f:の') },
  { id: 'kara', lv: 'N5', t: '「から」從、因為', d: '接在名詞後是「從…」（九時から）；接在句子後是「因為…」（雨ですから）。', m: c => byE('f:から')(c) || byE('f:ですから')(c) },
  { id: 'made', lv: 'N5', t: '「まで」到', d: '表示終點，常和「から」配對：「AからBまで」＝從 A 到 B。', m: byE('f:まで') },
  { id: 'ya', lv: 'N5', t: '「や」列舉', d: '「AやB」＝A 和 B 等等，只舉出其中幾個。', m: byE('f:や') },
  { id: 'dake', lv: 'N5', t: '「だけ」只有', d: '接在名詞或數量後面：只…。例如「一つだけ」＝只有一個。', m: byE('f:だけ') },
  { id: 'zutsu', lv: 'N5', t: '「ずつ」各…、每…', d: '接在數量後面，表示平均分配或每次的量。例如「一人に二つずつ」＝每人各兩個。', m: byE('f:ずつ') },
  { id: 'gurai', lv: 'N5', t: '「ぐらい／くらい」大約', d: '接在數量、時間、距離後面表示大概的量。例如「十分ぐらい」＝大約十分鐘。', m: c => byE('f:ぐらい')(c) || byE('f:くらい')(c) },
  { id: 'nado', lv: 'N5', t: '「など」等等', d: '列舉之後加「など」，表示還有其他的，常和「や」一起用：りんごやみかんなど＝蘋果、橘子等等。', m: byE('f:など') },
  { id: 'yori', lv: 'N5', t: '「より」比較', d: '「AよりBが…」＝B 比 A 更…。', m: byE('f:より') },
  { id: 'ka', lv: 'N5', t: '句尾「か」疑問', d: '放在句尾就變成問句，語調上揚，不需要問號也可以。', m: c => byE('f:か')(c) || byE('f:ですか')(c) || byF(/^要不要/)(c) },
  { id: 'ne', lv: 'N5', t: '句尾「ね」', d: '…呢。說話者覺得對方也會同意時加上。', m: byE('f:ね') },
  { id: 'yo', lv: 'N5', t: '句尾「よ」', d: '…喔。告訴對方他可能不知道的事。', m: byE('f:よ') },
  { id: 'desu', lv: 'N5', t: '「です」禮貌的「是」', d: '放在名詞或形容詞後面，讓句子變禮貌。過去是「でした」。', m: c => byE('f:です')(c) || byE('f:でした')(c) || byE('f:ですか')(c) || byE('f:ですから')(c) },
  { id: 'janai', lv: 'N5', t: '「じゃありません」不是', d: '「です」的否定。比較正式的寫法是「ではありません」。', m: c => byE('f:じゃありません')(c) || byE('f:ではありません')(c) },
  { id: 'deshou', lv: 'N5', t: '「でしょう」推測', d: '…吧。對不確定的事表示推測，或確認對方是否同意。', m: byE('f:でしょう') },
  { id: 'masu', lv: 'N5', t: '「〜ます」禮貌形', d: '動詞的禮貌說法，用在現在的習慣或未來要做的事。', m: c => byF(/^ます形：/)(c) || byE('f:ます')(c) },
  { id: 'masen', lv: 'N5', t: '「〜ません」否定', d: '「ます」的否定：不…。', m: c => byF(/^ます形否定/)(c) || byE('f:ません')(c) },
  { id: 'mashita', lv: 'N5', t: '「〜ました」過去', d: '「ます」的過去：…了。', m: c => byF(/^ます形過去：/)(c) || byE('f:ました')(c) },
  { id: 'masendeshita', lv: 'N5', t: '「〜ませんでした」過去否定', d: '沒有…（過去）。', m: c => byF(/^ます形過去否定/)(c) || byE('f:ませんでした')(c) },
  { id: 'mashou', lv: 'N5', t: '「〜ましょう」提議', d: '…吧。邀對方一起做，或主動提議。', m: c => byF(/^…吧（提議）/)(c) || byE('f:ましょう')(c) },
  { id: 'masenka', lv: 'N5', t: '「〜ませんか」邀請', d: '要不要…？比「ましょう」更客氣的邀約。', m: c => byF(/^要不要/)(c) || byE('f:ませんか')(c) },
  { id: 'tai', lv: 'N5', t: '「〜たい」想要做', d: '動詞ます形去掉「ます」加「たい」：想做…。禮貌說法再加「です」。', m: c => byF(/^想要/)(c) || byE('f:たい')(c) || byE('f:たいです')(c) },
  { id: 'nini', lv: 'N5', t: '「〜に行く」去做…', d: '動詞ます形去掉「ます」加「に」，再接「行く、来る」：去（來）做某事。', m: byF(/^ます形＋に/) },
  { id: 'te', lv: 'N5', t: '「て形」連接', d: '把兩個動作接在一起：先做 A，再做 B。也是很多句型的基礎。', m: byF(/^て形：/) },
  { id: 'tekudasai', lv: 'N5', t: '「〜てください」請…', d: '動詞て形加「ください」，禮貌地請對方做某事。', m: c => byF(/^てください/)(c) || byE('f:てください')(c) },
  { id: 'naidekudasai', lv: 'N5', t: '「〜ないでください」請不要…', d: '動詞ない形加「でください」，禮貌地請對方不要做。', m: c => byF(/^ないでください/)(c) || byE('f:ないでください')(c) },
  { id: 'teimasu', lv: 'N5', t: '「〜ています」正在…／狀態', d: '動詞て形加「います」：正在做的事，或持續的狀態（住んでいます＝住在）。', m: c => byF(/^ていま/)(c) || byE('f:ています')(c) },
  { id: 'temoii', lv: 'N5', t: '「〜てもいいですか」可以…嗎', d: '動詞て形加「もいいですか」，詢問許可。', m: c => byF(/^てもいいですか/)(c) || byE('f:てもいいですか')(c) },
  { id: 'tekara', lv: 'N5', t: '「〜てから」…之後', d: '動詞て形加「から」：做完 A 之後再做 B，強調先後順序。例如「食べてから、歯を磨きます」＝吃完再刷牙。', m: c => byF(/^てから/)(c) || byE('f:てから')(c) },
  { id: 'nagara', lv: 'N5', t: '「〜ながら」一邊…一邊…', d: '動詞ます形去掉「ます」加「ながら」：同時做兩件事，主要的動作放在後面。例如「音楽を聞きながら勉強します」。', m: byE('f:ながら') },
  { id: 'tari', lv: 'N5', t: '「〜たり〜たりする」列舉動作', d: '動詞た形加「り」，舉出幾個代表性的動作，最後用「する」收尾。例如「本を読んだり、映画を見たりします」。', m: byF(/^たり/) },
  { id: 'nai', lv: 'N5', t: '「〜ない」否定（普通體）', d: '「ません」的普通說法。', m: byF(/^ない形/) },
  { id: 'ta', lv: 'N5', t: '「〜た」過去（普通體）', d: '「ました」的普通說法。', m: c => byF(/^た形/)(c) || byE('f:た')(c) },
  { id: 'ikatta', lv: 'N5', t: 'い形容詞過去「〜かった」', d: '去掉「い」加「かった」：（那時）很…。禮貌說法再加「です」。', m: byF(/^過去：/) },
  { id: 'ikunai', lv: 'N5', t: 'い形容詞否定「〜くない」', d: '去掉「い」加「くない」：不…。', m: byF(/^否定：/) },
  { id: 'iku', lv: 'N5', t: 'い形容詞「〜く」', d: '去掉「い」加「く」變成副詞（大きく開ける＝張大），或接「なる」表示變化（寒くなる＝變冷）。', m: byF(/^副詞形/) },
  { id: 'naru', lv: 'N5', t: '「〜くなる」變得…', d: 'い形容詞去掉「い」加「くなる」，表示狀態改變：寒くなりました＝變冷了。', m: c => byF(/^變得/)(c) || byE('f:なりました')(c) },
  { id: 'nana', lv: 'N5', t: 'な形容詞＋「な」＋名詞', d: 'な形容詞放在名詞前要加「な」：静かな所（安靜的地方）。', m: byF(/^＋な/) },
  { id: 'kono', lv: 'N5', t: '「この／その／あの」', d: '這個／那個（近對方）／那個（遠處），後面一定接名詞。', m: c => { const t = c.toks.find(t => /^(この|その|あの|どの)$/.test(t.s)); return t ? t.s : null; } },
  { id: 'aruiru', lv: 'N5', t: '「あります／います」存在', d: '東西、植物用「あります」；人、動物用「います」。常見句型：「地點に＋東西が＋あります」。', m: c => { const t = c.toks.find(t => t.e && /^v:(ある|いる)\|/.test(t.e)); return t ? t.s : null; } },
];

// 找出一句例句用到的文法點
function grammarOf(w, toks, D) {
  const segs = w.segs;
  const list = toks.map(t => {
    const s = segs.slice(t.s0, t.s1).map(x => x.t).join('');
    let e = t.e, f = t.f || '';
    if (t.self) { const g = D.get(s); if (g) { f = g.f || ''; e = g.e; } else if (w.pg === '文法') e = 'f:' + s; }
    return { s, e, f };
  });
  // て形＋ください／います 合成一個句型
  for (let i = 0; i < list.length - 1; i++) {
    const a = list[i], b = list[i + 1];
    if (!/^て形/.test(a.f)) continue;
    let f = '';
    if (b.s === 'ください') f = 'てください：請…';
    else if (/^(います|いました|いません)$/.test(b.s)) f = 'ています：正在…、…著';
    else if (b.s === 'から') f = 'てから：…之後';
    if (f) { list.splice(i, 2, { s: a.s + b.s, e: a.e, f }); continue; }
    // て形＋も＋いい＋ですか → 「〜てもいいですか」
    const c2 = list[i + 2], d2 = list[i + 3];
    if (b.s === 'も' && c2 && c2.s === 'いい' && d2 && /^ですか/.test(d2.s)) list.splice(i, 4, { s: a.s + 'もいいですか', e: a.e, f: 'てもいいですか：可以…嗎' });
  }
  const c = { toks: list, sent: w.sent };
  const out = [];
  if (list.some(t => t.e === 'f:なりました')) list.forEach(t => { if (t.f && /^副詞形/.test(t.f)) t.f = '變得'; });
  for (const p of GRAMMAR_POINTS) { const s = p.m(c); if (s) out.push({ p, s }); }
  return out;
}

// ===== 詞形變化表與詞性解說 =====
const TYPE_INFO = {
  '動詞(一類)': ['一類動詞（五段動詞）', '字尾是う段音（う、く、ぐ、す、つ、ぬ、ぶ、む、る）。變化時，字尾在あ、い、う、え、お段之間移動：ます形把字尾換成い段（飲む → 飲みます），ない形換成あ段（飲む → 飲まない，う結尾的換成わ）。て形看字尾：う・つ・る → って，む・ぶ・ぬ → んで，く → いて，ぐ → いで，す → して。「行く」是例外，て形是「行って」。'],
  '動詞(二類)': ['二類動詞（一段動詞）', '字尾是「る」，前面通常是い段或え段的音（見る、食べる）。變化最簡單：去掉「る」，直接加ます、て、ない、た（食べる → 食べます、食べて、食べない、食べた）。'],
  '動詞(三類)': ['三類動詞（不規則動詞）', '只有「する」（做）和「来る」（來）兩個，加上「名詞＋する」的動詞（勉強する、散歩する）。變化不規則，要直接背：する → します、して、しない；来る → 来ます（きます）、来て（きて）、来ない（こない）。'],
  'い形容詞': ['い形容詞', '以「い」結尾的形容詞，可以直接放在名詞前面（大きい犬）。變化發生在最後的「い」：過去換成「かった」，否定換成「くない」，連接下一句換成「くて」。「いい」比較特別，變化時要用「よ」開頭（よかった、よくない）。'],
  'な形容詞': ['な形容詞', '放在名詞前面要加「な」（静かな町）。本身不變化，變化都在後面的「です」：でした、じゃありません。變成副詞時加「に」（静かに）。'],
  '名詞': ['名詞', '表示人、事、物、地方的詞，本身不變化。後面加「です」是「是…」；過去加「でした」，否定加「じゃありません」。'],
  '副詞': ['副詞', '用來形容動作或形容詞的程度、方式（とても、ゆっくり），本身不變化，通常放在動詞或形容詞前面。'],
  '指示詞・連接詞': ['指示詞・連接詞', '「こそあど」系列的詞（この・その・あの・どの、こちら・そちら…）和連接句子的詞（そして、しかし、それから）。本身不變化：この、その這類後面一定要接名詞；連接詞放在句子開頭，用來接上一句。'],
  '數字與時間': ['數字與時間', '數字、日期、時間的說法本身不變化。注意有些數字在不同場合念法不同，例如「四」可以念よん或し，「七」可以念なな或しち。'],
  '招呼語與常用句': ['招呼語與常用句', '固定的說法，不用拆開變化，整句記起來，在對的場合使用就好。'],
  '文法': ['文法', '助詞或句型，接在其他詞的後面，用來表示關係或語氣。'],
};
// 一類動詞裡，長得像二類（い段、え段＋る）的例外
const LOOKS_ICHIDAN = w => /(い|き|ぎ|し|じ|ち|に|ひ|び|ぴ|み|り|え|け|げ|せ|ぜ|て|で|ね|へ|べ|ぺ|め|れ)る$/.test(w.reading);

function conjugate(w) {
  // 回傳 [{label, s(表層), r(讀音), note}]
  const rows = [];
  const add = (label, s, r, note) => rows.push({ label, s, r, note: note || '' });
  if (w.pg === '動詞') {
    const cls = (w.pos.match(/[一二三]類/) || [''])[0];
    const A = verbForms(w.word, cls), B = verbForms(w.reading, cls);
    const get = re => { const i = A.findIndex(x => re.test(x[1])); return i >= 0 ? [A[i][0], B[i] ? B[i][0] : ''] : null; };
    const pick = [
      ['原形', /^原形/, '字典上查到的樣子；接「の」「前に」等句型時要用原形'],
      ['ます形', /^ます形：/, '禮貌的說法'],
      ['否定', /^ます形否定/, '不…（禮貌）'],
      ['過去', /^ます形過去：/, '…了（禮貌）'],
      ['過去否定', /^ます形過去否定/, '沒有…（禮貌）'],
      ['て形', /^て形：/, '連接下一個動作；很多句型的基礎'],
      ['〜てください', /^てください/, '請…'],
      ['〜ています', /^ていま/, '正在…、…著'],
      ['ない形', /^ない形/, '不…（普通體）'],
      ['た形', /^た形/, '…了（普通體）'],
      ['〜たい', /^想要/, '想要…'],
    ];
    for (const [label, re, note] of pick) { const g = get(re); if (g) add(label, g[0], g[1], note); }
    if (w.word === 'ある') { for (const l of ['〜てください', '〜ています', '〜たい']) { const k = rows.findIndex(r => r.label === l); if (k >= 0) rows.splice(k, 1); } }
    if (w.word === 'ある') { const i = rows.findIndex(r => r.label === 'ない形'); const row = { label: 'ない形', s: 'ない', r: 'ない', note: '不規則：沒有' }; if (i >= 0) rows[i] = row; else rows.splice(8, 0, row); }
  } else if (w.pg === 'い形容詞') {
    const ii = w.word === 'いい';
    const sb = ii ? 'よ' : w.word.slice(0, -1), rb = ii ? 'よ' : w.reading.slice(0, -1);
    add('原形', w.word, w.reading, '可以直接放在名詞前面');
    add('〜です', w.word + 'です', w.reading + 'です', '禮貌的說法');
    add('過去', sb + 'かったです', rb + 'かったです', '（那時）很…');
    add('否定', sb + 'くないです', rb + 'くないです', '不…');
    add('過去否定', sb + 'くなかったです', rb + 'くなかったです', '（那時）不…');
    add('て形', sb + 'くて', rb + 'くて', '連接下一句：又…又…');
    add('副詞', sb + 'く', rb + 'く', '…地；接「なる」是變得…');
  } else if (w.pg === 'な形容詞') {
    add('〜です', w.word + 'です', w.reading + 'です', '禮貌的說法');
    add('過去', w.word + 'でした', w.reading + 'でした', '（那時）很…');
    add('否定', w.word + 'じゃありません', w.reading + 'じゃありません', '不…');
    add('過去否定', w.word + 'じゃありませんでした', w.reading + 'じゃありませんでした', '（那時）不…');
    add('＋な＋名詞', w.word + 'な', w.reading + 'な', '修飾名詞，例：' + w.word + 'な人');
    add('＋に', w.word + 'に', w.reading + 'に', '變成副詞：…地');
  } else if (w.pg === '名詞' || w.pg === '數字與時間') {
    add('〜です', w.word + 'です', w.reading + 'です', '是…');
    add('過去', w.word + 'でした', w.reading + 'でした', '（那時）是…');
    add('否定', w.word + 'じゃありません', w.reading + 'じゃありません', '不是…');
  }
  return rows;
}
function typeInfo(w) {
  const base = TYPE_INFO[w.pos] || TYPE_INFO[w.pg] || [w.pos, ''];
  let extra = '';
  if (w.pos === '動詞(一類)' && LOOKS_ICHIDAN(w)) extra = `注意：「${w.word}」雖然是 い段或え段＋る 結尾，看起來像二類，但其實是一類動詞，要特別記住。`;
  if (w.word === '行く') extra = '注意：「行く」的て形是例外，是「行って」，不是「行いて」。';
  if (w.word === 'ある') extra = '注意：「ある」的否定是「ない」，不是「あらない」。';
  if (w.word === 'いい') extra = '注意：「いい」變化時要換成「よ」：よかった、よくない、よくて。';
  return { title: base[0], desc: base[1], extra };
}

// ===== 各變化形的句型例句（固定的標準例句）=====
// [句子, 讀音, 中文, 要標出的部分]；「|」是對齊振り仮名用的分段
const FORM_EXAMPLES = {
  '動詞|原形': [['音楽を聞くのが好きです。', 'おんがくをきくのがすきです。', '我喜歡聽音樂。', '聞く'], ['寝る前に歯を磨きます。', 'ねるまえにはをみがきます。', '睡覺前刷牙。', '寝る']],
  '動詞|ます形': [['毎朝コーヒーを飲みます。', 'まいあさコーヒーをのみます。', '我每天早上喝咖啡。', '飲みます']],
  '動詞|否定': [['私はお酒を飲みません。', 'わたしはおさけをのみません。', '我不喝酒。', '飲みません']],
  '動詞|過去': [['昨日、映画を見ました。', 'きのう、えいがをみました。', '昨天看了電影。', '見ました']],
  '動詞|過去否定': [['昨日は何も食べませんでした。', 'きのうはなにもたべませんでした。', '昨天什麼都沒吃。', '食べませんでした']],
  '動詞|て形': [['朝ご飯を食べて、学校へ行きます。', 'あさごはんをたべて、がっこうへいきます。', '吃完早餐，然後去學校。', '食べて']],
  '動詞|〜てください': [['ちょっと待ってください。', 'ちょっとまってください。', '請稍等一下。', '待ってください']],
  '動詞|〜ています': [['今、雨が降っています。', 'いま、あめがふっています。', '現在正在下雨。', '降っています'], ['姉は東京に住んでいます。', 'あねはとうきょうにすんでいます。', '姊姊住在東京。（持續的狀態）', '住んでいます']],
  '動詞|ない形': [['今日は学校へ行かない。', 'きょうはがっこうへいかない。', '今天不去學校。（對朋友說）', '行かない']],
  '動詞|た形': [['昨日、友達に会った。', 'きのう、ともだちにあった。', '昨天見到朋友了。（對朋友說）', '会った']],
  '動詞|〜たい': [['日本へ行きたいです。', 'にほんへいきたいです。', '我想去日本。', '行きたい']],
  'い形容詞|原形': [['大きい犬がいます。', 'おおきいいぬがいます。', '有一隻大狗。', '大きい']],
  'い形容詞|〜です': [['この本は面白いです。', 'このほんはおもしろいです。', '這本書很有趣。', '面白いです']],
  'い形容詞|過去': [['昨日は寒かったです。', 'きのうはさむかったです。', '昨天很冷。', '寒かったです']],
  'い形容詞|否定': [['この料理は辛くないです。', 'このりょうりはからくないです。', '這道菜不辣。', '辛くないです']],
  'い形容詞|過去否定': [['テストは難しくなかったです。', 'テストはむずかしくなかったです。', '考試不難。', '難しくなかったです']],
  'い形容詞|て形': [['この部屋は広くて、明るいです。', 'このへやはひろくて、あかるいです。', '這個房間又寬敞又明亮。', '広くて']],
  'い形容詞|副詞': [['大きく書いてください。', 'おおきくかいてください。', '請寫大一點。', '大きく'], ['だんだん寒くなりました。', 'だんだんさむくなりました。', '漸漸變冷了。', '寒く']],
  'な形容詞|〜です': [['この町は静かです。', 'このまちはしずかです。', '這個城鎮很安靜。', '静かです']],
  'な形容詞|過去': [['昨日は暇でした。', 'きのうはひまでした。', '昨天很閒。', '暇でした']],
  'な形容詞|否定': [['私は料理が上手じゃありません。', 'わたしはりょうりがじょうずじゃありません。', '我不擅長做菜。', '上手じゃありません']],
  'な形容詞|過去否定': [['テストは簡単じゃありませんでした。', 'テストはかんたんじゃありませんでした。', '考試不簡單。', '簡単じゃありませんでした']],
  'な形容詞|＋な＋名詞': [['静かな部屋が好きです。', 'しずかなへやがすきです。', '我喜歡安靜的房間。', '静かな']],
  'な形容詞|＋に': [['静かに話してください。', 'しずかにはなしてください。', '請小聲說話。', '静かに']],
  '名詞|〜です': [['私は学生です。', 'わたしはがくせいです。', '我是學生。', '学生です']],
  '名詞|過去': [['昨日は雨でした。', 'きのうはあめでした。', '昨天下雨。', '雨でした']],
  '名詞|否定': [['私は先生じゃありません。', 'わたしはせんせいじゃありません。', '我不是老師。', '先生じゃありません']],
};
FORM_EXAMPLES['數字與時間|〜です'] = [['今日は日曜日です。', 'きょうはにちようびです。', '今天是星期日。', '日曜日です']];
FORM_EXAMPLES['數字與時間|過去'] = [['昨日は月曜日でした。', 'きのうはげつようびでした。', '昨天是星期一。', '月曜日でした']];
FORM_EXAMPLES['數字與時間|否定'] = [['今日は休みじゃありません。', 'きょうはやすみじゃありません。', '今天不是休假日。', '休みじゃありません']];

// 把一句話整理成可顯示的物件：segs（振り仮名）、toks（可點單字）、hl（要標出的 seg 範圍）
function prepSentence(text, reading, zh, hlText, D) {
  const segs = align(text, reading) || [{ t: text.replace(/\|/g, ''), r: null }];
  const plain = text.replace(/\|/g, '');
  const hl = segRange(segs, plain.indexOf(hlText), hlText.length);
  return { segs, plain, reading: reading.replace(/\|/g, ''), zh, hl, toks: tokenizeSegs(segs, 0, segs.length, D) };
}
// 字元範圍 → 覆蓋它的 seg 範圍
function segRange(segs, start, len) {
  if (start < 0) return null;
  let pos = 0, a = -1, b = -1;
  for (let i = 0; i < segs.length; i++) {
    const s0 = pos, s1 = pos + segs[i].t.length;
    if (a < 0 && s1 > start) a = i;
    if (s0 < start + len) b = i + 1;
    pos = s1;
  }
  return a >= 0 && b > a ? [a, b] : null;
}
// 某個字的某個變化形：從全部例句裡找真的用到這個形的句子
function corpusExamples(row, w, words, max) {
  const out = [];
  if (!row.s || row.s.length < 2) return out;
  for (const x of words) {
    if (x.pg === '文法' && x.id !== w.id) continue;
    const i = x.sent.indexOf(row.s);
    if (i < 0) continue;
    // 確認句中那段真的是這個字（避免撞到別的字，例如「来ます」對到別的動詞）
    const before = x.sent[i - 1];
    if (before && /[一-鿿]/.test(before) && /^[一-鿿]/.test(row.s)) continue;
    const after = x.sent.slice(i + row.s.length);
    if (row.label === '原形' && /^(ます|ません)/.test(after)) continue;
    out.push({ x, start: i });
    if (out.length >= max) break;
  }
  return out;
}

