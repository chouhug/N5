(function (G) { const EN = G.EN || (G.EN = {});
/* 英文 B2 文法關卡：由淺到深，後面的關卡會用到前面學過的東西 */
EN.GX_PATH = [
  ['完成式和過去', '現在完成式、for／since、完成進行式、過去完成式', ['pres-perf', 'for-since', 'perf-cont', 'past-perf']],
  ['未來和情態動詞', 'will 和 be going to、未來完成式、must／have to、推測、had better', ['future', 'fut-perf', 'obligation', 'deduction', 'better-rather']],
  ['動詞句型', '後面接 -ing 還是 to、used to、片語動詞、make／let', ['gerund', 'infinitive', 'ing-to', 'used-to', 'phrasal', 'make-let']],
  ['名詞和形容詞', '不可數名詞、few／little、bored／boring、詞性變化、形容詞＋介係詞', ['uncount', 'quant', 'ed-ing', 'word-form', 'prep-coll']],
  ['比較', '比較級、so／such、too／enough、程度副詞', ['compar', 'so-such', 'too-enough', 'degree']],
  ['被動和子句', '被動語態、請人做、關係子句、間接引述、間接問句', ['passive', 'have-done', 'relative', 'reported', 'rep-q']],
  ['假設', '三種條件句、I wish、unless、should have', ['cond1', 'cond2', 'cond3', 'wish', 'cond-link', 'past-modal']],
  ['連接', '雖然、為了、因為所以、說話時的轉折語', ['contrast', 'purpose', 'cause', 'markers']]
];
})(typeof window !== 'undefined' ? window : globalThis);
