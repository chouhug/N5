/* B2 文法點與變化規則（英文）
   每個文法點：id、title、tag（分類）、body（說明 HTML）、m（比對規則）、ex（額外例句）
   比對規則 m：{ re: 正規式字串（不分大小寫） } 或 { tok: 判斷函式名稱 } */
(function (G) {
  'use strict';
  const EN = G.EN || (G.EN = {});

  /* ---------- 比對工具 ---------- */
  let LK = null;
  function look() {
    if (!LK) LK = EN.buildLookup(EN.W, Object.assign({}, EN.EXTRA_FORMS, EN.EXTRA_LOOKUP));
    return LK;
  }
  EN.getLookup = look;
  // 所有動詞的過去分詞、-ing 形（含基本字），給正規式用
  let PP = null, ING = null;
  function formSets() {
    if (PP) return;
    PP = new Set(); ING = new Set();
    look().forEach((arr, k) => {
      if (arr.some(x => /過去分詞/.test(x.desc) && !/片語動詞/.test(x.desc))) PP.add(k);
      if (arr.some(x => /-ing 形/.test(x.desc) && !/片語動詞/.test(x.desc))) ING.add(k);
    });
    ['used', 'supposed'].forEach(x => PP.delete(x));
  }
  function toks(s) {
    const out = []; let i = 0;
    for (const t of EN.tokenize(s)) { out.push({ t: t.t, w: t.w, s: i, e: i + t.t.length, k: EN.norm(t.t).toLowerCase() }); i += t.t.length; }
    return out;
  }
  const info = k => look().get(k) || [];
  const ent = x => x.idx >= 0 ? EN.W[x.idx] : null;
  const W = T => T.map((t, i) => t.w ? i : -1).filter(i => i >= 0);
  const BE = new Set(['am', 'is', 'are', 'was', 'were', 'be', 'been', 'being', "it's", "that's", "there's", "he's", "she's"]);
  const HAVE = new Set(['have', 'has', "haven't", "hasn't", "i've", "you've", "we've", "they've"]);
  const SUBJ = new Set(['i', 'you', 'he', 'she', 'it', 'we', 'they']);   // 疑問句：Have you…?
  const ADV = new Set(['already', 'just', 'never', 'ever', 'recently', 'finally', 'not', 'still', 'always', 'eventually', 'nearly', 'completely', 'often', 'also', 'really', 'only', 'gradually', 'previously', 'originally', 'highly', 'deeply', 'properly', 'immediately']);
  // 從第 i 個字往後，跳過副詞，回傳下一個字的位置
  function nextSkip(T, i) {
    const ws = W(T); let p = ws.indexOf(i) + 1;
    while (p < ws.length && (ADV.has(T[ws[p]].k) || SUBJ.has(T[ws[p]].k))) p++;
    return p < ws.length ? ws[p] : -1;
  }
  const isPP = t => { formSets(); return PP.has(t.k); };
  const isING = t => { formSets(); return ING.has(t.k) && t.k !== 'thing' && t.k !== 'morning' && t.k !== 'evening'; };
  const TOK = {
    presPerf(T) {
      const r = [];
      W(T).forEach(i => { if (!HAVE.has(T[i].k)) return; const j = nextSkip(T, i); if (j > 0 && isPP(T[j]) && T[j].k !== 'been') r.push(i, j); else if (j > 0 && T[j].k === 'been') { const k = nextSkip(T, j); if (k < 0 || !isING(T[k])) r.push(i, j); } });
      return r;
    },
    pastPerf(T) {
      const r = [];
      W(T).forEach(i => { if (T[i].k !== 'had' && T[i].k !== "hadn't") return; const j = nextSkip(T, i); if (j > 0 && isPP(T[j]) && T[j].k !== 'had') r.push(i, j); });
      return r;
    },
    perfCont(T) {
      const r = [];
      W(T).forEach(i => { if (!HAVE.has(T[i].k) && T[i].k !== 'had') return; const j = nextSkip(T, i); if (j > 0 && T[j].k === 'been') { const k = nextSkip(T, j); if (k > 0 && isING(T[k])) r.push(i, j, k); } });
      return r;
    },
    passive(T) {
      const r = [];
      W(T).forEach(i => {
        if (!BE.has(T[i].k) && T[i].k !== 'get' && T[i].k !== 'got') return;
        const j = nextSkip(T, i);
        if (j < 0 || !isPP(T[j])) return;
        const n = nextSkip(T, j);
        if (n > 0 && T[n].k === 'to' && ['used', 'supposed'].includes(T[j].k)) return;
        // 形容詞用法（I was surprised／She is interested）不算
        if (info(T[j].k).some(x => { const e = ent(x); return e && e[1] === 'adj'; })) return;
        r.push(i, j);
      });
      return r;
    },
    phrasal(T) {
      const r = [];
      W(T).forEach(i => {
        info(T[i].k).forEach(x => {
          const e = ent(x); if (!e || e[1] !== 'v-ph' || !/^片語動詞 .* 的/.test(x.desc)) return;
          const rest = e[0].split(' ').slice(1);
          const ws = W(T); let p = ws.indexOf(i) + 1, ok = true, got = [i], skip = 0;
          for (const part of rest) {
            while (p < ws.length && T[ws[p]].k !== part && skip < 2 && /^(it|them|him|her|me|you|us|the|a|my|your|this)$/.test(T[ws[p]].k)) { p++; skip++; }
            if (p < ws.length && T[ws[p]].k === part) { got.push(ws[p]); p++; } else { ok = false; break; }
          }
          if (ok) r.push(...got);
        });
      });
      return r;
    },
    edIng(T) { return W(T).filter(i => info(T[i].k).some(x => { const e = ent(x); return e && e[1] === 'adj' && /(ed|ing)$/.test(e[0]); })); },
    uncount(T) { return W(T).filter(i => info(T[i].k).some(x => { const e = ent(x); return e && e[1] === 'n' && /unc/.test(e[3]) && !/的一部分/.test(x.desc) && !/ /.test(e[0]); })); },
    compar(T) {
      const r = [], ws = W(T);
      ws.forEach((i, p) => {
        const k = T[i].k, nx = ws[p + 1], pv = ws[p - 1];
        const cmp = info(k).some(x => /^(比較級|最高級)$/.test(x.desc)) || /^(better|best|worse|worst|more|less|most|least)$/.test(k);
        if (!cmp) return;
        if (/^(most|least)$/.test(k) && !(pv !== undefined && T[pv].k === 'the')) return;   // most people（大部分的人）不算
        if (/^(more|less)$/.test(k) && !(nx !== undefined && (T[ws.indexOf(nx) + 1] && T[ws[ws.indexOf(nx) + 1]] || {}).k === 'than') && !(pv !== undefined && T[pv].k === 'the')) {
          // more／less 後面要有 than，或是 the more…
          const later = ws.slice(p + 1, p + 4).some(j => T[j].k === 'than');
          if (!later) return;
        }
        r.push(i);
        if (pv !== undefined && /^(the|much|far|even|slightly)$/.test(T[pv].k)) r.push(pv);
        ws.slice(p + 1, p + 4).forEach(j => { if (T[j].k === 'than') r.push(j); });
      });
      return r;
    },
    wordForm(T) { return W(T).filter(i => info(T[i].k).some(x => { const e = ent(x); return e && (e[1] === 'n' || e[1] === 'adj') && x.idx >= 0 && /(tion|ment|ness|ity|ance|ence|able|ible|ful|less|ous|ive)$/.test(e[0]) && !/ /.test(e[0]); })); },
    gerund(T) {
      const V = /^(enjoy|enjoys|enjoyed|avoid|avoids|avoided|mind|admitted|admit|denied|deny|suggest|suggested|consider|considered|imagine|regret|finish|finished|keep|kept|practice|risk|spend|spent|spending|stop|stopped|can't stand|recommend|miss|missed|worth|without|after|before|about|of|for|in|on|at|to)$/;
      const r = [];
      W(T).forEach(i => { if (!V.test(T[i].k)) return; const j = nextSkip(T, i); if (j > 0 && isING(T[j]) && !(T[i].k === 'to' && !/(forward|used)/.test((T[W(T)[W(T).indexOf(i) - 1]] || {}).k || ''))) r.push(j); });
      return r;
    },
    infin(T) {
      const V = /^(want|wants|wanted|decide|decided|refuse|refused|hope|hoped|manage|managed|afford|intend|offer|offered|promise|promised|pretend|pretended|aim|agree|agreed|plan|planned|seem|seems|seemed|tend|expect|expected|learn|learned|try|trying|tried|need|needs|would like|encourage|encouraged|persuade|persuaded|remind|warn|warned|ask|asked|allow|told)$/;
      const r = [];
      W(T).forEach(i => {
        if (!V.test(T[i].k)) return;
        const ws = W(T); let p = ws.indexOf(i) + 1;
        if (p < ws.length && /^(me|you|him|her|us|them|my|not)$/.test(T[ws[p]].k)) p++;
        if (p < ws.length && T[ws[p]].k === 'to' && p + 1 < ws.length) r.push(i, ws[p], ws[p + 1]);
      });
      return r;
    }
  };

  function grammarMatch(g, sentence) {
    const s = EN.norm(sentence);
    const ranges = [];
    if (g.m.re) {
      const re = new RegExp(g.m.re, 'gi');
      let m;
      while ((m = re.exec(s))) { if (!m[0]) { re.lastIndex++; continue; } ranges.push([m.index, m.index + m[0].length]); }
    } else if (g.m.tok) {
      const T = toks(s);
      [...new Set(TOK[g.m.tok](T))].sort((a, b) => a - b).forEach(i => ranges.push([T[i].s, T[i].e]));
    }
    return ranges;
  }
  EN.grammarMatch = grammarMatch;

  const L = "A-Za-z'";
  const B = '(?<![' + L + '-])';
  const E = '(?![' + L + '-])';
  const w = list => B + '(?:' + list + ')' + E;
  const T2 = (h, rows) => '<table><tr>' + h.map(x => '<th>' + x + '</th>').join('') + '</tr>' + rows.map(r => '<tr>' + r.map(x => '<td>' + x + '</td>').join('') + '</tr>').join('') + '</table>';
  const PR = "(?:i|you|he|she|it|we|they|someone|nobody)";

  EN.GRAMMAR = [
    // ---- 時態 ----
    { id: 'pres-perf', tag: '時態', title: '現在完成式 have done', m: { tok: 'presPerf' },
      body: '<p><b>have／has ＋ 過去分詞</b>，把過去和現在連起來：</p><ul><li>經驗：<i>Have you ever been to Japan?</i></li><li>剛發生、結果現在還看得到：<i>I have lost my keys.</i>（現在找不到）</li><li>從過去持續到現在：<i>I have lived here since 2020.</i></li></ul><p>常一起出現的字：<b>already、just、yet、ever、never、recently、so far</b>。</p><p>有明確的過去時間（yesterday、last year、in 2019）就要用過去式：<i>I <b>saw</b> him yesterday.</i>（不是 have seen）</p>' },
    { id: 'for-since', tag: '時態', title: 'for、since、ago', m: { re: w('for (?:\\w+ )?(?:years|months|weeks|days|hours|minutes|a while|ages|a long time)|since|ago') },
      body: T2(['字', '接什麼', '例子'], [['for', '一段時間', 'I have known her <b>for</b> ten years.'], ['since', '起點（時間、事件）', 'I have lived here <b>since</b> I was a child.'], ['ago', '多久以前（配過去式）', 'I met her ten years <b>ago</b>.']]),
      ex: [['I have known her for ten years.', '我認識她十年了。'], ['I met her ten years ago.', '我十年前認識她。']] },
    { id: 'perf-cont', tag: '時態', title: '現在完成進行式 have been doing', m: { tok: 'perfCont' },
      body: '<p><b>have／has been ＋ -ing</b>，強調一件事從過去<b>一直在做</b>到現在（可能還沒結束）：</p><p><i>I have been waiting for an hour.</i>（等了一小時，還在等）<br><i>She has been working here since May.</i></p><p>比較：<i>I have read the book.</i>（讀完了）／<i>I have been reading the book.</i>（一直在讀，不一定讀完）</p>',
      ex: [['I have been waiting for an hour.', '我已經等了一小時了。'], ['She has been learning English since she was six.', '她從六歲就開始學英文了。'], ['How long have you been living here?', '你在這裡住多久了？']] },
    { id: 'past-perf', tag: '時態', title: '過去完成式 had done', m: { tok: 'pastPerf' },
      body: '<p><b>had ＋ 過去分詞</b>：說過去某個時間點<b>之前</b>就已經發生的事（過去的過去）。</p><p><i>When I arrived, the film <b>had</b> already <b>started</b>.</i>（我到的時候電影已經開始了）</p><p>常見在 when、before、after、by the time 的句子，以及間接引述裡。</p>',
      ex: [['When I arrived, the film had already started.', '我到的時候，電影已經開始了。'], ['She had never seen snow before she moved to Canada.', '她搬去加拿大之前從沒看過雪。']] },
    { id: 'future', tag: '時態', title: '未來：will、be going to、現在進行式', m: { re: w("will|won't|i'll|you'll|(?:am|is|are|was|were) going to") },
      body: T2(['說法', '用在', '例子'], [['will', '當下決定、預測、承諾', 'I will call you later.'], ['be going to', '已經有的打算；看得到跡象的預測', 'I am going to study abroad. Look at those clouds — it is going to rain.'], ['現在進行式', '已經約好、安排好的事', 'I am meeting her at six.']]) },
    { id: 'fut-perf', tag: '時態', title: '未來進行式與未來完成式', m: { re: w('will be \\w+ing|will have (?:\\w+ )?\\w+(?:ed|en|t)') },
      body: '<ul><li><b>will be ＋ -ing</b>：未來某時正在進行：<i>This time tomorrow, I <b>will be flying</b> to Tokyo.</i></li><li><b>will have ＋ 過去分詞</b>：未來某時之前會完成：<i>By June, I <b>will have finished</b> my degree.</i></li></ul>',
      ex: [['This time tomorrow, I will be flying to Tokyo.', '明天這個時候我正在飛往東京。'], ['By June, I will have finished my degree.', '到六月我就會拿到學位了。'], ['Don’t call at eight; we will be having dinner.', '八點別打來，那時我們在吃晚餐。']] },
    { id: 'used-to', tag: '時態', title: 'used to、be used to、get used to', m: { re: w('used to') },
      body: T2(['說法', '意思', '例子'], [['used to ＋ 原形', '以前常常（現在不了）', 'I <b>used to</b> play the piano.'], ['be used to ＋ 名詞／-ing', '習慣於', 'I <b>am used to</b> getting up early.'], ['get used to ＋ 名詞／-ing', '漸漸習慣', 'You will <b>get used to</b> the weather.']]) +
        '<p>否定和疑問：<i>I didn’t use to…</i>、<i>Did you use to…?</i>（不加 d）</p>',
      ex: [['You will get used to the weather.', '你會習慣這裡的天氣的。']] },
    // ---- 假設 ----
    { id: 'cond1', tag: '假設', title: '第一條件句：If it rains, I will…', m: { re: w('if|unless') + "(?=[^.!?]*\\b(?:will|won't|'ll)\\b)|" + w("will|won't") + "(?=[^.!?]*\\b(?:if|unless)\\b)" },
      body: '<p>說<b>真的可能發生</b>的事：<b>If ＋ 現在式, will ＋ 原形</b>。</p><p><i>If it rains tomorrow, we <b>will</b> stay at home.</i></p><p>if 子句裡不用 will：<s>If it will rain</s>。</p><p><b>unless</b>＝if…not：<i>You will miss the bus <b>unless</b> you leave now.</i></p>',
      ex: [['If it rains tomorrow, we will stay at home.', '如果明天下雨，我們就待在家。'], ['If you need help, I will be here.', '如果你需要幫忙，我會在這裡。']] },
    { id: 'cond2', tag: '假設', title: '第二條件句：If I had…, I would…', m: { re: w('if') + "(?=[^.!?]*\\b(?:would|could|might)\\b(?! have))|" + w("would|could") + "(?! have)(?=[^.!?]*\\bif\\b)" },
      body: '<p>說<b>現在不是真的、或不太可能</b>的情況：<b>If ＋ 過去式, would ＋ 原形</b>。</p><p><i>If I had more money, I <b>would</b> travel more.</i>（但我現在沒錢）<br><i>If I <b>were</b> you, I <b>would</b> take the job.</i>（給建議）</p><p>be 動詞在這裡常用 <b>were</b>，各人稱都一樣。</p>',
      ex: [['If I had more money, I would travel more.', '如果我有更多錢，我會多旅行。'], ['If I were you, I would take the job.', '如果我是你，我會接下那份工作。'], ['What would you do if you won the lottery?', '如果你中了樂透，你會做什麼？']] },
    { id: 'cond3', tag: '假設', title: '第三條件句：If I had known…', m: { re: w("would have|wouldn't have|could have|might have") + "(?=[^.!?]*\\bif\\b)|" + w('if') + "(?=[^.!?]*\\b(?:would|could|might)(?:n't)? have\\b)" },
      body: '<p>說<b>過去沒有發生</b>的情況（後悔、假設）：<b>If ＋ had ＋ 過去分詞, would have ＋ 過去分詞</b>。</p><p><i>If I <b>had studied</b> harder, I <b>would have passed</b>.</i>（但我當時沒用功，沒過）</p>',
      ex: [['If I had left earlier, I would have caught the train.', '如果我早點出門，就趕得上火車了。'], ['We would have won if he hadn’t missed the goal.', '要不是他射門沒進，我們就贏了。']] },
    { id: 'wish', tag: '假設', title: 'I wish…／If only…', m: { re: w('wish|wished|if only') },
      body: T2(['說法', '意思', '例子'], [['wish ＋ 過去式', '希望現在不一樣', 'I <b>wish</b> I had more time.'], ['wish ＋ had ＋ 過去分詞', '後悔過去的事', 'I <b>wish</b> I had studied harder.'], ['wish ＋ would', '希望別人改變（抱怨）', 'I <b>wish</b> you would stop talking.']]) +
        '<p><b>If only</b> 的意思一樣，但語氣更強：<i>If only I had listened to you!</i></p>',
      ex: [['I wish I had more time.', '真希望我有更多時間。'], ['I wish I had studied harder.', '真希望我當初更用功。'], ['If only I had listened to you!', '要是我當初聽你的就好了！']] },
    { id: 'cond-link', tag: '假設', title: 'unless、as long as、provided that、in case', m: { re: w('unless|as long as|provided that|in case') },
      body: T2(['字', '意思', '例子'], [['unless', '除非（＝if…not）', 'Unless you hurry, you will be late.'], ['as long as／provided that', '只要', 'You can go as long as you are back by ten.'], ['in case', '以防萬一', 'Take a coat in case it gets cold.']]) },
    // ---- 被動與使役 ----
    { id: 'passive', tag: '被動', title: '被動語態 be done', m: { tok: 'passive' },
      body: '<p><b>be ＋ 過去分詞</b>：重點在「東西被怎樣了」，誰做的不重要或不知道。</p>' + T2(['時態', '例子'], [['現在式', 'English <b>is spoken</b> here.'], ['過去式', 'My bike <b>was stolen</b>.'], ['現在完成式', 'The flight <b>has been cancelled</b>.'], ['未來', 'The package <b>will be delivered</b> tomorrow.'], ['情態動詞', 'It <b>can be done</b>.']]) +
        '<p>要說是誰做的，用 <b>by</b>：<i>The book was written <b>by</b> a teacher.</i></p>' },
    { id: 'have-done', tag: '被動', title: '使役：have／get something done', m: { re: w('(?:have|has|had|get|got|getting|having) (?:my|your|his|her|our|their|the|a) \\w+ (?:\\w+ed|cut|done|fixed|repaired|painted|checked|cleaned|delivered|stolen)') },
      body: '<p><b>have／get ＋ 東西 ＋ 過去分詞</b>：請別人幫你做（不是自己做）。</p><p><i>I <b>had my hair cut</b> yesterday.</i>（我去剪頭髮）<br><i>We are <b>getting the kitchen painted</b>.</i></p>',
      ex: [['I had my hair cut yesterday.', '我昨天去剪頭髮。'], ['We are getting the kitchen painted next week.', '我們下週要請人粉刷廚房。'], ['You should have your eyes checked.', '你應該去檢查眼睛。']] },
    { id: 'make-let', tag: '被動', title: 'make、let、allow', m: { re: w('(?:make|makes|made|let|lets) (?:me|you|him|her|us|them|it|people) \\w+|(?:allow|allows|allowed) (?:me|you|him|her|us|them|people) to') },
      body: T2(['說法', '意思', '例子'], [['make ＋ 人 ＋ 原形', '逼、讓（使）', 'My parents <b>made me</b> clean my room.'], ['let ＋ 人 ＋ 原形', '准許、讓', 'Let me help you.'], ['allow ＋ 人 ＋ to 原形', '允許（較正式）', 'They don’t <b>allow us to</b> use phones.']]),
      ex: [['My parents made me clean my room.', '我爸媽逼我整理房間。'], ['Let me help you.', '讓我幫你。'], ['They don’t allow us to use phones in class.', '他們不准我們上課用手機。']] },
    // ---- 間接引述、子句 ----
    { id: 'reported', tag: '子句', title: '間接引述：He said that…', m: { re: w('(?:said|told \\w+|explained|admitted|announced|mentioned|claimed|promised)(?: that)?') + '(?= \\w)' },
      body: '<p>轉述別人說的話時，時態通常<b>往過去退一格</b>：</p>' + T2(['直接引述', '間接引述'], [['"I am tired."', 'She said (that) she <b>was</b> tired.'], ['"I will come."', 'He said he <b>would</b> come.'], ['"I have finished."', 'She said she <b>had finished</b>.'], ['"I can swim."', 'He said he <b>could</b> swim.']]) +
        '<p><b>say</b> 後面直接接內容；<b>tell</b> 後面要先接人：<i>He <b>told me</b> that…</i>（不說 said me）</p>',
      ex: [['She said that she was tired.', '她說她很累。'], ['He told me he would come.', '他跟我說他會來。']] },
    { id: 'rep-q', tag: '子句', title: '間接問句：Do you know where…?', m: { re: w('(?:know|wonder|tell me|sure|ask|asked|explain|remember|idea)(?: \\w+)? (?:where|what|why|how|when|who|whether|if)') },
      body: '<p>把問題放進句子裡，<b>語序要改回陳述句</b>（主詞在動詞前）：</p>' + T2(['直接問句', '間接問句'], [['Where is the station?', 'Do you know where the station <b>is</b>?'], ['Why did she leave?', 'I wonder why she <b>left</b>.'], ['Will he come?', 'I am not sure <b>whether／if</b> he will come.']]) },
    { id: 'relative', tag: '子句', title: '關係子句：who、which、that、whose', m: { re: '(?<=\\w,? )(?:who|which|whose|whom)' + E },
      body: T2(['關係詞', '指', '例子'], [['who', '人', 'The man <b>who</b> lives next door is a doctor.'], ['which', '東西', 'The book <b>which</b> I bought is great.'], ['that', '人或東西（口語）', 'The film <b>that</b> we saw was funny.'], ['whose', '…的', 'She is the girl <b>whose</b> brother is famous.'], ['where', '地方', 'This is the town <b>where</b> I grew up.']]) +
        '<p><b>非限定</b>關係子句（只補充說明，前後有逗號）不能用 that：<i>My brother, <b>who</b> lives in Paris, is a chef.</i></p>',
      ex: [['The man who lives next door is a doctor.', '住在隔壁的男人是醫生。'], ['My brother, who lives in Paris, is a chef.', '我哥哥住在巴黎，是個廚師。'], ['She is the girl whose brother is famous.', '她就是哥哥很有名的那個女生。']] },
    // ---- 情態動詞 ----
    { id: 'deduction', tag: '情態動詞', title: '推測現在：must be、might be、can’t be', m: { re: w("must|might|may|could|can't|cannot") + ' be' + E },
      body: T2(['說法', '有多確定', '例子'], [['must be', '幾乎肯定（是）', 'You <b>must be</b> tired after the trip.'], ['might／may／could be', '有可能', 'She <b>might be</b> at home.'], ['can’t be', '幾乎肯定（不是）', 'That <b>can’t be</b> true!']]),
      ex: [['You must be tired after the trip.', '旅行完你一定很累。'], ['She might be at home.', '她可能在家。'], ['That can’t be true!', '那不可能是真的！']] },
    { id: 'past-modal', tag: '情態動詞', title: '推測與後悔過去：must have、should have', m: { re: w("must|might|may|could|can't|couldn't|should|shouldn't|would|wouldn't") + ' have' + E },
      body: T2(['說法', '意思', '例子'], [['must have done', '過去一定…了', 'He <b>must have missed</b> the bus.'], ['might／could have done', '過去可能…', 'She <b>might have forgotten</b>.'], ['can’t have done', '過去不可能…', 'He <b>can’t have seen</b> me.'], ['should have done', '早該…（但沒做）', 'You <b>should have told</b> me.'], ['shouldn’t have done', '不該…（但做了）', 'I <b>shouldn’t have eaten</b> so much.']]),
      ex: [['He must have missed the bus.', '他一定是沒趕上公車。'], ['You should have told me.', '你早該告訴我的。'], ['I shouldn’t have eaten so much.', '我不該吃那麼多的。']] },
    { id: 'obligation', tag: '情態動詞', title: '義務與建議：must、have to、should', m: { re: w("must(?! be| have)|mustn't|have to|has to|had to|don't have to|doesn't have to|should(?! have)|ought to|need to|needn't") },
      body: T2(['說法', '意思'], [['must／have to', '必須'], ['mustn’t', '不准（禁止）'], ['don’t have to', '不用（沒必要）'], ['should／ought to', '應該（建議）'], ['need to', '需要']]) +
        '<p>注意：<i>You <b>mustn’t</b> smoke here.</i>（禁止）和 <i>You <b>don’t have to</b> come.</i>（不來也沒關係）意思差很多。</p>',
      ex: [['You mustn’t smoke here.', '這裡禁止吸菸。'], ['You don’t have to come if you are busy.', '你忙的話可以不用來。']] },
    { id: 'better-rather', tag: '情態動詞', title: 'had better、would rather、it’s time', m: { re: w("had better|'d better|would rather|'d rather|it's time|it is time") },
      body: T2(['說法', '意思', '例子'], [['had better ＋ 原形', '最好（不然有麻煩）', 'You <b>had better</b> hurry.'], ['would rather ＋ 原形', '寧願', 'I <b>would rather</b> stay in.'], ['it’s time ＋ 過去式', '早該…了', '<b>It’s time</b> we left.']]),
      ex: [['It’s time we left.', '我們該走了。']] },
    // ---- 動詞句型 ----
    { id: 'gerund', tag: '動詞句型', title: '動詞後面接 -ing', m: { tok: 'gerund' },
      body: '<p>這些動詞後面接 <b>-ing</b>（不接 to）：</p><p><b>enjoy、avoid、mind、admit、deny、suggest、consider、imagine、finish、keep、practice、miss、risk、can’t stand</b></p><p><i>Would you mind <b>opening</b> the window?</i><br><i>He admitted <b>stealing</b> the money.</i></p><p>介係詞後面也一律接 -ing：<i>I am good at <b>cooking</b>.</i>、<i>Thanks for <b>helping</b> me.</i>、<i>I look forward to <b>seeing</b> you.</i></p>' },
    { id: 'infinitive', tag: '動詞句型', title: '動詞後面接 to ＋ 原形', m: { tok: 'infin' },
      body: '<p>這些動詞後面接 <b>to ＋ 原形</b>：</p><p><b>want、decide、hope、plan、refuse、manage、afford、offer、promise、pretend、agree、seem、tend、expect、learn</b></p><p><i>We can’t afford <b>to buy</b> a new car.</i><br><i>He refused <b>to answer</b>.</i></p><p>動詞 ＋ 人 ＋ to：<i>She persuaded me <b>to join</b>.</i>、<i>I reminded him <b>to call</b>.</i></p>' },
    { id: 'ing-to', tag: '動詞句型', title: 'remember／stop／try ＋ -ing 或 to（意思不同）', m: { re: w('(?:remember|remembered|forget|forgot|stop|stopped|try|tried|regret|regretted) (?:to \\w+|\\w+ing)') },
      body: T2(['', '＋ -ing', '＋ to'], [['remember', '記得做過', '記得要去做'], ['forget', '忘了做過', '忘了要去做'], ['stop', '停止做（某事）', '停下來去做（另一件事）'], ['try', '試試看（當方法）', '努力想做到'], ['regret', '後悔做了', '很遺憾要…（正式）']]) +
        '<p><i>I remember <b>locking</b> the door.</i>（記得鎖過了）／<i>Remember <b>to lock</b> the door.</i>（記得要鎖）<br><i>He stopped <b>smoking</b>.</i>（戒菸）／<i>He stopped <b>to smoke</b>.</i>（停下來抽根菸）</p>',
      ex: [['I remember locking the door.', '我記得有鎖門。'], ['Remember to lock the door.', '記得要鎖門。'], ['He stopped to buy some water.', '他停下來買水。']] },
    { id: 'phrasal', tag: '動詞句型', title: '片語動詞：give up、look after…', m: { tok: 'phrasal' },
      body: '<p>動詞 ＋ 介係詞／副詞，意思常常跟原本的字差很多：<i>give up</i>（放棄）、<i>turn down</i>（拒絕）、<i>look after</i>（照顧）。</p><ul><li><b>可以拆開的</b>：受詞可以放中間，受詞是代名詞時<b>一定</b>放中間：<i>turn the offer down</i>／<i>turn <b>it</b> down</i>（不說 turn down it）</li><li><b>不能拆開的</b>：<i>look after <b>the baby</b></i>／<i>look after <b>her</b></i></li></ul><p>片語動詞是 B2 很重要的一塊，口語比 tolerate、postpone 這類字更常用：<i>put up with</i>＝tolerate、<i>put off</i>＝postpone。</p>' },
    // ---- 比較、程度 ----
    { id: 'compar', tag: '比較', title: '比較級與最高級', m: { tok: 'compar' },
      body: T2(['規則', '比較級', '最高級'], [['一個音節', 'cheaper', 'the cheapest'], ['-y 結尾', 'easier', 'the easiest'], ['兩個音節以上', 'more expensive', 'the most expensive'], ['不規則', 'better／worse／further', 'the best／the worst']]) +
        '<p>加強比較級：<b>much、far、a lot、even</b>：<i>It is <b>much</b> cheaper.</i>；稍微：<b>slightly、a bit</b>。</p><p><b>the ＋ 比較級, the ＋ 比較級</b>：越…越…：<i><b>The more</b> you practice, <b>the better</b> you get.</i></p>',
      ex: [['The more you practice, the better you get.', '練得越多，就越厲害。'], ['The train is much faster than the bus.', '火車比公車快得多。']] },
    { id: 'so-such', tag: '比較', title: 'so…that、such…that', m: { re: w('so (?:\\w+ )?(?:that|\\w+)(?= that)|such (?:a |an )?\\w+(?: \\w+)?(?= that)|so (?:many|much|few|little)') },
      body: T2(['說法', '接什麼', '例子'], [['so ＋ 形容詞／副詞', '', 'It was <b>so</b> cold <b>that</b> the lake froze.'], ['such (a) ＋ 形容詞 ＋ 名詞', '', 'It was <b>such a</b> good film <b>that</b> I saw it twice.']]),
      ex: [['It was so cold that the lake froze.', '天氣冷到湖都結冰了。'], ['It was such a good film that I saw it twice.', '那部電影好看到我看了兩次。'], ['The lecture was so boring that I fell asleep.', '那堂課無聊到我睡著了。']] },
    { id: 'too-enough', tag: '比較', title: 'too 和 enough', m: { re: w('too \\w+|\\w+ enough|enough \\w+') },
      body: '<ul><li><b>too ＋ 形容詞 (＋ to 原形)</b>：太…（所以不能）：<i>This coffee is <b>too hot</b> to drink.</i></li><li><b>形容詞 ＋ enough</b>：夠…：<i>Is the room <b>big enough</b>?</i></li><li><b>enough ＋ 名詞</b>：<i>We don’t have <b>enough time</b>.</i></li></ul><p>注意 enough 的位置：形容詞在前，名詞在後。</p>',
      ex: [['This coffee is too hot to drink.', '這杯咖啡太燙了，不能喝。'], ['Is the room big enough for four people?', '這個房間夠四個人住嗎？'], ['We don’t have enough time.', '我們時間不夠。']] },
    { id: 'degree', tag: '比較', title: '程度副詞：fairly、quite、rather、extremely', m: { re: w('fairly|quite|rather(?! than)|extremely|completely|entirely|highly|deeply|slightly|totally|absolutely') },
      body: T2(['程度', '字'], [['有一點', 'slightly、a bit'], ['還算', 'fairly、quite（英式）'], ['相當（常帶點意外）', 'rather、quite（美式）'], ['非常', 'very、extremely、highly'], ['完全', 'completely、entirely、totally、absolutely']]) +
        '<p>absolutely 用在本身就很強的形容詞：<i>absolutely <b>amazing</b>／<b>exhausted</b></i>（不說 very amazing）。</p>' },
    // ---- 連接 ----
    { id: 'contrast', tag: '連接', title: '轉折：although、however、despite', m: { re: w('although|though|even though|however|despite|in spite of|whereas|nevertheless|on the other hand') },
      body: T2(['字', '接什麼', '例子'], [['although／even though', '句子', '<b>Although</b> it rained, we went out.'], ['despite／in spite of', '名詞或 -ing', '<b>Despite</b> the rain, we went out.'], ['however／nevertheless', '新的句子開頭，後面加逗號', 'It rained. <b>However</b>, we went out.'], ['whereas', '對比兩件事', 'I like tea, <b>whereas</b> she likes coffee.']]) +
        '<p>常見錯誤：<s>Despite it rained</s> → <i>Despite <b>the rain</b></i>／<i>Despite <b>the fact that</b> it rained</i>。</p>' },
    { id: 'purpose', tag: '連接', title: '目的：so that、in order to', m: { re: w('so that|in order to|in order not to|so as to') },
      ex: [['I saved money so that I could travel in the summer.', '我存錢，好讓自己夏天可以去旅行。'], ['Speak slowly so that everyone can understand.', '說慢一點，讓大家都聽得懂。']],
      body: T2(['說法', '接什麼', '例子'], [['to／in order to', '原形動詞', 'I went to the bank <b>to</b> get some money.'], ['so that', '句子（常配 can／could／would）', 'I left early <b>so that</b> I would not be late.']]) },
    { id: 'cause', tag: '連接', title: '原因與結果：because of、due to、therefore', m: { re: w('because of|due to|therefore|as a result|thus|that is why') },
      body: T2(['字', '接什麼', '例子'], [['because', '句子', 'We stayed in <b>because</b> it was raining.'], ['because of／due to', '名詞', 'The flight was delayed <b>due to</b> fog.'], ['therefore／as a result', '新的句子', 'He was ill. <b>Therefore</b>, he stayed at home.']]) },
    { id: 'markers', tag: '連接', title: '說話時的轉折語', m: { re: w('in fact|actually|in other words|to be honest|as far as i know|in general|basically|apparently|for instance|in addition|moreover|furthermore|anyway') },
      body: T2(['說法', '用途'], [['in fact／actually', '其實（修正或補充）'], ['in other words', '換句話說'], ['to be honest', '老實說'], ['as far as I know', '就我所知'], ['for instance', '例如'], ['moreover／furthermore／in addition', '而且（書面）'], ['anyway', '反正、總之（換話題）']]) +
        '<p>B2 寫作和口說加上這些字，聽起來就自然很多。</p>' },
    // ---- 名詞、形容詞 ----
    { id: 'uncount', tag: '名詞', title: '不可數名詞：advice、information…', m: { tok: 'uncount' },
      body: '<p>這些字中文可以數，英文<b>不可數</b>：不加 -s、不加 a／an、動詞用單數。</p><p><b>advice、information、news、furniture、equipment、luggage、research、knowledge、progress、homework、accommodation、traffic</b></p><p>要說「一個」：<i>a piece of advice</i>、<i>a piece of furniture</i>、<i>an item of news</i>。</p><p>常見錯誤：<s>an advice</s>、<s>informations</s>、<s>The news are good</s>（→ The news <b>is</b> good）。</p>' },
    { id: 'quant', tag: '名詞', title: 'few、a few、little、a little', m: { re: w('a few|few|a little|little|plenty of|a lot of|lots of|several|hardly any') },
      body: T2(['', '可數', '不可數'], [['一些（正面）', 'a few friends', 'a little time'], ['很少（幾乎沒有）', 'few friends', 'little time'], ['很多', 'many／a lot of', 'much／a lot of']]) +
        '<p><i>I have <b>a few</b> friends here.</i>（有幾個，還不錯）／<i>I have <b>few</b> friends here.</i>（沒什麼朋友，有點寂寞）</p>' },
    { id: 'ed-ing', tag: '形容詞', title: '-ed 和 -ing 形容詞：bored／boring', m: { tok: 'edIng' },
      body: '<ul><li><b>-ed</b>：人的<b>感覺</b>：<i>I am <b>bored</b>.</i>（我覺得無聊）</li><li><b>-ing</b>：事物<b>帶給人</b>的感覺：<i>The film is <b>boring</b>.</i>（電影很無聊）</li></ul>' + T2(['-ed（我覺得）', '-ing（它讓人覺得）'], [['bored', 'boring'], ['interested', 'interesting'], ['confused', 'confusing'], ['embarrassed', 'embarrassing'], ['disappointed', 'disappointing'], ['surprised', 'surprising']]) +
        '<p>常見錯誤：<s>I am boring</s>＝「我是個無聊的人」。</p>' },
    { id: 'word-form', tag: '形容詞', title: '詞性變化：字首與字尾', m: { tok: 'wordForm' },
      body: T2(['字尾', '變成', '例子'], [['-tion／-sion', '名詞', 'decide → decision、inform → information'], ['-ment', '名詞', 'develop → development、achieve → achievement'], ['-ness／-ity', '名詞', 'kind → kindness、able → ability'], ['-able／-ible', '形容詞（可以…的）', 'afford → affordable、rely → reliable'], ['-ful／-less', '形容詞（有／沒有）', 'harm → harmful、use → useless'], ['-ous／-ive', '形容詞', 'danger → dangerous、impress → impressive']]) +
        T2(['字首', '意思', '例子'], [['un-／in-／im-／dis-', '不、相反', 'unexpected、independent、impossible、disagree'], ['re-', '再', 'replace、rebuild'], ['over-／under-', '過度／不足', 'overcome、underestimate']]) +
        '<p>B2 考試常考「填入正確的詞性」，看到新字時順便記它的家族。</p>' },
    { id: 'prep-coll', tag: '形容詞', title: '形容詞 ＋ 介係詞', m: { re: w('(?:interested|good|bad|afraid|proud|aware|keen|famous|responsible|similar|different|tired|worried|capable|jealous|satisfied|disappointed|grateful|familiar|popular|suitable) (?:in|at|of|on|for|to|from|about|with)') },
      body: T2(['介係詞', '常見搭配'], [['in', 'interested in'], ['at', 'good at、bad at'], ['of', 'afraid of、proud of、aware of、capable of、jealous of、tired of'], ['on', 'keen on'], ['for', 'famous for、responsible for、grateful for'], ['about', 'worried about、excited about'], ['with', 'satisfied with、disappointed with、familiar with、popular with'], ['to／from', 'similar to、different from']]) +
        '<p>這些搭配沒有規則，最好整組背：不要背 interested，要背 <b>interested in</b>。</p>' }
  ];

  /* ---------- 變化規則頁 ---------- */
  // 規則頁會把好幾個文法點的說明接在一起，每段前面加上小標題，才看得出換了主題
  const gb = id => { const g = EN.GRAMMAR.find(g => g.id === id); return '<h3 class="gb-h">' + g.title + '</h3>' + g.body; };
  const sp = e => EN.spec(e[3]);
  EN.RULES = [
    { id: 'r-irr', title: '不規則動詞', icon: 'v',
      body: '<p>不規則動詞的過去式、過去分詞要一個一個背。常見的類型：</p>' + T2(['類型', '例子'], [['三個都一樣', 'cut – cut – cut、put、let、hit、cost、spread、burst'], ['後兩個一樣', 'feel – felt – felt、keep、lend、seek、bend、hang'], ['後兩個不一樣', 'steal – stole – stolen、hide – hid – hidden、freeze – froze – frozen'], ['母音 i → a → u', 'begin – began – begun、swim、sing、ring']]) + '<p>B2 常考的是過去分詞：被動（<i>was stolen</i>）、完成式（<i>have hidden</i>）、第三條件句（<i>would have forgiven</i>）都用得到。</p>',
      demo: ['steal', 'hide', 'freeze', 'forgive', 'shake', 'tear', 'withdraw', 'overcome', 'spread', 'seek'],
      filter: e => e[1] === 'v' && EN.conjugate(e[0], e[1]).irregular },
    { id: 'r-ph', title: '片語動詞', icon: 'v',
      body: gb('phrasal'), demo: ['give up', 'turn down', 'look after', 'put up with', 'come up with', 'figure out'],
      filter: e => e[1] === 'v-ph' },
    { id: 'r-adj', title: '比較級', icon: 'g',
      body: gb('compar'), demo: ['tough', 'calm', 'brave', 'tiny', 'narrow', 'wealthy', 'generous', 'reliable', 'fit'],
      filter: e => e[1] === 'adj' },
    { id: 'r-noun', title: '名詞複數與不可數', icon: 'n',
      body: '<p>規則：一般加 <b>-s</b>；s、x、ch、sh 結尾加 <b>-es</b>；子音＋y 結尾改 <b>-ies</b>（city → cities）。</p><p>不規則：child → children、man → men、woman → women、person → people、life → lives、species → species。</p>' + gb('uncount'),
      demo: ['ability', 'opportunity', 'species', 'colleague', 'advice', 'equipment', 'research', 'furniture'],
      filter: e => e[1] === 'n' },
    { id: 'r-form', title: '詞性變化', icon: 'g', body: gb('word-form'), demo: ['achieve', 'develop', 'decide', 'afford', 'harm', 'reliable'],
      filter: e => (e[1] === 'n' || e[1] === 'adj') && /(tion|ment|ness|ity|able|ible|ful|less|ous|ive)$/.test(e[0]) },
    { id: 'r-ed', title: '-ed／-ing 形容詞', icon: 'g', body: gb('ed-ing'), demo: ['bored', 'boring', 'confused', 'confusing', 'embarrassed', 'embarrassing'],
      filter: e => e[1] === 'adj' && /(ed|ing)$/.test(e[0]) }
  ];

  // 詞性家族（規則頁「詞性變化」的示範表）
  const FAMILY = [
    ['achieve', 'achievement', '—', '—'], ['develop', 'development', '—', '—'], ['decide', 'decision', 'decisive', 'decisively'], ['afford', '—', 'affordable', '—'],
    ['harm', 'harm', 'harmful／harmless', 'harmfully'], ['rely', 'reliability', 'reliable', 'reliably'], ['succeed', 'success', 'successful', 'successfully'],
    ['create', 'creation', 'creative', 'creatively'], ['impress', 'impression', 'impressive', 'impressively'], ['respond', 'response', 'responsive', '—']
  ];
  const cell = t => ({ t, f: 1 });
  EN.demoTable = function (id, list) {
    const R = EN.RULES.find(r => r.id === id);
    const ents = (list && list.length ? list : []).concat(R ? R.demo.map(x => EN.W.find(e => e[0] === x)).filter(Boolean) : []).filter((e, i, a) => a.indexOf(e) === i);
    if (id === 'r-irr') return { head: ['原形', '過去式', '過去分詞'], rows: ents.filter(e => /^v/.test(e[1])).map(e => { const c = EN.conjugate(e[0], e[1]); return [c.base, c.past, c.pp].map(cell); }) };
    if (id === 'r-ph') return { head: ['片語動詞', '意思', '過去式'], rows: ents.filter(e => e[1] === 'v-ph').map(e => [cell(e[0]), { t: e[4] }, cell(EN.conjugate(e[0], e[1]).past)]) };
    if (id === 'r-adj') return { head: ['原級', '比較級', '最高級'], rows: ents.filter(e => e[1] === 'adj').map(e => { const f = EN.adjForms(e); return [f[0], f[1] || '—', f[2] ? 'the ' + f[2] : '—'].map(cell); }) };
    if (id === 'r-noun') return { head: ['單數', '複數'], rows: ents.filter(e => e[1] === 'n').map(e => { const f = EN.nounForms(e); return [cell(e[0]), f.unc ? { t: '不可數' } : cell(f.pl)]; }) };
    if (id === 'r-form') return { head: ['動詞', '名詞', '形容詞', '副詞'], rows: FAMILY.map(r => r.map(t => t === '—' ? { t } : cell(t))) };
    if (id === 'r-ed') return { head: ['-ed（人覺得）', '-ing（讓人覺得）'], rows: [['bored', 'boring'], ['confused', 'confusing'], ['embarrassed', 'embarrassing'], ['disappointed', 'disappointing'], ['surprised', 'surprising'], ['amazed', 'amazing'], ['annoyed', 'annoying'], ['frightened', 'frightening'], ['exhausted', 'exhausting']].map(r => r.map(cell)) };
    return null;
  };
})(typeof window !== 'undefined' ? window : globalThis);
