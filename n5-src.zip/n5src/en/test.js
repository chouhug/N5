/* 英文資料與引擎測試：node en/test.js */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const SRC = __dirname;
const ctx = { console };
ctx.globalThis = ctx;
vm.createContext(ctx);
for (const f of ['engine.js', 'data1.js', 'data2.js', 'data3.js', 'data4.js', 'data5.js', 'basic.js', 'grammar.js', 'quiz.js', 'gx1.js', 'gx2.js', 'gx3.js', 'gxpath.js']) {
  vm.runInContext(fs.readFileSync(path.join(SRC, f), 'utf8'), ctx, { filename: f });
}
const EN = ctx.EN;
const W = EN.W;
let fails = 0, checks = 0;
const failList = [];
function ok(cond, msg) { checks++; if (!cond) { fails++; failList.push(msg); } }
function eq(a, b, msg) { ok(JSON.stringify(a) === JSON.stringify(b), msg + '：預期 ' + JSON.stringify(b) + '，得到 ' + JSON.stringify(a)); }
const by = (w, pos) => W.find(e => e[0] === w && (!pos || e[1] === pos));

/* 1. 欄位格式 */
const POS = new Set(['n', 'v', 'v-ph', 'adj', 'adv', 'conj', 'prep', 'pron', 'expr']);
W.forEach((e, i) => {
  ok(Array.isArray(e) && e.length === 9, `第 ${i} 筆欄位數不是 9：${JSON.stringify(e)}`);
  ok(POS.has(e[1]), `${e[0]}：未知詞性 ${e[1]}`);
  e.forEach((x, j) => ok(typeof x === 'string' && x.length > 0, `${e[0]}：第 ${j} 欄是空的`));
  ok(e[2] === '-', `${e[0]}：英文沒有性別，第 3 欄要是 -`);
  ok(/^[a-z][a-z ’'-]*$/.test(e[0].replace(/ I /, ' i ')), `${e[0]}：單字要小寫英文字母`);
  ok(/[。！？」]$/.test(e[7]), `${e[0]}：例句中文沒有句末標點：${e[7]}`);
  ok(/[.!?]$/.test(e[6].trim()), `${e[0]}：例句沒有句末標點：${e[6]}`);
  ok(/^[A-Z]/.test(e[6]), `${e[0]}：例句要大寫開頭`);
  ok(!/[一-鿿]/.test(e[5] + e[6]), `${e[0]}：英文解釋或例句混到中文`);
  // 美式拼法
  ok(!/\b(colour|behaviour|neighbour|centre|favourite|travelling|cancelled|organis|realis|humour|theatre)\w*/i.test(e[0] + ' ' + e[6]), `${e[0]}：請用美式拼法：${e[6]}`);
});
/* 2. 不可重複 */
const keys = new Set();
W.forEach(e => { const k = e[0] + '|' + e[1]; ok(!keys.has(k), `重複的單字：${k}`); keys.add(k); });

/* 3. 例句要對上填空答案，而且答案是該字的變化形 */
const LOOK = EN.getLookup();
const words = s => EN.tokenize(s).filter(t => t.w).map(t => EN.norm(t.t).toLowerCase());
function findSeq(a, b) { for (let i = 0; i + b.length <= a.length; i++) if (b.every((x, j) => a[i + j] === x)) return true; return false; }
const OBJ = /^(it|them|him|her|me|you|us|the|a|my|your|this|great)$/;
W.forEach(e => {
  const [w, pos, , , , , sent, , ans] = e;
  ok(findSeq(words(sent), words(ans)), `${w}：例句「${sent}」裡找不到答案「${ans}」`);
  const A = words(ans);
  let isForm;
  if (pos === 'v-ph') {
    const c = EN.conjugate(w, pos);
    const head = A[0], rest = A.slice(1).filter(x => !OBJ.test(x));
    isForm = c.forms.some(f => f.split('/').some(x => x.split(' ')[0] === head)) && rest.join(' ') === c.rest.split(' ').filter(x => !OBJ.test(x)).join(' ');
  } else if (A.length > 1 || / /.test(w)) {
    isForm = EN.norm(ans).toLowerCase() === w || w.split(' ').some(x => A.includes(x)) || A.every(x => (LOOK.get(x) || []).some(y => y.lemma === w));
  } else isForm = A[0] === w || (LOOK.get(A[0]) || []).some(x => x.lemma === w);
  ok(isForm, `${w}：答案「${ans}」不是 ${w} 的變化形`);
});

/* 4. 點字查詢沒有漏字 */
const missing = new Map();
const chk = (s, who) => EN.tokenize(s).filter(t => t.w).forEach(t => {
  const k = EN.norm(t.t).toLowerCase();
  if (!LOOK.has(k) && !EN.NAMES[k]) missing.set(k, (missing.get(k) || []).concat(who));
});
W.forEach(e => chk(e[6], e[0]));
EN.GRAMMAR.forEach(g => (g.ex || []).forEach(s => chk(s[0], '文法:' + g.id)));
ok(missing.size === 0, '例句中查不到的字：' + [...missing].map(([k, v]) => k + '(' + v.slice(0, 2).join(',') + ')').join('  '));
eq(EN.tokenize("I don't know.").filter(t => t.w).map(t => t.t), ['I', "don't", 'know'], '縮寫算一個字');

/* 5. 動詞變化 */
const VREF = {
  achieve: 'achieve achieves achieved achieved achieving', admit: 'admit admits admitted admitted admitting', apologize: 'apologize apologizes apologized apologized apologizing',
  cancel: 'cancel cancels canceled canceled canceling', deny: 'deny denies denied denied denying', occur: 'occur occurs occurred occurred occurring',
  prefer: 'prefer prefers preferred preferred preferring', regret: 'regret regrets regretted regretted regretting', supply: 'supply supplies supplied supplied supplying',
  worry: 'worry worries worried worried worrying', discuss: 'discuss discusses discussed discussed discussing', steal: 'steal steals stole stolen stealing',
  hide: 'hide hides hid hidden hiding', freeze: 'freeze freezes froze frozen freezing', bite: 'bite bites bit bitten biting', tear: 'tear tears tore torn tearing',
  overcome: 'overcome overcomes overcame overcome overcoming', spread: 'spread spreads spread spread spreading', bet: 'bet bets bet bet betting', seek: 'seek seeks sought sought seeking',
  lay: 'lay lays laid laid laying', withdraw: 'withdraw withdraws withdrew withdrawn withdrawing', forgive: 'forgive forgives forgave forgiven forgiving',
  'give up': 'give up|gives up|gave up|given up|giving up', 'put up with': 'put up with|puts up with|put up with|put up with|putting up with',
  'run out of': 'run out of|runs out of|ran out of|run out of|running out of', 'drop out': 'drop out|drops out|dropped out|dropped out|dropping out',
  'get rid of': 'get rid of|gets rid of|got rid of|gotten rid of/got rid of|getting rid of', 'lie': null
};
for (const [v, ref] of Object.entries(VREF)) {
  if (!ref) continue;
  const e = by(v); ok(!!e, `參考表的動詞 ${v} 不在單字資料裡`); if (!e) continue;
  const c = EN.conjugate(e[0], e[1]);
  eq(c.forms.join(/\|/.test(ref) ? '|' : ' '), ref, `${v} 的變化`);
}
W.filter(e => /^v/.test(e[1])).forEach(e => {
  const c = EN.conjugate(e[0], e[1]);
  ok(c.forms.length === 5 && c.forms.every(x => /^[a-z /'-]+$/.test(x)), `${e[0]}：變化不完整 ${c.forms}`);
  ok(!!EN.formsTable(e), `${e[0]}：沒有變化表`);
});
eq(EN.third('watch'), 'watches', 'watches'); eq(EN.ing('lie'), 'lying', 'lying'); eq(EN.ing('see'), 'seeing', 'seeing');

/* 6. 名詞、形容詞 */
eq(EN.nounForms(by('opportunity', 'n')).pl, 'opportunities', 'opportunities');
eq(EN.nounForms(by('species', 'n')).pl, 'species', 'species');
eq(EN.nounForms(by('advice', 'n')).unc, true, 'advice 不可數');
eq(EN.nounForms(by('approach', 'n')).pl, 'approaches', 'approaches');
eq(EN.adjForms(by('tiny', 'adj')), ['tiny', 'tinier', 'tiniest'], 'tiny');
eq(EN.adjForms(by('fit', 'adj')), ['fit', 'fitter', 'fittest'], 'fit');
eq(EN.adjForms(by('brave', 'adj')), ['brave', 'braver', 'bravest'], 'brave');
eq(EN.adjForms(by('generous', 'adj')), ['generous', 'more generous', 'most generous'], 'generous');
eq(EN.adjForms(by('bored', 'adj'))[1], 'more bored', 'bored');
W.filter(e => e[1] === 'n' || e[1] === 'adj').forEach(e => ok(!!EN.formsTable(e), `${e[0]}：沒有變化表`));
W.filter(e => e[1] === 'n').forEach(e => { const f = EN.nounForms(e); ok(f.unc || f.plOnly || /^[a-z ]+$/.test(f.pl), `${e[0]}：複數怪怪的 ${f.pl}`); });

/* 7. 答案比對 */
eq(EN.checkAnswer('Colour', 'color'), 'ok', '英式拼法也算對');
eq(EN.checkAnswer('realised', 'realized'), 'ok', '-ise／-ize');
eq(EN.checkAnswer('cancelled', 'canceled'), 'ok', 'cancelled／canceled');
eq(EN.checkAnswer('don’t', "don't"), 'ok', '彎引號');
eq(EN.checkAnswer('stoped', 'stopped'), 'wrong', '拼錯');

/* 8. 文法點 */
EN.GRAMMAR.forEach(g => {
  let n = 0;
  W.forEach(e => { if (EN.grammarMatch(g, e[6]).length) n++; });
  (g.ex || []).forEach(x => { if (EN.grammarMatch(g, x[0]).length) n++; });
  ok(n >= 3, `文法點「${g.title}」只找到 ${n} 個例句`);
  (g.ex || []).forEach(x => ok(EN.grammarMatch(g, x[0]).length > 0, `文法點「${g.title}」的範例句沒有被標出：${x[0]}`));
  (g.ex || []).forEach(x => ok(/[。！？]$/.test(x[1]), `文法點「${g.title}」範例句的中文要有句末標點：${x[1]}`));
});
const gids = new Set(); EN.GRAMMAR.forEach(g => { ok(!gids.has(g.id), '文法點 id 重複：' + g.id); gids.add(g.id); });
const hl = (id, s) => EN.grammarMatch(EN.GRAMMAR.find(g => g.id === id), s).map(([a, b]) => EN.norm(s).slice(a, b));
eq(hl('passive', 'My bike was stolen last night.'), ['was', 'stolen'], '被動');
eq(hl('passive', 'I was surprised to see him.'), [], '形容詞不算被動');
eq(hl('pres-perf', 'Have you read any good books recently?'), ['Have', 'read'], '現在完成式');
eq(hl('phrasal', 'She turned down the job offer.'), ['turned', 'down'], '片語動詞');
eq(hl('phrasal', 'Don’t worry, I will sort it out.'), ['sort', 'out'], '拆開的片語動詞');
eq(hl('cond3', 'If I had studied harder, I wouldn’t have failed the test.').length > 0, true, '第三條件句');
eq(hl('ed-ing', 'The lecture was so boring that I fell asleep.'), ['boring'], '-ing 形容詞');

/* 9. 出題 */
const rng = (() => { let s = 11; return () => { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; }; })();
W.filter(e => /^v/.test(e[1])).forEach(e => {
  for (let k = 0; k < 6; k++) {
    const q = EN.makeVerbQuestion(e, rng);
    ok(q.options.includes(q.answer) && new Set(q.options).size === q.options.length && q.options.length === 4, `${e[0]}：動詞題選項有問題：${q.options}（答案 ${q.answer}）`);
    ok(EN.conjugate(e[0], e[1]).forms[q.person].split('/').includes(q.answer), `${e[0]}：動詞題答案錯了 ${q.answer}`);
    ok(q.options.every(o => !/(.)\1e?ing$|eeing$|eeed$/.test(o.split(' ')[0]) || /(ee|ss|ll)ing$/.test(o.split(' ')[0]) || EN.conjugate(e[0], e[1]).forms.some(f => f.split('/').includes(o))), `${e[0]}：動詞題有怪怪的選項 ${q.options}`);
  }
});
EN.PREP_DRILLS.forEach(d => ok(d[0].includes('___') && !d[2].includes(d[1]) && d[2].length === 3 && new Set(d[2]).size === 3 && /[。！？]$/.test(d[3]), `介係詞練習格式錯誤：${d[0]}`));
ok(EN.PREP_DRILLS.length >= 40, '介係詞練習太少');

/* 10. 規則頁、發音 */
EN.RULES.forEach(R => {
  ok(W.filter(e => R.filter(e)).length > 0, `規則「${R.title}」沒有字`);
  R.demo.forEach(x => ok(R.id === 'r-form' || W.some(e => e[0] === x), `規則「${R.title}」的示範字 ${x} 找不到`));
  const t = EN.demoTable(R.id, []);
  ok(!!t && t.rows.length > 0 && t.rows.every(r => r.length === t.head.length), `規則「${R.title}」的示範表格式錯誤`);
});
eq(EN.ALPHABET.length, 32, '音標數');
EN.READ_ITEMS.forEach(r => ok(r.w.includes(r.part) && r.opts.length === 3 && r.opts.every(Boolean) && new Set(r.opts).size === 3, `讀音題格式錯誤：${r.w}`));
EN.LISTEN_PAIRS.forEach(p => ok(p.length === 2 && p[0] !== p[1], `聽音題格式錯誤：${p}`));

const cnt = p => W.filter(e => e[1] === p).length;
/* 文法關卡：每個文法點剛好出現一次 */
const pathIds = (EN.GX_PATH || []).flatMap(x => x[2]);
eq(pathIds.slice().sort(), EN.GRAMMAR.map(g => g.id).sort(), '文法關卡要剛好包含所有文法點');
/* 文法練習題（EN.GX） */
const GX = EN.GX || {};
EN.GRAMMAR.forEach(g => ok(GX[g.id], `文法 ${g.id} 沒有練習題`));
Object.entries(GX).forEach(([id, x]) => {
  ok(EN.GRAMMAR.some(g => g.id === id), `GX ${id} 不在 GRAMMAR`);
  ok(Array.isArray(x.ex) && x.ex.length >= 1, `GX ${id} 沒有範例`);
  ok(Array.isArray(x.q) && x.q.length >= 6, `GX ${id} 題目少於 6`);
  (x.ex || []).forEach((e, i) => {
    ok(e.length === 5 && e[0] && e[1] && e[4], `GX ${id} 範例 ${i} 欄位不全`);
    ok(Array.isArray(e[2]) && e[2].length >= 2 && e[2].every(p => p.length === 2 && p[0] && (p[1] || /^[,.;—–!?]$/.test(p[0]))), `GX ${id} 範例 ${i} 拆字格式錯`);
    ok(e[2].every(p => e[0].includes(p[0])), `GX ${id} 範例 ${i} 拆字不在句子裡：${e[2].map(p => p[0]).filter(w => !e[0].includes(w))}`);
    ok(Array.isArray(e[3]) && e[3].length >= 1, `GX ${id} 範例 ${i} 沒有說明`);
    ok(/[。！？]$/.test(e[1]), `GX ${id} 範例 ${i} 中文沒句號：${e[1]}`);
  });
  ok(new Set((x.q || []).map(q => q[0])).size === (x.q || []).length, `GX ${id} 有重複的題目`);
  (x.q || []).forEach((q, i) => {
    ok(q.length === 5 && q[0] && q[1] && q[3] && q[4], `GX ${id} 題 ${i} 欄位不全`);
    ok(q[0].includes('___'), `GX ${id} 題 ${i} 沒有空格：${q[0]}`);
    ok(Array.isArray(q[2]) && q[2].length >= 2 && q[2].length <= 3, `GX ${id} 題 ${i} 選項數`);
    ok(!q[2].includes(q[1]) && new Set(q[2]).size === q[2].length, `GX ${id} 題 ${i} 選項重複或含答案`);
  });
});
console.log(`${W.length} 個字（名詞 ${cnt('n')}、動詞 ${cnt('v')}、片語動詞 ${cnt('v-ph')}、形容詞 ${cnt('adj')}、副詞與連接詞 ${cnt('adv') + cnt('conj') + cnt('prep')}、片語 ${cnt('expr')}），${EN.GRAMMAR.length} 個文法點，${EN.RULES.length} 頁變化規則，${EN.PREP_DRILLS.length} 題介係詞與搭配`);
console.log(`${checks} 項檢查，${fails} 項失敗`);
if (fails) { console.log(failList.slice(0, 80).join('\n')); process.exit(1); }
