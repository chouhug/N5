/* 英文 B2 文法的範例拆解與練習題（1）：時態、情態動詞、動詞句型、名詞形容詞
   EN.GX[文法點 id] = {
     ex: [[句子, 中文, [[字, 意思], …], [逐字說明…], 白話總結]],
     q:  [[題目（___ 是空格）, 答案, [錯的選項…], 中文, 為什麼]]
   }
   英文有很多撇號，所以這個檔案的字串一律用雙引號 */
(function (G) {
  const EN = G.EN || (G.EN = {});
  EN.GX = Object.assign(EN.GX || {}, {
    // ---------- 第 1 關：完成式和過去 ----------
    "pres-perf": {
      ex: [["I have lived here for ten years.", "我在這裡住了十年（現在還住）。", [["I", "我"], ["have", "（完成）"], ["lived", "住"], ["here", "這裡"], ["for", "長達"], ["ten", "十"], ["years", "年"]],
        ["have ＋ 過去分詞＝從過去一直到現在。", "如果說 I lived here for ten years，表示已經不住了。"],
        "現在完成式連接「過去」和「現在」：事情從以前開始、影響或持續到現在。"],
        ["Have you ever been to Japan?", "你去過日本嗎？", [["Have", "（完成）"], ["you", "你"], ["ever", "曾經"], ["been", "去過"], ["to", "到"], ["Japan", "日本"]],
        ["問經驗用 Have you ever…?", "去過某地用 been to，不是 gone to（gone 是去了還沒回來）。"],
        "問「這輩子有沒有做過」，不管哪一年，用現在完成式。"]],
      q: [["I ___ my keys. I can't find them.", "have lost", ["lost", "had lost"], "我把鑰匙弄丟了，找不到。", "過去的事影響現在（現在找不到），用現在完成式。"],
        ["She ___ to Paris three times.", "has been", ["has gone", "went"], "她去過巴黎三次。", "經驗用 has been；has gone 是「去了還沒回來」。"],
        ["I ___ him yesterday.", "saw", ["have seen", "have saw"], "我昨天見過他。", "有明確的過去時間（yesterday）就用過去式，不用完成式。"]]
    },
    "for-since": {
      ex: [["I've known her since 2015, for over ten years.", "我從 2015 年就認識她，已經十多年了。", [["I've", "我已經"], ["known", "認識"], ["her", "她"], ["since", "從…起"], ["2015", "2015"], [",", ""], ["for", "長達"], ["over", "超過"], ["ten", "十"], ["years", "年"]],
        ["since ＋ 起點（某年、某天）。", "for ＋ 一段時間（十年、三天）。"],
        "since 後面是「時間點」，for 後面是「時間長度」；ago 是「多久以前」，配過去式。"]],
      q: [["We've been friends ___ we were kids.", "since", ["for", "ago"], "我們從小就是朋友。", "since ＋ 起點（一件事）。"],
        ["I've waited ___ two hours.", "for", ["since", "ago"], "我等了兩個小時。", "for ＋ 一段時間。"],
        ["I moved here three years ___ .", "ago", ["since", "for"], "我三年前搬來這裡。", "「多久以前」用 ago，配過去式。"]]
    },
    "perf-cont": {
      ex: [["I've been studying all day.", "我念了一整天書（現在還在念或剛念完）。", [["I've", "我已經"], ["been", "（進行）"], ["studying", "念書"], ["all", "整"], ["day", "天"]],
        ["have been ＋ -ing＝從過去一直「在做」，強調持續的過程。"],
        "強調「做了多久、一直在做」用完成進行式；強調「做完了多少」用完成式。"]],
      q: [["You look tired. ___ you been running?", "Have", ["Did", "Are"], "你看起來好累，你剛剛在跑步嗎？", "從剛剛一直在做、留下結果：have been -ing。"],
        ["I've been ___ this book for a week.", "reading", ["read", "to read"], "這本書我讀了一個禮拜（還沒讀完）。", "have been 後面接 -ing。"],
        ["I've ___ three books this month.", "read", ["been reading", "reading"], "我這個月讀完了三本書。", "強調「完成的數量」用完成式，不用進行。"]]
    },
    "past-perf": {
      ex: [["When I arrived, the train had already left.", "我到的時候，火車已經開走了。", [["When", "當"], ["I", "我"], ["arrived", "到達"], [",", ""], ["the", "那班"], ["train", "火車"], ["had", "（過去完成）"], ["already", "已經"], ["left", "離開"]],
        ["兩件過去的事：火車先走（had left），我後到（arrived）。"],
        "過去完成式是「過去的過去」：比另一件過去的事更早發生。"]],
      q: [["She was sad because she ___ her phone.", "had lost", ["has lost", "loses"], "她很難過，因為她弄丟了手機。", "弄丟比難過更早：had lost。"],
        ["I ___ never seen snow before I went to Korea.", "had", ["have", "was"], "我去韓國之前從沒看過雪。", "在去韓國（過去）之前：had seen。"],
        ["By the time we got there, the film ___ .", "had started", ["has started", "starts"], "我們到的時候電影已經開始了。", "by the time ＋ 過去 → 另一件用 had done。"]]
    },
    "used-to": {
      ex: [["I used to smoke, but now I'm used to living without it.", "我以前抽菸，但現在已經習慣不抽了。", [["I", "我"], ["used", "以前"], ["to", "（會）"], ["smoke", "抽菸"], [",", ""], ["but", "但是"], ["now", "現在"], ["I'm", "我是"], ["used", "習慣"], ["to", "（於）"], ["living", "生活"], ["without", "沒有"], ["it", "它"]],
        ["used to ＋ 原形＝以前常常、現在不了。", "be used to ＋ -ing／名詞＝習慣某事。"],
        "used to do 是「以前會」，be used to doing 是「已經習慣」，get used to doing 是「漸漸習慣」。"]],
      q: [["I used to ___ in Taipei.", "live", ["living", "lived"], "我以前住在台北。", "used to 後面接原形。"],
        ["I'm used to ___ up early.", "getting", ["get", "got"], "我習慣早起。", "be used to 後面接 -ing。"],
        ["It took me a year to get used to ___ on the left.", "driving", ["drive", "drove"], "我花了一年才習慣靠左開車。", "get used to 後面接 -ing。"]]
    },
    // ---------- 第 2 關：未來和情態動詞 ----------
    "future": {
      ex: [["I'm going to visit my aunt, and I'm meeting her at six.", "我打算去看阿姨，六點跟她見面。", [["I'm", "我"], ["going", "打算"], ["to", "（要）"], ["visit", "拜訪"], ["my", "我的"], ["aunt", "阿姨"], [",", ""], ["and", "而且"], ["I'm", "我"], ["meeting", "見面"], ["her", "她"], ["at", "在"], ["six", "六點"]],
        ["be going to＝已經打算好的計畫。", "現在進行式＝已經約好、排好時間的事。"],
        "will 是當下決定或預測；be going to 是早就有的打算；現在進行式是已經安排好的行程。"]],
      q: [["The phone's ringing. — I ___ get it.", "'ll", ["'m going to", "'m getting"], "電話響了。——我來接。", "當下才決定，用 will。"],
        ["Look at those clouds. It's ___ rain.", "going to", ["will to", "going"], "看那些雲，要下雨了。", "看到證據的預測用 be going to。"],
        ["I ___ the dentist tomorrow at ten.", "'m seeing", ["see", "'ll seeing"], "我明天十點要看牙醫。", "已經約好的行程用現在進行式。"]]
    },
    "fut-perf": {
      ex: [["This time tomorrow I'll be flying to London.", "明天這時候我會正在飛往倫敦。", [["This", "這"], ["time", "時候"], ["tomorrow", "明天"], ["I'll", "我會"], ["be", "（進行）"], ["flying", "飛"], ["to", "到"], ["London", "倫敦"]],
        ["will be ＋ -ing＝未來某個時間點正在做。"],
        "未來進行式說「那時候正在做」，未來完成式說「到那時已經做完」。"],
        ["By June I'll have finished the course.", "到六月我就會上完這門課了。", [["By", "到…為止"], ["June", "六月"], ["I'll", "我會"], ["have", "（完成）"], ["finished", "完成"], ["the", "那門"], ["course", "課程"]],
        ["will have ＋ 過去分詞＝在未來某時間之前已經完成。", "常和 by（到…為止）一起用。"],
        "看到 by ＋ 未來時間，常常就是未來完成式。"]],
      q: [["Don't call at eight — I'll ___ dinner.", "be having", ["have had", "having"], "八點別打來，我那時會正在吃晚餐。", "那個時間點正在做：will be -ing。"],
        ["By 2030 they ___ built the new airport.", "will have", ["will be", "have"], "到 2030 年他們就會蓋好新機場了。", "by ＋ 未來時間 → will have done。"],
        ["Next month I'll have ___ here for five years.", "worked", ["working", "work"], "下個月我就在這裡工作滿五年了。", "will have 後面接過去分詞。"]]
    },
    "obligation": {
      ex: [["You don't have to come, but you mustn't be late if you do.", "你不一定要來，但要來就不能遲到。", [["You", "你"], ["don't", "不"], ["have", "必須"], ["to", "（要）"], ["come", "來"], [",", ""], ["but", "但是"], ["you", "你"], ["mustn't", "不准"], ["be", "是"], ["late", "遲到"], ["if", "如果"], ["you", "你"], ["do", "（來）"]],
        ["don't have to＝不必（可以不做）。", "mustn't＝不准（一定不能做）。"],
        "肯定句 must 和 have to 很像，但否定句意思完全不同：mustn't 是禁止，don't have to 是不用。"]],
      q: [["You ___ wear a uniform. It's optional.", "don't have to", ["mustn't", "shouldn't to"], "你不一定要穿制服，可以自己選。", "不必＝don't have to。"],
        ["You ___ smoke here. It's forbidden.", "mustn't", ["don't have to", "needn't"], "你不能在這裡抽菸，這是禁止的。", "禁止＝mustn't。"],
        ["You look ill. You ___ see a doctor.", "should", ["must to", "have"], "你看起來不舒服，應該去看醫生。", "建議用 should。"]]
    },
    "deduction": {
      ex: [["He must be tired; he can't be hungry, he just ate.", "他一定很累；他不可能餓，他才剛吃過。", [["He", "他"], ["must", "一定"], ["be", "是"], ["tired", "累的"], [";", ""], ["he", "他"], ["can't", "不可能"], ["be", "是"], ["hungry", "餓的"], [",", ""], ["he", "他"], ["just", "剛剛"], ["ate", "吃了"]],
        ["must be＝我很確定是。", "can't be＝我很確定不是（不用 mustn't）。", "might／could be＝可能是。"],
        "推測現在：很確定 must，可能 might／could，確定不是 can't。"]],
      q: [["The lights are off. They ___ be out.", "must", ["can't", "mustn't"], "燈都關了，他們一定出去了。", "有證據、很確定：must。"],
        ["That ___ be John — he's in Paris.", "can't", ["mustn't", "must"], "那不可能是 John，他在巴黎。", "確定不是：can't，不是 mustn't。"],
        ["Take an umbrella. It ___ rain later.", "might", ["must", "can't"], "帶把傘，等一下可能會下雨。", "不確定的可能用 might。"]]
    },
    "better-rather": {
      ex: [["You'd better leave now; I'd rather stay.", "你最好現在走；我寧願留下來。", [["You'd", "你最好"], ["better", "（最好）"], ["leave", "離開"], ["now", "現在"], [";", ""], ["I'd", "我寧願"], ["rather", "（寧願）"], ["stay", "留下"]],
        ["had better ＋ 原形＝最好（不然會有後果）。", "would rather ＋ 原形＝寧願、比較想。"],
        "'d 在 'd better 是 had，在 'd rather 是 would，後面都接原形。"]],
      q: [["You'd better ___ late again.", "not be", ["not to be", "don't be"], "你最好別再遲到。", "had better 的否定：had better not ＋ 原形。"],
        ["I'd rather ___ at home tonight.", "stay", ["to stay", "staying"], "我今晚寧願待在家。", "would rather 後面接原形。"],
        ["It's time we ___ home.", "went", ["go", "will go"], "我們該回家了。", "It's time ＋ 主詞 ＋ 過去式，表示「早該做了」。"]]
    },
    // ---------- 第 3 關：動詞句型 ----------
    "gerund": {
      ex: [["I enjoy cooking, and I've finished cleaning.", "我喜歡做菜，而且打掃完了。", [["I", "我"], ["enjoy", "喜歡"], ["cooking", "做菜"], [",", ""], ["and", "而且"], ["I've", "我已經"], ["finished", "完成"], ["cleaning", "打掃"]],
        ["enjoy、finish、avoid、mind、suggest 後面一定接 -ing。"],
        "有些動詞後面的動作要用 -ing，像名詞一樣：enjoy reading、avoid eating。"]],
      q: [["Would you mind ___ the window?", "opening", ["to open", "open"], "你介意開一下窗嗎？", "mind 後面接 -ing。"],
        ["He suggested ___ a taxi.", "taking", ["to take", "take"], "他建議搭計程車。", "suggest 後面接 -ing。"],
        ["I'm looking forward to ___ you.", "seeing", ["see", "saw"], "我很期待見到你。", "look forward to 的 to 是介係詞，後面接 -ing。"]]
    },
    "infinitive": {
      ex: [["I decided to quit and hope to travel.", "我決定辭職，希望能去旅行。", [["I", "我"], ["decided", "決定"], ["to", "（去）"], ["quit", "辭職"], ["and", "而且"], ["hope", "希望"], ["to", "（去）"], ["travel", "旅行"]],
        ["decide、hope、want、plan、promise 後面接 to ＋ 原形。"],
        "跟「未來想做、打算做」有關的動詞，常接 to ＋ 原形。"]],
      q: [["She promised ___ me.", "to call", ["calling", "call"], "她答應會打給我。", "promise 後面接 to ＋ 原形。"],
        ["We can't afford ___ a new car.", "to buy", ["buying", "buy"], "我們買不起新車。", "afford 後面接 to ＋ 原形。"],
        ["He refused ___ the question.", "to answer", ["answering", "answer"], "他拒絕回答這個問題。", "refuse 後面接 to ＋ 原形。"]]
    },
    "ing-to": {
      ex: [["I stopped to buy coffee, then stopped drinking it.", "我停下來買咖啡，後來就戒掉喝咖啡了。", [["I", "我"], ["stopped", "停下"], ["to", "（為了）"], ["buy", "買"], ["coffee", "咖啡"], [",", ""], ["then", "後來"], ["stopped", "停止"], ["drinking", "喝"], ["it", "它"]],
        ["stop to do＝停下來「去做」某事。", "stop doing＝停止「正在做」的事。"],
        "remember、forget、stop、try 接 -ing 或 to，意思不一樣：-ing 多半是已經做過的，to 多半是接下來要做的。"]],
      q: [["Remember ___ the door when you leave.", "to lock", ["locking", "lock"], "離開時記得鎖門。", "記得「要去做」：remember to do。"],
        ["I remember ___ him at the party.", "meeting", ["to meet", "meet"], "我記得在派對上見過他。", "記得「做過」：remember doing。"],
        ["Try ___ it off and on again.", "turning", ["to turning", "turn"], "試試看關掉再打開。", "try doing＝試試看這個方法。"]]
    },
    "phrasal": {
      ex: [["She gave up smoking and now looks after her health.", "她戒菸了，現在很照顧自己的健康。", [["She", "她"], ["gave", "（放棄）"], ["up", "（放棄）"], ["smoking", "抽菸"], ["and", "而且"], ["now", "現在"], ["looks", "（照顧）"], ["after", "（照顧）"], ["her", "她的"], ["health", "健康"]],
        ["give up＝放棄、戒掉。", "look after＝照顧。", "片語動詞的意思常常猜不出來，要整組背。"],
        "動詞 ＋ 小字（up、off、after…）組成新意思：give up、turn down、look after。"]],
      q: [["Can you ___ my cat this weekend?", "look after", ["look for", "look up"], "你這週末可以幫我照顧貓嗎？", "照顧＝look after；look for 是找。"],
        ["They ___ the meeting until Friday.", "put off", ["put on", "put up"], "他們把會議延到星期五。", "延期＝put off。"],
        ["I ___ an old friend in town.", "ran into", ["ran out", "ran over"], "我在鎮上巧遇老朋友。", "巧遇＝run into。"]]
    },
    "make-let": {
      ex: [["My boss made me work late but let me leave early on Friday.", "老闆叫我加班，但星期五讓我早走。", [["My", "我的"], ["boss", "老闆"], ["made", "使、逼"], ["me", "我"], ["work", "工作"], ["late", "晚"], ["but", "但是"], ["let", "讓"], ["me", "我"], ["leave", "離開"], ["early", "早"], ["on", "在"], ["Friday", "星期五"]],
        ["make ＋ 人 ＋ 原形＝逼某人做。", "let ＋ 人 ＋ 原形＝允許某人做。"],
        "make 和 let 後面接原形（不加 to）；allow 要加 to：allow me to leave。"]],
      q: [["My parents let me ___ out late.", "stay", ["to stay", "staying"], "我爸媽讓我晚歸。", "let ＋ 人 ＋ 原形。"],
        ["They don't allow us ___ photos.", "to take", ["take", "taking"], "他們不准我們拍照。", "allow ＋ 人 ＋ to ＋ 原形。"],
        ["The film made me ___ .", "cry", ["to cry", "crying"], "那部電影讓我哭了。", "make ＋ 人 ＋ 原形。"]]
    },
    // ---------- 第 4 關：名詞和形容詞 ----------
    "uncount": {
      ex: [["Can you give me some advice and information?", "你可以給我一些建議和資訊嗎？", [["Can", "可以"], ["you", "你"], ["give", "給"], ["me", "我"], ["some", "一些"], ["advice", "建議"], ["and", "和"], ["information", "資訊"]],
        ["advice、information 是不可數名詞：不加 -s，不能說 an advice。"],
        "中文覺得能數的，英文不一定能數：advice、information、furniture、news 都不可數。"]],
      q: [["She gave me a useful piece of ___ .", "advice", ["advices", "an advice"], "她給了我一個有用的建議。", "不可數，要「一個」用 a piece of。"],
        ["The news ___ good.", "is", ["are", "were"], "這個消息很好。", "news 雖然有 s，但是不可數單數。"],
        ["We need some new ___ .", "furniture", ["furnitures", "a furniture"], "我們需要一些新家具。", "furniture 不可數。"]]
    },
    "quant": {
      ex: [["I have a few friends here, but little free time.", "我在這裡有幾個朋友，但空閒時間很少。", [["I", "我"], ["have", "有"], ["a few", "幾個"], ["friends", "朋友"], ["here", "這裡"], [",", ""], ["but", "但是"], ["little", "很少"], ["free", "空閒的"], ["time", "時間"]],
        ["a few＋可數＝有一些（正面）。", "little＋不可數＝很少、幾乎沒有（負面）。"],
        "可數用 few／a few，不可數用 little／a little；有 a 是「還有一些」，沒 a 是「幾乎沒有」。"]],
      q: [["There's ___ milk left. Let's buy some.", "little", ["few", "a few"], "牛奶快沒了，我們買一點吧。", "milk 不可數，「幾乎沒有」用 little。"],
        ["I've got ___ minutes. What's up?", "a few", ["a little", "little"], "我有幾分鐘，什麼事？", "minutes 可數，「有一些」用 a few。"],
        ["Very ___ people came to the party.", "few", ["little", "a little"], "很少人來派對。", "people 可數，「很少」用 few。"]]
    },
    "ed-ing": {
      ex: [["The film was boring, so I was bored.", "那部電影很無聊，所以我覺得很無聊。", [["The", "那部"], ["film", "電影"], ["was", "是"], ["boring", "令人無聊的"], [",", ""], ["so", "所以"], ["I", "我"], ["was", "是"], ["bored", "感到無聊的"]],
        ["-ing：東西本身讓人有這種感覺。", "-ed：人感覺到這種感覺。"],
        "電影 boring（讓人無聊），我 bored（覺得無聊）。說自己 I'm boring 是「我很無趣」。"]],
      q: [["I'm really ___ in history.", "interested", ["interesting", "interest"], "我對歷史很有興趣。", "人的感覺用 -ed。"],
        ["The news was ___ .", "shocking", ["shocked", "shock"], "這個消息很驚人。", "東西帶給人的感覺用 -ing。"],
        ["She felt ___ after the long trip.", "exhausted", ["exhausting", "exhaust"], "長途旅行後她累壞了。", "人的感覺用 -ed。"]]
    },
    "word-form": {
      ex: [["It's impossible to be happy without happiness.", "沒有幸福就不可能快樂。", [["It's", "它是"], ["impossible", "不可能的"], ["to", "（要）"], ["be", "是"], ["happy", "快樂的"], ["without", "沒有"], ["happiness", "幸福"]],
        ["im- ＋ possible＝不可能。", "happy ＋ -ness＝名詞「幸福」。"],
        "字首改意思（un-、im-、dis-），字尾改詞性（-ness、-tion 名詞；-ful、-able 形容詞；-ly 副詞）。"]],
      q: [["He drives very ___ .", "carefully", ["careful", "care"], "他開車很小心。", "修飾動詞要用副詞 -ly。"],
        ["Thank you for your ___ .", "kindness", ["kind", "kindly"], "謝謝你的好意。", "your 後面要名詞：kind → kindness。"],
        ["That's a very ___ question.", "difficult", ["difficulty", "difficultly"], "那是個很難的問題。", "名詞前面要形容詞。"]]
    },
    "prep-coll": {
      ex: [["She's good at maths and interested in art.", "她擅長數學，對藝術有興趣。", [["She's", "她是"], ["good", "擅長的"], ["at", "（在）"], ["maths", "數學"], ["and", "而且"], ["interested", "有興趣的"], ["in", "（對）"], ["art", "藝術"]],
        ["good at、interested in、afraid of 是固定搭配。"],
        "形容詞後面接哪個介係詞是固定的，要整組背。"]],
      q: [["I'm afraid ___ spiders.", "of", ["from", "with"], "我怕蜘蛛。", "afraid of。"],
        ["She's proud ___ her son.", "of", ["for", "on"], "她以兒子為榮。", "proud of。"],
        ["He's responsible ___ the project.", "for", ["of", "to"], "他負責這個專案。", "responsible for。"]]
    }
  });
})(typeof window !== 'undefined' ? window : globalThis);
