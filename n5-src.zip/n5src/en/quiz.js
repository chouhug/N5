/* 出題邏輯（英文）：動詞變化題、介係詞與搭配練習、音標與發音練習資料
   英文沒有冠詞性別，單選的第五種題型改成「介係詞與搭配」，全部用人工挑選、只有一個答案的句子 */
(function (G) {
  'use strict';
  const EN = G.EN || (G.EN = {});
  EN.ART_DEMO_EXTRA = {};
  function shuffle(a, rnd) { rnd = rnd || Math.random; a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
  function pick(a, rnd) { return a[Math.floor((rnd || Math.random)() * a.length)]; }
  EN.shuffle = shuffle; EN.pick = pick;

  // 沒有從例句挖題的冠詞題：App 會改出 PREP_DRILLS
  EN.makeArtQuestion = () => null;
  EN.DRILLS_ONLY = true;   // 單選「介係詞與搭配」不看題目來源，一律出練習句
  EN.artWrong = (q, opt) => !q.valid.includes(opt);

  EN.PREP_DRILLS = [
    ['I am not very interested ___ politics.', 'in', ['on', 'at', 'about'], '我對政治不太有興趣。'],
    ['She is really good ___ explaining things.', 'at', ['in', 'on', 'for'], '她很會解釋事情。'],
    ['He is afraid ___ dogs.', 'of', ['from', 'with', 'about'], '他怕狗。'],
    ['I am worried ___ my exam.', 'about', ['for', 'of', 'on'], '我很擔心考試。'],
    ['This town is famous ___ its cheese.', 'for', ['of', 'with', 'by'], '這個小鎮以起司聞名。'],
    ['Your phone is similar ___ mine.', 'to', ['with', 'as', 'from'], '你的手機跟我的很像。'],
    ['Life in the city is very different ___ life in the country.', 'from', ['of', 'with', 'at'], '城市生活和鄉村生活很不一樣。'],
    ['Are you satisfied ___ the service?', 'with', ['of', 'for', 'about'], '您對服務滿意嗎？'],
    ['I am not keen ___ horror films.', 'on', ['in', 'at', 'with'], '我不太喜歡恐怖片。'],
    ['Who is responsible ___ this project?', 'for', ['of', 'on', 'to'], '誰負責這個專案？'],
    ['She is proud ___ her children.', 'of', ['about', 'for', 'with'], '她以孩子為傲。'],
    ['It depends ___ the weather.', 'on', ['of', 'from', 'at'], '要看天氣。'],
    ['I apologized ___ being late.', 'for', ['of', 'about', 'to'], '我為遲到道歉。'],
    ['He insisted ___ paying for dinner.', 'on', ['for', 'to', 'in'], '他堅持要付晚餐的錢。'],
    ['She succeeded ___ passing the exam.', 'in', ['on', 'at', 'for'], '她成功通過了考試。'],
    ['I am looking forward ___ seeing you.', 'to', ['for', 'at', 'on'], '我很期待見到你。'],
    ['You can rely ___ me.', 'on', ['to', 'in', 'at'], '你可以依靠我。'],
    ['We need to focus ___ the main problem.', 'on', ['in', 'at', 'to'], '我們要專注在主要的問題上。'],
    ['He suffers ___ back pain.', 'from', ['of', 'with', 'by'], '他有背痛的毛病。'],
    ['Congratulations ___ your new job!', 'on', ['for', 'to', 'at'], '恭喜你找到新工作！'],
    ['The book was written ___ a famous journalist.', 'by', ['from', 'of', 'with'], '這本書是一位有名的記者寫的。'],
    ['I will be there ___ Monday.', 'on', ['in', 'at', 'by'], '我星期一會到。'],
    ['The meeting starts ___ nine o’clock.', 'at', ['on', 'in', 'by'], '會議九點開始。'],
    ['She was born ___ 1998.', 'in', ['on', 'at', 'by'], '她 1998 年出生。'],
    ['Please finish the report ___ Friday.', 'by', ['until', 'in', 'at'], '請在星期五前完成報告。'],
    ['I waited for you ___ midnight.', 'until', ['by', 'to', 'at'], '我等你等到半夜。'],
    ['There is a lack ___ money.', 'of', ['for', 'in', 'about'], '缺錢。'],
    ['What is the reason ___ the delay?', 'for', ['of', 'to', 'about'], '延誤的原因是什麼？'],
    ['There has been an increase ___ prices.', 'in', ['of', 'on', 'at'], '價格上漲了。'],
    ['Thank you ___ your help.', 'for', ['about', 'of', 'to'], '謝謝你的幫忙。'],
    ['I agree ___ you.', 'with', ['to', 'on', 'for'], '我同意你。'],
    ['He was accused ___ stealing money.', 'of', ['for', 'with', 'about'], '他被指控偷錢。'],
    ['___ the other hand, it is very expensive.', 'On', ['In', 'At', 'By'], '但另一方面，它很貴。'],
    ['I deleted the file ___ accident.', 'by', ['on', 'in', 'with'], '我不小心刪掉了檔案。'],
    ['He broke it ___ purpose.', 'on', ['by', 'in', 'with'], '他是故意弄壞的。'],
    ['Book your tickets ___ advance.', 'in', ['on', 'by', 'at'], '請提前訂票。'],
    ['The elevator is out ___ order.', 'of', ['from', 'in', 'off'], '電梯故障了。'],
    ['She takes ___ her mother.', 'after', ['over', 'off', 'up'], '她很像她媽媽。'],
    ['I can’t put up ___ this noise.', 'with', ['to', 'for', 'on'], '我受不了這個噪音。'],
    ['We have run out ___ milk.', 'of', ['from', 'off', 'with'], '我們的牛奶沒了。'],
    ['He came up ___ a great idea.', 'with', ['to', 'by', 'for'], '他想出了一個好點子。'],
    ['The match was called ___ because of the rain.', 'off', ['out', 'up', 'down'], '比賽因為下雨取消了。'],
    ['She turned ___ the job offer.', 'down', ['off', 'out', 'over'], '她拒絕了那份工作邀約。'],
    ['Could you look ___ my cat this weekend?', 'after', ['for', 'at', 'up'], '這週末你可以幫我照顧貓嗎？'],
    ['The police are looking ___ the case.', 'into', ['after', 'up', 'out'], '警方正在調查這個案子。'],
    ['I ___ my homework every evening.', 'do', ['make', 'take', 'have'], '我每天晚上寫作業。'],
    ['Everyone ___ mistakes.', 'makes', ['does', 'takes', 'has'], '每個人都會犯錯。'],
    ['You need to ___ a decision soon.', 'make', ['do', 'take', 'have'], '你得盡快做決定。'],
    ['Sometimes you have to ___ a risk.', 'take', ['make', 'do', 'put'], '有時候你得冒險。'],
    ['Let’s ___ a break.', 'take', ['make', 'do', 'give'], '我們休息一下吧。'],
    ['He is ___ research on climate change.', 'doing', ['making', 'taking', 'having'], '他在做氣候變遷的研究。'],
    ['Can I ___ you a favor?', 'ask', ['do', 'make', 'take'], '可以請你幫個忙嗎？'],
    ['She ___ a speech at the wedding.', 'gave', ['made', 'did', 'said'], '她在婚禮上致詞。'],
    ['It was a ___ storm, so we stayed inside.', 'heavy', ['strong', 'big', 'hard'], '暴風雨很大，所以我們待在屋裡。'],
    ['There was ___ traffic on the way here.', 'heavy', ['strong', 'big', 'many'], '來這裡的路上很塞。'],
    ['I would like a ___ coffee, please.', 'strong', ['heavy', 'hard', 'big'], '我要一杯濃咖啡。'],
    ['Please ___ attention to the instructions.', 'pay', ['give', 'make', 'take'], '請注意說明。'],
    ['Let’s keep in ___ after graduation.', 'touch', ['contact', 'tie', 'talk'], '畢業後保持聯絡吧。']
  ];

  // 動詞變化題：問過去式、過去分詞、第三人稱單數或 -ing
  const ASK = [
    { k: 2, label: '過去式', subj: ['Yesterday I', 'Last week she', 'In 2020 we'] },
    { k: 3, label: '過去分詞', subj: ['I have', 'It has been', 'She had'] },
    { k: 1, label: '現在式（第三人稱單數）', subj: ['She usually', 'He often', 'It always'] },
    { k: 4, label: '進行式（-ing）', subj: ['I am', 'They were', 'We are'] }
  ];
  function makeVerbQuestion(entry, rnd) {
    rnd = rnd || Math.random;
    const c = EN.conjugate(entry[0], entry[1]);
    // 不規則動詞多考過去式和過去分詞
    const pool = c.irregular ? [ASK[0], ASK[1], ASK[0], ASK[1], ASK[2], ASK[3]] : ASK;
    let a = pick(pool, rnd);
    if (a.k === 3 && c.forms[3] === c.forms[2] && !c.irregular && rnd() < 0.7) a = ASK[2 + Math.floor(rnd() * 2)];
    const answer = c.forms[a.k].split('/')[0];
    const head = c.head, rest = c.rest ? ' ' + c.rest : '';
    const wrong = new Set();
    c.forms.forEach((f, i) => { if (i !== a.k) f.split('/').forEach(x => wrong.add(x)); });
    // 常見錯誤：規則化（goed、stealed）、重複字尾子音或沒重複、少了 e
    // 只有子音＋母音＋子音結尾（stop、admit）才拿「重複字尾子音」當干擾選項，不會出現 criticizeeing 這種字
    const cvc = /[^aeiou][aeiou][bcdfgklmnprstvz]$/.test(head) && (head.match(/[aeiouy]+/g) || []).length === 1;
    wrong.add(EN.regEd(head) + rest); wrong.add(head + 'ing' + rest);
    if (cvc) { wrong.add(EN.regEd(head, true) + rest); wrong.add(EN.ing(head, true) + rest); wrong.add(head + 'ed' + rest); }
    if (/[^e]e$/.test(head)) wrong.add(head + 'ed' + rest);   // 忘了去 e：hideed（ee 結尾的不算）
    if (a.k === 1) { wrong.add(head + 's' + rest); wrong.add(head + 'es' + rest); }
    const ok = new Set(c.forms[a.k].split('/'));
    const opts = shuffle([...wrong].filter(x => x && !ok.has(x) && x !== answer), rnd);
    // 選項至少要有一個是這個動詞真正的其他形，題目才有意義
    const real = opts.filter(x => c.forms.some(f => f.split('/').includes(x)));
    const fake = opts.filter(x => !real.includes(x));
    const pick3 = real.slice(0, 2).concat(fake, real.slice(2)).slice(0, 3);
    const options = shuffle([answer].concat(pick3), rnd);
    return { kind: 'verb', tense: a.k === 2 ? 'passato' : 'presente', label: a.label, subj: pick(a.subj, rnd), person: a.k, answer, options, word: entry, conj: c };
  }
  EN.makeVerbQuestion = makeVerbQuestion;

  /* ---------- 發音（音標） ---------- */
  // [音標, 例字（點了會唸）, 標題, 說明, 例字]
  EN.ALPHABET = [
    ['/ɪ/', 'sit', '短的「一」', '比中文的「一」短、鬆，嘴巴稍微打開；不要唸成長音 /iː/', 'sit'],
    ['/e/', 'bed', '像「ㄝ」', '嘴巴半開，短促', 'bed'],
    ['/æ/', 'cat', '「ㄝ」和「ㄚ」之間', '嘴巴張大往兩邊拉，像不耐煩的「欸～」', 'cat'],
    ['/ʌ/', 'cup', '短的「ㄚ」', '嘴巴自然張開，聲音短；love、money、come 也是這個音', 'cup'],
    ['/ʊ/', 'book', '短的「ㄨ」', '嘴唇微圓、放鬆，比 /uː/ 短', 'book'],
    ['/ɑ/', 'hot', '「ㄚ」（美式）', '嘴巴張大、舌頭放低；英式唸圓唇的 /ɒ/', 'hot'],
    ['/ə/', 'about', '弱弱的「ㄜ」', '最常見的音！沒重音的母音幾乎都唸這個：about、teacher、banana', 'about'],
    ['/iː/', 'sheep', '長的「一」', '嘴巴往兩邊拉，拉長；sheep 和 ship 意思不同', 'sheep'],
    ['/uː/', 'food', '長的「ㄨ」', '嘴唇圓、往前嘟', 'food'],
    ['/ɔː/', 'law', '「ㄛ」拉長', '嘴巴圓、打開；美式很多人唸成 /ɑ/', 'law'],
    ['/ɜːr/', 'bird', '捲舌的「ㄦ」', '舌頭捲起來，嘴巴不要圓：bird、work、learn', 'bird'],
    ['/ɑːr/', 'car', '「ㄚ」＋捲舌', '美式要捲舌；英式不捲，只拉長「ㄚ」', 'car'],
    ['/eɪ/', 'day', '「ㄟ」', 'day、make、rain', 'day'],
    ['/aɪ/', 'time', '「ㄞ」', 'time、my、light', 'time'],
    ['/ɔɪ/', 'boy', '「ㄛ一」', 'boy、noise、choice', 'boy'],
    ['/aʊ/', 'now', '「ㄠ」', 'now、house、down', 'now'],
    ['/oʊ/', 'go', '「ㄡ」', 'go、home、know；不要唸成單純的「喔」', 'go'],
    ['/ɪr/', 'near', '「一ㄦ」', 'near、here、year', 'near'],
    ['/er/', 'hair', '「ㄝㄦ」', 'hair、where、care', 'hair'],
    ['/ʊr/', 'tour', '「ㄨㄦ」', 'tour、sure（很多人唸成 /ɔːr/）', 'tour'],
    ['/θ/', 'think', '咬舌的清音', '舌尖輕咬在上下牙齒中間吹氣，不是 s 也不是 f：think、three、month', 'think'],
    ['/ð/', 'this', '咬舌的濁音', '跟 /θ/ 一樣咬舌，但聲帶震動：this、mother、weather', 'this'],
    ['/v/', 'very', '上齒碰下唇（震動）', '不是 b 也不是 w：very、voice、seven', 'very'],
    ['/w/', 'wine', '圓唇滑音', '嘴唇圓起來再打開，牙齒不碰嘴唇：wine、wait', 'wine'],
    ['/r/', 'right', '捲舌（不碰上顎）', '舌尖往後捲，不碰任何地方；嘴唇稍圓', 'right'],
    ['/l/', 'light', '舌尖碰上牙齦', '字首的 l 清楚；字尾的 l（feel、ball）舌根抬起，像「ㄡ」', 'light'],
    ['/ʃ/', 'she', '像「噓」', 'she、shop、nation', 'she'],
    ['/ʒ/', 'vision', '「噓」＋震動', 'vision、usually、measure', 'vision'],
    ['/tʃ/', 'chair', '像「七」（圓唇）', 'chair、watch、nature', 'chair'],
    ['/dʒ/', 'job', '像「居」（震動）', 'job、age、bridge', 'job'],
    ['/ŋ/', 'sing', '「ㄥ」', 'sing、long；ng 結尾不要再加 g 的音', 'sing'],
    ['/z/', 'zoo', '震動的 s', 'zoo、easy、dogs；不要唸成中文的「ㄗ」', 'zoo']
  ];

  EN.PRON_RULES = [
    { t: '沒重音的母音唸 /ə/', d: '英文的節奏來自<b>重音</b>：重音節唸清楚、拉長，其他母音縮成弱弱的 /ə/。<i>banana</i> 唸 bə-NA-nə，不是三個「ㄚ」。', ex: [['banana', 'bə-NA-nə'], ['about', 'ə-BOUT'], ['teacher', 'TEA-chər'], ['problem', 'PROB-ləm'], ['photograph', 'PHO-tə-graph']] },
    { t: '名詞重音在前、動詞在後', d: '同一個字當名詞和動詞時，重音常常不同：名詞在<b>第一個音節</b>，動詞在<b>第二個</b>。', ex: [['record', 'RE-cord（名詞）'], ['present', 'PRE-sent（名詞）'], ['increase', 'IN-crease（名詞）'], ['object', 'OB-ject（名詞）'], ['permit', 'PER-mit（名詞）']] },
    { t: '-tion、-ic、-ity 的重音', d: '字尾是 <b>-tion、-sion、-ic、-ical、-ity</b> 時，重音落在這個字尾<b>前面一個音節</b>：infor<b>MA</b>tion、eco<b>NO</b>mic、a<b>BI</b>lity。所以同一家族的字重音會移動：<b>PHO</b>tograph → pho<b>TO</b>graphy → photo<b>GRA</b>phic。', ex: [['information', 'in-for-MA-tion'], ['economic', 'e-co-NO-mic'], ['ability', 'a-BI-li-ty'], ['photography', 'pho-TO-gra-phy'], ['decision', 'de-CI-sion']] },
    { t: '-ed 的三種唸法', d: '在 <b>t、d</b> 後面唸 /ɪd/（多一個音節）；在 <b>p、k、f、s、sh、ch</b> 等清音後面唸 /t/；其他唸 /d/。', ex: [['wanted', '/ɪd/'], ['needed', '/ɪd/'], ['worked', '/t/'], ['stopped', '/t/'], ['played', '/d/'], ['lived', '/d/']] },
    { t: '-s 的三種唸法', d: '在 <b>s、z、sh、ch、j</b> 的音後面唸 /ɪz/；在 <b>p、t、k、f</b> 後面唸 /s/；其他唸 /z/。', ex: [['buses', '/ɪz/'], ['watches', '/ɪz/'], ['cats', '/s/'], ['books', '/s/'], ['dogs', '/z/'], ['plays', '/z/']] },
    { t: '不發音的字母', d: '有些字母只寫不唸：<b>k</b>nife、<b>w</b>rite、i<b>s</b>land、clim<b>b</b>、lis<b>t</b>en、<b>h</b>our、could 的 <b>l</b>、Wednesday 的第一個 <b>d</b>。', ex: [['knife', 'k 不唸'], ['write', 'w 不唸'], ['island', 's 不唸'], ['climb', 'b 不唸'], ['listen', 't 不唸'], ['hour', 'h 不唸']] },
    { t: 'th 要咬舌', d: '<b>th</b> 有兩種：清音 /θ/（think、three）和濁音 /ð/（this、the、mother）。舌尖放在上下牙齒中間，不要唸成 s、f 或 d。', ex: [['think', '/θ/'], ['three', '/θ/'], ['month', '/θ/'], ['this', '/ð/'], ['weather', '/ð/']] },
    { t: '字尾的子音要收乾淨', d: '中文字尾很少有子音，所以常把英文字尾的音吞掉或加母音（good 唸成「古德」）。字尾的 t、d、k 只要嘴巴做出動作、輕輕停住就好，不要加「ㄜ」。', ex: [['good', '/d/'], ['book', '/k/'], ['night', '/t/'], ['help', '/p/'], ['fixed', '/kst/']] },
    { t: '美式的 t 會變輕', d: '美式英文中，t 夾在兩個母音中間、而且不是重音時，會唸成很快的 d（彈舌）：<i>water</i> 唸像「哇的」、<i>better</i> 像「貝德」。', ex: [['water', 'wa-der'], ['better', 'be-der'], ['city', 'ci-dy'], ['get up', 'ge-dup'], ['a lot of', 'a lo-dof']] },
    { t: '連音：子音接母音', d: '前一個字的子音結尾，接下一個字的母音開頭時，要連在一起唸：<i>turn off</i> 唸 tur-noff、<i>pick it up</i> 唸 pi-ki-tup。片語動詞特別常這樣連。', ex: [['turn off', 'tur-noff'], ['pick it up', 'pi-ki-tup'], ['look at it', 'loo-ka-dit'], ['give up', 'gi-vup'], ['an apple', 'a-napple']] },
    { t: '弱讀：功能字唸得很輕', d: '<b>to、of、for、can、and、a、the</b> 這類小字在句子裡通常唸弱音：<i>a cup of tea</i> 的 of 唸 /əv/，聽起來像「a cup a tea」；<i>I can swim</i> 的 can 唸 /kən/。強調時才唸完整。', ex: [['a cup of tea', 'of → /əv/'], ['I can swim', 'can → /kən/'], ['fish and chips', 'and → /ən/'], ['going to', 'gonna'], ['want to', 'wanna']] },
    { t: 'ough 的唸法不固定', d: '<b>ough</b> 是英文最難的拼法，要一個一個記：though（/oʊ/）、through（/uː/）、enough（/ʌf/）、thought（/ɔː/）、cough（/ɔːf/）。', ex: [['though', '/oʊ/'], ['through', '/uː/'], ['enough', '/ʌf/'], ['thought', '/ɔː/'], ['cough', '/ɔːf/']] }
  ];

  // 聽音選拼字（最小對立組）
  EN.LISTEN_PAIRS = [
    ['ship', 'sheep'], ['live', 'leave'], ['sit', 'seat'], ['full', 'fool'], ['pull', 'pool'], ['bad', 'bed'], ['man', 'men'], ['cap', 'cup'], ['hat', 'hut'],
    ['walk', 'work'], ['light', 'right'], ['glass', 'grass'], ['collect', 'correct'], ['very', 'berry'], ['vote', 'boat'], ['fan', 'van'], ['think', 'sink'],
    ['three', 'tree'], ['mouth', 'mouse'], ['then', 'den'], ['they', 'day'], ['rice', 'rise'], ['bag', 'back'], ['wine', 'vine'], ['hard', 'heart']
  ];

  // 看拼字選讀法
  const S = {
    id: '/ɪd/（多一個音節）', t: '/t/', d: '/d/', iz: '/ɪz/', s: '/s/', z: '/z/', th: '/θ/（咬舌清音）', dh: '/ð/（咬舌濁音）', mute: '不發音', k: '/k/', h: '/h/', b: '/b/', w: '/w/',
    ou: '/oʊ/', uu: '/uː/', uf: '/ʌf/', ss: '/s/', kk: '/k/', dj: '/dʒ/', g: '/g/', sh: '/ʃ/', ch: '/tʃ/', ii: '/iː/', i: '/ɪ/', ae: '/æ/', a: '/ʌ/', schwa: '/ə/'
  };
  EN.READ_ITEMS = [
    ['wanted', 'ed', 'id', ['t', 'd']], ['needed', 'ed', 'id', ['t', 'd']], ['worked', 'ed', 't', ['d', 'id']], ['stopped', 'ed', 't', ['d', 'id']], ['played', 'ed', 'd', ['t', 'id']], ['lived', 'ed', 'd', ['t', 'id']],
    ['buses', 'es', 'iz', ['s', 'z']], ['cats', 's', 's', ['z', 'iz']], ['dogs', 's', 'z', ['s', 'iz']],
    ['think', 'th', 'th', ['dh', 's']], ['weather', 'th', 'dh', ['th', 'd']], ['knife', 'k', 'mute', ['k', 'h']], ['write', 'w', 'mute', ['w', 'h']], ['hour', 'h', 'mute', ['h', 'w']], ['climb', 'b', 'mute', ['b', 'w']], ['listen', 't', 'mute', ['t', 'd']],
    ['though', 'ough', 'ou', ['uu', 'uf']], ['through', 'ough', 'uu', ['ou', 'uf']], ['enough', 'ough', 'uf', ['ou', 'uu']],
    ['city', 'c', 'ss', ['kk', 'sh']], ['giant', 'g', 'dj', ['g', 'h']], ['chef', 'ch', 'sh', ['ch', 'kk']], ['school', 'ch', 'kk', ['ch', 'sh']], ['chair', 'ch', 'ch', ['sh', 'kk']],
    ['sheep', 'ee', 'ii', ['i', 'ae']], ['money', 'o', 'a', ['ou', 'schwa']], ['about', 'a', 'schwa', ['ae', 'a']]
  ].map(([w, part, ans, wr]) => ({ w, part, ans: S[ans], opts: [S[ans]].concat(wr.map(k => S[k])) }));
})(typeof window !== 'undefined' ? window : globalThis);
