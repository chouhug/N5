/* 英文變化引擎：動詞（第三人稱、過去式、過去分詞、-ing）、名詞複數、形容詞比較級、斷詞與查詢、答案比對
   拼字以美式為主；填空寫英式拼法（colour、realise）也算對
   - 動詞第 4 欄規格 key=value;…：past=、pp=（不規則）、dbl（重複字尾子音：stop → stopped）、s=（第三人稱單數另寫）、ing=
     片語動詞（v-ph）用第一個字變化：give up → gave up、given up；其他字照抄
   - 名詞：pl=（不規則複數）、unc（不可數）、plonly（只有複數）
   - 形容詞：cmp=,sup=（不規則）、more（用 more／most）、dbl（big → bigger）、nocmp */
(function (G) {
  'use strict';
  const EN = G.EN || (G.EN = {});
  G.LX = EN;
  EN.GENDER = {};   // 沒有名詞性別

  /* ---------- 小工具 ---------- */
  function spec(s) {
    const o = {};
    if (!s || s === '-') return o;
    s.split(';').forEach(p => { const i = p.indexOf('='); if (i < 0) o[p.trim()] = true; else o[p.slice(0, i).trim()] = p.slice(i + 1).trim(); });
    return o;
  }
  EN.spec = spec;
  const norm = s => String(s).replace(/[’‘`´]/g, "'").replace(/[“”]/g, '"');
  const stripAccents = s => String(s).normalize('NFD').replace(/[̀-ͯ]/g, '');
  EN.norm = norm; EN.stripAccents = stripAccents;
  const VOW = /[aeiou]/;
  const isCons = c => !!c && /[a-z]/.test(c) && !VOW.test(c);

  /* ---------- 動詞 ---------- */
  function third(b) {
    if (b === 'have') return 'has';
    if (b === 'be') return 'is';
    if (/(s|x|z|ch|sh|o)$/.test(b) && !/(oo)$/.test(b)) return b + 'es';
    if (/[^aeiou]y$/.test(b)) return b.slice(0, -1) + 'ies';
    return b + 's';
  }
  function regEd(b, dbl) {
    if (dbl) return b + b.slice(-1) + 'ed';
    if (/e$/.test(b)) return b + 'd';
    if (/[^aeiou]y$/.test(b)) return b.slice(0, -1) + 'ied';
    return b + 'ed';
  }
  function ing(b, dbl) {
    if (dbl) return b + b.slice(-1) + 'ing';
    if (/ie$/.test(b)) return b.slice(0, -2) + 'ying';
    if (/[^aeiouy]e$/.test(b) && !/(ee|ye|oe)$/.test(b) && b !== 'be') return b.slice(0, -1) + 'ing';
    return b + 'ing';
  }
  EN.third = third; EN.regEd = regEd; EN.ing = ing;
  // 常見不規則動詞（基本字也用得到）
  const IRR = {
    be: 'was/were,been', have: 'had,had', do: 'did,done', go: 'went,gone', get: 'got,gotten/got', make: 'made,made', take: 'took,taken', come: 'came,come',
    see: 'saw,seen', know: 'knew,known', give: 'gave,given', find: 'found,found', think: 'thought,thought', tell: 'told,told', say: 'said,said',
    become: 'became,become', leave: 'left,left', feel: 'felt,felt', bring: 'brought,brought', begin: 'began,begun', keep: 'kept,kept', hold: 'held,held',
    write: 'wrote,written', stand: 'stood,stood', hear: 'heard,heard', let: 'let,let', mean: 'meant,meant', set: 'set,set', meet: 'met,met', run: 'ran,run',
    pay: 'paid,paid', sit: 'sat,sat', speak: 'spoke,spoken', lie: 'lay,lain', lead: 'led,led', read: 'read,read', grow: 'grew,grown', lose: 'lost,lost',
    fall: 'fell,fallen', send: 'sent,sent', build: 'built,built', understand: 'understood,understood', draw: 'drew,drawn', break: 'broke,broken',
    spend: 'spent,spent', cut: 'cut,cut', rise: 'rose,risen', drive: 'drove,driven', buy: 'bought,bought', wear: 'wore,worn', choose: 'chose,chosen',
    seek: 'sought,sought', throw: 'threw,thrown', catch: 'caught,caught', deal: 'dealt,dealt', win: 'won,won', forget: 'forgot,forgotten', sell: 'sold,sold',
    fight: 'fought,fought', teach: 'taught,taught', eat: 'ate,eaten', drink: 'drank,drunk', sleep: 'slept,slept', put: 'put,put', show: 'showed,shown',
    fly: 'flew,flown', swim: 'swam,swum', sing: 'sang,sung', ride: 'rode,ridden', hit: 'hit,hit', hurt: 'hurt,hurt', shut: 'shut,shut', cost: 'cost,cost',
    bear: 'bore,borne', bite: 'bit,bitten', blow: 'blew,blown', bend: 'bent,bent', bet: 'bet,bet', bind: 'bound,bound', burst: 'burst,burst', feed: 'fed,fed',
    forgive: 'forgave,forgiven', freeze: 'froze,frozen', hang: 'hung,hung', hide: 'hid,hidden', lay: 'laid,laid', lend: 'lent,lent', light: 'lit,lit',
    overcome: 'overcame,overcome', shake: 'shook,shaken', shine: 'shone,shone', shoot: 'shot,shot', sink: 'sank,sunk', slide: 'slid,slid', spread: 'spread,spread',
    steal: 'stole,stolen', stick: 'stuck,stuck', strike: 'struck,struck', swear: 'swore,sworn', sweep: 'swept,swept', tear: 'tore,torn', wake: 'woke,woken',
    withdraw: 'withdrew,withdrawn', undertake: 'undertook,undertaken', arise: 'arose,arisen', forbid: 'forbade,forbidden', foresee: 'foresaw,foreseen',
    mislead: 'misled,misled', upset: 'upset,upset', quit: 'quit,quit', split: 'split,split', fit: 'fit,fit', dig: 'dug,dug', can: 'could,', will: 'would,',
    may: 'might,', shall: 'should,', must: ',', ring: 'rang,rung', sew: 'sewed,sewn', prove: 'proved,proven', tread: 'trod,trodden', weep: 'wept,wept',
    stink: 'stank,stunk', spin: 'spun,spun', 'mistake': 'mistook,mistaken', 'beat': 'beat,beaten', 'flee': 'fled,fled', 'grind': 'ground,ground'
  };
  EN.IRR = IRR;
  const DBL = new Set(['stop', 'plan', 'drop', 'admit', 'commit', 'occur', 'prefer', 'refer', 'regret', 'permit', 'control', 'submit', 'transfer', 'ship', 'chat', 'shop', 'jog', 'hug', 'rob', 'beg', 'nod', 'rub', 'skip', 'step', 'trip', 'tap', 'grab', 'wrap', 'slip', 'clap', 'travel', 'cancel', 'label', 'quarrel', 'equip', 'compel', 'expel', 'propel', 'rebel', 'omit', 'forget', 'begin', 'swim', 'run', 'sit', 'win', 'get', 'put', 'cut', 'hit', 'set', 'let', 'shut', 'quit', 'split', 'dig', 'spin', 'upset', 'bet', 'fit', 'stab', 'scan', 'ban', 'pat', 'pet', 'rot', 'sob', 'tip', 'zip']);
  // travel、cancel 是美式不重複 l：traveled、canceling
  const US_SINGLE_L = new Set(['travel', 'cancel', 'label', 'quarrel']);
  let SPEC = null;
  function specOf(lemma) {
    if (!SPEC || SPEC.n !== (EN.W || []).length) { const m = {}; (EN.W || []).forEach(e => { if (/^v/.test(e[1])) m[e[0]] = e[3]; }); SPEC = { n: (EN.W || []).length, m }; }
    return spec(SPEC.m[lemma]);
  }
  // 單一動詞的五個形：[原形, 第三人稱單數, 過去式, 過去分詞, -ing]
  function verbForms(b, sp) {
    sp = sp || {};
    const irr = IRR[b];
    const dbl = !!sp.dbl || (DBL.has(b) && !US_SINGLE_L.has(b));
    let past, pp;
    if (sp.past) { past = sp.past; pp = sp.pp || sp.past; }
    else if (irr) { [past, pp] = irr.split(','); }
    else { past = regEd(b, dbl); pp = past; }
    if (sp.pp) pp = sp.pp;
    return [b, sp.s || third(b), past, pp, sp.ing || ing(b, dbl)];
  }
  EN.verbForms = verbForms;
  function conjugate(lemma, type) {
    const words = lemma.split(' ');
    const head = words[0], rest = words.slice(1).join(' ');
    const sp = specOf(lemma);
    const f = verbForms(head, sp);
    const join = x => x ? (rest ? x.split('/').map(y => y + ' ' + rest).join('/') : x) : '';
    const forms = f.map(join);
    return {
      lemma, type, cls: type, inf: lemma, head, rest, forms,
      base: forms[0], s3: forms[1], past: forms[2], pp: forms[3], ing: forms[4],
      present: forms, presentFull: [forms[0], forms[2], forms[3]], passato: [], imperative: null,
      sep: !!sp.sep, note: sp.note || '', irregular: !!(sp.past || IRR[head]), presTab: '變化'
    };
  }
  EN.conjugate = conjugate;

  /* ---------- 名詞 ---------- */
  function plural(w) {
    if (/(s|x|z|ch|sh)$/.test(w)) return w + 'es';
    if (/[^aeiou]y$/.test(w)) return w.slice(0, -1) + 'ies';
    return w + 's';
  }
  EN.plural = plural;
  function nounForms(e) {
    const w = e[0], sp = spec(e[3]);
    if (sp.unc) return { sg: w, pl: '', plOnly: false, plGender: '-', indef: '', unc: true };
    if (sp.plonly) return { sg: w, pl: '', plOnly: true, plGender: '-', indef: '' };
    const words = w.split(' ');
    const last = words.pop();
    const pl = sp.pl || (words.length ? words.join(' ') + ' ' : '') + plural(last);
    return { sg: w, pl, plOnly: false, plGender: '-', indef: /^[aeio]|^u(?!ni|se|su|ro)|^hour|^hon/.test(w) ? 'an' : 'a' };
  }
  EN.nounForms = nounForms;

  /* ---------- 形容詞 ---------- */
  const syll = w => (w.replace(/e$/, '').match(/[aeiouy]+/g) || ['']).length;
  function adjComp(e) {
    const w = e[0], sp = spec(e[3]);
    if (sp.nocmp) return null;
    if (sp.cmp) return [sp.cmp, sp.sup];
    if (sp.more || / /.test(w) || syll(w) >= 3 || (syll(w) === 2 && !/y$/.test(w)) || /(ed|ing|ful|ous|ive|al)$/.test(w)) return ['more ' + w, 'most ' + w];
    if (sp.dbl) return [w + w.slice(-1) + 'er', w + w.slice(-1) + 'est'];
    if (/e$/.test(w)) return [w + 'r', w + 'st'];
    if (/[^aeiou]y$/.test(w)) return [w.slice(0, -1) + 'ier', w.slice(0, -1) + 'iest'];
    return [w + 'er', w + 'est'];
  }
  EN.adjComp = adjComp;
  function adjForms(e) { const c = adjComp(e); return c ? [e[0], c[0], c[1]] : [e[0]]; }
  EN.adjForms = adjForms;

  /* ---------- 斷詞 ---------- */
  const L = "A-Za-zÀ-ÖØ-öø-ÿ";
  // 縮寫（don't、it's）和連字號的字（well-known）算一個字
  const TOK_RE = new RegExp("[" + L + "]+(?:['-][" + L + "]+)*|[^" + L + "]+", 'g');
  const IS_W = new RegExp('^[' + L + ']');
  function tokenize(sentence) {
    const out = []; const s = norm(sentence); let m; TOK_RE.lastIndex = 0;
    while ((m = TOK_RE.exec(s))) out.push({ t: m[0], w: IS_W.test(m[0]) });
    return out;
  }
  EN.tokenize = tokenize;

  /* ---------- 查詢表 ---------- */
  const VDESC = ['原形', '第三人稱單數', '過去式', '過去分詞', '-ing 形'];
  function buildLookup(words, extra) {
    const map = new Map();
    const add = (form, lemma, desc, idx) => {
      if (!form || form === '-') return;
      const k = norm(form).toLowerCase();
      if (!map.has(k)) map.set(k, []);
      const arr = map.get(k);
      if (!arr.some(e => e.lemma === lemma && e.desc === desc)) arr.push({ lemma, desc, idx });
    };
    const verbAdd = (b, lemma, desc0, idx, sp) => {
      const f = verbForms(b, sp);
      const seen = {};
      f.forEach((x, i) => x.split('/').forEach(y => { if (!y) return; (seen[y] = seen[y] || []).push(VDESC[i]); }));
      Object.keys(seen).forEach(y => add(y, lemma, desc0 + seen[y].filter((v, j, a) => a.indexOf(v) === j).join('、'), idx));
    };
    words.forEach((e, idx) => {
      const [w, pos, , other] = e;
      if (pos === 'v-ph') {
        const c = conjugate(w, pos);
        verbAdd(c.head, w, '片語動詞 ' + w + ' 的', idx, specOf(w));
        c.rest.split(' ').forEach(x => add(x, w, '片語動詞「' + w + '」的一部分', idx));
        return;
      }
      if (/ /.test(w) && pos !== 'n') {
        w.split(' ').forEach(x => add(x, w, '「' + w + '」的一部分', idx));
        return;
      }
      if (/^v/.test(pos)) { verbAdd(w, w, '', idx, specOf(w)); return; }
      if (pos === 'n') {
        const f = nounForms(e);
        if (/ /.test(w)) w.split(' ').forEach(x => add(x, w, '「' + w + '」的一部分', idx));
        add(w, w, f.unc ? '不可數名詞' : f.plOnly ? '只用複數' : '單數', idx);
        if (f.pl) { add(f.pl.split(' ').pop(), w, '複數', idx); add(f.pl, w, '複數', idx); }
        return;
      }
      if (pos === 'adj') {
        add(w, w, '原級', idx);
        const c = adjComp(e);
        if (c && !/ /.test(c[0])) { add(c[0], w, '比較級', idx); add(c[1], w, '最高級', idx); }
        return;
      }
      add(w, w, '', idx);
      if (other && other !== '-' && !/=/.test(other)) other.split('/').forEach(x => add(x, w, '', idx));
    });
    // 基本字（只供點字查詢，不出題）：[原形, 詞性, 中文, 其他形或規格]
    (EN.BASIC || []).forEach(b => {
      const [w, pos, zh, more] = b;
      if (pos === 'v') { verbAdd(w, w, zh + '：', -1, spec(more && /=/.test(more) ? more : '')); return; }
      add(w, w, zh, -1);
      if (pos === 'n' && !/unc/.test(more || '')) add(more && !/=/.test(more) ? more : plural(w), w, zh + '（複數）', -1);
      else if (pos === 'adj' && more && !/=/.test(more)) more.split('/').forEach((x, i) => add(x, w, i ? '最高級' : '比較級', -1));
      else if (more && !/=/.test(more)) more.split('/').forEach(x => add(x, w, zh, -1));
    });
    if (extra) for (const k of Object.keys(extra)) add(k, extra[k][0], extra[k][1], -1);
    return map;
  }
  EN.buildLookup = buildLookup;

  // 英式、美式拼法都算對
  const UKUS = s => s.replace(/our(s|ed|ing|ite|able)?\b/g, 'or$1').replace(/is(e|ed|es|ing|ation|ations)\b/g, 'iz$1').replace(/tre\b/g, 'ter').replace(/tres\b/g, 'ters')
    .replace(/ll(ed|ing|er)\b/g, 'l$1').replace(/ogue\b/g, 'og').replace(/ence\b/g, 'ense').replace(/yse(d|s)?\b/g, 'yze$1');
  function checkAnswer(input, answer) {
    const clean = x => norm(stripAccents(String(x))).trim().replace(/\s+/g, ' ').replace(/[?!.,]$/g, '').toLowerCase();
    const a = clean(input), b = clean(answer);
    if (!a) return 'wrong';
    if (a === b) return 'ok';
    if (UKUS(a) === UKUS(b)) return 'ok';
    return 'wrong';
  }
  EN.checkAnswer = checkAnswer;

  /* ---------- 單字頁的變化表（給 App 用） ---------- */
  EN.VERB_TABLE = true;
  EN.formsTable = function (e) {
    if (/^v/.test(e[1])) {
      const c = conjugate(e[0], e[1]);
      const rows = [['原形', c.base], ['第三人稱單數', c.s3], ['過去式', c.past.replace('/', '／')], ['過去分詞', c.pp.replace('/', '／')], ['-ing 形', c.ing]];
      return { head: null, rows, note: c.irregular ? '不規則動詞：過去式、過去分詞要背。' : '' };
    }
    if (e[1] === 'n') {
      const f = nounForms(e);
      if (f.unc) return { rows: [['單數', e[0]]], note: '不可數名詞：沒有複數，前面不加 a／an。要說數量用 some、much、a piece of…' };
      if (f.plOnly) return { rows: [['複數', e[0]]], note: '這個字只用複數形。' };
      return { rows: [['單數', f.indef + ' ' + e[0]], ['複數', f.pl]], note: spec(e[3]).pl ? '不規則複數。' : '' };
    }
    if (e[1] === 'adj') {
      const c = adjComp(e);
      if (!c) return { rows: [['原級', e[0]]], note: '這個字通常沒有比較級。' };
      return { rows: [['原級', e[0]], ['比較級', c[0]], ['最高級', 'the ' + c[1]]], note: spec(e[3]).cmp ? '不規則比較級。' : '' };
    }
    return null;
  };
  EN.formsLine = function (e) {
    if (/^v/.test(e[1])) { const c = conjugate(e[0], e[1]); return c.irregular ? [c.base, c.past, c.pp].join(' – ') : ''; }
    if (e[1] === 'n') { const f = nounForms(e); return f.unc ? '不可數' : f.plOnly ? '只用複數' : spec(e[3]).pl ? '複數：' + f.pl : ''; }
    if (e[1] === 'adj') { const c = adjComp(e); return c && spec(e[3]).cmp ? c.join(' – ') : ''; }
    return null;
  };
})(typeof window !== 'undefined' ? window : globalThis);
